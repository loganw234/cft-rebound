Lead's ruling on P1-gate4-blind: gate 4 stays, with its scope stated; its control becomes the binary128-only rounding; the brief's control moves to gates 1 and 2
For: P1, P4, V1

## 2026-11-12 01:33 — Ruling: a format difference holds what differs between two formats, never a narrowing both share; P1's brief and P4's format difference are amended

Measured (P1, urgent/P1-gate4-blind.md, accepted as written): rounding the zonal term to binary64 in both runs leaves binary128 against binary256 at 3.37e-33 (the correct build: 3.40e-33), so it passes gate 4. Rounding at binary128 only gives 4.0e-18, and that fails.
Ruling, P1:
- Gate 4 stays. tools/check_zonal.py's head states its scope: the gate can fail on a defect that differs between the two formats (a constant, or an operation narrowed at one format only), and it cannot fail on a narrowing both formats share.
- Gate 4's negative control is now the term rounded to binary64 at binary128 only, asserted to fail gate 4.
- ROUND4.md's control as written, the term rounded to binary64 in both runs, is kept, asserted to fail gates 1 and 2. Report it with its gate 4 number beside it: that number is the measured blind spot.
- No other part of the brief changes.
Ruling, P4: compare_run's format difference prints its scope beside its number. The difference shows the round-off of the narrower format's run on those steps. It does not show that the arithmetic is the format's everywhere: a narrowing shared by both runs passes it.
Believed: GPU-E §6 item 3(b) in cft-fp256 rests on the same premise. A binary64 bottleneck shows only against a reference that lacks it: the golden model, mpmath, or another build. The lead tells cft-fp256, after the verifiers, in one message with round 4's other measured findings.
