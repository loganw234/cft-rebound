You are parcel **P4** of round 4 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `9a42b1d` (main, where round 4's P0 landed; branch `round4-p0` points at it too). **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 9a42b1d` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. At binary64 it is bit-identical to REBOUND. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) builds on the CPU what a GPU run will be held to. A later GPU run will write this tree's own record format for 17,544 waves of a Saturn ring. Your parcel is the driver that holds such a run against this tree.

## Start here

1. `ROUND4.md`, all of it, then its **P4** section, which is your job's definition.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1. **Its canonical failure is exactly your risk:** a gate driving a stand-in, its tests never pointed at the real thing.
3. The record format, from its writer: src/ias15_cft.c's `main()`, from `# cft-rebound ias15 record v1` and `# cft-rebound ias15 ensemble record v1` to the trailer.
   - The `# program=` line carries the run's arguments, and tools/check_records.py reads it back as exactly that.
   - Each system's `# system s steps_done=... steps_rejected=... mean_pc_iterations=...` line is in an ensemble's trailer.
   - The sample columns are named in the `# columns:` line.
4. tools/check_ensemble.py, which already compares an ensemble's members with `--member k` runs, bit for bit, and tools/check_records.py. Reuse their parsing by import where you can, rather than writing it again. If either has to change, that is a shared file: say so in the ledger first.
5. tools/compare_formats.py, for the difference between two formats on the same steps.
6. `CLAUDE.md`.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there at your three moments. Append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P4.md`, and anything that must not wait as `urgent-P4-<slug>.md` there. **Arm the watcher on `.ledger\urgent\` first.**

## Your job

`tools/compare_run.py` takes a run's record (an ensemble's, or one system's), the problem file it ran, and this tree's `ias15_cft`.
1. **It samples members:** seeded, and stratified by member index. P2's generator sorts waves by radius, so the index is radius. It also takes every member whose trailer shows a rejected step.
2. **It reruns each sampled member** here, as `--member k`, with the record's own arguments.
3. **It reports each one** as identical or not, by name and first differing line. Beside the bits go the physics counters:
   - steps, rejections and mean passes, from the member's trailer;
   - the closest approach of each test particle to each massive body, **at the samples**, and labelled so;
   - on request, the format difference: the member rerun at a second format on the same steps (`--dt-out`, then `--dt-file` with `--epsilon 0`).

**The driver reads only the record format, never ias15_cft's internals.** A GPU engine that writes the same records is then held without changing the driver. The lead owns the test that points the driver at the first GPU run.

**Particles.** P3 is building, in parallel, a replay of one particle out of its wave. Leave a clearly named place for it, and **do not fake it**.
- While P3's tool is absent, the driver prints `particles: not sampled (no particle replay in this tree)`, and your gate asserts that line.
- The lead's P3 x P4 seam test fills that place.

## What reading the code already turned up - verify it, do not trust it

- **The ensemble record's sample lines carry the system index first:** `system s sample step t dt_next dt_last E`, then six values a body. A `--member k` run's lines are the same without the system field. check_ensemble.py does exactly this comparison; read how before you write it again.
- **`--dt-out` is one system only.** For an ensemble, use `--member`.
- **The problem file's path is not in the record.** `problem=` is the problem's `name` line. So the driver takes the file as an argument, and asserts the name matches.
- **A record written by another format or arithmetic** must be refused by name, never compared as if it were comparable.

## The gate (tools/check_compare_run.py; one leg, in `check`, `check-quick` and `check-light`, with every executed artifact an `--input`)

- **The driver on a small ensemble run of this tree** reports every sampled member identical, with its counters. Build the ensemble with make_ensemble.py, or hand-make a small one with test particles (`active`, P0's).
- **The particles line is asserted,** as above.
- **Negative controls,** each permanent in the gate, because a driver that cannot fail is the failure this parcel exists to prevent. Each case asserts the driver reports FAIL with the name in it:
  - one byte changed in one member's sample line: FAIL, naming that member and line;
  - one member's lines missing from the record: FAIL, naming it;
  - a record from another format, or another arithmetic: refused by name;
  - a different problem file under the record's name: refused by name.

## Files you own

- tools/compare_run.py and tools/check_compare_run.py, both new;
- one leg in each of the Makefile's three tiers.

## Files you must NOT touch

- **Everything under src/:** P1's and P3's right now.
- **Other parcels' tools:** P2's tools/make_ring.py and tools/check_ring.py; P3's tools/check_replay.py and tools/extract_particle.py; P1's tools/check_zonal.py.
- **tools/check_ensemble.py and tools/check_records.py are existing legs.** Import from them; do not change them without saying so first.
- **Integrator-only:** README.md, ROADMAP.md, CLAUDE.md, docs/VALIDATION.md, docs/HARDWARE.md, PARCELS.md, ROUND3.md, ROUND4.md, third_party/MANIFEST.
- Anything outside your worktree. `C:\Users\logan\source\repos\cft-fp256` is read only, and `C:\Users\logan\source\repos\cft-rebound-r4` is the lead's.

## Building and testing on this host

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.
- Run your gate and `make check-light` while you work.
- Before you report, run a full `make check` in the background, started from PowerShell: `Start-Process -FilePath "C:\Program Files\Git\bin\bash.exe" -ArgumentList "<your script.sh>" -WindowStyle Hidden -PassThru`. Spell TMP and TEMP out as the Windows directory inside that script.
- **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **Nothing compares the trailer for you.** Whatever you rely on there, you assert.
- **Bit-identity is not validity.** The counters go beside the bits.
- **A gate that cannot fail is not a gate.**
- **Derive; never transcribe.** Column positions come from the record's own `# columns:` line.
- **Label every claim** as MEASURED or BELIEVED.
- **Never bare `git stash`.** No WSL, no GPU, no card. **No speed claims.**

## Do not

- push, merge or rebase, or commit to main. Commit inside your worktree only.
- fake the particle sampling.
- "fix" anything outside your scope. Report it instead.

## Report

- what changed, file by file;
- the gate output, as **actual lines**;
- the controls, with their results;
- what you did not do;
- **anything you found that this brief or ROUND4.md got wrong.**

If something makes the approach unworkable, stop and report it.
