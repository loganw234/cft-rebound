You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) adds a second: what it builds is held by physics, not only by bits, because a GPU wave will later be held to it. **That is what this is about: whether a change just weakened either.**

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail ("inert by construction", or one that passes against itself);
- bit-identity taken for validity.

## What to verify

Commit `569ee4e`: parcel **P3** of round 4, which claims:
- **`--attempts-out FILE`** writes an attempts record. It holds `# cft-rebound attempts v1`, `# run <the run's key>` and a legend, then one line per attempt, `<dt as exact hex> a` or `<dt> r`, and last `<dt> next`. It covers one system only, and an ensemble is refused by name.
- **The replay.** `--dt-file` recognises the attempts form by its first line and replays it.
  - The recorded outcome is taken in place of `choose_timestep()`'s, and on a recorded rejection x, v and a are restored.
  - The `er`/`br` prediction after a rejection is the shared code.
  - An old dt file reads exactly as before.
- **The key.** `sched_key()` hashes the outcomes with the dts under the attempts form and names it `dt_file=attempts`. It adds no field, and no older key moves.
- **`--run-key`** prints the run's key and exits before it opens any file.
- **`tools/extract_particle.py`** (new) builds the particle's sub-system.
  - It writes the wave's `G`, `active` and `zonal` lines and its first N_active body lines, verbatim and in order, then body J.
  - It re-keys the wave's schedule with the program's own `--run-key`, after asserting that both records' `# run` lines are the wave's key, that both records hold the same number of attempts, and that the sub-system's lines are the wave's.
  - It refuses by name a body that is not a test particle, a wave with no `active` line, and a zonal body at or past N_active.
- **`tools/check_replay.py`** (new) is the gate.
  - It runs three hand-made waves. A has no rejection. B starts from a first dt far too large and rejects its first attempt. C has a flyby past Janus and rejects only after accepted steps.
  - All three run at fp64, fp128 and fp256. B and C also run on the FMA form and the program engine.
  - Each sampled particle, replayed alone, matches the wave in the particle, all 7 massive bodies, t, both dts, E, the exact-time pair and every counter.
  - The program or the tool refuses by name another wave, a changed massive body, and swapped outcomes.
- **Finding (MEASURED, the parcel's):** a rejection after an accepted step leaves no state bit; only a rejection before the first accepted step marks the bits.
- **Suites (the parcel's):** the full `make check` on 569ee4e gave rc 0, 20 legs, 0 FAIL, with every existing leg's ok count equal to P0's and check_corrector at 278 ok. `make check-light` on 60457ce gave rc 0.
- **Controls (the parcel's):**
  - an accepted attempt's dt moved by one ulp: FAIL at every format;
  - a rejected attempt deleted: the bits differ when it was the first attempt; otherwise only the counters differ;
  - the prediction after a recorded rejection taken as after an accepted step: FAIL at every format, engine and form.
- **Files:** src/ias15_cft.c (+155/-4), tools/extract_particle.py and tools/check_replay.py (new), and the Makefile.

Read `git show --stat 569ee4e`, the diff, and the **P3** section of `ROUND4.md`, which is its brief. The parcel's final report is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\P3-report.md`; its brief as dispatched is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\briefs\filled\P3.md`; its ledger entries are `C:\Users\logan\source\repos\cft-rebound\.ledger\P3.md`. Read the lead's file (`lead.md`) there too, but **do not read the other parcels' files**: you are paid for independence.

You are in an isolated worktree. First `git checkout --detach 569ee4e`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, then verify each pin's HEAD against `third_party/MANIFEST`:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree and run the gate yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` (read it, never write it) or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it after the merge. Run the parcel's own gate, the legs it touches, and `make check-light` if you can, all in the background.

## Specific things to attack

1. **Rejected attempts.** Does the attempts record carry every attempt, with its dt, outcome and passes? On a recorded rejection, does the replay take the same restore and the same prediction from er and br, with the same ratio? Verify by measurement on a wave that rejects (count its rejections), not only by reading.
2. **The run key.** Does it still refuse another wave, other massive bodies, and an old single-system schedule replayed into a sub-system? Does an existing schedule recorded at `9a42b1d` replay unchanged at `569ee4e`? Measure it: record at the base, replay at the commit.
3. **The massive bodies.** Does the gate compare every massive body at every sample, not only the particle? Build the control with a "test" particle given a tiny mass, and show the gate fails on the massive bodies.
4. **Body order.** Is the sub-system's order (massive bodies first, same order, then the particle) asserted?
5. **`--dt-out`'s existing format.** Is it unchanged byte for byte? Committed CSVs in results/ were produced from it.
6. **check_corrector.py.** Does it still pass? If its matches changed, were they only the refusal text P3 changed?
7. **The controls move a dt or remove a rejection, not a count** (entry 41). Re-run two.
8. **Scope in src/ias15_cft.c.** List every hunk of `git diff 9a42b1d 569ee4e -- src/ias15_cft.c`, and say which owned region each lies in: the dt record's writer and reader, the step loop's replay branch, `sched_key()`, or option parsing. P3 says it also added usage lines and a head-comment paragraph. Anything outside the owned regions is a finding.
9. **"No older key moves."** Measure it. Print the run key (the schedule's `# run` line from `--record-iters`) at 9a42b1d and at 569ee4e, for the accepted-steps dt-file form and for no dt file, on several problems and formats. Report whether the bytes are identical.
10. **"A rejection after an accepted step leaves no state bit."** Attack it on a wave of your own making, not the gate's: at binary256 on the program engine, and at binary64 in the FMA form.
11. **"`--run-key` opens no file."** Point `--attempts-out`, `--dt-out` and `--record-iters` at existing files, run a `--run-key` call, and confirm each file is unchanged afterwards.

The items every verifier checks:

- **The untouched path must be untouched.** Verify it **by measurement, not by reading**. The records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between `9a42b1d` and `569ee4e`. Build the base in a directory of your own. Run tools/check_records.py at `569ee4e` and report its result lines.
- **Re-run at least two of the parcel's negative controls,** independently and from copies. Pick the most load-bearing, and confirm each fails where claimed.
- **Scope.** Check `git diff --stat 9a42b1d 569ee4e` against the brief's "Files you own". Anything outside it is a finding, even if it looks correct.
- **Claims in comments and the commit message.** A sentence that asserts a property, such as "exact", "cannot happen", "derived" or "byte for byte", is checked with the bytes.
- **The usual shapes:** an assertion loosened; a tolerance where exactness was required; a case that cannot fail; a constant transcribed rather than derived; a TODO where work was claimed.
- **Anything else.** Tell me what I did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,500 words.
