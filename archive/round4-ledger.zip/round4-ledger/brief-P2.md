You are parcel **P2** of round 4 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `9a42b1d` (main, where round 4's P0 landed; branch `round4-p0` points at it too). **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 9a42b1d` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. At binary64 it is bit-identical to REBOUND. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) builds on the CPU everything a GPU wave will later be held to: a Saturn ring, one 64-body wave a system (Saturn, six moons, 57 test particles), each wave on its own adaptive step. Your parcel makes that ring exist and run, and **it must be held by physics, not only by bits**.

## Start here

1. `ROUND4.md`, all of it, then its **P2** section, which is your job's definition.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`, §1 and §5.
3. The problem grammar: the comment above `read_problem()` in src/ias15_cft.c lists every line. P0 added `active n` (built) and `zonal k R J2 J4` (refused by name until P1).
4. The generators you will sit beside: tools/make_problems.py, tools/make_nbody.py and tools/make_ensemble.py, for how problem files are written (hex floats, exact). The gates you will model on: tools/check_ensemble.py (an ensemble against `--member` runs, bit for bit) and tools/check_program_engine.py (the program engine against the loop engine).
5. The study the ring comes from: `C:\Users\logan\source\repos\cft-fp256\docs\studies\GPU-E-mi300x-ring.md` (read only), §3 (steps an orbit) and §4 (Saturn, the rings, the moons, with sources).
6. `CLAUDE.md`: how to build on Windows, the suite tiers, and the traps.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there before you start, again before you design anything this brief calls shared or forbidden, and again before your report. You can read it but not write it: append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P2.md`. Anything that must not wait goes in the same drop as `urgent-P2-<slug>.md`. **Arm the watcher on `.ledger\urgent\` first** (the README has the loop).

## Your job

Write two things:
- **`tools/make_ring.py`.** It writes ring problems: Saturn with its zonal line, six moons and test particles, as one system or as an ensemble of 64-body waves (7 massive bodies, then 57 particles). The particles are sorted by radius before they are cut into waves, every value is exact hex, and the same arguments always give the same bytes.
- **`tools/check_ring.py`, and its leg.** It runs those problems at every format and holds them to bits and to physics.

## What reading the code already turned up - verify it, do not trust it

- **The format.** A problem file is `name`, `G`, `N`, `E`, `system NAME` and `body NAME m x y z vx vy vz`, every number a hex float.
  - An ensemble needs an `N` line, and every system has exactly N bodies. So **the particle count must be a multiple of 57**.
  - `active 7` makes bodies 0-6 of every system massive. Saturn and the moons come first, in every system.
  - A run's record says `# active 7 of 64 bodies a system: 420 pairs a force evaluation, a system`. That count is derived from the engine's own loops.
- **Units:** km and s, G = 1, masses as GM in km^3 s^-2.
- **Saturn and the moons, from the study's §4.** Those values are READ there, from NASA's and JPL's pages and Cassini's field; the study lists the sources. Cite them from the study, and use no web page of your own.
  - Saturn: GM 37.931e6; equatorial radius 60,268 km; J2 16,290.573e-6 and J4 -935.314e-6 (Cassini).
  - The study's J4 table states no reference radius; it BELIEVES 60,330 km. Put that pair in the zonal line, and say so in the file's head.
  - The moons, by GM, a (km) and e: Mimas 2.50349, 186,000, 0.020; Pan 0.00028, 133,600, 0; Prometheus 0.01071, 139,400, 0.002; Pandora 0.00926, 141,700, 0.004; Epimetheus 0.03514, 151,400, 0.020; Janus 0.12662, 151,500, 0.007.
  - The annulus is 130,000 to 142,000 km.
- **The moons' phases and inclinations are synthetic:** fixed, documented values, not an epoch's. That is ROUND4.md's decision 5, and it keeps this parcel off the web. The inclinations are small and **not zero**.
- **Epimetheus and Janus are co-orbital,** with a 100 km apart. Synthetic phases that put them near each other start a close encounter. Keep them far apart in longitude.
- **Pan, Prometheus and Pandora lie inside the annulus.** A particle started within a few Hill radii of a moon (Pan's is about 18 km, Prometheus's and Pandora's about 60) makes that wave's steps collapse. Exclude such starts, say by how much, and count the exclusions.
- **Particles go on near-circular orbits** at the circular speed in the oblate field, the speed with J2 and J4 at their radius in the equatorial plane. Their inclinations are small and **not zero**, and their radii and phases come from a seeded generator.
  - Python's float `+ - * /` and `math.sqrt` are correctly rounded binary64; `math.sin` and `math.cos` are not guaranteed to be. Use mpmath for trigonometry, rounded once to binary64, so the file is the same on every host. That is BELIEVED; the check across hosts waits for a WSL slot. mpmath 1.3.0 is in the Windows Miniconda Python.
- **The frame:** the barycentre of the massive bodies, applied to every body.
- **The zonal line is refused until P1 lands.** The generator writes it unless `--no-zonal`, and **your gates use `--no-zonal`**. P0 owns the refusal's case and P1 replaces it; the lead's P1 x P2 seam test runs your ring with the line.
- **Cost.** At 64 bodies the engine computes all 2,016 pairs and folds only the 420 the rows need. A binary64 step at 64 bodies took about 0.9 s on this host in round 3, in REBOUND's form, and binary128 and binary256 cost more. Keep the leg to a few minutes at full scale, and say what `check-quick` and `check-light` run.

**The trap that would be a silent wrong answer: a flat ring.** With every particle and moon in the equatorial plane, every z term of J2 and J4 is exactly zero, and P1's z terms would pass every ring run untested. Your rings must not be flat, and one of your physics counters says so: the largest |z| in a wave, asserted above zero.

## The gates (tools/check_ring.py; one leg, in `check`, `check-quick` and `check-light`, with every executed artifact an `--input`)

- **Determinism.** The generator run twice gives the same bytes, and a different seed gives different ones.
- **Engines.** One wave at binary64, binary128 and binary256: the loop and program engines in the FMA form agree bit for bit, and the loop engine runs it in REBOUND's form.
- **The ensemble.** Each member of an ensemble of k waves gets the bits it gets alone (`--member`).
- **Test particles are inert on the real problem.** `active 7` against all 64 bodies active gives the same bits, at every format.
- **Physics counters, each printed beside the bits and asserted:**
  - 420 pairs a force evaluation, from the record's line;
  - the moons act: the wave with its moons' masses set to zero differs from the wave with them;
  - no particle leaves the annulus or reaches Saturn;
  - a wave's largest |z| is above zero;
  - a wave far from the moons takes within 10% of 36.2 steps an orbit at epsilon 1e-9. That figure is the study's, MEASURED on a circular orbit about a point mass; a miss is a finding to report, not a bound to loosen.

## Negative control

Build it from a **copy**, run it, confirm it fails, delete it, and report both results with their numbers: in a copy of an ensemble, move one particle's starting x by one ulp. The ensemble-against-member comparison must fail for that member, and only for it.

## Files you own

- tools/make_ring.py and tools/check_ring.py, both new;
- one leg in each of the Makefile's three tiers.

## Files you must NOT touch

- **Everything under src/.** P1 is editing src/ias15_zonal.inc and src/ias15_cft.c's zonal lines. P3 is editing src/ias15_cft.c's dt record, replay branch and run key. If the ring needs an engine change, say so in the ledger at once.
- **Other parcels' tools:** P1's tools/check_zonal.py and data/problems/zonal_*.txt; P3's tools/check_replay.py and tools/extract_particle.py; P4's tools/compare_run.py.
- **Integrator-only:** README.md, ROADMAP.md, CLAUDE.md, docs/VALIDATION.md, docs/HARDWARE.md, PARCELS.md, ROUND3.md, ROUND4.md, third_party/MANIFEST.
- Anything outside your worktree. `C:\Users\logan\source\repos\cft-fp256` is read only, and `C:\Users\logan\source\repos\cft-rebound-r4` is the lead's.

## Building and testing on this host

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional: without it, bare `cc` is the 32-bit toolchain.
- No `make -j` in a fresh tree.
- Run your gate and `make check-light` while you work.
- Before you report, run a full `make check` in the background. It took 2 h 36 min on 2026-11-06 and runs longer on today's shared, fully loaded host. Start it from PowerShell, with `Start-Process -FilePath "C:\Program Files\Git\bin\bash.exe" -ArgumentList "<your script.sh>" -WindowStyle Hidden -PassThru`, and spell TMP and TEMP out as the Windows directory inside that script.
- **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **Bit-identity is not validity:** print the physics beside every comparison, and assert it.
- **A gate that cannot fail is not a gate.**
- **Derive; never transcribe.** Read the 420, and the steps, from the record. Never type them into the check.
- **Label every claim** as MEASURED or BELIEVED.
- **The `--light` scaling rules** are in CLAUDE.md: say which kind each case is.
- **Never bare `git stash`.** No WSL, no GPU, no card, no network. **No speed claims.**

## Do not

- push, merge or rebase, or commit to main. Commit inside your worktree only.
- commit large generated problem files. Generate them into the build directory, as check_gravity.py does for its n-body problems.
- "fix" anything outside your scope. Report it instead.

## Report

- what changed, file by file;
- the gate output, as **actual lines**;
- the control, with its numbers;
- every constant the generator uses, with its source;
- what you did not do;
- **anything you found that this brief or ROUND4.md got wrong.**

If something makes the approach unworkable, stop and report it.
