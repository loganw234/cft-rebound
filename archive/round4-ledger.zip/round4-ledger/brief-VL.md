You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. Round 4 (ROUND4.md) adds a second invariant: what it builds is held by physics, not only by bits.

**What you verify is the round's lead's own work.** Each of the four parcels (P1-P4) had its own verifier. The lead then merged them and wrote the seam tests and fixes below, and **no verifier has looked at those**. That is the gap you close.

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail (inert by construction, or passing against itself);
- bit-identity taken for validity.

## What to verify

Branch `round4-int5` at commit `e5636a9`, in the repository `C:\Users\logan\source\repos\cft-rebound` (worktrees share its branches). Its history from `9a42b1d`, the base with P0, alternates parcel merges with the lead's commits:

- `4dd53f3` Merge P1, then **`291c99c`, the lead's fix after V1's READY**:
  - read_problem() refuses a second zonal line, a fifth zonal field and a second active field;
  - tools/check_gravity.py part 2c gains those three cases;
  - src/ias15_zonal.inc's `zonal_gives()` is one predicate for the record's reaction count and zonal_apply()'s loop; the lead claims it moves no bit;
  - tools/check_scalar.py requires each CONST_FUNCS body;
  - text fixes in check_zonal.py and ias15_zonal.inc.
- `9dd4051` Merge P2, then **`ecd2b20` and `110834f`, tools/check_ring_seams.py part 1 (P1 x P2)**, a new leg in each tier. It runs a ring with its zonal line and the same file with the line deleted:
  - **without the line:** each particle moves outward as an orbit of eccentricity delta = 3/2 J2 (R/r)^2 - 15/8 J4 (R/r)^4, within 10% of delta r (1 - cos M);
  - **with the line:** each particle stays circular to 1e-3 of that;
  - **a permanent control:** J4 zeroed;
  - **the node counter:** each particle's node regresses at n - nu (first order in J2 and J4) to 0.5% over ten orbits, and the theory without J4 misses by at least five times as much;
  - **bits:** the engines, `active 7` against every body active, and an ensemble against its waves.
- `801e2be` Merge P4, then **`7d50392`, the lead's hardening of P4's control a5**: one planted field in every body, not only the last.
- `7ece3e3` Merge P3, then:
  - **`acf9fff`, check_ring_seams part 2 (P2 x P3, P1 x P3):** P2's generated waves with P1's zonal line; particles replayed out of them through P3's extract() at three formats, first-attempt rejections included; a control that deletes the zonal line from one sub-system.
  - **`e5636a9`, the P3 x P4 seam:** tools/compare_run.py's sample_particles() is wired to P3's replay. Each rerun member's rerun writes its attempts record and schedule. Two particles a member (its least closest approach at the samples, and one by the seed) are replayed alone and held to the RECORD's lines. tools/check_compare_run.py asserts the picks, and new control p plants a digit in a sampled particle and in the primary.

The lead's reasoning and measurements are in the ledger: `C:\Users\logan\source\repos\cft-rebound\.ledger\lead.md`, the entries from 2026-11-12 03:00 on. Each commit message states its claims; read them with `git log --format=%B 9a42b1d..e5636a9`. Do not read the parcels' own files in the ledger.

You are in an isolated worktree. First `git checkout --detach e5636a9`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, with plain separate commands for each pin (a compound shell loop may be refused). Then build:

```bash
git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/rebound third_party/rebound
git -C third_party/rebound checkout --quiet bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93
git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256 third_party/cft-fp256
git -C third_party/cft-fp256 checkout --quiet 922c2ade78fad995a0871bf07cebf8b9fbcb2b9f
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```
Check each pin against third_party/MANIFEST. The PATH line is not optional: without it, bare `cc` is the 32-bit toolchain. No `make -j` in a fresh tree. The binaries need the PATH line to run, too. To compile a control from a Python script, name the compiler by its full path (C:\msys64\mingw64\bin\gcc.exe).

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree, and run the gates yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` itself (read it, never write it), `C:\Users\logan\source\repos\cft-rebound-r4` or `C:\Users\logan\source\repos\cft-rebound-seam` (the lead's; a full suite runs there), or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`: the lead runs it after each merge. Run the gates these commits touch, in full, and `make check-light` if you can, all in the background. The host is shared and loaded, so expect long times.

## Specific things to attack

1. **291c99c's refusals.** Could any valid problem file now be refused? Try trailing whitespace, CRLF line endings, and every problem in data/problems/. Is `zonal_gives()` really bit-neutral? Measure: --zonal-selftest at every format, and data/problems/zonal_saturn.txt at three formats on both engines and forms, at 22ca3de's build against e5636a9's, timing masked. Do the new check_gravity cases fail on a build without the refusals?
2. **Seam part 1's physics.** Derive the no-line excursion delta r (1 - cos M) and the n and nu expressions yourself; are they right to the order used? Does each bound mean what its comment says? Build controls from copies of src/ias15_zonal.inc and show the part fails:
   - J2's radial force scaled by 1.01: the circularity check must fail;
   - J4's z part dropped: the node counter must fail, or say why it cannot;
   - the z sign of the force flipped.
   Is the node fit robust? Could short-period terms or the moons fake a pass?
3. **Seam part 2.** Re-run one replay by hand from the commit's description. Does P3's imported compare() compare every value? Does the zonal-line control really bite through the bits, and not only through the key?
4. **a5's hardening.** Is every body now covered? Run a mutant of compare_run.py that skips body 1, or any middle body, and show it fails.
5. **The P3 x P4 wiring.**
   - Does writing --attempts-out and --record-iters in the rerun move any record line? Measure it.
   - Is the replay held to the record and not to the rerun? Make a mutant that compares the replay against the rerun's output, and show control p fails it.
   - Is the least-closest-approach pick right?
   - Is a member whose rerun FAILed still sampled?
   - Are the not-callable states (an empty stand-in, check_replay.py alone) caught?
   - Is anything claimed that is not built, such as producer attempts records?
6. **The merge resolutions.** For 4dd53f3, 9dd4051, 801e2be and 7ece3e3, and the cherry-pick behind acf9fff:
   - Was each conflict resolved with both sides kept and nothing lost?
   - Diff each merge against both parents in the conflicted files, and confirm each tier's leg list is the union of its parents'.
   - Does every tier list the same 24 legs?
7. **The untouched path.** Records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between 9a42b1d and e5636a9, timing masked. Run tools/check_records.py at e5636a9 and report its result lines.
8. **Anything else.** Tell the lead what it did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,800 words.
