You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) adds a second: what it builds is held by physics, not only by bits, because a GPU wave will later be held to it. **That is what this is about: whether a change just weakened either.**

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail ("inert by construction", or one that passes against itself);
- bit-identity taken for validity.

## What to verify

Commit `517e8d5`: parcel **P4** of round 4, which claims:
- **`tools/compare_run.py`** (new) takes a record, `--problem FILE`, `--format F` and `--arith A`, all required, and this tree's ias15_cft.
  - It reads only the record format, streaming the record twice.
  - It imports `check_ensemble.parse()`, `check_records.header_args()` and `check_equivalence.hex_to_fraction()`; neither of the first two files was changed.
  - It takes columns from the record's own `# columns:` line.
- **It refuses by name (rc 2), before comparing anything:**
  - a file that is not a record; a header missing a field the rerun needs; a record run from a dt file;
  - a record of another format or arithmetic than `--format`/`--arith`;
  - a problem file that is not the record's: its name, N, E, G, system names, every body's name and mass, the `active` line, and every system's sample 0 against its initial state;
  - a rerun whose own header is not the record's run, field by field.
- **It fails by member and name (rc 1):** a member missing or incomplete, checked for every member, sampled or not; a sampled member's first differing line, with line, sample, step, column and both hex values; and its trailer counters against the rerun's, with the rejections summed against the record's total.
- **The sample:** contiguous strata of member index, one member a stratum chosen by the least SHA-256 of (seed, index), so the same on any host; every member with a rejected step is added.
- **Counters beside each verdict:** steps, rejections, mean and largest passes, and cap hits. Each test particle's closest approach to each active body, labelled "AT THE SAMPLES (not between them)".
- **`--format-diff F2`:** the member is rerun with `--dt-out`, then at F2 with `--dt-file --epsilon 0`, and measured by tools/compare_formats.py.
  - Since 517e8d5, every such line ends with the lead's ruled scope: "the difference shows the narrower format's round-off on these steps; a narrowing both runs share passes it".
  - Its note now depends on whether the member's FIRST attempt was rejected. The driver decides that by whether the dt file's first step equals the record's dt0.
- **Particles:** `sample_particles()` is the named, empty place for the lead's P3 x P4 seam.
  - It prints `particles: not sampled (no particle replay in this tree)` while neither tools/extract_particle.py nor tools/check_replay.py exists.
  - Once either exists, it prints "NOT SAMPLED, and NOT WIRED", so the gate fails until the seam is wired. This is deliberate.
- **`tools/check_compare_run.py`** (new) is the gate.
  - **The ensemble:** hand-made, 9 waves since 517e8d5, each a primary, a moon and 3 inclined test particles, under `active 2`.
  - **Its rejections:** members 0 and 1 reject their first attempt; member 8 rejects 3 attempts, only after an accepted step; the rest reject nothing. Members 0-7 are byte-identical to c640f65's 8-member record.
  - **Case 1** runs at fp64, fp128 and fp256.
  - **Cases 3 to 6:** the seeded sample; another format and arithmetic held as recorded; one-system records; the program engine.
  - **The permanent controls:** a, a2 (a byte changed), b (a trailer counter), c (a member missing), d (a record cut short), e (another format or arithmetic), f (REBOUND's record; a problem file given as the record) and g (a different problem file under the record's name, four ways).
- **Mutants (the parcel's):** 14 one-defect copies of the driver, each run through its own `check_compare_run --quick`. Every one was caught, and the unmutated copy passed.
- **The Makefile:** one `check_compare_run` leg after check_ensemble in each tier.
- **Suites (the parcel's):**
  - full make check on c640f65: rc 0, 20 legs, 907 ok, 0 FAIL;
  - make check-light on 517e8d5: rc 0, with 12 legs run and 8 skipped by the gate cache, each skip printed by name;
  - the gate on 517e8d5: full mode 54 ok, `--quick` 34 ok, PASS.
- **Files:** tools/compare_run.py and tools/check_compare_run.py (new), and the Makefile.

Read `git show --stat 517e8d5`, the diff, and the **P4** section of `ROUND4.md`, which is its brief. The parcel's final report is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\P4-report.md`; its brief as dispatched is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\briefs\filled\P4.md`; its ledger entries are `C:\Users\logan\source\repos\cft-rebound\.ledger\P4.md`. Read the lead's file (`lead.md`) there too, but **do not read the other parcels' files**: you are paid for independence.

You are in an isolated worktree. First `git checkout --detach 517e8d5`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, then verify each pin's HEAD against `third_party/MANIFEST`:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree and run the gate yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` (read it, never write it) or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it after the merge. Run the parcel's own gate, the legs it touches, and `make check-light` if you can, all in the background.

## Specific things to attack

1. **Can it pass against itself?** Trace what it compares: the RECORD's lines against a RERUN's, or a rerun against a rerun? Plant a difference in the record and confirm it is caught.
2. **Only the record format.** Does the driver read any ias15_cft internal (a debug flag, a dump) that a GPU engine's record would not have?
3. **The particle placeholder.** Is "particles: not sampled" printed and asserted? Is there anything that pretends to sample particles?
4. **The controls are permanent:** a byte changed, a member missing, another format, another problem. Does each fail by name, and is each asserted to fail?
5. **Sampling.** Is it seeded? Does it include every member with a rejected step? Is the closest approach labelled "at the samples"?
6. **Reuse.** Does it import check_ensemble.py's or check_records.py's parsing, or write it again? If again, does it agree with them on a real record?
7. **The format difference.** Is it run on the same steps, through a dt file?
8. **The scope line and the rejection note (517e8d5).** Is the ruled scope text printed on every format-difference line, and does the gate assert it? P4 says the gate states the text itself rather than reading it from the driver. Can the first-attempt test misfire, that is, can a member whose first attempt was rejected have a dt file whose first step equals dt0? Read choose_timestep's rejection path in src/ias15_cft.c to decide.
9. **Member 8's dt_next.** The gate leaves dt_next out of member 8's dt-file replay comparison, because a sample printed just before a rejected attempt carries that attempt's dt. Is the exclusion confined to that one comparison, and stated there? Could it hide a difference that matters?
10. **The P3 x P4 tripwire.** In a copy, add a file named tools/extract_particle.py (try an empty one too) and run the gate. Does the driver print "NOT WIRED" and the gate fail, so that no stub can satisfy it?
11. **Members 0 to 7 unchanged.** P4 says adding member 8 left members 0-7 byte-identical to c640f65's 8-member record. Measure it.

The items every verifier checks:

- **The untouched path must be untouched.** Verify it **by measurement, not by reading**. The records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between `9a42b1d` and `517e8d5`. Build the base in a directory of your own. Run tools/check_records.py at `517e8d5` and report its result lines.
- **Re-run at least two of the parcel's negative controls,** independently and from copies. Pick the most load-bearing, and confirm each fails where claimed.
- **Scope.** Check `git diff --stat 9a42b1d 517e8d5` against the brief's "Files you own". Anything outside it is a finding, even if it looks correct.
- **Claims in comments and the commit message.** A sentence that asserts a property, such as "exact", "cannot happen", "derived" or "byte for byte", is checked with the bytes.
- **The usual shapes:** an assertion loosened; a tolerance where exactness was required; a case that cannot fail; a constant transcribed rather than derived; a TODO where work was claimed.
- **Anything else.** Tell me what I did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,500 words.
