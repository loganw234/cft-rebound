# V4 third look at P4, commit 79bd206: READY

The two NOT READY gaps are closed, and the lead's checks (a) to (d) all confirm. One limit of the new control a5 remains; I measured it and judge it not blocking (end of report).

**Setup.** I ran `git checkout --detach 79bd206`; src/ is unchanged. Everything I edited was a copy, now deleted, and the worktree is clean. Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v4\`, as mt3.py and r3_*.log.

**(a) Diff: confirmed.** `git diff --stat f27f9c6 79bd206` shows two files: tools/check_compare_run.py (+77/−1) and tools/compare_run.py (+3). Since 9a42b1d the whole parcel is still the Makefile plus those two tools.

**(b) a5's columns are derived, not typed: confirmed by measurement.** `column_plan()` splits the record's own `# columns:` line into three parts: the fields after `sample step`, every per-body field, and every field of the exact-time pair.
- The per-body fields are planted in the last body; N comes from the `# program=` line and the body's name from the `# body` lines.
- On the real line it yields exactly the 12 claimed columns.
- I gave it a line with three columns I made up: a scalar `Lz`, a per-body `m` and a pair field `t_err`. It returned 15 columns, each at its shifted position, with no edit to the gate. So a column added to the record's format reaches a5 unedited.

**(c) Mutants, `--quick`, on copies: confirmed.**

| Mutant | Gate result |
|---|---|
| Your `rv[:-2]` (exact-time pair skipped) | RESULT: FAIL, caught by a5 alone (t_hi and t_lo reported IDENTICAL) |
| Mine: compare everything except velocities (`if a != b and not rec.cols.value_name(j, names).startswith("v")`) | FAIL, caught by a5 alone (vx, vy, vz of body 4); a, a2, a3 and a4 all pass |

So my mutant is one a5 catches and nothing earlier did.

**(d) Gate runs: confirmed.**
- **Full:** 64 ok, 0 FAIL, RESULT: PASS, in about 7 minutes.
- **`--quick`:** 42 ok, PASS.

The `--exe` fix works: a relative `build/ias15_cft.exe` with forward slashes resolves to an absolute path, and the driver passes a kepler record.

**Not blocking: a5 plants its per-body fields in the last body only.**
- **Measured:** a mutant that skips body 0's six values passes `--quick` with 42 ok. No control touches bodies 0, 1 or 3; a4 covers only body 2's x, at fp128.
- **Why it doesn't block:**
  - The shipped driver compares every body in one flat loop.
  - Unlike the pair, which `check_equivalence.parse_record` already drops, no existing code path or natural refactor skips a first or middle body.
- **Why it would matter if it happened:** the primary's coordinates are small. A last-bit difference there, such as from the zonal reaction on the primary, can stay below every other body's last bit and never show elsewhere.
- **Hardening, if wanted:** plant one field in each body as well, at the cost of at most one more record.

P4's 21 mutants: I did not re-run them.

**READY.**
