You are parcel **P3** of round 4 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `9a42b1d` (main, where round 4's P0 landed; branch `round4-p0` points at it too). **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 9a42b1d` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. At binary64 it is bit-identical to REBOUND. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) builds on the CPU what a GPU wave will be held to. A GPU run of 10^6 ring particles will be checked by sampling. Your parcel is the cheap half of that check: one particle's whole trajectory, reproduced bit for bit from its wave's record, in a system of Saturn, the moons and that particle alone.

## Start here

1. `ROUND4.md`, all of it, then its **P3** section, which is your job's definition.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`, §1 and §5.
3. docs/VALIDATION.md entry 41, round 3's P2. It built the recorded corrector schedule that `--replay-iters` replays, and found that a count moved by one is inert on most attempts. Read it before you design a control.
4. The code, in src/ias15_cft.c at your base:
   - the step loop, `step_attempt()`, and its accept and reject;
   - `choose_timestep()`;
   - the rejection path that restores and re-predicts from `er` and `br`;
   - `--dt-out`'s writer (search `fprintf(dt_out`) and `read_dt_file()`;
   - the schedule's `sched_key()`, `sched_open()`, `sched_begin()`, `sched_pass()` and `sched_end()`;
   - `main()`'s handling of `--dt-file`, which needs `--epsilon 0`, and of `--dt-out`, which is one system only.
5. tools/check_corrector.py: how the schedule's record, replay and refusals are gated today. It runs `--dt-file` with `--replay-iters` only as a refusal.
6. `CLAUDE.md`.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there at your three moments. Append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P3.md`, and anything that must not wait as `urgent-P3-<slug>.md` in the same drop. **Arm the watcher on `.ledger\urgent\` first.**

## Your job

Make a particle replay out of its wave, whatever the wave did, rejected attempts included. That takes three things:
- **An attempts record:** every attempt's dt, whether it was accepted, and its passes.
- **A replay that follows it,** rejections included.
- **A sub-system:** a tool writes the wave's massive bodies, its zonal and active lines, and particle j, with a schedule this tree accepts for it.

The gate then shows each sampled particle, and every massive body, at the wave's bits at every sample.

## What reading the code already turned up - verify it, do not trust it

- **A replay cannot reproduce a rejected step today.**
  - `--dt-out` writes only accepted steps' `dt_done`, plus one final next dt (steps + 1 lines).
  - `--dt-file` needs `--epsilon 0`, so a replay never rejects.
  - After a rejection, the next attempt restores the step's start and predicts `e` and `b` from `er` and `br`, with the ratio dt / `SDTLAST`. A replay without that attempt takes another path.
  - `--replay-iters` alone does carry rejected attempts: the schedule has a line an attempt.
  - **A finding to confirm:** a replay that knows each attempt's dt and outcome, and takes the same restore and prediction on a recorded rejection, reproduces the wave bit for bit. Check it against the code path.
- **The run key** (`sched_key()`) hashes the masses, the initial state and the dt list, with format, N, E and the run's settings. Since P0 it also names a problem's `active` and `zonal` lines when present.
  - The particle's sub-system is a different problem by construction, so its schedule is refused as "a different run".
  - Pick one way through, and say why. Either the key gains a form that names the massive bodies and the schedule and leaves the test particles out, or a tool re-keys a schedule for the sub-system after asserting that the sub-system's massive bodies, zonal and active lines are the wave's, line for line.
  - Whichever you pick, a schedule recorded for one wave must still be refused for a different wave, or for different massive bodies.
- **Why the sub-system replay can be exact** (BELIEVED, from the code): test particles add exactly +0 to every massive body's sums (P0's gate measured it on outer), and a particle's own acceleration reads only the massive bodies. With the same attempts and the same passes, the massive bodies take the same bits in both systems, and so does the particle. Your gate is what makes this MEASURED.
- **Line numbers move.** P1 edits src/ias15_cft.c's zonal lines and its `--zonal-selftest` while you work, so search by name rather than by line number.

**The trap that would be a silent wrong answer.** The massive bodies match only because test particles add exactly nothing to them. Suppose a "test" particle has a tiny mass, or the sub-system has its bodies in another order. Then the massive bodies differ, while the particle's own bits could still look right over a short run. So **the gate compares every massive body too**, at every sample, and the sub-system's body order is asserted.

## The gates (tools/check_replay.py; one leg, in `check`, `check-quick` and `check-light`, with every executed artifact an `--input`)

- **No rejections.** A small ring wave at every format: you hand-make it with `active` (P0's), since P2's generator lands in parallel. Each of k sampled particles, replayed alone, gives the wave's bits for that particle and for every massive body, at every sample.
- **A rejection.** A wave forced to reject, by a first dt far too large, passes the same test.
- **Physics counters, each asserted:** the replayed schedule's rejected attempts (above zero in the rejection case), and the particle's travel (it moved).
- **The refusals:**
  - the schedule replayed for another wave: refused by name;
  - the sub-system with a massive body changed: refused by name;
  - the old single-system replay, unchanged: its existing gate in tools/check_corrector.py still passes.

## Negative controls

Build each from a **copy**, run it, confirm it fails, delete it, and report both results with their numbers:
- one attempt's dt moved by one ulp: the particle's bits differ;
- the schedule with its rejected attempt deleted: refused by name, or the bits differ (say which);
- the replay with the rejection path's prediction taken as after an accepted step: the bits differ.

Round 3 found a pass count moved by one inert on most attempts (entry 41), so these controls move a dt, or remove a rejection, not a count.

## Files you own

- **In src/ias15_cft.c, only these:** `--dt-out`'s writer and `read_dt_file()`, or new code beside them for the attempts record; the step loop's replay branch, where a recorded rejection is taken; the run key in `sched_key()`; and the option parsing for any new flag.
- **New files:** tools/extract_particle.py and tools/check_replay.py.
- **One leg** in each of the Makefile's three tiers.

## Files you must NOT touch

- **src/ias15_zonal.inc, and src/ias15_cft.c's zonal and `--zonal-selftest` lines,** which are P1's right now. **`read_problem()`** is P0's and shared.
- **Other parcels' tools:** P2's tools/make_ring.py and tools/check_ring.py; P4's tools/compare_run.py.
- **Integrator-only:** README.md, ROADMAP.md, CLAUDE.md, docs/VALIDATION.md, docs/HARDWARE.md, PARCELS.md, ROUND3.md, ROUND4.md, third_party/MANIFEST.
- Anything outside your worktree. `C:\Users\logan\source\repos\cft-fp256` is read only, and `C:\Users\logan\source\repos\cft-rebound-r4` is the lead's.

You may make small edits to tools/check_corrector.py, and only these: if your key change alters a refusal message it matches, fix its match. Say so in your report.

## Building and testing on this host

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.
- Run your gate, tools/check_corrector.py and `make check-light` while you work.
- Before you report, run a full `make check` in the background. It took 2 h 36 min on 2026-11-06, and runs longer on today's loaded host. Start it from PowerShell, with `Start-Process -FilePath "C:\Program Files\Git\bin\bash.exe" -ArgumentList "<your script.sh>" -WindowStyle Hidden -PassThru`, and spell TMP and TEMP out as the Windows directory inside that script.
- **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **Every committed record must stay byte for byte where it is.** tools/check_records.py holds them. A change to `--dt-out`'s existing format moves committed CSVs' producers, so add a form beside it rather than change it.
- **Bit-identity is not validity.** Print the physics beside every comparison.
- **A gate that cannot fail is not a gate.**
- **Derive; never transcribe.**
- **Label every claim** as MEASURED or BELIEVED.
- **The `--light` scaling rules:** the step-sequence cases stay unscaled (CLAUDE.md). Say which kind each case is.
- **Never bare `git stash`.** No WSL, no GPU, no card. **No speed claims.**

## Do not

- push, merge or rebase, or commit to main. Commit inside your worktree only.
- change what an existing schedule or dt file means. An old file must replay exactly as before, or be refused by name.
- "fix" anything outside your scope. Report it instead.

## Report

- what changed, file by file;
- the gate output, as **actual lines**;
- each control, with its numbers;
- the key design you chose, and why;
- what you did not do;
- **anything you found that this brief or ROUND4.md got wrong.**

If something makes the approach unworkable, stop and report it.
