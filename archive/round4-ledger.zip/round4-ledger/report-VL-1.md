**VL report: the lead's round-4 commits at e5636a9**

**NOT READY.** I found one defect, and it is in a gate, not in shipped code. Everything else checks out, apart from four small text fixes.

**Setup.** I detached the worktree at e5636a9 (`git log --oneline -1`), cloned both pins locally and checked them against MANIFEST (bdfda4b…, 922c2ad…), and ran `make … all programs` with the PATH line. The build was clean apart from the usual warnings in pinned REBOUND, and `cc -dumpmachine` reported x86_64-w64-mingw32. For before/after comparisons I made `git archive` copies at 9a42b1d, 22ca3de and e5636a9 under scratch, each with its own pins and build. Every control was a copy under scratch, built with C:\msys64\mingw64\bin\gcc.exe, run, then deleted. `git status` is clean. One disclosure: `git merge-tree --write-tree` added unreachable objects to the shared object store; no ref moved.

Scripts and logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl.

### 1. 291c99c: confirmed
- **Valid files still run.** C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\variants.py took all six files in data/problems/ plus a generated one-system ring and a two-wave ring. Each was run with CRLF endings, with trailing blanks and tabs, and with both: 24 of 24 ran (rc 0) and gave the original's record, timing masked.
- **Edge cases, compared with 22ca3de.** A trailing `# comment` on the active or zonal line, and a zonal line repeated word for word, are now refused by name (22ca3de ran them). Leading blanks, `active +2`, `active 02` and an eighth field on a body line still run. No line the head comment's grammar allows is refused.
- **zonal_gives() moves no bit.** C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\cmp_records.py ran `--zonal-selftest` at all three formats, plus zonal_saturn at three formats on the loop engine (both forms) and the program engine. 22ca3de against e5636a9: 12 of 12 byte-identical.
- C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\zonal_extra.py added three cases on all three engine/forms: zonal_saturn with every body active (reaction 2), a 64-body wave with `active 7` (reaction 6), and the same wave all-active (reaction 63). 9 of 9 identical.
- **Control.** I built e5636a9's ias15_cft.c with the three `die()` lines removed and ran the tree's `check_gravity.py --quick` against it. Exactly the three new cases FAIL (rc 0, 18 ok). An unmutated copy through the same harness gives 21 ok, PASS.
- **check_scalar.** `recount()` on a source copy with `zonal_ready` renamed stops by name at e5636a9; 22ca3de's recount accepts it silently.
- **Full gates on a clean copy:** check_gravity `--library` 44 ok, check_zonal 87 ok, check_scalar `--library` 99 ok, all PASS.

### 2. Seam part 1 physics: confirmed, with two text fixes
- **No-line excursion.** A tangential start with v² = (GM/r0)(1+δ) about a point mass is a pericentre with e = δ exactly and a = r0/(1−δ). So r − r0 = δ r0 (1 − cos M)(1 + O(δ)).
  - The code takes M from √(GM/r0³) rather than from a's mean motion. That is a 1.5δM phase error, about 2% at M ≈ 4 rad, which is exactly the measured 2.0% and inside the 10% bound.
- **n and ν.** From Φ, n² = r⁻¹∂Φ/∂r and ν² = ∂²Φ/∂z² at z = 0 give exactly the stated coefficients: 3/2 and −15/8 for n², 9/2 and −75/8 for ν². n − ν → −(3/2) J2 (R/r)² n at leading order. Both are right to the order used.
- **Bounds.** Each bound tests what its verdict says.
- **Text fix 1.** Line 28's "(measured: about 3e-5)" is the `--quick` number (3.50e-5). Full mode measures 1.53e-4.
- **Text fix 2.** Line 24 says the 10% no-line check holds P2's speeds to J4. J4's share of δ is 1.4%, below that check's resolution. J4 is actually held by the with-line check together with the J4-zeroed control (18× the bound).
- **Controls.** Copies of ias15_zonal.inc were built by C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\mk_mutants.py, and the tree's `check_ring_seams.py` was run in full against each:

| Control | Result |
|---|---|
| Unmutated copy | 32 ok, PASS |
| J2's x/y factor ×1.01 | circularity FAIL, 1.17e-2 against a bound of 1e-3 |
| J4's z factor zeroed | circularity passes; node counter FAIL, 3.72e-2 against 5e-3; energy FAIL |
| z factor negated | node counter FAIL (nodes advance instead of regress, off by 3.0); energy FAIL |

- **Node fit** (C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\nodes.py, on the seam's own ring):
  - the whole run gives 8.99e-4, the gate's number;
  - each half alone gives 4.0e-3 and 3.2e-3;
  - every third sample gives 9.4e-4;
  - with the moons made massless, their share of each rate is at most 5.3e-4.
  - The leftover is short-period noise that shrinks as the span grows. It sits 31 times below J4's signal (2.8e-2), so neither it nor the moons can fake a pass of those defects. A defect smaller than about 0.4% of the rate would pass.
- **Full check_ring_seams** on the clean copy: 32 ok, PASS.

### 3. Seam part 2: confirmed
- **Replay by hand,** in a case the gate does not run: make_ring `--seed 1 --particles 114`; wave 1 at fp128 from dt 1e5 (first attempt rejected), with `--attempts-out` and `--record-iters`; extract_particle.py's command line for body 35; then the printed replay.
  - C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\byhand\cmp35.py: 406 of 406 tokens across the 7 sample lines match the wave, and so do the counters. Compared against body 36 instead, 42 of 42 differ.
- **P3's compare()** checks every token of each replay line, plus the sample count. The part adds five trailer counters.
- **Zonal-line control** (C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\byhand\nz.py): with the line deleted and the schedule re-keyed through `--run-key`, the replay runs (rc 0) and differs in 42 of 49 massive-body samples. The tool's own schedule is refused for that file (rc 3). The gate itself gives rc 0 and 64 of 72. It bites through the bits, not only through the key.

### 4. a5 hardening: confirmed
- Every body now gets one planted field (x, y, z, vx for bodies 0–3), and the last body gets all six. So every body is covered, though not every (body, field) pair.
- Mutants from C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\mk_cr_mutants.py, run through each copy's `check_compare_run --quick`:
  - skipping body 1: a5 FAILs, "NOT: y of body 1 (moon) in member 1: IDENTICAL" (43 ok, 1 FAIL);
  - skipping body 2: a5, a4 and p all FAIL.

### 5. P3 x P4 wiring: shipped code right; defect in its gate
- **The new rerun options move no record line.** C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\att_moves.py ran 30 configurations, plain against `--attempts-out --record-iters`, and against those plus `--dt-out`. They covered the gate's members 0, 1 and 8 (first-attempt and later rejections), a 64-body wave, zonal_saturn, fp64 and fp128, on three engine/forms. 30 of 30 identical.
- **Held to the record.** A mutant that holds the replay to the rerun's lines fails exactly control p's two verdicts ("0 of its 2"), with 42 ok.
- **The least-closest-approach pick is right.** C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\picks.py recomputed exact distances from the fp64 record: the pick is correct in all 6 sampled members. Note that "active body" includes the primary.
- **A FAILed member is still sampled.** Control p shows it, and so does the ring in item 8.
- **Not-callable states are caught.** Control i passes. Beyond it, C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\notcallable.py: a syntax error or `extract = None` FAILs by name (rc 1), and extract_particle.py without check_replay.py works.
- **Nothing is claimed that isn't built.** Producer attempts records are stated as not built. Two lines in compare_run.py's header are stale: "(P1's zonal line, when it lands)" and "P1's to write".
- **Defect (in the gate).** Only two of the values the particle comparison checks are held by any test.
  - A copy whose `particle_compare` checks only the particle's x and the primary's x passes `check_compare_run --quick`: 44 ok, RESULT: PASS, rc 0. That copy checks no head field, no other massive body, no exact-time pair and no trailer counter, yet still prints "N values and the trailer's counters".
  - Control p plants only x columns, and full mode plants nothing further on the particle path.
  - Failure scenario: an edit that drops the exact-time pair from `particle_compare` (V4's `rv[:-2]` shape, on the pair vaugadd produces, which G1B is expected to refuse) would ship with every gate green.
  - This is the hole V4 sent P4 back for at 04:34, now in the lead's own code.
  - Fix: apply a5's plan to a sampled particle's member line — each head field, each field of the particle and of every massive body, and the pair — plus one trailer counter, each asserted to FAIL that particle's replay by column.

### 6. Merge resolutions: confirmed
- **4dd53f3 and 9dd4051:** `git merge-tree --write-tree` reproduces both commits' trees exactly; there were no conflicts.
- **801e2be:** the Makefile had four conflict blocks. The commit is exactly "keep both sides" (ours, then theirs) and matches the automatic merge everywhere else (+14/−0 and +30/−3 against the two parents).
- **7ece3e3:** one conflict in src/ias15_cft.c (`do_zonal` beside `do_key`), resolved as keep-both; src is identical to 3b69eae.
- **Cherry-pick behind acf9fff:** check_ring_seams.py equals a clean three-way `git merge-file` of 7ece3e3, base 3b69eae and 21185e1. The patch is 21185e1's apart from context lines. The Makefile conflict took 21185e1's IN_RSEAMS and kept IN_COMPARE beside it.
- **Leg lists:** C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\legs.py checked every commit. Each merge's tiers are the union of its parents', the three tiers list the same legs in the same order, e5636a9 has 24/24/24, and every `$(IN_*)` used is defined once.

### 7. Untouched path: confirmed
- C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\cmp_records.py ran the five problems that exist at 9a42b1d (zonal_saturn came later) at fp64, fp128 and fp256 on three engine/forms, adaptive, plus fixed-step runs at fp64. 9a42b1d against e5636a9: 60 of 60 byte-identical, timing masked. kepler_e09 and kepler_e099 each reject a step, so the rejection path is included.
- `tools/check_records.py --build build` in full: nine "values identical" lines, RESULT: PASS.

### 8. Anything else
- **A combination no gate runs:** compare_run on P2's generated ring carrying P1's zonal line. Every compare_run case uses hand-made waves with no zonal line, yet that is the shape the GPU half's records will have.
  - C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\ring_driver.py: three waves at fp64 from dt 1e5 gave PASS, with 3 members and 6 particles (replayed with the zonal line) identical.
  - With one digit planted in Mimas's x on member 0's last line, the member and both its particle replays FAIL, naming line 212. So it works, but nothing gates it.
- **Inline comments** are now refused on active and zonal lines but still silently ignored on body lines. One sentence in read_problem's comment would make that explicit.
- **make check-light, cold, in the worktree:** all 24 legs ran, 890 ok, 0 FAIL, make exit 0, 63 minutes.
- **Full gates on the clean copy:** check_compare_run 66 ok and check_ring_seams 32 ok, both PASS. I stopped my optional full runs of check_replay and check_ring before they finished; both passed in check-light, and no process of mine is left running.

**NOT READY.** The one defect is item 5: the particle path's comparison is held by its gate in two values only. Everything else is confirmed. The fixes are text only: two in check_ring_seams.py's header and two stale lines in compare_run.py's header.
