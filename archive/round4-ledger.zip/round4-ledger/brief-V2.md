You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) adds a second: what it builds is held by physics, not only by bits, because a GPU wave will later be held to it. **That is what this is about: whether a change just weakened either.**

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail ("inert by construction", or one that passes against itself);
- bit-identity taken for validity.

## What to verify

Commit `250789e`: parcel **P2** of round 4, which claims:
- **`tools/make_ring.py`** (new) writes Saturn, then six moons, then test particles, as one system (`--one-system`) or as waves of 64 bodies: 7 massive, then 57 particles. Every file carries `active 7`, and `zonal 0 R J2 J4` unless `--no-zonal` is given.
  - Particles are sorted by radius, then cut into waves. A particle count that is not a multiple of 57 is refused by name.
  - Every value is computed in mpmath at 160 bits from the constants rounded to binary64, then rounded to binary64 once.
  - Orbits use REBOUND's `reb_particle_from_orbit` formulas (third_party/rebound/src/tools.c:940-997). The frame is the barycentre of the massive bodies.
  - A start within 5 Hill radii of a moon is refused and drawn again, and the file's head counts the refusals by moon.
  - Each file is circular in its own field: a point mass's speeds under `--no-zonal`, the oblate field's (J2, J4) speeds without it, for Pan too.
  - The same arguments give the same bytes, another seed gives other bytes, and mpmath's gmpy and pure-Python backends give the same bytes.
- **`tools/check_ring.py`** (new) is the gate. Its claims:
  - the loop and program engines in the FMA form are bit-identical on a wave at fp64, fp128 and fp256;
  - REBOUND's form runs the wave, differing from the FMA form at 1.7e-11 relative against a stated bound;
  - `active 7` against all 64 bodies active is identical, trailer included, with 420 against 2016 pairs read from the record;
  - `ias15_ref`, REBOUND's own IAS15, matches ias15_cft in REBOUND's form, 2716 values identical, on one all-active 64-body wave at binary64;
  - each ensemble member matches its `--member` run, at binary64 on the program engine;
  - physics counters, each asserted: the moons act, every particle stays in the annulus and off Saturn, every wave's largest |z| is above zero, and the far wave takes 35.89 steps an orbit against GPU-E's MEASURED 36.2, within 10%.
- **The Makefile:** one `check_ring` leg after check_ensemble in `check` (full: 3 formats, 23 runs, 240 s), `check-quick` and `check-light` (`--quick`: fp64, 15 runs, 85 to 124 s).
- **Suites (the parcel's):** the full `make check` on 250789e gave rc 0, 20 legs, 894 ok, 0 FAIL. `make check-light` gave rc 0.
- **Controls (the parcel's):**
  - one particle's x moved by one ulp in a copy of the ensemble: only that member fails;
  - a copy of the generator with zero inclinations: the |z| counter fails while all 27 bit comparisons pass.
- **Files:** tools/make_ring.py and tools/check_ring.py (new), and the Makefile. Nothing else.

Read `git show --stat 250789e`, the diff, and the **P2** section of `ROUND4.md`, which is its brief. The parcel's final report is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\P2-report.md`; its brief as dispatched is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\briefs\filled\P2.md`; its ledger entries are `C:\Users\logan\source\repos\cft-rebound\.ledger\P2.md`. Read the lead's file (`lead.md`) there too, but **do not read the other parcels' files**: you are paid for independence.

You are in an isolated worktree. First `git checkout --detach 250789e`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, then verify each pin's HEAD against `third_party/MANIFEST`:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree and run the gate yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` (read it, never write it) or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it after the merge. Run the parcel's own gate, the legs it touches, and `make check-light` if you can, all in the background.

## Specific things to attack

1. **Determinism.** Same arguments, same bytes; is there any `math.sin`, `math.cos` or float formatting that is not exact? Run the generator twice, and once more under a different `PYTHONHASHSEED`.
2. **The constants against their source.** Every value in make_ring.py against the study's §4 table (C:\Users\logan\source\repos\cft-fp256\docs\studies\GPU-E-mi300x-ring.md, read only). Is each one cited? Is the reference radius paired with J2 and J4?
3. **The physics of the initial state.** The circular speed in the oblate field: check v^2 against r |a_r| with J2 and J4 for a few particles. Is the frame barycentric? Is the Hill-radius exclusion real (count it) and are Epimetheus and Janus far apart in longitude?
4. **Not flat.** Is a wave's largest |z| above zero, asserted, for the particles AND the moons?
5. **The inert claim on the ring.** Does `active 7` against all 64 active compare the whole record at every format? Could it pass if `active` were ignored? (It would not, because the 420 pairs line would be missing; check that it is asserted from the record, not typed.)
6. **The ensemble against its members, and the engines.** Do these use the record's own columns and compare every line, as check_ensemble.py does?
7. **The steps-an-orbit counter.** Is it measured on a wave far from the moons, and is the 36.2 the study's (circular orbit, point mass)? Is the 10% bound asserted, or only printed?
8. **The zonal line.** Does the generator write P0's syntax (`zonal k R J2 J4`, k = 0)? Do the gates run with `--no-zonal`, so nothing breaks when P1 lands?
9. **Cost.** The leg's time in `check`, `check-quick` and `check-light`, measured.
10. **The orbits.** Compare make_ring.py's orbit-to-state code with `reb_particle_from_orbit` in third_party/rebound/src/tools.c at the pin, line by line. Then recover a, e and the inclination from a few written states, independently.
11. **REBOUND's IAS15 on a wave.** Which binary and which source does the `ias15_ref` comparison run? Is every value compared? Could it pass if `ias15_ref` ran this port's engine?
12. **The exclusion at its default.** The gate tests the exclusion at 300 Hill radii. Does the default, 5 Hill radii, bite at a size the gate does not run? Measure it at a moderate size (57,000 particles, say) and check the counts in the file's head.
13. **What the gate says it covers.** The ensemble comparison runs at binary64 only, on the program engine. Does the output say so, and does any line claim more?

The items every verifier checks:

- **The untouched path must be untouched.** Verify it **by measurement, not by reading**. The records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between `9a42b1d` and `250789e`. Build the base in a directory of your own. Run tools/check_records.py at `250789e` and report its result lines.
- **Re-run at least two of the parcel's negative controls,** independently and from copies. Pick the most load-bearing, and confirm each fails where claimed.
- **Scope.** Check `git diff --stat 9a42b1d 250789e` against the brief's "Files you own". Anything outside it is a finding, even if it looks correct.
- **Claims in comments and the commit message.** A sentence that asserts a property, such as "exact", "cannot happen", "derived" or "byte for byte", is checked with the bytes.
- **The usual shapes:** an assertion loosened; a tolerance where exactness was required; a case that cannot fail; a constant transcribed rather than derived; a TODO where work was claimed.
- **Anything else.** Tell me what I did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,500 words.
