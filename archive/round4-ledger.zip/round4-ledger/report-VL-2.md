**VL re-check of 7a339d1: NOT READY.** Everything 7a339d1 claims checks out, but a mutant of my own on a different axis — sample lines rather than columns — still passes the gate. The fix is one extra planted change.

The worktree is detached at 7a339d1 and rebuilt with `make … all programs`, with no warnings. All controls were copies under scratch, now deleted; the tree is clean and nothing of mine is still running.

**(a) Scope.** `git diff --stat e5636a9 7a339d1`: 5 files, +196/−10 — the Makefile (IN_RSEAMS only), a comment in src/ias15_cft.c, check_compare_run.py, check_ring_seams.py, and compare_run.py's header text. That matches the commit. **Confirmed.**

**(b) p2's plan is read from the record, not typed.** `particle_plan()` parses the `# columns:` line; the names come from the `# body` lines and the active count from `# active`.
- On the real line it yields 24 columns.
- On a line with one invented head, body and pair column it yields 29, with no edit to the code.
- On a labelled test line it points at exactly the head fields, bodies 0 and 1, the particle and the pair, skipping `|` and the other particles.

**Confirmed.**

**(c) Mutants against the new gate** (each in a copy of tools/, running the copy's `check_compare_run --quick`):
- **My two-x mutant** now fails at p2 alone: "2 held", with t, dt_next and dt_last named; 44 ok, 1 FAIL. **Confirmed.**
- **My own new mutant** compares every column but only the last sample line. It passes: 45 ok, RESULT: PASS, rc 0. Control p and all of p2's plants sit on the member's last sample line, so the earlier lines of the particle path are never checked. **Defect (in the gate; the shipped code is right).**
  - Failure scenario: an edit that makes `particle_compare` check only the final sample ships green. It would miss a replay whose only difference is an intermediate line's dt_next. That is the one difference P3 and V3 measured can occur alone, when a rejected attempt after an accepted step is lost.
  - For comparison, the member path's gate checks sample 0 (control a3) as well as the last line.
  - Fix: plant one of p2's columns on sample 1, a middle line, and assert the replay fails naming that line.
- **Note, not blocking:** p2 checks one trailer counter of the five, the same level as the member path's control b.

**(d) Seam part 3.** `check_ring_seams --quick` at 7a339d1: 21 ok, PASS.
- Main check: rejections [1, 1]; both members IDENTICAL; 4 particles replayed with the zonal line, all IDENTICAL.
- Control: a digit in Mimas's x on line 142 fails wave 0 and both of its particle replays, naming the column; wave 1 stays IDENTICAL.
- **Not inert.** With a `particle_compare` that compares nothing, the control FAILs ("0 of its 2"). The main check still passes under that mutant, as it must: it is this tree's record against this tree's rerun by construction, and the control is what covers it.
- Minor: the control finds its token with compare_run's own `Columns`. check_compare_run's independent column reader covers a bug shared there.
- Minor: the comment says each wave rejects its first attempt; the code asserts only that each rejects at least once, which is all the sampling needs.

**Confirmed.**

**(e) The four texts.**
- check_ring_seams' header: 3.5e-5 over the 12 steps of `--quick` and 1.5e-4 over the full 24 — I measured 3.50e-5 and 1.53e-4. J4 is now said to be held by the circular check and its J4-zeroed control.
- compare_run's two lines: P1's `# zonal` line is now named among the header lines this tree writes, and the zonal limit is restated. The check is one-way, the rerun's lines must appear in the record, as it is for every header line, so "like every other header line" holds.
- read_problem's comment: inline comments are refused on active and zonal lines, and a body line ignores anything after its seventh field. That matches my earlier test.

**Confirmed.**

**Touched gates with `--quick` at 7a339d1:** check_compare_run 45 ok with p2 "25 held", and check_ring_seams 21 ok, both PASS. These match the lead's numbers.

**NOT READY**, on the one gap in (c): the particle path is checked on its last sample line only.
