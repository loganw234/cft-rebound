**V3 re-check of P3's 2638e72: READY.** Both of my findings are fixed (D1, the pipe misread; F2, the false comment), and I found nothing new.

I checked out 2638e72 and rebuilt with `make … all programs`: rc 0, no new warnings. The old-reader control is deleted; scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\V3\`.

**(a) Scope: confirmed.**
- `git diff --stat 569ee4e 2638e72`: `src/ias15_cft.c` +28/−16 and `tools/check_replay.py` +228/−34, nothing else.
- The source changes are F2's corrected head comment, the start of `read_dt_file()` with a new `is_attempts_line()`, and the `--run-key` comment.
- The first line now goes through the same `fgets()` the loop uses, and nothing is rewound. Lines reach the parser in exactly the base's order.

**(b) Pipes: confirmed** (`t_pipe4.py`, `t_pipe2.py`, `t_pipe3.py`; `pipe_recheck.log`).
- kepler, outer, kepler_e099 and outer padded to 32-byte lines all go through a Windows named pipe with rc 0 at both 9a42b1d and 2638e72.
- In every case the 2638e72 pipe record is identical to 9a42b1d's (0 sample lines differ, timing masked) and to the same file read normally.
- The padded file now starts at its first line (dt0 0x1.47ae147ae147bp-7); 569ee4e started at line 129.
- An attempts record through the pipe: 0 of 61 lines differ.

**(c) Old dt files from regular files: confirmed** (`sweep.py`, `sweep3.log`).
- 31 configurations, base 9a42b1d against 2638e72: kepler, outer, pythagorean and kepler_e099 at fp64/fp128 on loop, FMA and program; kepler and kepler_e09 at fp256; my `active 6` wave at fp64 on all three.
- Records are identical in three runs per configuration: plain, with `--dt-out`/`--record-iters`, and replaying the base's dt file through the new reader.
- `--dt-out` files and schedules, `# run` lines included, are byte-identical.
- `sweep_r45.py`: 62 of 62 base-recorded schedules replayed at 2638e72 give the base's run.

**(d) The new pipe case bites: confirmed.**
- Control: 2638e72's source with the start of `read_dt_file()` put back to 569ee4e's (`att_line()` then `rewind()`). The diff is confined to that block; I built it from a copy, then deleted it.
- `check_replay.py --quick` against it: 118 ok and exactly one FAIL, RESULT: FAIL.
- The failure is the padded `--dt-out` (385 lines, 12,320 bytes) through the pipe: "rc 0, 5 of them differ and its counters are NOT the file's".
- The attempts-record pipe case passes on that build, as it should.
- The POSIX `/dev/stdin` path was not run here; it remains P3's believed claim.

**(e) Nothing loosened: confirmed.** The diff removes one verdict and adds six.
- **B's deletion:** `len(bad) > 0` became `nb > 0`, counted over the bodies alone. That is stricter, since the bodies are a subset of `bad`. It measures 32 of 40 pairs.
- **C's deletion:** it keeps `not bad and steps_rejected == wave − 1`. The deleted attempt is now one with no sample just before it, and if none exists the case fails by name.
- **New case:** deleting a rejection that does have a sample before it must move only that line's dt_next, from the deleted dt to the next attempt's. It runs at fp256 and in `--quick` (sample 6). At sample 7 it is not exercised, and a printed note says so rather than a verdict.
- **"It moved":** it now sums the angle sample to sample, which accepts anything the old net measure did, with the thresholds unchanged. This fixes the whole-orbit false failure P3 had disclosed; it is not a bit check.
- The precondition's own ok line is true by construction; only its no-candidate branch can fail, and that fails by name.

**(f) The gate: confirmed.**
- `check_replay.py --build build`: 303 ok, 0 FAIL, RESULT: PASS. The whole-wave-without-schedule check holds in all 21 rows, and the pipe case shows 0 of 5 lines differing in both forms.
- `--quick`: 119 ok, 0 FAIL, RESULT: PASS.

**READY.**
