"""Fill V-common.md for one verifier: the parcel's claims, its V-attacks.md section
plus the lead's extra attacks, the commit and the base. Usage:
    python -I fill_v.py BRIEFS_DIR PARCEL VNAME COMMIT BASE
"""
import re
import sys

B, parcel, vname, commit, base = sys.argv[1:6]
SCR = r"C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad"
LEDGER = r"C:\Users\logan\source\repos\cft-rebound\.ledger"

common = open(f"{B}/V-common.md", encoding="utf-8").read()
attacks_all = open(f"{B}/V-attacks.md", encoding="utf-8").read()

m = re.search(rf"^## {vname} .*?\n(.*?)(?=^## |\Z)", attacks_all, re.S | re.M)
if not m:
    sys.exit(f"no {vname} section in V-attacks.md")
listed = m.group(1).strip("\n")
nums = [int(x) for x in re.findall(r"^(\d+)\. ", listed, re.M)]
assert nums == list(range(1, len(nums) + 1)), nums

extra = [l for l in open(f"{B}/attacks-extra-{vname}.md", encoding="utf-8").read().splitlines() if l.strip()]
k = len(nums)
for e in extra:
    k += 1
    listed += f"\n{k}. {e}"

claims = open(f"{B}/claims-{parcel}.md", encoding="utf-8").read().strip("\n")

old = "The parcel's own report is in the ledger: `" + LEDGER + "\\{PARCEL}.md`."
assert old in common, "the report sentence was not found in V-common.md"
new = ("The parcel's final report is `" + SCR + "\\gpu\\reports\\{PARCEL}-report.md`; its brief as dispatched is `"
       + SCR + "\\gpu\\briefs\\filled\\{PARCEL}.md`; its ledger entries are `" + LEDGER + "\\{PARCEL}.md`.")
out = common.replace(old, new)

for key, val in (("{CLAIMS}", claims), ("{ATTACKS}", listed), ("{COMMIT}", commit),
                 ("{PARCEL}", parcel), ("{BASE}", base)):
    assert key in out, key
    out = out.replace(key, val)
left = re.findall(r"\{[A-Z]+\}", out)
assert not left, left

with open(f"{B}/filled/{vname}.md", "w", encoding="utf-8", newline="\n") as f:
    f.write(out)
print(f"{vname}: {len(out.splitlines())} lines, {len(nums)} listed attacks + {len(extra)} extra")
