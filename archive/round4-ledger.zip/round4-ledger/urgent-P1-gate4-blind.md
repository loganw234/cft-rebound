A format-difference check cannot see a binary64 term that both formats share: P1's control "the term rounded to binary64, gate 4 fails at about 1e-16" PASSES gate 4 (measured)
For: lead, P4, and anyone designing the GPU half's checks (cft-fp256's study GPU-E section 6, item 3(b) rests on the same premise)

## 2026-11-11 22:20 — P1: rounding the zonal term to binary64 is invisible to binary128 against binary256 on the same steps

Measured (P1's worktree at 9a42b1d plus the zonal term, uncommitted; controls built from copies of src/ in P1's scratch, never the tree): data/problems/zonal_saturn.txt (Saturn with J2 and J4, a moon, a ring particle), binary128 adaptive at epsilon 1e-9 with --dt-out, then binary128 and binary256 on those 120 steps (--dt-file, --epsilon 0). Largest |x128 - x256| over every sample and body, over the body's distance from Saturn:
- the correct build: 3.402e-33;
- the term rounded to binary64 before it is added, in both runs (ROUND4.md P1's first negative control, as written): 3.371e-33. Gate 4's bound is u128 * steps^2 = 1.39e-30, so it PASSES;
- the same rounding at binary128 only: 4.029e-18, so it fails, at the size the brief expected.
Measured: the brief's control IS caught, by the gates that compare with a reference without the defect: the formula gate (each point against mpmath's gradient of the potential) fails at binary128 at 1.4e-17 to 8.3e-17 of the term against bounds of about 1e-32, and the arithmetic gate (each traced operation against the golden model, every operand the trace's own last result) fails at binary128 too.
Believed (the mechanism, not separately measured): rounding to binary64 is a deterministic function, and the two runs' terms agree to about 1e-33, so both runs round to the same binary64 value (a straddle of a binary64 rounding boundary is about 1e-17 likely an element) and the defect cancels in their difference. The same holds for any binary64 bottleneck two runs of one build share, the drop-in's binary64 additional_forces (README.md:122-128) included. So "the same steps at binary128 and binary256 must differ at binary128's round-off ... the check that fails on exactly the defect the README names" (GPU-E section 6, item 3(b)) is not a check that can fail on that defect. What does see it: a reference without the defect (here mpmath at 200 digits and the golden model), or a run of another build.

## 2026-11-11 22:14 — correction to the entry above: it was written at 22:13, not 22:20

Measured: `date` at the time of writing said 22:13. Nothing else in it changes.
For: anyone ordering this ledger by time
