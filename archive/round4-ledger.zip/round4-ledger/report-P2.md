# P2 report (round 4): a Saturn ring generator, its gate and its leg (resent with one added limit)

Both tools are written and the leg is in all three tiers. The full `make check` passes on the final commit: rc 0, every verdict read from the log. The negative control fails for the perturbed wave only, as it must.

The work is on branch `worktree-agent-a816124f18f42dc90`, base 9a42b1d (checked). It is two commits: 94b0daa (work in progress) and 250789e (final). Nothing was pushed or merged, and the tree is clean.

**What's new since my first report:** P1's urgent message `P1-gate4-blind.md` arrived afterwards. It changes nothing my gate asserts, but it limits what my wide-format figures show; that limit is added under "What I did not do" and is in my ledger drop.

## What changed, file by file
- **`tools/make_ring.py`** (new). It writes Saturn, then six moons, then test particles, either as one system (`--one-system`) or as waves of 64 bodies (7 massive, then 57 particles).
  - The file carries `active 7` and `zonal 0 R J2 J4`, unless `--no-zonal` is given.
  - Particles are sorted by radius, then cut into waves.
  - Everything is computed in mpmath at 160 bits from the constants rounded to binary64, and each written value is rounded to binary64 once.
  - Orbits use REBOUND's own orbit-to-position formulas (`reb_particle_from_orbit`, tools.c:940-997). The frame is the barycentre of the massive bodies.
  - A start within 5 Hill radii of a moon is refused and drawn again; the file's head says how many, near which moon.
  - A particle count that is not a multiple of 57 is refused by name.
- **`tools/check_ring.py`** (new). The gate, described below.
- **`Makefile`**. An input list `IN_RING` (the gate, the generator, `check_equivalence.py`, `ias15_cft`, `ias15_ref` and `programs/out/*.cftp`), and one `check_ring` leg after `check_ensemble` in each of `check`, `check-quick` and `check-light`. `check` now has 20 legs, so CLAUDE.md's "19 legs each" needs updating; that file is yours.

## Gate output (actual lines, from the full `make check`, ring leg 00:44 to 00:48)
```
  ok   the same arguments twice give the same 41859 bytes, and seed 2 gives other bytes (differing)
  ok   mpmath's gmpy backend and its python backend give the same bytes
  ok   Saturn first, then the moons (mimas, pan, prometheus, pandora, epimetheus, janus): the 7 massive bodies, bit for bit the same in all 4 waves; every particle massless
  ok   circular in the file's own field (a point mass's): |v|^2 r / GM - 1 at most 6.7e-16, r.v / (|r||v|) at most 1.6e-16
  ok   not flat: every wave's largest |z| from Saturn is at least 116.294 km
  ok   without --no-zonal: `zonal 0 60330.0 0.016290573 -0.000935314` holds R, J2 and J4, and every particle, and pan, has the oblate field's circular speed ... to 6.7e-16
  ok   the exclusion bites: at 300 Hill radii it refused 63 draws, and the closest start kept is 300.1 Hill radii from a moon
  ok   fp64: the loop and program engines in the FMA form: 7 sample lines identical over 6 steps (3.833 passes a step), counters and flags the loop's, the program's predictor ran 6 times
  ok   fp128: the loop and program engines in the FMA form: 4 sample lines identical over 3 steps (8.000 passes a step), ...
  ok   fp256: the loop and program engines in the FMA form: 3 sample lines identical over 2 steps (16.000 passes a step), ...
  ok   fp64: the loop engine in REBOUND's form runs it, differing from the FMA form (first at sample 2, dt_next), its largest relative difference 1.698e-11 against a bound of 2^-26.5 = 1.1e-08 ...
  ok   fp256 loop engine rebound form: `active 7` against all 64 active, 3 sample lines identical, the trailer too: 420 pairs a force evaluation against 2016
  ok   fp64: w00001 as one system of 64, every body active: REBOUND's own IAS15 (ias15_ref) against ias15_cft in REBOUND's form at its defaults: 7 samples, 2716 values identical
  ok   the same 7 sample lines as the gate's all-active run of w00001 (--member 1, --max-iter 60), so REBOUND's IAS15 has the bits `active 7` has
  ok   w00002: 7 sample lines identical, its trailer too (6 steps, 4.000 passes a step)        [and w00000, w00001, w00003]
  ok   the comparison can fail: p0000143's x moved by one ulp ... w00002 differs from its run alone (...; 7 of its 7 samples differ) and every other wave still matches
       MEASURED, not asserted, each wave's last step: w00000 dt 1333.10 s, 35.89 an orbit of p0000000 ...; w00002 dt 1388.09 s, 35.89 an orbit of pan, its shortest (37.11 of its innermost particle's); w00003 ... (38.37 ...)
  ok   the moons act: with their masses zeroed the wave differs; after 6 steps a particle (p0000110) is 2.161e-02 km from where the moons put it, 1.6e-07 of its radius
  ok   the far wave w00000 (radii to 132941 km, wholly inside pan's pericentre less 5 Hill radii, 133510 km): 35.89 steps an orbit of p0000000, its shortest (47845 s), over steps 12 to 24 at epsilon 1e-9, against GPU-E's MEASURED 36.2: -0.9% (the bound is 10%)
  ok   the pairs ...: 231 pairs a force evaluation in 1 run of `active 7 of 37`; 420 pairs a force evaluation in 16 runs of `active 7 of 64` (2016 with every body active); and no line in the 6 runs with every body active
  ok   over all 23 runs, 167 sampled systems: every particle stayed in the annulus [130000, 142000) and off Saturn (60268 km), ... the largest change of a radius 0.149 km; every wave's largest |z| at least 108.728 km
check_ring: 23 runs of ias15_cft, 236 s of them; 240 s in all
RESULT: PASS
```
That is an excerpt of the leg's 37 ok lines; the full leg output is in `check_ring_in_make_check.txt` (paths at the end).

How each check gets its expected value:
- The 420 pairs are read from each run's `# active` line and compared with REBOUND's two-loop count, n(n-1)/2 + (N-n)n, computed from that run's own problem file.
- Steps and times come from the record. The orbital period comes from the file's own state.
- 36.2 is the study's figure.

**Tiers and cost (MEASURED on today's shared host):**
- `check` runs the leg in full: all three formats, 23 runs, 240 s.
- `check-quick` and `check-light` both pass `--quick`: binary64 only, fewer steps, 15 runs, about 85 to 124 s.
- Every case is a step-count case. None integrates to a time, none is a step sequence, and none merges, so no `--light` rule applies.

**Suites (read from the logs):**

| Suite | Commit | Time | Result |
|---|---|---|---|
| `make check-light` | 94b0daa's Makefile; its ring leg ran the final gate | 41 min 46 s | rc 0, 20 legs, 12 RESULT: PASS, 0 FAIL |
| `make check` | 250789e | 2 h 36 min 3 s | rc 0, 20 legs each `--mode full`, 12 RESULT: PASS, 0 FAIL, no fork errors |

The full `make check` printed 894 ok lines: main's 857 plus exactly check_ring's 37. Its other verdict lines are all present: constants 78 match, check_dropin every case passed, check_dropin --wide passed, archive gates 1-3 PASS, gate_real PASS at all three formats, gate_subprocess PASS. The one `--` line is gate_subprocess's body_count, as on main.

## Negative controls
Both were built from copies in the scratchpad, run in `--quick`, confirmed failing, and deleted.

1. **The brief's control.** The gate's ensemble run reads a copy of the ring in which p0000143's x is moved from `0x1.99c89695d5c96p+16` to `0x1.99c89695d5c97p+16`; the member runs still read the original.
   - Result: `FAIL w00002: first difference at sample 0, body 36 x: ensemble 0x1.99c89695d5c97p+16, alone 0x1.99c89695d5c96p+16`, then `RESULT: FAIL` with rc 1.
   - w00000, w00001 and w00003 still matched: 28 ok lines.
   - Without the change, the same lines read `ok w00002: 5 sample lines identical, its trailer too (4 steps, 4.250 passes a step)`.
2. **A flat ring** (my addition). A copy of the generator with every inclination set to zero.
   - Result: `FAIL not flat: ... at least 0.000 km`, 42 `FAIL the physics ... flat` lines, and the end-of-gate check over all runs failing on |z|; `RESULT: FAIL`.
   - All 27 bit-comparison lines still passed. That is the silent wrong answer ROUND4.md warns of, now caught by the |z| counter.

## Constants and their sources
- **Read in GPU-E §4** (the study's sources; no web page was read):
  - Saturn's GM 37.931e6 km³/s² and equatorial radius 60,268 km: NASA's fact sheet.
  - J2 16,290.573e-6 and J4 -935.314e-6: Cassini (Iess et al. 2019, in Fortney et al.).
  - Reference radius 60,330 km: the study BELIEVES it, since its table states none. The file's head says so.
  - The moons' GM, a and e: JPL SSD.
  - The annulus, 130,000 to 142,000 km: the study's recommendation.
- **Units:** km and s, with G = 1.
- **Synthetic** (ROUND4.md decision 5): the moons' inclination, node, pericentre and true anomaly, in degrees:
  - Mimas 1.0, 30, 60, 0
  - Pan 0.05, 150, 0, 0
  - Prometheus 0.05, 210, 0, 60
  - Pandora 0.05, 300, 30, 0
  - Epimetheus 0.2, 0, 0, 45
  - Janus 0.2, 180, 0, 45 (180° from Epimetheus)
- **Synthetic, the particles:** inclination 1e-4 to 1e-3 rad; draws from `random.Random(seed)`, default seed 1.
- **My choices:** exclusion at 5 Hill radii; 57 particles a wave; 160 bits in mpmath.
- **Formulas:**
  - Hill radius a(m/3M)^(1/3). It reproduces the study's column: 18.0, 63.4, 61.4, 521.2, 102.3 and 157.0 km.
  - Circular speed v² = (GM/r)(1 + 3/2 J2 (R/r)² − 15/8 J4 (R/r)⁴), from ROUND4.md P1's potential in the equatorial plane.
- **Gate:** 36.2 steps an orbit (GPU-E §3, MEASURED) with the brief's 10%; epsilon 1e-9; `--max-iter 60`; first step 100 s. The format precisions 53, 113 and 237 are checked against each record's `pc_tol_shift`.

## What I did not do
- **(New) The binary128 and binary256 form comparisons don't prove full width.** They are two runs of one build, and the two forms share gravity, the corrector's error and the step control. BELIEVED from P1's mechanism: a binary64 bottleneck in a shared part would cancel in the difference, so the figures 4.3e-30 and 1.9e-68 are not evidence that a ring run is at full width. No check here has a reference built without such a bottleneck, except REBOUND's IAS15, and that runs only at binary64.
- The ensemble comparison runs at binary64 only, on the program engine; check_ensemble still covers ensembles at every format. The engine and test-particle checks do run at every format.
- No ring with the zonal line is ever run, since P0 refuses it. Only its file is checked: the line itself, and the speeds of the particles and of Pan.
- No cross-host check, since WSL was off limits. What I MEASURED is that mpmath's gmpy and pure-Python backends give identical bytes on this host.
- No case forces a rejected step, and no close encounters; the gate's runs are 2 to 24 steps.
- The mpmath package is not a gate-cache input (the constants leg doesn't key on it either).
- "The engine computes all 2,016 pairs" is INFERRED from the code, not measured.
- I committed no generated file. The full-scale ring was measured, then deleted.

## What the brief or ROUND4.md got wrong
- **"Oblate speed" and "your gates use `--no-zonal`" can't both hold for one file.** COMPUTED from a with-zonal file read in a point mass's field: particle e is 0.0045 to 0.0053, apocentres sit 1,275 to 1,396 km beyond the start, and the outermost reaches 143,253 km, outside the annulus.
  - So `--no-zonal` also gives point-mass speeds. Each file is circular in its own field, and the moons are scaled the same way, so Pan stays circular.
  - For the P1 x P2 seam test, generate the ring without `--no-zonal`. To isolate the zonal line, delete it from that file rather than comparing two generated files.
- **10^6 particles is not a multiple of 57.** `--particles 1000000` is refused by name; 17,544 waves hold 1,000,008 particles. MEASURED at that size: 175 MB, written in 3 min 36 s, with 49 of 1,000,057 draws refused (Pan 2, Prometheus 19, Pandora 28).
- **"Each wave on its own adaptive step" hides a cap.** A system's shortest orbit sets its step, and Pan's (49,819 s) is shorter than every particle's outside its radius. MEASURED: waves w00002 and w00003 step at exactly Pan's rate, 1388.09 s, which is 38.4 steps per orbit of w00003's own innermost particle.
  - COMPUTED: about 3% more steps over the whole ring. GPU-E's cost model doesn't include this.
  - The far-wave figure itself holds: 35.89 steps an orbit, 0.9% under 36.2.
- **The two forms differ in the step, not only at round-off.** MEASURED at binary64: REBOUND's form and the FMA form differ in dt_next by 1.7e-11 relative after 3 steps. BELIEVED cause: the step control works from the high-order corrector coefficients, which amplify round-off. Records should be compared like with like.
- **The brief's clone loop** (`while read ... git -C`) is refused by the worktree-isolation guard. Plain, separate `git clone` and `git checkout` commands worked.

## Other findings
- REBOUND's own IAS15 (`ias15_ref`) reproduces a ring wave bit for bit at binary64, and that record is the `active 7` run's. The gate now holds this.
- Everything above is also in my ledger drop, as six entries plus one correction to their times; the last entry is the response to P1's message.

Files are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\`:
- `p2\p2-check.log`
- `p2\p2-check-light.log`
- `p2\check_ring_in_make_check.txt`
- `p2\ctl_ulp.log`
- `p2\ctl_flat.log`
- `p2\make_controls.py`
- `ledger-drop\P2.md`
