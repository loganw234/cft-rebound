**V3 on P3 at 569ee4e: NOT READY.** There is one small defect (D1) and one false comment (F2). Everything else is confirmed, both as shipped and as gated.

Every item's commands are in the named script under `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\V3\`, with its logs. The control copies are deleted.

**Setup.** `git checkout --detach 569ee4e`, then `git log --oneline -1` showed 569ee4e. I cloned third_party locally; both HEADs match MANIFEST. `make OS=Windows_NT … all programs` gave rc 0 and no new warnings. I built the base 9a42b1d from `git archive` in `V3\base`.

**Gate and suites.**
- `python tools/check_replay.py --build build` at every format: 276 ok, 0 FAIL, RESULT: PASS.
- `make check-light`: rc 0, 20 legs, 667 ok, 0 FAIL, no fork errors.
- Full `make check` not run, per the brief.

**1. Rejected attempts: confirmed** (`mkwave.py`, `exp_wave.py`, `exp64.py`).
- My own wave is outer.txt's bodies plus a 1e-10 Msun rock (`active 6`) and five particles, one aimed past the rock. It rejects 6 times after accepted steps, including consecutive attempts 4 and 5. From dt0 = 1000 d it rejects once on the first attempt and once later.
- I also built a 64-body ring wave (420 pairs), with 5 late rejections, or 1 first plus 5 late.
- The record holds every attempt: its count equals the trailer and the schedule lines, and its accepted dts and `next` equal `--dt-out`'s.
- Replaying the whole wave through it: 0 differing sample lines and equal counters, at fp64 loop, fp64 FMA and fp256 program.
- Every particle replayed alone: 0 mismatches in the particle, every massive body, head, tail and counters. On the 64-body wave that is 6,528 values with 0 mismatches.
- The passes live in the schedule, not the attempts record; that was P3's stated choice.

**2. Run key: confirmed.** In six runs, each of these is refused by name with rc 3:
- the wave's schedule, not re-keyed, replayed into a sub-system;
- particle 7's re-keyed schedule used for particle 6;
- a whole-wave accepted-steps schedule replayed into a sub-system;
- another wave (one particle's x moved 1 ulp), by both the tool and the program;
- the rock's mass moved 1 ulp, by both.

Schedules recorded at 9a42b1d and replayed at 569ee4e: 144 of 144 give the base's run, every sample line and counter. The gate itself covers another wave, a changed body and swapped outcomes.

**3. Massive bodies: confirmed, and the comparison is load-bearing.**
- `compare()` checks all 7 massive bodies at every sample.
- I made a gate copy that gives particle p2 a mass of 2^-40. It passes on the shipped build (192 ok), because testparticle_type 0 ignores that mass.
- It fails all 42 particle rows on a build copy where test particles pull on the massive bodies.
- At fp64 only Saturn differs, at 4 of 5 samples. The particle, the other bodies, t, dts and E all match, so a particle-only check would have passed.
- Limit: the gate's own particles are all massless, so the shipped gate passes that faulty build (108 ok). Holding testparticle_type 0 is check_gravity's job (P0).

**4. Body order: confirmed.** The tool asserts the massive lines and then the particle, line for line, and the gate's swap case is refused by both tool and program. Swapping Jupiter and Saturn by hand moved no bit in 4 of 5 runs, so it is the assertion, not the physics, that holds the order.

**5. `--dt-out`: confirmed.**
- Byte-identical at base and head in 72 configurations.
- Regenerated `kepler_dt2.txt` and `pythagorean_dt2.txt` equal the committed files once Windows line endings (CRLF, written at both commits) are read as LF.
- The committed dtfile replays reproduce 21 of 21 sample lines each.

**6. check_corrector: confirmed.** P3 did not touch it. The full `--library` run gives rc 0, 278 ok, "20 of 20", and its 342 lines are identical to P0's leg in the lead's `p0-check.log`. In `--quick` mode, base and head output are identical, 188 ok.

**7. Controls: confirmed** (copies, then deleted).
- C1: the replay predicts after a recorded rejection as if after an accepted step. The gate fails at every format, engine and form that rejects:
  - wave B: 34 to 36 mismatches of 40 per particle;
  - wave C: only the flyby (5) at fp64/fp128 in REBOUND's form, 1 and 6 in the FMA form and program engine, 21 to 22 at fp256.
- C2: one accepted attempt's dt moved 1 ulp in every record. The gate fails in all 21 rows and for all 63 particles (A 26, B 24 to 27, C 3 to 11).

**8. Scope: 13 hunks.**
- The head comment (the usage line at `:64`, the paragraph at `:79–87`) is outside the owned regions. It is comment-only and P3 disclosed it, but it is a finding by the rule.
- Writer and reader: `:1137–1143`, `:3033–3039`, `:3169–3237`, `:4619–4621`, `:4640–4644`, `:4653–4663`, `:4765–4771`.
- Replay branch: `:2984–3000`, `:3046`.
- `sched_key()`: `:4406–4414`.
- Option parsing: `:4481–4484`, `:4525–4526`, `:4629–4639`.

**9. No older key moves: confirmed.** The `--record-iters` schedules, `# run` line included, are byte-identical at base and head in 72 configurations, both with no dt file and with an accepted-steps dt file. The 72 are five problems, my `active 6` wave, the gate's ring and a kepler ensemble member, each at three formats on loop, FMA and program. A 3-system ensemble: 9 of 9.

**10. A rejection after an accepted step leaves no state bit: confirmed, with one precision.**
- Tested on my wave at fp256 on the program engine and at fp64 in the FMA form.
- Deleting any late rejection, or all six, moves no state value.
- The only token that moves is `dt_next` on a sample printed just before the deleted attempt; that token is the deleted attempt's own dt.
- Deleting a first-attempt rejection moves every line (61 of 61 at fp64, 41 of 41 at fp256).

**11. `--run-key` opens no file: confirmed.**
- Existing files at all three outputs keep their content, size and mtime.
- A missing `--replay-iters` file and a missing `--programs` directory are never opened.
- Its output matches the `# run` line in 8 configurations.
- It does read the problem and the dt file, so "opens no file" means no output file.

**Untouched path: confirmed.** In 72 configurations the records are identical with timing fields masked. `check_records.py` at every format: 9 ok, RESULT: PASS.

**D1, defect: an old dt file read through a pipe is silently misread.**
- `read_dt_file()` reads the first line, then calls `rewind(f)` without checking it. A pipe cannot rewind, and the C runtime drops its 4,096-byte buffer.
- I fed dt files through a Windows named pipe (`t_pipe.py`, `t_pipe2.py`):
  - 9a42b1d reads kepler, outer and a padded file exactly as it does from a regular file.
  - 569ee4e refuses kepler ("has 0 steps") and outer (a parse error).
  - The padded file has 32-byte lines, so the 4,096-byte cut lands on a line boundary. 569ee4e runs it with rc 0, starting from line 129 (dt0 0x1.09e1efafcabc2p+7). All 6 sample lines are wrong and nothing is printed.
- Scenario: `--dt-file <(zcat run.dt.gz)` on Linux. The exact outcome there depends on the C library (believed, not measured).
- The attempts form itself works through a pipe (0 of 61 lines differ).
- Fix: parse the line already read instead of rewinding, or refuse a non-seekable file by name. No gate covers this.

**F2, false comment.** At `:79–87` the head comment says that with `--replay-iters` of the same run's schedule the replay "is that run, bit for bit". In fact that schedule is refused with rc 3, because the replay's key differs (`epsilon`, `dt_file=attempts`). The whole run replays bit for bit with no schedule at all (0 of 61 lines, three cases); only a sub-system needs a schedule, and it must be re-keyed.

**Also.**
- The gate's C-deletion case expects 0 mismatches only because no sample falls just before the deleted attempt. A different `--sample` could make it fail with nothing wrong.
- `ATT_MAGIC` is copied by hand into the tool, but if it drifts every extraction is refused, so it fails loudly.
- No loosened assertions, tolerances, vacuous cases or TODOs.

**NOT READY.** D1 needs a fix and a case, and F2 needs one sentence. A scoped re-check of those two plus the gate would be enough.
