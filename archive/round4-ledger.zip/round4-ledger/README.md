# The round ledger

**This repository's one change to the template (round 3, 2026-11-02; kept
for round 4).** Agents run in isolated worktrees. An isolated agent can
READ this directory but cannot write to it, which V0 measured on
2026-10-31. So:
- **Read here:** every file, `urgent/` included, at the three moments
  below.
- **Write your entries to**
  `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\<your-name>.md`,
  append only. The lead places them here verbatim and says so in
  `lead.md`.
- An escalation that must not wait goes in the same drop as
  `urgent-<your-name>-<slug>.md`. The lead watches the drop.

Scaffolding for a parcel round, not history. Ignored by version
control; the lead folds anything durable into `docs/VALIDATION.md` and
`ROADMAP.md` at the end of the round, archives this directory as
`archive/round4-ledger.zip` (rounds 2 and 3 are
`archive/round2-ledger.zip` and `archive/round3-ledger.zip`), and
removes the working copy.

It exists because **a brief is written once, at dispatch, and cannot be
updated.** Anything learned while the parcels are running otherwise
reaches them never — it arrives in a final report, after the sibling who
needed it has finished.

## How to use it

This directory is **outside every worktree**. Agents work in separate
checkouts and cannot see each other's files, so reach this by its
absolute path:

    C:\Users\logan\source\repos\cft-rebound\.ledger\

**One file per author, append only.** Yours is `<your-name>.md` —
`P1.md`, `verifier-P2.md`, `lead.md`. Read every file in the directory;
write only to your own. Never edit anyone else's, and never edit an
entry you already wrote: append a correction underneath instead.

**Read at three moments** — the floor, not the mechanism; `urgent/`
below is the rest of it:

1. once before starting anything;
2. again before designing anything that touches a file your brief
   called shared or forbidden;
3. again before writing your final report.

**Write when this clears the bar:** *would it have changed another
parcel's work, or the lead's?* Three things do.

1. **Environment and setup** — what the tree needs before it builds,
   what your base commit actually turned out to be, a tool that is not
   where it looks.
2. **A brief that turned out wrong** — the moment you find it, not in
   your report. A sibling may be acting on the same wrong premise right
   now.
3. **A finding about shared code** — behaviour in a function another
   parcel owns, an upstream defect, a constraint that will bind someone
   else.

**Do not write** progress, plans, or anything only your own parcel cares
about. A ledger full of status is one nobody reads.

**Mark what you measured.** Every entry says which claims were
*measured* and which are *believed*, to the same standard as your
report. Other agents build on these, and an unverified claim propagates
faster than a verified one.

## `urgent/` — the push channel

The three moments above are a **polling schedule**, and its latency is
its interval. A correction posted ten minutes after you start sits
unread until your next read moment. `urgent/` is the way past that.

**Arm a watcher on it before you start anything**, persistently, so a
new message becomes a notification rather than something you find later:

```bash
U=C:/Users/logan/source/repos/cft-rebound/.ledger/urgent; mkdir -p "$U"
seen=$(ls "$U" 2>/dev/null | sort)
while true; do
  cur=$(ls "$U" 2>/dev/null | sort)
  comm -13 <(echo "$seen") <(echo "$cur") | while read -r f; do
    head -1 "$U/$f"; grep -m1 '^For:' "$U/$f" 2>/dev/null || true
  done
  seen=$cur; sleep 20
done
```

**Arm it inline rather than from a script file.** Everyone in the round
shares a scratch directory and the watcher is the one script everyone
writes, so it is the one filename everyone collides on — that happened
on this mechanism's first use. If you must use a file, put your own
name in it.

**The watch is not the mechanism, it is latency reduction.** A watcher
that has died — timed out, killed, stopped for volume — looks exactly
like a directory with nothing new in it. If you notice yours is gone,
re-arm it **and do a full read**, because you cannot tell how long it
was dead.

**The bar for writing here is "stop what you are doing and read this",**
and it is mostly the lead's: a brief that turned out wrong, a merge that
invalidated an assumption, a thing you were told to delete that turns
out to be load bearing. Everything else goes in your own file. A channel
that fires for things that could have waited is one people learn to
ignore.

**One file per message, renamed into place.** Compose it somewhere else
and `mv` it in, so a watcher can never catch a half-written file, and so
a new message is an unambiguous event:

    <who>-<short-slug>.md

First line is the headline. Include a `For:` line — the watcher prints
those two and nothing else, so they are what someone decides on.

**Verifiers watch the lead's file only.** A verifier is paid for
independence, and a stream of "the parcel says this is fine" is exactly
what erodes it.

**The lead watches the whole directory**, not just this one — only the
lead can see a pattern across parcels. And escalating to the lead
through `urgent/` is what this channel is *for* as much as the other
direction: if your brief is wrong, if you are in the wrong place, if
something you were told is load bearing turns out not to be, put it
here rather than in your final report. An escalation that turns out to
be your own misreading costs nothing; one that waits two hours for a
report costs whatever the sibling did in the meantime.

## Entry format

    ## <date time> — <one-line headline>

    Measured: ...
    Believed: ...
    For: <who this is likely to matter to, or "anyone">
