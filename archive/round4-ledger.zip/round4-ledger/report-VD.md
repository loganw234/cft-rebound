**VD on 79128a1: NOT READY.** I found no wrong number. I found two false statements, one stale marker, and seven minor texts. Each fix is a line or two.

I read all six documents, D's report and brief, every report in gpu\reports, the ledger (lead.md, P1-P4.md, urgent\), both suite logs, the commit log 7a7a279..d9c8c8c, and the code at d9c8c8c. I edited no tracked file, built nothing and ran no suite. I stayed out of cft-fp256 and read the scratchpad's copy of GPU-E instead.

### 1. Numbers against sources: confirmed, one unchecked

- **RING.md, every number.** All match:
  - the constants: P1's and P2's reports, GPU-E §4;
  - 160 bits and the 99n + 1,000 bound: make_ring.py:110, :240;
  - 174,691,521 bytes, the radii, 141.850 km, 49 of 1,000,057 (2/19/28): P2.md 22:35;
  - e 0.0045–0.0053 and 143,253 km: P2.md 22:15;
  - ten runs and 399,049: V2-1 item 1;
  - 1.7e-11: P2.md 01:30;
  - the header fields: compare_run.py:156-157;
  - 3.371e-33, 3.402e-33, 4.029e-18: urgent/P1-gate4-blind.md;
  - 35.89, 132,941 km, −0.9%: P2's gate line;
  - 36.2 and 7p + 1: GPU-E l.188 and l.134;
  - 420 against 2,016: GPU-E l.377;
  - 1,388.09, 49,819 and 38.4: P2.md 21:45;
  - 34 mul: V1 item 3; GPU-E's estimate: its l.131;
  - 8 mul a call: P1.md 22:31;
  - the decisions: ROUND4.md:641-657.

  I could not check "at `be40005b` the study is unchanged since `56006987`" (RING.md:210, VALIDATION.md:6590). It is D's own git diff in cft-fp256, and no report or ledger entry records it.
- **CLAUDE.md.** All match:
  - 2 h 47 min, 20 legs, 291c99c: the log, 03:47:46–06:34:31;
  - 42 min, 13 s, 19 legs, 9e9879f: VALIDATION.md:5401-5403, "on the tree this entry lands with";
  - 63 min, 24 legs, e5636a9: VL-1 item 8;
  - "four times": V4 twice and VL twice.
- **Entries 46-51.** More than 120 numbers, every entry covered, no mismatch:
  - 46: 857 and 858 by the two patterns, 11 PASS, 18:49:08–21:08:53, the six digests, mpmath 1.3.0 and ABI 0.18 (p0-check.log); 117, 9 of 9 and 170 (lead.md).
  - 47: 980, 302/44/99/87, 12 PASS and the quoted lines (291c99c log :1027, :1052-1133). P1's control table: 1.4e-17–8.3e-17, 2.22e-20, 2.37e-2, 4.35e-5, +1.32e-6, 5.97e-3, 1.19e-4. V1: 6.7e-16, 2.8e-201, 126/1,382, 160/349/510/62, 9.6–150, 100, 671, 2e-149, 1.32e-33. P1: 977 and 87.
  - 48: 41,859, 1.698e-11, 2,716, 0.149, 27/42 (P2's report); 1,423/1,471 and 39.3 (P2.md); V2's 31, 1,645, 2 of 57,002, 72/315, 33/1, 1,940, 6,644, 40/34; 894.
  - 49: 0 of 7, 5/7/7 and the three problems (P3.md 21:58); 19 and 21 of 48 (P3.md 22:40); P3's 276, 26, 37, 29/42, 34–36, 33 of 64; V3's 6,528, 144, line 129, 0 of 61, 62 of 62, 118/1, 303/119; 12,320 and 32 of 40 (2638e72).
  - 50: 1.8° (check_compare_run.py:151); P4's 12/14/18/21 mutants, 907, 22:50:46–01:27:14 and the case-1 lines; V4's 54, 63, 15, 17/17/9; 16 columns over 3 records (7d50392); the `# program=` fields (ias15_cft.c:4693-4701).
  - 51: part 1 (lead.md 03:59, 110834f); 3.5e-5 (VL-2); 15 replays, 192–432, 64 of 72 (acf9fff); 66 ok (e5636a9); VL's figures (VL-1 to -3); the lapse times (lead.md 01:33, 08:05).

  Entry 47's "its section 2" is right: GPU-E l.131 lies in §2. P1.md's "section 3" was P1's slip.

### 2. Claims against labels: two defects

- **A refuted claim, restated (defect).** VALIDATION.md:5813-5816: "check_corrector runs every one at binary64 from dt 0.01, which on zonal_saturn exercises the replay and nothing physical (P1; V1)". That is P1's belief (P1.md 22:31). V1 measured otherwise (item 17): the adaptive runs grow from dt 0.01 s to about 1,200 s, roughly an orbit. Only the fixed runs, which reach t = 3 s, are non-physical.
  - **Correction:** "check_corrector runs every one at binary64: its adaptive runs from dt 0.01 s grow to about 1,200 s, roughly an orbit, and its fixed runs reach t = 3 s, exercising the replay and nothing physical (V1)."
- **The three named refutations: confirmed.**
  - "21 mul (+13)" appears only as P1's first count; 34 is used everywhere.
  - Entry 49's "reads and runs as before" is stated for 2638e72, where V3-2 measured it through a pipe and from files.
  - "Cannot carry a rejected step" appears only qualified.
- **A gate overstated (defect).** README.md:249-250: "the ring's generator, and a wave at every format against REBOUND and its ensemble". check_ring runs ias15_ref (check_ring.py:653-677) and the ensemble comparison (:689-691) at binary64 only.
  - **Correction:** "the ring's generator; a wave at every format on both engines, and at binary64 against REBOUND's own IAS15 and its ensemble".
- **Minor: RING.md:93**, "another format, arithmetic, producer or problem refused". Another producer's record passes (V4-1 item 2). What is refused is a record lacking a rerun field, as ias15_ref's is. It should say that.
- **Minor: ROUND4.md:691-692 and VALIDATION.md:5713-5714.** They say gate 4's control "is" the binary128-only rounding, and that the plan's control is "kept, asserted". Both were copies, run once by P1 and by V1 and then deleted; check_zonal.py only names the control (:92). Add "run from copies; not a permanent control".
- Beyond those, no figure is labelled MEASURED where its source says BELIEVED or READ.

### 3. Derived counts: confirmed

- I counted the `--leg` lines per target by script: 24/24/24 at d9c8c8c, in the same order in all three tiers.
- The earlier counts are 19 at 7a7a279 and 9e9879f, 20 at 291c99c, 23 at 7d50392 and 24 at e5636a9.
- README's options are all in the parser: `--attempts-out` (:4547), `--run-key` (:4548, :4653-4664) and `--zonal-selftest` (:4539). Its grammar matches read_problem() (:1022 and the comment above it).

### 4. Pin line: confirmed

The 922c2ad row is byte-identical (equal md5); it moved from :180 to :182. check_pins.sh:41 greps for the hash anywhere in README.

### 5. LEAD-FILL: confirmed

There are exactly two markers, at VALIDATION.md:6546-6547. There is no TODO, TBD, FIXME or XXX. The only blank cells are the header corners at RING.md:24 and :265.

### 6. Consistency: stale after D

The commits, counts, merge order and decisions agree across RING.md, ROUND4.md, ROADMAP.md and entries 46-51. But lead.md's 08:56 entry, written after D's commit, changes the plan: P3 takes d9c8c8c's suite alone, and the docs get a suite of their own. So:
- **VALIDATION.md:6547**, "P3's final suite on `round4-int5` with these docs", needs to become two markers: one for d9c8c8c's suite, and one for the docs commit's suite. The second can only be recorded "docs aside", as entry 45 did.
- **VALIDATION.md:6386** ("three suites rather than four") and **ROADMAP.md:862** ("the last two suites") need the 08:56 change.
- If the docs commit adds `--zonal-selftest` to the usage block, entry 47's limit at :5817-5818 must go.
- Minor: ROUND4.md:682 says the ledger is "archived as" the zip, where entry 46 (:5449) says "is to be archived as". Make both match what lands.

### 7. D's nine items

1. Right: P4 was resumed at 01:40, 03:46 and 04:34, and V4 sent it back twice.
2. Right (lead.md 01:33).
3. Right: both figures pass gate 4, and each is cited by name.
4. Right: the parser at :4539 and ias15_zonal.inc:75.
5. Right (08:05 to 08:13).
6. Right: check_ring.py:14-16 still says the zonal line is refused.
7. Right: P4's six digests (P4 report l.11) are other digests. Entry 45's six appear in both logs.
8. **Wrong.** The 7d50392 log ended `rc=0` at 09:09:48, with 23 legs and all six digests present. The first marker can be filled now, and CLAUDE.md's "last measured" make check row should then move to that suite.
9. Partly right. README's times (:582, :587, :622, :712) are undated figures from 19 legs, and its 31-minute check-light now sits against CLAUDE.md's 63 minutes. Add "(19 legs, 2026-11-06)".

### 8. Anything else (minor)

- **CLAUDE.md:75-76**, "only the particle's x": control p also planted the primary's x (VL-1 item 5). Say "only x".
- **VALIDATION.md:6240**, control i "NOT WIRED and exit 1": that was the control at 79bd206. Since e5636a9, control i holds the not-callable states (check_compare_run.py:1026-1057).
- **RING.md:104-106** drops `[--programs programs/out]` from compare_run's usage (compare_run.py:10).
- **RING.md:46-47**, "not a multiple of 57 is refused": that holds for waves only. `--one-system` is exempt (make_ring.py:288).
- **CLAUDE.md's times are not like for like.** Entry 45's runs were from clean with the build, while 291c99c's suite and VL's check-light ran on built trees.

**NOT READY.** Two fixes are required: README.md:249-250, and entry 47's check_corrector limit. The second LEAD-FILL marker and the suite count must also be brought into line with lead.md's 08:56 plan. The rest is minor.
