# P1 report: J2 and J4 in libcft's format

P1 is done and every gate passes. The full `make check` on b3f664b ended rc=0 at 01:40:35 after 2 h 32 min. It ran all 20 legs in full mode, with 977 `^  ok ` lines and no line containing FAIL. Every leg printed its verdict, there were no fork errors, and the single `--` line is gate_subprocess's body_count, as on main. Seventeen of the 19 existing legs have exactly P0's ok count. The other two grew only by the cases my new problem file adds: check_corrector +24 and check_scalar +9. P0's six digests are unchanged, and check_records passes, so no committed record line moved. `make check-light` also passed: rc 0, 20 legs, 671 ok, 0 FAIL.

Branch `worktree-agent-a3eb979b1b380c4cf` on base 9a42b1d has four commits: c0c99be, 06adb1a, b3f664b and 22ca3de. The last changes only the head comment and one verdict's text in check_zonal.py; I reran that gate in full on it with the same binary: 87 ok, PASS. Nothing is pushed or merged.

## Three things that bear on the round

- **Your first control can't fail gate 4 (measured).** If the term is rounded to binary64 in both runs, binary128 and binary256 still agree to 3.371e-33 over 120 shared steps; the correct build gives 3.402e-33. Rounding the same value twice gives the same bits, so the defect cancels. I posted this as `urgent/P1-gate4-blind.md` and applied your 01:33 ruling. The gate's head now states gate 4's scope, its verdict prints that scope beside the number, and its control is the binary128-only rounding.
- **I found and fixed a dead check in my own gate.** The dropped-reaction control first *passed* gate 2's line for body k ("|error| 0.998, the bound 0.998"): the bound absorbed the formula error. It now fails, as shown in the noreact row below.
- **I chose REBOUNDx's order from memory, unverified.** REBOUNDx isn't pinned here and I didn't read it. If your answer to decision 4 pins it, the first op-for-op comparison will confirm the order or correct the include's head. The cost: 10 divides and 1 square root per body per force evaluation, where GPU-E priced 1 divide.

## What changed

- **`src/ias15_zonal.inc`**: the whole term.
  - **Acceleration.** Every other body in each system gets J2 then J4, as vector library calls over all of them, with no FMA.
  - **Reaction on k.** It is `(G·m_j)·prefac·fac·d`, which is the brief's "term × m_j/M" in exact arithmetic, but with no divide by M. Body k subtracts the reactions in ascending body order, from bodies that act on active ones only: under `active n`, a test particle feels the term and gives no reaction.
  - **Potential.** It is added after the pair terms: each interacting body's J2 part in ascending order, then each one's J4 part.
  - **Record line.** It names R, J2, J4 and the two counts, e.g. "acts on 2 bodies a system, and body 0 takes the reaction of 1".
  - **Trace and selftest.** Every operation and every element move is traced. `zonal_ready()` refuses by name, before any output, a zonal line whose body is a test particle. The library half compiles a stub.
- **`src/ias15_cft.c`**: only the lines the brief allows, plus the two comments that described the refusal.
  - P0's refusal line is deleted.
  - `--zonal-selftest`: a declaration, its parse, and its dispatch.
  - A one-line hook, `if (zonal_on) zonal_ready();`, after the active line is applied.
- **`tools/gen_constants.py`**: check 3 derives the 19 integer coefficients from P2 and P4 and checks them against mpmath's derivative of the potential. It emits `zonal[]` and the `IAS15_ZONAL_*` index names.
- **`src/ias15_constants.h` and `data/ias15_constants.json`**: regenerated, additions only.
- **`data/problems/zonal_saturn.txt`**: Saturn, a Mimas-like moon inclined 3°, and a ring particle at the Encke gap inclined 2°, under `active 2`. `check_zonal.py --write-problem` derives it, and the gate holds the committed file to that byte for byte.
- **`tools/check_zonal.py`**: the gate (outlined below).
- **Makefile**: one `check_zonal` leg in each tier, with every executed artifact an `--input`, including the golden model's files and `third_party/MANIFEST`. `IN_SCALAR` gains the include.
- **Boundaries I crossed, and why:**
  - `tools/check_gravity.py`: P0's refusal case is replaced by "accepted, named by the record, carried by the run key". ROUND4.md says P1 replaces it, though the brief's file list omits that file.
  - `tools/check_scalar.py`: the recount now reads `*.inc` files and `zcall()` sites, and lists the term's constant operands as their own printed "left" kind. I added the zonal problem as a matrix case because that gate fails unless every file in `data/problems/` is one of its cases.
  - `IN_SCALAR` in the Makefile, because the recount now reads the include.

## Formula, order and reference radius

- **Order: REBOUNDx's `gravitational_harmonics.c`, as I recall it, evaluated left to right.**
  - Shared: `r2 = dx*dx+dy*dy+dz*dz`, `costheta2 = dz*dz/r2`.
  - J2: `3.*J2*R*R/r2/r2/r/2.`, with `fac = 5c2-1` and z's factor `fac-2`.
  - J4: `5.*J4*R^4/r2/r2/r2/r/8.`, with `63c2c2-42c2+3` and z's factor `fac+12-28c2`.
  - The coefficients are stored signed and added, which gives the same bits as REBOUNDx's subtractions.
- **Why:** one order serves both forms, and a binary64 comparison with REBOUNDx (decision 4) could be op for op.
- **Cost, counted from the trace:** per body per force evaluation, 3 sub, 21 mul (+13 for a body whose reaction counts), 14 add, 1 sqrt and 10 div. Two of the divides are by 2 and 8, which are exact. There is no FMA.
- **Physics problem's values:**
  - **R = 60,330 km.** BELIEVED, the study's belief and mine: the reference radius of Cassini's gravity solutions, not the 60,268 km equatorial radius. The source table doesn't state it.
  - **J2 = 16290.573e-6, J4 = −935.314e-6:** Iess et al. 2019, via Fortney et al. arXiv:2304.09215, Table 4.1.
  - **GM = 37.931e6:** NASA's Saturn fact sheet.
  - **Mimas's GM and a:** JPL SSD.
  - I took all of these from GPU-E §4's table and did not read the primary sources.
- **Gate 2's bound** comes from each traced value's chain of roundings (γ_k = k·u/(1−k·u), with k up to 61), applied to the dataflow evaluated in absolute values, plus 1e-150 for mpmath's own error. The dataflow evaluated exactly must also equal mpmath's gradient within 1e-150, which checks the formula apart from its rounding. At binary256 the widest bound is 1.33e-69 of the term, inside the 1e-68 asked.

## Gate output (actual lines, from the suite log)

What the gate does, in brief: gate 1 checks every traced operation against cft-fp256's golden model and checks that each operand is what the trace last left. Gate 2 compares 14 points (10 off the plane, 4 on it) and each system's reaction and potential with mpmath at 200 digits. Gate 3 covers energy and momentum at every format and the apsidal and nodal rates at binary64. Gate 4 is the binary128/binary256 format difference. The rest covers both engines, an ensemble against its members, the 2^-40 test-particle case, the record line, the run key's `zonal=` field, and three refusals.

- `ok   126 operations, 1382 elements, each against the golden model's bits and flags (flags seen 0x10), … : 0 mismatches; 10 points off the plane … and 4 on it …: 0 wrong` (all three formats)
- `ok   fp256: the bound is 1.33e-69 of the term at its widest, against the 1e-68 asked`
- `ok   fp256: J4's z part over the bound, at its least off the plane: 1.3e+66 (wanted above 1000, …)`
- `ok   fp64, 1100 steps adaptive: the energy, Phi's J terms included, moves 1.56e-15 of itself; the same orbits without the term, 1.22e-15 (…the bound is 10 times it)`
- `ok   fp128: the total momentum moves 2.16e-34 of the bodies' |m v|, and 2.88e-34 without the term …`
- `ok   the apsidal rate (wanted positive: the apsides advance): 6.61078e-7 rad/s over 30.2 orbits; first-order theory 6.6178e-7 (n - kappa); off by 0.00106, against the second order's 0.00359 …`
- `ok   the nodal rate (wanted negative: the node regresses): -6.5874e-7 rad/s over 30.2 orbits; first-order theory -6.6178e-7 (n - nu); off by 0.00459, against the second order's 0.00866 …`
- `ok   the nodal rate, J4 resolved: the same theory without J4 gives -6.4278e-7, 0.0248 off the measured rate …`
- `ok   121 samples on the same 120 steps: the positions differ by 3.4e-33 of the distance from Saturn at most, against binary128's round-off, u128 * steps^2 = 1.39e-30 (binary64's: 1.6e-12), and must differ at all; the term itself moved them 0.201`
- `ok   fp256: the program engine against the loop engine's FMA-form record, 4 samples: identical; each engine and form against its run without the zonal line: every one differs`
- `ok   the schedule replayed under another J2: rc 3, refused by name; the keys differ in zonal (…)`
- `RESULT: PASS`

I chose to hold the run key's `zonal=` field in my own gate, part 5. A schedule replayed under another J2, J4 or R, or without the zonal line, is refused, and the two keys differ in `zonal=` alone.

## Negative controls

Each was built from a copy of `src/` in scratch, run against `check_zonal --quick`, and then deleted; the logs are kept at `scratchpad\p1\ctl-*.log`.

| control | result (measured) |
|---|---|
| Term rounded to binary64 in both runs (your first control) | **Passes gate 4**: 1.43e-33 against a bound of 1.54e-31 (3.371e-33 over 120 steps). Gate 1 fails, naming op 29: "operand tx[0] is …af000000000000000, and the trace last left …aed9f7c569b5e5fbb there". Gate 2 fails at 1.4e-17 to 8.3e-17 of the term against bounds near 1e-32. 3(c) also fails: momentum moves 2.22e-20 against 1.55e-34. |
| Rounded at binary128 only (gate 4's control under your ruling) | Gate 4 fails: 5.77e-19 against 1.54e-31 (4.0e-18 over 120 steps). |
| J4's z part dropped, using the trace's own arithmetic | Gate 1 passes. Gate 2 fails at all 30 off-plane checks, e.g. u = −0.998: 2.37e-2 of the term against a bound of 3.16e-14. It passes at all 12 on-plane checks. |
| z sign of the force flipped, potential untouched, traced | 3(a) fails at every format: the energy moves 4.35e-5 (fp64) and 4.16e-5 (fp128, fp256), against 1.2e-15 and 7e-31. Momentum holds. The node advances at +1.32e-6 rad/s. |
| Reaction on body k dropped | 3(c) fails: momentum moves 5.97e-3 and 5.06e-3 of \|m v\|, against 4e-16, 2e-34 and 7e-72. Gate 2's body-k line now fails at 0.998 of the reaction. |
| One ulp on op 54, element 5, after the C's own consistency check | Gate 1 alone fails at each format: "operation 54 (mul f = f mul c2) element 5: the library gave 3fd39e573c6ee1a1 …, the golden model 3fd39e573c6ee1a0". |
| Reaction also taken from test particles (an extra control) | Gate 2's body-k line fails at 1.19e-4 against 1.5e-14. The 2^-40 integration case reports "THEY DIFFER". |

## What I did not do

- No REBOUNDx comparison; that waits on decision 4.
- Nothing on a card, a GPU or WSL, and no speed claims.
- No J2/J4 in the drop-in; its library half has a stub.
- Rates (3b) are measured at binary64 only.
- I added no check that the constants header is current.
- I didn't touch the usage block at the top of `ias15_cft.c` or README's option list, both of which lack `--zonal-selftest`.
- The selftest's pair is synthetic: R = 1.5 with Saturn's J2/J4 numbers, used for arithmetic only, and its comment doesn't say so.
- **`--light`:** every case integrates to a step count. `--quick` cuts them for check-quick and check-light (600 binary64 steps and 40 wide ones, against 1100 and 120). No case is a check_dropin case, so `--light`'s step scaling never applies.

## What the brief or ROUND4.md got wrong

1. **Gate 4 can't fail on the first control as written**, as measured above. GPU-E §6 item 3(b) rests on the same premise.
2. **"The constants leg checks the header is current" is not so.** `gen_constants.py --no-write` returns after its derivation checks and never compares the header or JSON. A stale header passes every tier.
3. **The file lists left out files the job needs.** P0's refusal case lives in `tools/check_gravity.py`, which my list omitted. A file in `data/problems/` must also be a check_scalar case, and check_corrector runs every one at every mode.
4. **"Exactly zero for a test particle" holds as written only for a massless one.** I implemented `testparticle_type` 0, where a test particle gives no reaction whatever its mass, and two controls hold that.
5. **check-light took 40 min 50 s, not 31**, on a shared host.

Ledger entries are in the drop's `P1.md` and in `urgent/P1-gate4-blind.md`.

Files are in `C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-a3eb979b1b380c4cf\`:
- src\ias15_zonal.inc
- tools\check_zonal.py
- data\problems\zonal_saturn.txt
- tools\gen_constants.py
- tools\check_scalar.py
- tools\check_gravity.py
- Makefile

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p1\`:
- p1-check.log
- p1-check-light.log
- gate-full-final.log
