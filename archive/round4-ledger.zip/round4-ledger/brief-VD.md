You are a **verifier** of round 4's records. You try to disconfirm, and you report. You fix nothing.

## What to verify

Commit `79128a1` on branch `round4-docs`, in the repository `C:\Users\logan\source\repos\cft-rebound`. It is one commit on `d9c8c8c`, by the round's docs drafter (D), and it changes six documents:
- docs/VALIDATION.md, new entries 46-51;
- docs/RING.md (new);
- CLAUDE.md, README.md, ROADMAP.md and ROUND4.md.

These are the project's permanent record, and the integrator lands them. A wrong number there misleads every later round, and a claim stronger than its evidence is the failure this project exists to prevent.

D's report is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\D-report.md`. It lists every number D wrote, with its source, and nine things D could not resolve. D's own brief is `...\scratchpad\gpu\briefs\filled\D.md`, in the same scratchpad.

**The sources** (read only):
- the parcels' and verifiers' reports in `...\scratchpad\gpu\reports\`;
- the ledger `C:\Users\logan\source\repos\cft-rebound\.ledger\`. lead.md is the authority on merges, suites and rulings;
- the suite logs `...\scratchpad\gpu\p0-check.log` and `int-check-291c99c.log`;
- the commits, `git log --format='%h %s%n%n%b' 7a7a279..d9c8c8c`;
- the code at d9c8c8c.

## How to work

You are in an isolated worktree: `git checkout --detach 79128a1`. No build is needed, and do not run any suite: one is running on this host. Do not edit any tracked file, here or anywhere. Stay out of `C:\Users\logan\source\repos\cft-rebound-r4` and `cft-rebound-seam` (the lead's), `C:\Users\logan\source\repos\cft-fp256` (another session's), and the other worktrees. Never run bare `git stash`. Never push, merge or rebase.

## Check

1. **Every number against its source.** Use D's list as the index. Check at least every number in RING.md and in CLAUDE.md, and a sample of at least 40 across entries 46-51 that covers every entry. For each, report the source line, and whether it matches. Report each mismatch exactly.
2. **Every claim against its label.**
   - Is anything stated as MEASURED that was only BELIEVED or READ?
   - Is anything a verifier refuted still stated? (V1 corrected "21 mul (+13)" to 34. V3 refuted "an older dt file reads exactly as before". P3 and P4 refuted "a replay cannot carry a rejected step".)
   - Does any sentence overstate what a gate holds? Read the gate's code where needed.
3. **Derived counts.** Recount from the Makefile at d9c8c8c the legs per tier that CLAUDE.md states. Read the options README states against src/ias15_cft.c's parser.
4. **README's pin line.** Does README.md still name `922c2ad` exactly as before? tools/check_pins.sh greps for it.
5. **The LEAD-FILL markers.** Are there exactly the two D lists, and no other placeholder, TODO or empty table cell?
6. **Consistency.** Do RING.md, ROUND4.md's new section, ROADMAP.md and entries 46-51 agree with each other: the commits, the counts, the merge order, the decisions said to be Logan's?
7. **D's nine open items.** For each, say whether D's resolution is right.
8. **Anything else** a reader of these records would be misled by.

## Report

For each item: what you checked, what you found, and a verdict (confirmed, or defect with the exact text and its correction). End with READY or NOT READY. Keep it under 1,500 words.
