**V2 re-check of P2 at 8bb49b9: READY.** The fix closes the gap I reported: the gate now fails a ring with any moon flat in Saturn's plane, and fails a stand-in binary at ias15_ref's path. The generator still writes the same bytes. I found nothing new.

I checked out 8bb49b9 detached (its parent is 250789e). `make all programs` rebuilt nothing: the two executables have the same sha256 as before. The rest of my first verification stands, as you said. Logs and scripts are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\r2\`; the copies are deleted and `git status` is clean.

**(a) Scope: confirmed.** `git diff --stat 250789e 8bb49b9` shows only `tools/check_ring.py` (+97/−33) and `tools/make_ring.py` (+17/−13).

**(b) Generator bytes: confirmed.** I ran 250789e's `make_ring.py` (from `git show`) and 8bb49b9's on the same arguments. All five pairs are byte-identical:

| Ring | Size | sha256 |
|---|---|---|
| default, 228 particles, `--no-zonal` | 41,859 bytes | 179a90f0… (same as my first verification) |
| zonal, 228 particles | 42,021 bytes | e6265e9d… |
| exclusion at 300 Hill radii (63 draws refused) | 11,978 bytes | 360eeb03… |
| one system, 300 particles | 49,556 bytes | cf706e67… |
| zonal, 57,000 particles (2 draws refused) | 9,959,223 bytes | 161d5246… |

The new bound only acts when more than 99n + 1,000 draws are refused. `--exclude-hill 1000` now stops after 6,644 refused draws with "Lower --exclude-hill", rc 1, and writes no file.

**(c) Control C, all six moons flat: fails by name.** Gate run with `--quick` on a copy whose moons all have inclination 0: 33 ok, 1 FAIL, RESULT: FAIL, rc 1. The failing line is "FAIL the moons are not flat … mimas 0.0000, pan 0.0000, … janus 0.0000 degrees". On 250789e the same control passed.

**(d) My second control, Pan flat and the other five inclined: fails by name.** 33 ok, 1 FAIL, RESULT: FAIL, rc 1. The line reads "mimas 1.0000, pan 0.0000, prometheus 0.0500, …". This is the realistic case if an epoch's elements are ever used, since JPL lists Pan's inclination as about 0. It shows the check is made moon by moon, not on the largest value. The shipped gate's line also confirms why P2 chose sin i over |z|: "pan's z from Saturn is 0.0 km, at its node, which |z| would call flat". The formula sin i = |(h_x, h_y)| / |h| with h = r × v is correct, and it is exactly 0 for a flat orbit whether prograde or retrograde.

**(e) Stand-in at ias15_ref's path: fails by name.** I put a copy of `ias15_cft.exe` at `build/ias15_ref.exe`. It accepts ias15_ref's arguments and defaults to fp64, the loop engine, REBOUND's form and 12 passes. The bit comparison still passed ("1940 values identical"), which shows that before this fix the stand-in would have gone through. The new identity line fails: "FAIL ias15_ref.exe (built 2026-11-12 01:42:20) says `program=cft impl=libcft-0.18`". RESULT: FAIL, rc 1. The gate's first line now prints both binaries' build times.

**(f) The gate in full and in `--quick`: confirmed.**

| Mode | ok | FAIL | Result | Runs | Time |
|---|---|---|---|---|---|
| full | 40 | 0 | PASS, rc 0 | 23 | 391 s |
| `--quick` | 34 | 0 | PASS, rc 0 | 15 | 188 s |

Against 250789e's full run, the ok lines are the same 37 checks (two reworded) plus three new ones: the moons not flat, the exclusion bound, and ias15_ref's identity. All the numbers are unchanged (1.698e-11, 4.329e-30, 1.907e-68, 2716 values, 35.89 steps an orbit, −0.9%). The file check now holds N, E and active against make_ring's WAVE 64 and MASSIVE 7, read from the generator rather than typed in. The flat-copy self-test now covers both the |z| counter and the moons' inclination.

**READY.**
