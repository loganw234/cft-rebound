# V4 re-verification of P4 at f27f9c6: NOT READY

f27f9c6 fixes everything I reported, and the rest of my first verification stands. But the one mutant of my own choosing passes the whole new gate (item b).

**Setup.** I ran `git checkout --detach f27f9c6`, then `make … all programs`. The ias15_cft and ias15_ref binaries have the same hashes as at 517e8d5 (9d56b9aa…, e859a363…). All edits were to copies, now deleted, and the worktree is clean. Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v4\` (mt2.py, r2check.py, r2_*.log).

**(a) Diff: confirmed.** `git diff --stat 517e8d5 f27f9c6` shows three files: the Makefile (8 lines), tools/check_compare_run.py (154) and tools/compare_run.py (49). Nothing under src/ changed.

**(b) Mutants: two caught, one not.**
- **My float() mutant** (compare_run.py:744 changed to `if float(a[0]) != float(b[0]):`): `--quick` gives RESULT: FAIL; a3 and a4 both catch it.
- **A sign-only mutant** (`if a[0] != b[0]:`): FAIL, caught by a3 alone. So each new control bites on its own.
- **My mutant of choice: `compare()` skips the exact-time pair.** I changed line 743 to `zip(rv[:-2], mv[:-2])`. This is exactly what `check_equivalence.parse_record` does, and check_records uses that function. **It passes the full gate: 63 ok, 0 FAIL, RESULT: PASS.**
  - I tested it on a copy of a 9-wave fp64 record, with one digit of member 2's t_hi at step 40 changed.
  - The shipped driver FAILs it, naming "the exact-time pair's t_hi". The mutant passes it with rc 0.
  - On that line t is …230a and t_hi is …2309, so the pair carries information that t does not.

**Defect, the same kind as D:** the shipped code is right, but the gate would not catch it if it weren't.
- **Concrete scenario:** a GPU record whose positions match but whose exact-time pair does not. That pair comes from vaugadd, the path your 17:50 entry expects to meet G1B's AUGADD refusal on hip:N. Such a record would pass every tier as soon as someone moved the driver onto `parse_record`, which drops the pair.
- **Fix:** one permanent control past the bar (t_hi or t_lo), asserted to FAIL naming that field. A loop that builds one control per field from the record's own `# columns:` line would close this kind of gap for good.

**(c) Cache key: confirmed.** I ran this through make's own expansion, in a full copy of the tree: `make -n check-quick`, then the leg line exactly as printed.
- The cold run (76 inputs) ran: 41 ok, PASS. Repeating it gave SKIPPED.
- With an empty `tools/extract_particle.py` added, make printed 77 inputs, including `--input tools/extract_particle.py`.
- The leg then reran and failed: rc 1, 6 FAIL lines, all of them the particle seam firing (the driver now exits 1).
- A second repeat reran and failed again, because the failure retired the stamp.

**(d) a4's bits: confirmed.** a4 changes member 6's tp0 x on line 85 of the binary128 record, from …dd29d to …dd29c (hex digit 28 of 28). I checked both values two ways that don't use the gate's parser: integer round-half-even, and `float.fromhex`. Both round to `-0x1.b89bcdf740563p-3` (bits bfcb89bcdf740563). Digit 14 is `c`, far from a rounding tie.

**(e) Gate runs: confirmed.**
- **Full mode:** 63 ok, 0 FAIL, RESULT: PASS.
- **`--quick`:** 41 ok, PASS (the cold cache run in (c)).

All the new verdicts are present and ok:
- a3 and a4;
- h, which names "pairs a force evaluation";
- the three i lines: with neither of P3's files, PASS and rc 0; with each stand-in, NOT WIRED, RESULT: FAIL, rc 1;
- the sample's limit, at fp64, fp128 and fp256.

**Other claims, confirmed by reading:**
- The new rounding count is right: x takes two roundings, y, z and vx four, vy and vz six, in both `body()` and `flyby()`.
- `SAMPLE_LIMIT` is stated in the driver's header and printed once, after the sample line.
- The `# active` refusal names the field that differs.

I did not re-run P4's 18 mutants.

**NOT READY**, for the exact-time pair alone. Everything else in f27f9c6 is confirmed, and the fix is one control in check_compare_run.py.
