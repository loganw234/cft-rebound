I've finished every item and all the runs, so here is the report.

# V1 on P1 at 22ca3de: READY

**Summary.** The zonal term is right, its gate can fail, and nothing outside the term moved. I derived the force independently, rebuilt seven controls from copies, and compared 100 untouched-path runs between the two commits; everything agrees with P1's account. What I found is text and one seam:
- two comment sentences are wrong or unqualified;
- a cost claim the trace contradicts;
- P0's parser, now reachable, silently accepts a second `zonal` line.

**Setup.**
- Detached at 22ca3de; the pins were cloned locally and checked against MANIFEST.
- Two clean builds, `make … all programs archive` with the PATH line, both rc 0: this worktree, and a `git archive 9a42b1d` export.
- Every script and log is in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v1\`. The control copies are deleted, and no tracked file changed.

## Items

1. **Confirmed.** I derived −∇Φ_z by hand and compared it with `--zonal-selftest` at all three formats, decoding the bits with my own decoder in an mpmath script.
   - Worst relative error, reaction and potential included: 6.7e-16, 2.5e-34 and 1.6e-71.
   - Gate 2 differentiates the potential (`mpmath.diff` of a φ built from `mpmath.legendre`), not the force.
   - That reference matches my closed form to 2.8e-201, so 200 digits is ample for the 1.33e-69 bound.
2. **Confirmed.** The points are 6 north of the plane, 4 south and 4 on it, at r from 1.18 R to 17 R. In the J4-z control (`fz − fz` in J4's pass, traced):
   - gate 1 passes; all 30 off-plane lines fail, and all 12 on-plane lines pass;
   - the body-k lines, 3(a) (2.8e-7) and the nodal rate fail as well.
3. **Confirmed.**
   - The include has 70 `zcall()` sites and no other library call in the term (grep). My hand count, 80 + 46 = 126 operations and 1382 elements, equals the trace.
   - Per body per evaluation: 3 sub, 34 mul, 14 add, 1 sqrt, 10 div.
   - Nothing can escape the trace: every operand is checked against the trace's last write, and every printed result against the trace's state.
4. **Confirmed.** The reaction is subtracted in ascending body order, J2 then J4, and a test particle's is never added. 3(c)'s second body is Mimas (GM 2.5). With the reaction dropped:
   - 3(c) fails: momentum moves 6.0e-3, 5.1e-3 and 5.1e-3 of |mv|;
   - the body-k lines fail, and gate 1 passes.
5. **Confirmed by measurement.** The include has no FMA, and its helpers are plain `cft_run`, `cft_div` and `cft_sqrt`. An instrumented copy hashed x and a around every `zonal_accel()` call on the zonal problem, at every format:
   - program/fma equals loop/fma at all 160, 349 and 510 calls;
   - loop/rebound equals loop/fma at all 62 calls whose state matched before the term;
   - the selftest trace is byte-identical under all three settings.
6. **Confirmed.**
   - The 19 integers come from the header through `kderived`; the term has no coefficient literal.
   - The `constants` leg is rc 0 at both commits, with output identical except check 3's two lines.
   - Regenerating into scratch reproduces the committed header and JSON byte for byte.
7. **Confirmed, with one stated limit.** Flags are 0x10 at every format for a moon at 3.56e6 km, a body at 60,500 km, a body with dz = 0, and a test particle 1 m off the plane. Body k is never gathered.
   - The limit: at binary64, dz²/r2 underflows when |dz| ≲ 2e-149 km at the Encke gap, and the run aborts (measured: `div raised 0x18`).
   - That window is wider than gravity's own (1.5e-154 km). Neither is reachable.
8. **Confirmed.** P1 extended the recount to read `*.inc` files and `zcall()` sites. `check_scalar.py --library`, full mode:
   - 90 ok at 9a42b1d and 99 at 22ca3de, both PASS;
   - the extra 9 are the zonal case at 3 formats × 3 engine/forms;
   - the recount still finds 24 sites, with existing "left" entries byte-identical; it adds ZK (constants go from 44 to 45) and the include's entries.
9. **Confirmed.** zonal_saturn.txt states R = 60,330 km as BELIEVED, with J2 and J4 from Iess 2019 via Fortney and GPU-E §4; every value decodes exactly. The selftest's R = 1.5 and check_gravity's R = 1 are synthetic and not labeled as such.
10. **Confirmed.** Both runs take one dt file (`--dt-out`, then `--dt-file --epsilon 0`), and the bound is u128·steps².
    - Rounded to binary64 at binary128 only: gate 4 fails, 5.77e-19 against 1.54e-31.
    - Rounded in both runs: gates 1, 2, 3(a) and 3(c) fail at fp128 and fp256, while gate 4 passes (3.95e-34 at 40 steps; 1.32e-33 against 1.39e-30 at 120 steps).
    - The gate's head and its verdict state the ruling's scope.
11. **Confirmed: each crossing is necessary and correct, and nothing is weakened.**
    - `check_gravity.py --library`: 41 ok and PASS at both commits. The only changed line is P0's refusal case, now an acceptance.
    - `gen_constants.py`: checks 1 and 2 are untouched.
    - `check_scalar.py`: as in item 8.
    - `IN_SCALAR` gains the include the recount now reads.
12. **Confirmed.** The coefficients come from the Bonnet recurrence, and check 3 compares them with `mpmath.legendre`'s numerical gradient. Copies with J4_Z1, P2_S0, J2_DEN or J4_S2 moved each fail check 3 (rc 1, nothing written). The header and JSON lose 0 lines, and a structural comparison shows only `zonal` keys added.
13. **Confirmed.** This is pinned REBOUND's meaning (rebound.h:268: "active particles do not feel test-particles"), and the energy sums over N_interact (tools.c:117). With every body's reaction taken:
    - gate 2's body-k line fails at every format (1.2e-4 and 4.3e-5);
    - the 2^-40 case reports THEY DIFFER.
14. **Confirmed.** The bound is rigorous: Higham's model, with divisors and square-root operands asserted free of cancellation, plus an exact-dataflow check at 1e-150. Every formula control also fails the exact check. At each control's least favourable point the error exceeds the bound by:

    | control | decades over the bound |
    |---|---|
    | J4's z part dropped | 10.7 |
    | z sign flipped | 13.2 |
    | test particles' reaction taken | 9.6 |
    | reaction dropped | 150 |
    | binary64 narrowing | 14.7 |

15. **Defect (wording).** `src/ias15_zonal.inc:16` opens with "THE ORDER IS REBOUNDx'S." and `:240` says "what REBOUNDx forms for each body", both stated flat; the BELIEVED qualifier is at `:38`. A reader of either line takes the order as read from REBOUNDx when it was recalled. The record line and the gate's output claim nothing about REBOUNDx.
16. **Confirmed.** b3f664b..22ca3de changes only check_zonal.py's head comment and one message. The full gate at 22ca3de: 87 ok, 0 FAIL, RESULT: PASS in 4 min 38 s.
17. **Measured.**
    - check_corrector: the file adds 6 configurations (24 ok lines in check-light) and 18 runs, 60 s one at a time. The adaptive runs grow from dt 0.01 s to about 1,200 s and cover roughly an orbit. The fixed runs reach t = 3 s, so they exercise the replay and nothing physical.
    - check_scalar: 36 runs, 74 s one at a time, covering about half an orbit.

## Every verifier's items

- **Untouched path: confirmed by measurement.** 100 configurations are identical between the commits with timing masked and `calls=` included:
  - 5 problems × fp64/fp128/fp256 × adaptive and fixed × loop/rebound, loop/fma and program/fma;
  - `--cs augmented`;
  - a 4-member ensemble and one member, at fp64 and fp128 on both engines;
  - a `--dt-out` then `--dt-file` replay.

  The library half's preprocessed source gains only two unused arrays. `check_records.py` at 22ca3de: RESULT: PASS, 9 of 9.
- **Controls:** seven rebuilt from copies (above), and P1's two others also behave as claimed:
  - with the z sign flipped, 3(a) fails (4.35e-5, 4.16e-5) while momentum holds and the node advances;
  - one ulp on op 54 fails gate 1 alone, which names it.
- **Scope:** outside the brief's list are gen_constants.py, check_gravity.py, check_scalar.py's matrix case, `IN_SCALAR`, and two comments in ias15_cft.c. All are disclosed and necessary.
- **make check-light** (a clean export of 22ca3de with fresh pinned clones): rc 0, 20 legs, 671 ok, 0 FAIL, no cache skips.

## Findings

1. **A wrong comment.** check_zonal.py:82 says gate 4's bound is "eleven decades under binary64's". u128/u64 = 2^-60, which is 18 decades, and the verdict itself prints 1.39e-30 beside 1.6e-12.
2. **A wrong claim.** P1's report, P1's ledger and this brief say "21 mul (+13 for a reacting body)". In the trace all 13 reaction multiplies are E(N−1) wide, so every body pays 34, test particles included, and theirs are thrown away. The divide and square-root counts are right. The cft-fp256 message should not call "the multiplies agree" measured.
3. **A seam (owner: P0's parser; P1's change made it reachable).** Measured:
   - a second `zonal` line is accepted and silently replaces the first, and the run equals the second line alone;
   - a fifth field on the line is silently ignored;
   - a second `active` line, by contrast, is refused by name.

   No gate covers either case. Failure scenario: a problem written with two oblate bodies runs with one, rc 0.
4. **A count computed beside the term.** The record's "takes the reaction of N" is `zreact` from `zonal_ready()`, not counted from the loop that subtracts. With every body's reaction taken, the record still said 1 (other lines failed).
5. **A soft spot.** check_scalar uses `bodies.get("zonal_ready", "")`. If that function is renamed, the term's constants drop out of the recount with no failure.

**READY.** Findings 1 and 2 and item 15 are text fixes, and finding 3 is for you.
