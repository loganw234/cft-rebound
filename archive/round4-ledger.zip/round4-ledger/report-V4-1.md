check-light is clean. Both "SKIPPED" lines are in-leg notes (gate_subprocess's known body_count line and a `--quick` sweep note), not cache skips: the cold cache recorded all 20 legs. I've re-read the brief, so here is the report.

# V4 on P4 at 517e8d5: NOT READY

The driver is right under every attack I made. The gate has one gap (D below): a driver that compares binary64 values instead of bits passes the whole gate. The shipped code is right; the gate would not catch it if it weren't.

**Setup.**
- `git checkout --detach 517e8d5`, then `git log --oneline -1` printed 517e8d5.
- third_party was cloned locally and both HEADs equal MANIFEST (bdfda4bd, 922c2ad).
- `make … all programs`: rc 0, `cc -dumpmachine` x86_64-w64-mingw32.
- The base was `git archive 9a42b1d` into my scratch, with the same pins; built rc 0.
- Every edit was to a copy, and the copies are deleted. The worktree's `git status` is clean.
- Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v4\`: att.py, mt.py, untouched.py and *.log.

"drive(X)" below means `python tools/compare_run.py X --problem cr_waves.txt --format fp64 --arith rebound --strata 3 --seed 1`, run on copies of a 9-wave fp64 record. Its sample is [0, 1, 2, 3, 6, 8].

**Suites, my runs.**
- **Gate, full mode** (on byte-identical copies of the binaries): 54 ok, 0 FAIL, RESULT: PASS.
- **`make check-light`**, cold cache, 03:01 to 03:45: make rc 0, all 20 legs ran, 0 skipped.
  - 12 RESULT: PASS, plus "78 constants compared, all match", "every case passed", "--wide: passed", check_archive gates 1-3, gate_real ×3 and gate_subprocess PASS.
  - 593 ok lines, 0 FAIL, 0 fork errors. check_compare_run gave 34 ok, PASS.
- **`check_records.py`, full mode**: 9 ok, RESULT: PASS (kepler fixed and adaptive at fp64, fp128 and fp256; outer at fp64 and fp128; kepler aug at fp64).

## The numbered items

**1. Can it pass against itself? Confirmed.** `compare()` reads the record's own lines (pass 2, `extract()`) and the rerun's stdout, both through `check_ensemble.parse`, and compares (exact value, sign) tuples. I planted five differences with drive(copy). Each gave rc 1, naming the member, the record line and the column:
- member 8's E at step 20;
- member 2's dt_next at step 40;
- member 2's sample-0 dt_last made -0x0p+0;
- member 3's step 20 made 21 (reported incomplete);
- in an fp128 record, tp0's x changed in its last hex digit, with the same binary64 value.

**2. Only the record format? Confirmed.** Nothing reads a dump, a schedule or a debug flag, and the `# identity` and `# route` lines are ignored. A copy rewritten as another producer passed: program=gpu, impl=hip-6.2, backend=hip:0, no identity or route lines, one extra header line and one extra trailer line. With engine=hip it is REFUSED, because this tree's exe refuses that engine; with `--rerun-engine loop` it passes.

**3. The particle placeholder? Confirmed.** The line is printed once and asserted exactly in cases 1 and 5. A grep of the driver finds nothing else that touches particles.

**4. Permanent controls? Confirmed.** Controls a, c, e and g each assert the rc and the naming text. My own variants, on copies:
- member 8 deleted, member 5's sample 1 deleted, member 4's trailer deleted, and a duplicated line: each FAIL by name;
- fp256 held as fp128, fp64 held as fp256, and an fp128 FMA record held as REBOUND arithmetic: each REFUSED by name;
- nine problem variants, each REFUSED naming the difference: N 6, E 8, G one ulp up, a system renamed, a body renamed, w7's moon mass one ulp up, w7's tp2 vz one ulp up, active 3, and w3's and w4's bodies swapped;
- comments and blank lines added to the problem: PASS;
- record headers edited (the active pair count, pc_tol, the columns line, pc_tol_shift): each REFUSED by the rerun-header check.

One cosmetic issue: the pair-count refusal reads "active 2 here, and active 2 in the record".

**5. Sampling? Confirmed.**
- `--plan` with seeds 1-3 on 9 waves, and seeds 1-4 on 17 waves with 4 strata, matches my own SHA-256 recomputation. `PYTHONHASHSEED=12345` changes nothing.
- The rejecting members [0, 1, 8] are always added.
- The label reads "AT THE SAMPLES (3 of them, not between them)".

Two limits of the briefed design, both measured:
- A changed line in an unsampled member passes.
- If member 8's trailer is set to 0 rejections and the record's total is adjusted to match, member 8 leaves the sample and the record passes with rc 0. The sample trusts the very counters it is testing.

**6. Reuse? Confirmed.** The imports are at compare_run.py:125-127, and neither imported file is in the diff. The driver's own scan, extract and body reading agree with `check_ensemble.parse` for all 9 members, and for a kepler record.

**7. Format difference on the same steps? Confirmed.** With `--keep`, for members 0, 2 and 8: the replay's header carries dt_file= and epsilon=0x0p+0, the dt file has 41 lines for 40 steps, and dt_last is exactly equal at every sample.

**8. Scope line and rejection note? Confirmed.**
- Every format-difference line ends with the ruled text, plus its note. The gate requires that text to equal SCOPE + note exactly (check_compare_run.py:354-382), and SCOPE is written out in the gate itself.
- The first-attempt test cannot misfire. src/ias15_cft.c:2545-2553 rejects only when |dt_new/dt_done| < 0.25, and :2964 retries at dt_new. A dt-file line is written only for an accepted step (:3001-3002), at the step it was attempted with (:2946). So the file's first line equals dt0 exactly when the first attempt was accepted.
- Measured against a one-step run's rejection count, the test agrees for 17/17 members at fp64, 17/17 at fp128 and 9/9 at fp256.

**9. Member 8's dt_next? Confirmed, no defect.**
- dt_next is left out only in the gate's two dt-file replays, and that is stated at :404-408. In member 0's check, leaving it out makes the assertion stricter.
- With a sample every step, member 8's replay differs only in dt_next, at steps 4, 8 and 10, at fp64 and at fp128. At the gate's sampling (every 20 steps) it differs nowhere, so the exclusion is currently inert.
- The driver's own comparison includes dt_next (item 1 caught a planted dt_next).
- tp0's closest sampled approach to the moon is 7.7e-3 at t = 0.9885, so "meets it head on near t = 1" holds.

**10. The P3 x P4 tripwire? Confirmed, with two caveats.** I made copies with an empty `tools/extract_particle.py`, and with a stub `tools/check_replay.py`. In both, `check_compare_run --quick` gave RESULT: FAIL: 32 ok, 2 FAIL, the particles line in cases 1 and 5.
- **Note:** the driver itself prints NOT WIRED but exits 0, with "RESULT: PASS: …; particles due and NOT sampled". A caller that reads only the exit code sees a pass.
- **Minor defect:** P3's two file names are not inputs of the leg's cache key (`IN_COMPARE`).
  - In a copy, I ran the leg through gate_cache in quick mode, then added `extract_particle.py`. The cached run printed "check_compare_run: SKIPPED - inputs unchanged since it passed", rc 0. The same leg in full mode FAILed.
  - So check-quick and check-light stay green when only P3's files change, although P4's ledger says the leg "fails in all three tiers".
  - P3's actual merge also changes ias15_cft, which retires the stamp, and `make check` always runs the leg.
  - Fix: `$(patsubst %,--input %,$(wildcard tools/extract_particle.py tools/check_replay.py))`.

**11. Members 0 to 7 unchanged? Confirmed.** I wrote both ensembles, using c640f65's `write_waves` (from `git show c640f65:tools/check_compare_run.py`) and 517e8d5's.
- Systems w0-w7 have identical problem text.
- Their sample, system and trailer lines are byte-identical at fp64 (40 steps, sample 20) and at fp128 and fp256 (20 steps, sample 10): 48 lines each.

## The items every verifier checks

- **Untouched path: confirmed by measurement.** I made 144 runs on each build and all 144 records are byte-identical, with only seconds, steps_per_s, wall_seconds and t_* masked. The runs were:
  - 5 problems × fixed and adaptive × fp64, fp128 and fp256 × the loop engine in both forms and the program engine (FMA form);
  - the 9 waves and a 4-member kepler ensemble, each run whole and as members 0 and 3.

  The two executables differ in bytes, but src/ and the program images are identical.
- **Negative controls re-run:** a, c, e and g, independently, from copies (item 4), plus the gate's own run.
- **Scope: confirmed.** The diff is the Makefile, tools/compare_run.py and tools/check_compare_run.py, which is the brief's list.
- **Claims in comments and the commit message.**
  - check_compare_run.py:20-22 (also in P4's report) says "every value is one or two correctly rounded binary64 operations". That is wrong as a count: a test particle's y, z and vx take 4 roundings, and vy and vz take 6.
  - The conclusion it supports still holds: only IEEE operations and sqrt are used, and a rewritten waves file has the same sha256.
  - The commit messages' claims hold (items 8, 9 and 11).

## D. Defect: the gate cannot tell bits from binary64 values

This is METHOD.md §5's named shape. I made one copy with a single changed line, compare_run.py:727: `if a != b:` became `if float(a[0]) != float(b[0]):`. That compares binary64 values and drops the sign.
- Its gate in **full** mode: 54 ok, 0 FAIL, RESULT: PASS.
- That driver passes (rc 0) both of the records the shipped driver fails in item 1: the fp64 record whose sample-0 dt_last is -0x0p+0, and the fp128 record one hex digit off.
- Why the gate misses it: every byte-change control is on an fp64 record, none flips the sign of a zero, and case 1 at fp128 and fp256 tests only that a correct record passes.

**Concrete scenario:** a GPU record that differs from this tree only in the sign of a zero, or only below binary64's last bit at fp128 or fp256, passes every tier as soon as someone makes the comparison "faster".

**Fix:** two permanent controls, each asserted to FAIL naming the member, line and column:
- the sign of a zero flipped in the fp64 record;
- one hex digit past binary64 changed in case 4's fp128 record, which `--quick` already builds.

## Notes

- When a record's sample 0 differs from the problem file, the driver REFUSES (rc 2, "not the problem the record ran"). So a producer that corrupts sample 0 reads as a wrong problem file, not a FAIL.
- ROUND4.md's close-approach sampling, passes per orbit and the second format pair are absent, as P4 disclosed.
- P4's 14 mutants: I read its mutants3.out but did not re-run them.

**NOT READY**, for D alone; everything else is confirmed. The fix is two controls in check_compare_run.py.
