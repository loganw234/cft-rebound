The draft is committed on round4-docs as `79128a1`, one commit on `d9c8c8c` with the Co-Authored-By trailer. It changes only the six documents: nothing pushed, merged or built, and no code, tests or Makefile touched. Every number below comes from a report, a ledger entry, a log or the code, and the lead should still check each one.

## Commit
`git diff --stat d9c8c8c`:
```
 CLAUDE.md          |   38 +-
 README.md          |   67 ++-
 ROADMAP.md         |  120 +++++-
 ROUND4.md          |   54 ++-
 docs/RING.md       |  290 +++++++++++++
 docs/VALIDATION.md | 1175 ++++++++++++++++++++++++++++++++++++++++++++++++++++
 6 files changed, 1730 insertions(+), 14 deletions(-)
```
README still names `922c2ad` on the same line, byte for byte.

## LEAD-FILL markers
- `docs/VALIDATION.md:6546`: the P2 + P4 suite on `7d50392`.
- `docs/VALIDATION.md:6547`: P3's final suite on round4-int5 with these docs.

There are no other placeholders. Both suites have exactly one marker, and CLAUDE.md and ROUND4.md point to entry 51 for them.

## Numbers and their sources
**Derived by me:**
- **24 `--leg` lines in each tier** at `d9c8c8c`, counted with awk per target recipe.
- **Ok counts:** 857 and 980 lines matching `^  ok `, 19 and 20 legs, 11 and 12 `RESULT: PASS`, counted by grep on `p0-check.log` and `int-check-291c99c.log`.
- **Entry 45's six digests** appear in both of those logs.
- **GPU-E:** byte-identical between `56006987` and `be40005b` (git diff, 0 lines).
- **check-quick's commit `9e9879f`:** found with `git log -S` on entry 45's sentence.
- **Quoted gate lines:** from `int-check-291c99c.log` lines 1027 and 1052–1133.

**From the lead's ledger (`lead.md`):**
- The suites' start and end times and durations: 2 h 20 min, 2 h 47 min.
- The fork failure at leg 7 of 19, then 170 ok when rerun alone; controls (a)–(d).
- V0's 117 runs, 9 of 9 keys and its 3 energy problems.
- Per-leg counts 302/44/99/87.
- All merges, branches and times: 05:38, 06:00, 21:20–01:31, 3 h 17 min, "up to 4 h", 60 s, 08:05.
- Seam part 1's km figures, 1.5e-4, 1.8% and 18×; part 2's 64 of 72.
- The cft-fp256 messages, 66 ok and 42 ok.

**From commit messages:**
- `110834f`: 9.0e-4, 5e-3, 2.8e-2, 31×, 8.3e-3, 1.2e-15 over 360 steps.
- `acf9fff`: 192–432 values.
- `7a339d1`: 25 held, 21 ok.
- `d9c8c8c`: 15 of 27 held.
- `7d50392`: 16 columns over 3 records.
- `79bd206`: 12 columns over 2 records.
- `2638e72`: 385 lines × 32 bytes = 12,320 bytes.

**P1's report and urgent file:** 3.371e-33, 3.402e-33, 4.029e-18, the seven-row control table, 977 ok, 2 h 32 min, 87 ok, "21 mul (+13)".

**V1's report:**
- Worst errors 6.7e-16, 2.5e-34 and 1.6e-71; 2.8e-201.
- 70 sites, 126 operations and 1,382 elements; calls 160/349/510 and 62.
- 9.6 to 150 decades; 100 configurations; 671 ok.
- 2e-149 km and 1.5e-154 km; 34 mul; 1.32e-33.

**P2's report and ledger:**
- 41,859 bytes; 1.698e-11; 420 against 2,016 pairs; 2,716 values; 2.161e-02 km.
- 35.89 against 36.2, −0.9%; 0.149 km.
- 1,388.09, 49,819, 1,423 and 1,471 s; 38.4 and 39.3; about 3%.
- 174,691,521 bytes; 49 of 1,000,057 draws (2/19/28); the radii and |z|.
- e 0.0045–0.0053, out to 143,253 km; 1.7e-11; 4.3e-30 and 1.9e-68; 894 ok.

**V2's reports:** 31 ok; 1,645 and 399,049 values; 2 of 57,002; 72 runs and 315 lines; 33 ok and 1 FAIL; 1,940 values; 6,644 draws; 40 and 34 ok.

**P3's report and ledger:**
- 0 of 7; 5, 7 and 7; 0 of 48; 19 and 21.
- The control table: 26, 37, 4 against 5, 29 against 42, 34–36, 21–22, 5.
- 33 of 64; 276, 303, 119 and 1,133 ok.

**V3's reports:** 4,096 bytes, line 129, 6,528 values, 144 of 144, 0 of 61, 31 configurations, 62 of 62, 118 ok and 1 FAIL, 32 of 40.

**P4's report and ledger, and V4's reports:**
- Mutants 12/14/18/21; 907 ok; 857 against 858.
- 54 and 63 ok; 17/17/9; 15 columns; 42 ok.

**VL's reports:** 44 and 45 ok; 24 of 24; 12 of 12 and 9 of 9; 406 tokens; 1.17e-2 and 3.72e-2; 30 of 30; 60 of 60; 890 ok and 63 min; 1.4%; 29 columns; 27 and 18 held.

**Other sources:**
- GPU-E sections 2–4: its J2/J4 row, 7p + 1, the constants, 36.2.
- VALIDATION entry 45: 42 min and 13 s.
- make_ring.py: 99 refusals a particle + 1,000; 160 bits; 5 Hill radii.

## Contradictions and things I could not resolve
1. **"V4: three send-backs."** V4 looked three times but sent P4 back twice, on `517e8d5` and `f27f9c6`. P4 was resumed three times only if you count the lead's ruling at 01:40. Entry 50 says exactly that.
2. **"The drop unwatched for 3 h 17 min."** The ledger says the drop was unwatched from 21:20 to 01:31; 3 h 17 min is how late P1's urgent file was placed. Entry 51 gives both.
3. **The gate-4 control's figure.** For the same both-runs rounding at 120 steps, P1 measured 3.371e-33 and V1 measured 1.32e-33. Both pass gate 4, so I cite each by name.
4. **`--zonal-selftest` is missing from the usage block** at the head of `src/ias15_cft.c`, as P1 noted. I documented it from the parser at :4539 and `ias15_zonal.inc:75`, and stated it as a limit in entry 47. The fix is code, so it is not mine to make.
5. **Your third trap candidate** (a mutant that never applied) cost about 8 minutes by the ledger (08:05 to 08:13), not hours. I made it the last sentence of a trap that did cost hours: V4's and VL's send-backs for controls on one axis only.
6. **`tools/check_ring.py:15-16` is stale.** It still says the zonal line "is refused until round 4's P1 lands", which stopped being true at `4dd53f3`. It is code text.
7. **P4's "six digests" are a different six.** They are the normalabs and check_scalar digests, not entry 45's gate_real digests that ROUND4.md's P0 names, and P4 marked that identification BELIEVED. I checked entry 45's six myself.
8. **`int-check-7d50392.log` may have stalled.** When I read it at 08:27 it was last written at 07:56, at check_ensemble, the 12th leg logged.
9. **README's suite times are unchanged:** about 2.5 h, 42 min and 31 min. CLAUDE.md carries the dated ones.
