**VL re-check of d9c8c8c: READY.** The gap I reported on 7a339d1 is closed, and I found nothing new.

**(a) Scope.** `git diff --stat 7a339d1 d9c8c8c` shows two files: `tools/check_compare_run.py` (+43/−25) and one comment line in `tools/check_ring_seams.py`. Source and Makefile are unchanged, so the 7a339d1 build stands. That comment now says each wave rejects at least once, which is what the code asserts. **Confirmed.**

**(b) Mutants of the particle comparison.** Each ran in a scratch copy of `tools/` with its own `check_compare_run --quick`. The mutation script refuses to write a copy if a replacement doesn't match exactly once or changes nothing, and I checked the `MUTANT` lines in each copy before running.
- **Tree as committed:** 45 ok, PASS. p2 reports "27 held", on sample lines 1 and 2.
- **My last-line mutant** (every column, last sample line only): fails at p2 alone, 15 held, 44 ok. The missed plants are named, for example t in member 0 and dt_last in member 2. This matches the lead's count.
- **New mutant of mine:** the particle's own six fields on every line, but the head fields, massive bodies and exact-time pair on the last line only (as if those were left to the member comparison). It fails at p2 alone, 18 held, 44 ok. That is the 9 non-particle columns planted on line 1, as expected.
- **Confirmed.**

**(c) Is p2 inert or self-confirming? Neither.**
- **Planting is independent of the driver.** p2 finds each token from its own reading of `# columns:`; the driver names the column through its own `Columns` class.
- **Each check is specific.** It requires the planted line and column by name, the planted value as the record's, and the original value as the replay's. That also checks the record-body to replay-body mapping for every planted column.
- **Line coverage is enforced.** If fewer than two sample lines receive plants, p2 fails rather than passing quietly.
- **A shifted pick fails, not passes.** If a plant ever changed which particle is closest, p2 finds no line for the expected particle and fails.
- **Trailer plants are isolated.** The three counters are planted in a record whose sample lines are untouched, so each replay's first mismatch is its counter.
- **Two limits, both stated or contrived:**
  - steps_done and steps_rejected are not planted. The commit's comment states this, and the member comparison checks the same trailer values.
  - Each column is planted on only one line. A mutant would have to skip exactly the untested column-and-line pairs to slip through.

Mutant copies are deleted, the worktree is clean at d9c8c8c, and no process of mine is still running.

**READY.**
