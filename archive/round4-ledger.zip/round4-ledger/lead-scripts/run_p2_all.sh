#!/bin/bash
G=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu
cd /c/Users/logan/source/repos/cft-rebound-seam || exit 1
export PATH="/c/msys64/mingw64/bin:$PATH"
PY=/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe
( s=$(date +%s); $PY -B tools/check_compare_run.py --build build --quick > "$G/int5-compare-4.log" 2>&1; echo "=== clean rc=$? $(( $(date +%s) - s )) s" >> "$G/int5-compare-4.log" ) &
( s=$(date +%s); $PY -B tools/check_ring_seams.py --build build --quick > "$G/int5-seams-4.log" 2>&1; echo "=== seams rc=$? $(( $(date +%s) - s )) s" >> "$G/int5-seams-4.log" ) &
bash "$G/run_pc_mutants.sh" > "$G/mut-lines.out" 2>&1 &
wait
echo "### clean gate"; grep -E '^  FAIL|^RESULT|^=== |  ok   p2' "$G/int5-compare-4.log" | cut -c1-400
echo "### seams"; grep -E '^  FAIL|^RESULT|^=== ' "$G/int5-seams-4.log"
cat "$G/mut-lines.out"
for k in lastline firstline; do grep -E '^  FAIL p2' "$G/mut-pc-$k.log" | grep -o '([0-9]* held); NOT: .*' | cut -c1-300; done
