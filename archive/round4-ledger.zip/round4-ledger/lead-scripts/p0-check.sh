#!/bin/bash
# Round 4's P0: the full `make check` on round4-p0, launched from PowerShell
# (CLAUDE.md, "Launching a long suite from an agent").
cd /c/Users/logan/source/repos/cft-rebound-r4 || exit 1
export PATH="/c/msys64/mingw64/bin:$PATH"
T='C:\Users\logan\AppData\Local\Temp'
LOG=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/p0-check.log
{
  date '+start %F %T'
  git log --oneline -1
  make OS=Windows_NT TMP="$T" TEMP="$T" PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" check
  echo "rc=$?"
  date '+end %F %T'
} > "$LOG" 2>&1
