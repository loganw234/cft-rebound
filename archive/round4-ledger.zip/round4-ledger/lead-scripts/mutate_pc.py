"""One-defect copies of tools/compare_run.py's particle_compare, for the lead's
P3 x P4 gate (check_compare_run p2). Usage: python mutate_pc.py COPY KIND.
Exits non-zero, and changes nothing, when the mutation does not apply: a
mutant that is not mutated would be a stand-in passing for a control."""
import sys

path, kind = sys.argv[1], sys.argv[2]
src = open(path, encoding="utf-8").read()
a = src.index("def particle_compare(")
b = src.index("\ndef sample_particles(", a)
fn = src[a:b]


def once(text, old, new):
    if text.count(old) != 1:
        sys.exit("mutate_pc: %r occurs %d times in particle_compare, not once" % (old, text.count(old)))
    return text.replace(old, new)


LOOP_HEAD = "        lineno, line = lines[i]\n"
if kind == "pair":
    fn = once(fn, "    pairs += [(ns + rec.N * per + q, ns + len(bodies) * per + q) for q in range(npair)]\n", "")
elif kind == "counters":
    fn = once(fn, "    for c in COUNTERS:\n", "    for c in ():\n")
elif kind == "vl":
    sub = "    sub_lines = [l for l in out.splitlines() if l.startswith(\"sample \")]\n"
    fn = once(fn, sub, sub + "    pairs = [p for p in pairs if p[0] in (ns + bodies[-1] * per + rec.cols.per.index('x'), "
                            "ns + rec.cols.per.index('x'))]\n")
    fn = once(fn, "    for c in COUNTERS:\n", "    for c in ():\n")
elif kind == "lastline":
    fn = once(fn, LOOP_HEAD, "        if i != len(rs) - 1:\n            continue\n" + LOOP_HEAD)
elif kind == "firstline":
    fn = once(fn, LOOP_HEAD, "        if i != 1:\n            continue\n" + LOOP_HEAD)
else:
    sys.exit("mutate_pc: unknown mutant %r" % kind)
open(path, "w", encoding="utf-8", newline="\n").write(src[:a] + fn + src[b:])
print("mutated", kind)
