"""Round 4's ledger, archived as round 3's was: one zip, each file under
round4-ledger/ with its original timestamp, deflated, in sorted order.
Usage: python -I make_archive.py OUT.zip"""
import os
import sys
import time
import zipfile

SCR = r"C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad"
LEDGER = r"C:\Users\logan\source\repos\cft-rebound\.ledger"
G = os.path.join(SCR, "gpu")

entries = {}                      # archive name -> source path


def add(name, path):
    if not os.path.isfile(path):
        sys.exit("make_archive: missing %s" % path)
    if name in entries:
        sys.exit("make_archive: %s twice" % name)
    entries["round4-ledger/" + name] = path


for f in ("README.md", "lead.md", "P1.md", "P2.md", "P3.md", "P4.md"):
    add(f, os.path.join(LEDGER, f))
for f in sorted(os.listdir(os.path.join(LEDGER, "urgent"))):
    add("urgent/" + f, os.path.join(LEDGER, "urgent", f))
add("urgent-P1-gate4-blind.md", os.path.join(SCR, "ledger-drop", "urgent-P1-gate4-blind.md"))

for f in sorted(os.listdir(os.path.join(G, "briefs", "filled"))):
    add("brief-" + f, os.path.join(G, "briefs", "filled", f))
add("brief-V-common.md", os.path.join(G, "briefs", "V-common.md"))
add("brief-V-attacks.md", os.path.join(G, "briefs", "V-attacks.md"))
add("brief-fill_v.py", os.path.join(G, "briefs", "fill_v.py"))

for f in sorted(os.listdir(os.path.join(G, "reports"))):
    base = f[:-3] if f.endswith(".md") else f
    if base.endswith("-report"):
        name = "report-" + base[:-len("-report")] + ".md"
    else:
        who, _, n = base.partition("-report-")
        name = "report-%s-%s.md" % (who, n)
    add(name, os.path.join(G, "reports", f))

for src, name in (("p0-check-4b52705-stopped.log", "logs/make-check-4b52705-stopped.log"),
                  ("dropin-forced-rerun.txt", "logs/4b52705-leg7-rerun-alone.txt"),
                  ("p0-check.log", "logs/make-check-9a42b1d.log"),
                  ("int-check-291c99c.log", "logs/make-check-291c99c.log"),
                  ("int-check-7d50392.log", "logs/make-check-7d50392.log"),
                  ("int-check-d9c8c8c.log", "logs/make-check-d9c8c8c.log")):
    add(name, os.path.join(G, src))
for f in sorted(os.listdir(os.path.join(G, "p0ctl"))):
    add("logs/p0-controls/" + f, os.path.join(G, "p0ctl", f))
for f in ("mut-body0.log", "mut-pc-vl.log", "mut-pc-pair.log", "mut-pc-counters.log", "mut-pc-lastline.log",
          "mut-pc-firstline.log"):
    add("logs/mutants/" + f, os.path.join(G, f))
for f in ("drop-watch.sh", "p0-check.sh", "int-check.sh", "last_report.py", "make_archive.py", "mutate_pc.py",
          "run_pc_mutants.sh", "run_p2_all.sh"):
    add("lead-scripts/" + f, os.path.join(G, f))

out = sys.argv[1]
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(entries):
        path = entries[name]
        zi = zipfile.ZipInfo(name, date_time=time.localtime(os.path.getmtime(path))[:6])
        zi.compress_type = zipfile.ZIP_DEFLATED
        with open(path, "rb") as f:
            z.writestr(zi, f.read(), compresslevel=9)
# verify: every entry's bytes are its source's
with zipfile.ZipFile(out) as z:
    bad = [n for n in entries if z.read(n) != open(entries[n], "rb").read()]
    if bad or len(z.namelist()) != len(entries):
        sys.exit("make_archive: %d entries differ from their sources: %s" % (len(bad), bad[:5]))
print("%s: %d entries, %d bytes, every entry byte-identical to its source"
      % (out, len(entries), os.path.getsize(out)))
