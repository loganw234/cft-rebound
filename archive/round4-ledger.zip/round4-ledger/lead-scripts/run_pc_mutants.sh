#!/bin/bash
G=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu
SRC=/c/Users/logan/source/repos/cft-rebound-seam
PY=/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe
export PATH="/c/msys64/mingw64/bin:$PATH"
for kind in lastline firstline; do
  (
    M="$G/mut-pc-$kind"; rm -rf "$M"; mkdir -p "$M/build"
    cp -r "$SRC/tools" "$SRC/data" "$SRC/programs" "$M/"
    cp "$SRC/build/ias15_cft.exe" "$SRC/build/ias15_ref.exe" "$M/build/"
    $PY -B "$G/mutate_pc.py" "$M/tools/compare_run.py" $kind > "$G/mut-pc-$kind.log" 2>&1 || { echo "=== NOT MUTATED: the mutation did not apply, so no run" >> "$G/mut-pc-$kind.log"; rm -rf "$M"; exit 0; }
    s=$(date +%s)
    $PY -B "$M/tools/check_compare_run.py" --build "$M/build" --quick >> "$G/mut-pc-$kind.log" 2>&1
    echo "=== rc=$? $(( $(date +%s) - s )) s" >> "$G/mut-pc-$kind.log"
    rm -rf "$M"
  ) &
done
wait
for kind in lastline firstline; do echo "### $kind"; grep -E '^mutated|^  FAIL|^RESULT|^=== ' "$G/mut-pc-$kind.log" | cut -c1-300; done
