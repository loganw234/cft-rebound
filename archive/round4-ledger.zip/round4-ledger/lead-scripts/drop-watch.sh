#!/bin/bash
# The lead's watch on the ledger drop. Every 60 s it places each author's drop file
# verbatim into .ledger/ (copy, then rename into place). It exits, printing the
# headline and For: line, when an urgent-*.md file it has not seen appears; the lead
# reads that one and decides where it goes.
D=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/ledger-drop
LG=/c/Users/logan/source/repos/cft-rebound/.ledger
T=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/place-tmp
SEEN="$T/urgent-seen.txt"
mkdir -p "$T"; touch "$SEEN"
echo "drop watch armed $(date '+%Y-%m-%d %H:%M:%S')"
while true; do
  for f in "$D"/*.md; do
    [ -e "$f" ] || continue
    b=$(basename "$f"); case "$b" in urgent-*) continue;; esac
    if ! cmp -s "$f" "$LG/$b"; then cp "$f" "$T/$b" && mv -f "$T/$b" "$LG/$b" && echo "$(date '+%H:%M:%S') placed $b ($(wc -c < "$LG/$b") bytes)"; fi
  done
  for u in "$D"/urgent-*.md; do
    [ -e "$u" ] || continue
    b=$(basename "$u")
    if ! grep -qxF "$b" "$SEEN"; then
      echo "$b" >> "$SEEN"
      echo "$(date '+%H:%M:%S') NEW URGENT: $b"; head -2 "$u"
      exit 0
    fi
  done
  sleep 60
done
