import json, sys
src, out = sys.argv[1], sys.argv[2]
last = None
with open(src, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            o = json.loads(line)
        except Exception:
            continue
        if o.get("type") != "assistant":
            continue
        msg = o.get("message") or {}
        content = msg.get("content")
        if isinstance(content, str):
            texts = [content]
        else:
            texts = [c.get("text", "") for c in (content or []) if isinstance(c, dict) and c.get("type") == "text"]
        t = "\n".join(x for x in texts if x.strip())
        if len(t) > 2000 and ("report" in t[:300].lower() or "READY" in t[:300]):
            last = t
if last is None:
    sys.exit("no assistant text found")
with open(out, "w", encoding="utf-8", newline="\n") as g:
    g.write(last.rstrip() + "\n")
print(out, len(last), "chars; first line:", last.strip().splitlines()[0][:100])
