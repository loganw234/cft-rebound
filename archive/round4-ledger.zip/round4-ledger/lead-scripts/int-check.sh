#!/bin/bash
# Round 4: the full `make check` on the integration branch round4-int, after
# each merge, launched from PowerShell (CLAUDE.md, "Launching a long suite
# from an agent"). The log is named by the commit it ran, with git status
# printed first: the suite must run a committed, clean tree.
cd /c/Users/logan/source/repos/cft-rebound-r4 || exit 1
export PATH="/c/msys64/mingw64/bin:$PATH"
T='C:\Users\logan\AppData\Local\Temp'
H=$(git rev-parse --short HEAD)
LOG=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/int-check-$H.log
{
  date '+start %F %T'
  git log --oneline -1
  echo "status: $(git status --porcelain | wc -l) changed paths"
  make OS=Windows_NT TMP="$T" TEMP="$T" PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" check
  echo "rc=$?"
  date '+end %F %T'
} > "$LOG" 2>&1
