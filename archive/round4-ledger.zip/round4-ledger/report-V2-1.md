**V2 on P2 at 250789e: NOT READY.** There is one gap, and it is in the gate only. The gate does not check that the six moons are out of Saturn's equatorial plane. Copy C of the generator puts all six in the plane, and the gate still passes. The generator itself is right, and every other claim checked out.

Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\`. I edited no tracked file, and `git status` is clean.

**Setup.**
- I detached to 250789e and confirmed it with `git log --oneline -1`. My local third_party clones sit at the MANIFEST commits (rebound bdfda4bd, cft-fp256 922c2ade).
- `make … all programs` built at 250789e and at 9a42b1d, the base going into a scratch copy with its own clones; rc 0, x86_64-w64-mingw32.
- ias15_cft.exe is byte-identical between the two builds (sha256 089c445e…), and so are the 66 program images. ias15_ref.exe differs in 3 bytes, which are link timestamps.

**Gate in full** (`tools/check_ring.py --build <copy of build>`): 37 ok, 0 FAIL, RESULT: PASS, "23 runs, 381 s of them; 391 s in all". Its numbers match P2's pasted lines.

**make check-light** at 250789e, started from PowerShell: rc 0 in 69 min, 20 legs, 12 RESULT: PASS, 0 FAIL, 590 ok lines, no fork errors. The ring leg alone: 31 ok, PASS.

## The numbered items

1. **Determinism: confirmed.** I ran make_ring.py ten times. Same arguments under a different PYTHONHASHSEED, under MPMATH_NOGMPY=1, and to another output path all gave one sha256, equal to the gate's ring.txt; seed 2 differs. The only `math.` call is `ldexp`, which is exact here; the trig is mpmath's; every value is written with `.hex()`. As an independent check, my own 400-bit recomputation reproduced every value: 1,645 in the 228-particle ring and 399,049 in a 57,000-particle zonal ring.
2. **Constants: confirmed.** Every value matches GPU-E §4 (lines 224–245) and its answer 1, and each is cited. R = 60,330 km is labelled BELIEVED in the code and in the file's head. The written line `zonal 0 0x1.d754p+15 …` pairs R with J2 and J4.
3. **Initial state: confirmed.**
   - v²/(r|a_r|) − 1 against the J2/J4 field in the equatorial plane is at most 1.9e-16 (Pan −8.4e-17).
   - Against −∇Φ taken at each particle's own z it is up to 8.9e-9. That is by design: the brief asked for the equatorial speed, and particles sit up to 112 km off the plane.
   - The barycentre is at 1.1e-19 km. Epimetheus starts at 45.0° and Janus at 225.0°.
4. **Not flat: defect (gate gap).** The particles' |z| is asserted, on the file and at every sample (control B). Nothing asserts the moons: `largest_z()` takes particles only. The shipped moons are inclined; I recovered 1.0°, 0.05° ×3 and 0.2° ×2 from the file. Details below.
5. **Inert claim: confirmed.**
   - The check compares every sample token plus six counters.
   - The 420 is read from the record's `# active` line and checked against n(n−1)/2 + (N−n)n from the run's own file; the all-active record must have no such line.
   - A timing-masked diff of the two records differs only in that line, `calls` (16,244 against 30,608) and `staged_bytes`.
   - Control D, which feeds the all-active file to the "active" runs, fails all three rows.
6. **Ensemble and engines: confirmed.** Token-for-token comparison of every line, exact-time pair included, plus the per-system counters. That is at least as strict as check_ensemble.
7. **Steps an orbit: confirmed and asserted.** It is measured on w00000, and the gate asserts w00000 lies inside Pan's pericentre less 5 Hill radii. The 36.2 is the study's point-mass circular orbit, the mean of its halves 36.5 and 35.9. By the study's own method, w00000 gives 36.55 / 35.89, mean 36.22. w00003 steps at 35.89 an orbit of Pan, confirming P2's finding that Pan caps the step for waves outside it.
8. **Zonal line: confirmed.** It is P0's syntax with k = 0, and running the file reaches P0's refusal by name. Every gate run uses `--no-zonal`, so nothing breaks when P1 lands.
9. **Cost: measured** on a host shared with P1, P4, V1 and V3, so slower than P2's 240 s and 85–124 s.

   | Tier | Runs | Time |
   |---|---|---|
   | `check` | 23 | 391 s |
   | `check-light` | 15 | 157 s |
   | `check-quick` | 15 | same command and cache stamp as check-light |
   | my four `--quick` control copies | 14–15 | 170–189 s |

10. **Orbits: confirmed.** `rot()` is tools.c:985–992 term for term, and r and v0 are :972–973 times the oblate factor. From the `--no-zonal` file, the moons' a and e equal the table and their angles equal MOON_ANGLES. Particles have a = r, e ≤ 2.6e-16 and i from 1.008e-4 to 9.93e-4.
11. **ias15_ref: confirmed, with a note.**
    - The binary is `ref/ias15_ref.c` linked against librebound.a from rebound at bdfda4b. It refuses the ensemble file by name (`unknown line 'E'`), and its record header reads `impl=rebound`.
    - The gate compares all 388 values a sample exactly, sign included: 2,716 in all.
    - A stand-in binary at that path would pass. The gate neither checks `impl=` nor prints ias15_ref's build time; it prints only ias15_cft's, though METHOD §5 asks for every binary a gate runs.
12. **Exclusion at the default: confirmed.** At 57,000 particles the file's head says 2 of 57,002 draws were refused, one each near Prometheus and Pandora. My independent replay refuses the same two near the same moons, with no draw close to a threshold. The closest kept start is 6.09 Hill radii from Pandora. The gate's 300-Hill-radii case also recounts to its 63, moon by moon.
13. **Coverage: confirmed.** The output says "fp64, the program engine", and no line claims more.

## The items every verifier checks

- **Untouched path: confirmed by measurement.** All five problems in 8 settings (including 11 rejections), at three formats on loop fma, loop rebound and program fma. That is 72 runs per build and 315 sample lines, all identical with only timing masked.
- **check_records** (full) at 250789e: 9 ok, RESULT: PASS.
- **Controls**, built from copies and deleted:
  - **A**, my own instance of the brief's control: p0000020's x moved one ulp down. The gate printed `FAIL w00000: first difference at sample 0, body 27 x`; the other waves were ok; RESULT: FAIL.
  - **B**, the flat ring: `FAIL not flat … 0.000 km`, with every bit comparison still passing.
  - P2's own control logs predate 250789e (14 runs, no ias15_ref step). Mine ran on the final commit.
- **Scope: confirmed.** Only the Makefile, `tools/check_ring.py` and `tools/make_ring.py` changed.
- **Claims in comments: confirmed** against the bytes: "same bytes", "rounded once", "about 1,400 km" (measured 1,396), "650 times", "REBOUND's 12 passes".
- **Usual shapes:** nothing loosened, no TODO. Two nits:
  - PER_WAVE = 57 is written as a constant rather than derived as 64 − MASSIVE, and nothing asserts N = 64.
  - `--exclude-hill 1000` never finishes; nothing bounds the redraws.

## The defect

**Nothing holds the moons out of the plane.** Control C copies make_ring.py with the six moons' inclinations set to 0 and the particles untouched. All seven massive bodies then have z = vz = 0 exactly, and check_ring passes: 31 ok, RESULT: PASS, rc 0.

On such a ring every z term of J2 and J4 on a moon stays exactly zero at every step, and so does the z of its reaction on Saturn. The particles are massless, so the moons carry all of the ring's reactions (ROUND4.md, P1).

The failure: a GPU wave or a later P1 change with a wrong reaction z would match this tree bit for bit, and P4's driver would report it identical. That is the "inert by construction" trap ROUND4.md warns against. The generator's own header says the moons' inclinations are "not zero", but no gate or report covers it.

**Fix:** assert each moon's inclination, taken from r × v in the file, is above zero, with control C as its negative control. Use the inclination, not |z|, because Pan starts at its node with z = 0. Printing ias15_ref's build time can go in the same change.

Beyond that gap and the notes above, I found nothing.

**NOT READY.** One gate assertion is missing; no generator bit or record line needs to change.
