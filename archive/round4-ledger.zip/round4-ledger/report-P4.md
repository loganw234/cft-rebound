# P4 report: tools/compare_run.py, a run's records held against this tree

**Base and commit (MEASURED).** The base is 9a42b1d, checked with `git log --oneline -1` at the start. The work is one commit, **c640f65**, on branch `worktree-agent-a16e2203c9e2b005f` in `C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-a16e2203c9e2b005f`. Nothing was pushed, merged or rebased.

**Suites (MEASURED, read from the logs).**
- **Full `make check` on c640f65:** started from PowerShell at 22:50:46, ended at 01:27:14 (2 h 36 min), make rc=0.
  - 20 legs, each `--mode full` once, and every leg's own verdict line is present: 12 `RESULT: PASS`, constants "78 constants compared, all match", check_dropin "every case passed", `--wide` "passed", check_archive gates 1-3 PASS, gate_real PASS at all three formats, gate_subprocess PASS.
  - No FAIL: the six lines containing "FAIL" are my gate's ok lines naming its controls. No fork errors. One `--` line, gate_subprocess's body_count, which P0's log also has.
  - 907 lines match `^  ok `: P0's 857 plus my leg's 50.
  - I compared this log leg by leg with P0's own log (`gpu/p0-check.log`). Each of the 19 existing legs has exactly P0's ok count.
  - The six digests are identical to P0's: the normalabs hashes 63d241badb254352, 831e9a73f5c4a5a4 and a6c9f6b5ccebff81, and check_scalar's wide digests 88267a406b721e82, f045ae9e61c02879 and 4270b7a92d53b15e. That these are the six ROUND4.md means is BELIEVED.
- **`make check-light`** ran on the same content from 22:07:48 to 22:49:40, with make rc=0, 20 legs, 12 `RESULT: PASS`, a cold cache, and no real FAIL.

## What changed, file by file

**`tools/compare_run.py` (new, 961 lines): the driver.**
- **Usage:** `compare_run.py RECORD --problem FILE --format F --arith A [--exe] [--programs] [--seed 1] [--strata 8] [--format-diff F2] [--plan] [--rerun-engine loop|program] [--keep DIR]`.
- **What it reads:** only the record format. It streams the record twice: first its structure and trailers, then only the sampled members' lines.
- **Parsing is imported, not rewritten:** `check_ensemble.parse()` for the bit comparison and the trailers, `check_records.header_args()` for the header, and `check_equivalence.hex_to_fraction()` for exact values. I changed neither check_ensemble.py nor check_records.py.
- **Columns are derived** from the record's own `# columns:` line: x, y and z are found by name, and columns are named in FAIL messages. The driver also asserts that the line begins with the two fields check_ensemble reads by position.
- **REFUSED (rc 2), by name, before anything is compared:**
  - a file that is not a record, a header missing a field the rerun needs, or a record run from a dt file;
  - a record of another format or arithmetic than `--format` and `--arith`;
  - a problem file that is not the record's problem. The check covers its name, N, E, G and system names, every body's name and mass, the `active` line, and every system's sample 0 against its initial state;
  - a rerun whose own header is not the record's run. That check covers every program field, dt0, epsilon, G, pc_tol, the member's index, name and bodies, the columns, the `active` line in both directions, and every other header line this tree writes.
- **FAIL (rc 1), by member and name:**
  - a member missing from the record or incomplete in it, checked for every member, sampled or not;
  - a sampled member's first differing line: the record's line number, the sample, the step, the column, and both hex values;
  - its five trailer counters against the rerun's, and the members' rejections summed against the record's total.
- **The sample:** contiguous strata of member index, one member from each by the least SHA-256 of (seed, index), so a seed picks the same members on any host and any Python. Every member with `steps_rejected > 0` is added. `--plan` prints the sample without rerunning.
- **Counters beside each verdict:**
  - steps, rejections, mean and largest passes, and cap hits;
  - each test particle's closest approach to each active body, labelled "AT THE SAMPLES (not between them)";
  - with `--format-diff F2`, the member rerun with `--dt-out` and then at F2 with `--dt-file --epsilon 0`, measured by tools/compare_formats.py.
- **Particles:** `sample_particles()` is the named, empty place for the P3 x P4 seam.
  - While neither tools/extract_particle.py nor tools/check_replay.py exists, it prints `particles: not sampled (no particle replay in this tree)`.
  - Once either exists, it prints "NOT SAMPLED, and NOT WIRED", so my gate fails until the seam is wired, in whichever order P3 and P4 merge. This is deliberate (METHOD.md §1). P3's drop confirms both file names.

**`tools/check_compare_run.py` (new, 564 lines): the gate.**
- It hand-makes an ensemble because make_ensemble.py refuses `active` lines. The ensemble is 8 waves, each a primary, a moon and 3 massless inclined test particles, with `active 2`. Member index is radius, as in P2's generator.
- Every value is one or two correctly rounded IEEE operations.
- With dt0 0.3, members 0 and 1 reject their first attempt and the other six do not, so the first attempt is mixed.

**Makefile.**
- `IN_COMPARE` lists the gate, the driver, every script the driver imports or runs, ias15_cft, ias15_ref, data/problems/kepler.txt and the program images.
- The leg `check_compare_run` sits after check_ensemble in `check` (`--mode full`), and in `check-quick` and `check-light` (`--quick`). Each tier now has 20 legs.
- `--light` scales none of its cases: check-light runs it as check-quick does, like every Python leg. Its cases are fixed step counts; none is an integrate-to-a-time, step-sequence or merge case.

## The gate output (actual lines, full mode, from the `make check` log)
```
check_compare_run: build\ias15_cft.exe, built 2026-11-11 21:17:07
check_compare_run: build\ias15_ref.exe, built 2026-11-11 21:16:51
check_compare_run: case 1 at fp64 - the driver on an ensemble of 8 waves, 40 steps, with --format-diff fp128
  ok   fp64: the driver PASSES (rc 0): RESULT: PASS: 4 sampled member(s) of 8, every one identical to this tree's rerun, its counters beside it
  ok   fp64: the driver prints its sample
  ok   fp64: the record has a mixed first attempt: members [0, 1] rejected a step, 6 did not (this gate's reading of the record's trailers)
  ok   fp64: the sample [0, 1, 2, 6] holds every rejecting member [0, 1] and one member of each stratum [(0, 1), (2, 4), (5, 7)], and is 4 of 8
  ok   fp64: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 6 IDENTICAL
  ok   fp64: each sampled member's counters are its trailer's, 40 steps done each
  ok   fp64: 24 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 3.29e-7 relative, at the samples they name
  ok   fp64: the particles line, exactly: 'particles: not sampled (no particle replay in this tree)'
  ok   fp64: each sampled member's format difference, fp64 against fp128 on its own steps, is nonzero and below 1e4 units of fp64's round-off, 1.1e-12 (max |dx|/L 0: 8.583e-16, 1: 1.038e-15, 2: 8.777e-16, 6: 1.491e-15), and a member that rejected a step is said to
  ok   fp64: a sampled member that rejected nothing exists ([2, 6])
  ok   fp64: member 6 replayed from its dt file at fp64 is the record's member bit for bit (3 samples)
check_compare_run: case 1 at fp128 - the driver on an ensemble of 8 waves, 20 steps, with --format-diff fp256
  ok   fp128: the driver PASSES (rc 0): RESULT: PASS: 4 sampled member(s) of 8, every one identical to this tree's rerun, its counters beside it
  ok   fp128: the driver prints its sample
  ok   fp128: the record has a mixed first attempt: members [0, 1] rejected a step, 6 did not (this gate's reading of the record's trailers)
  ok   fp128: the sample [0, 1, 2, 6] holds every rejecting member [0, 1] and one member of each stratum [(0, 1), (2, 4), (5, 7)], and is 4 of 8
  ok   fp128: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 6 IDENTICAL
  ok   fp128: each sampled member's counters are its trailer's, 20 steps done each
  ok   fp128: 24 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 2.36e-7 relative, at the samples they name
  ok   fp128: the particles line, exactly: 'particles: not sampled (no particle replay in this tree)'
  ok   fp128: each sampled member's format difference, fp128 against fp256 on its own steps, is nonzero and below 1e4 units of fp128's round-off, 9.6e-31 (max |dx|/L 0: 1.942e-34, 1: 1.589e-34, 2: 6.023e-34, 6: 8.63e-34), and a member that rejected a step is said to
check_compare_run: case 1 at fp256 - the driver on an ensemble of 8 waves, 20 steps
  ok   fp256: the driver PASSES (rc 0): RESULT: PASS: 4 sampled member(s) of 8, every one identical to this tree's rerun, its counters beside it
  ok   fp256: the driver prints its sample
  ok   fp256: the record has a mixed first attempt: members [0, 1] rejected a step, 6 did not (this gate's reading of the record's trailers)
  ok   fp256: the sample [0, 1, 2, 6] holds every rejecting member [0, 1] and one member of each stratum [(0, 1), (2, 4), (5, 7)], and is 4 of 8
  ok   fp256: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 6 IDENTICAL
  ok   fp256: each sampled member's counters are its trailer's, 20 steps done each
  ok   fp256: 24 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 2.36e-7 relative, at the samples they name
  ok   fp256: the particles line, exactly: 'particles: not sampled (no particle replay in this tree)'
check_compare_run: case 3 - the sample, seeded and stratified (--plan)
  ok   every seed's sample holds every rejecting member and one member a stratum (10 of 10 seeds)
  ok   the seed chooses: 6 different picks over 10 seeds
  ok   seed 1's plan is case 1's sample ([0, 1, 2, 6])
check_compare_run: case 4 - the same problem at binary128 and in the FMA form, held as recorded
  ok   fp128: held at its own format and arithmetic, PASS, 4 members IDENTICAL
  ok   fp64 FMA form: held at its own format and arithmetic, PASS, 4 members IDENTICAL
check_compare_run: case 5 - one system's records: a --member run's, and a single problem's
  ok   a --member 3 record of the waves, held as one system: PASS, member 3 IDENTICAL with its trailer's counters (steps 40, rejected 0, mean passes 3.425, max passes 9, cap hits 0), its closest approaches, and the particles line (rc 0)
  ok   a single problem's record (kepler, every body active): PASS, IDENTICAL, and no test particles said (rc 0)
check_compare_run: case 6 - the FMA form on the program engine, as recorded and on the loop engine
  ok   the FMA form's program-engine record, rerun on the program engine: PASS, 4 members IDENTICAL
  ok   the FMA form's program-engine record, rerun on the loop engine: PASS, 4 members IDENTICAL
check_compare_run: the negative controls, each of which must FAIL or be refused, by name
  ok   a. one byte of member 6's line 77 (tp2's x, 0x1.e06eaecdb3e7fp-1 for 0x1.e06eaecdb3e7ep-1): FAIL naming member 6, line 77 and the column; the other 3 sampled IDENTICAL (rc 1)
  ok   a2. one byte of the --member 3 record's line 14: FAIL naming member 3 (w3), line 14 and the column (rc 1)
  ok   b. member 1's trailer mean_pc_iterations 3.317 made 3.318 (line 80): FAIL naming member 1 and the counter (rc 1)
  ok   c. member 7's 10 lines deleted, a member not sampled: FAIL naming it missing; the 4 sampled IDENTICAL (rc 1)
  ok   d. the record cut short at line 71: FAIL, all 8 members incomplete, and no trailer (rc 1)
  ok   e. a binary128 record held as binary64: REFUSED by name (rc 2)
  ok   e. an FMA-form record held as REBOUND's arithmetic: REFUSED by name (rc 2)
  ok   f. REBOUND's own record (ias15_ref, the same first line): REFUSED, naming the fields it lacks (rc 2)
  ok   f. a problem file given as the record: REFUSED, not a record (rc 2)
  ok   g. a different problem file under the record's name, a test particle's mass 0 made 2^-40: REFUSED by name (rc 2)
  ok   g. a different problem file under the record's name, the active line dropped: REFUSED by name (rc 2)
  ok   g. a different problem file under the record's name, one initial coordinate moved one ulp: REFUSED by name (rc 2)
  ok   g. a different problem file under the record's name, the name changed: REFUSED by name (rc 2)
RESULT: PASS
```
`--quick` runs the fp64 case 1, cases 3 to 5 and every control. In check-light it gave the same lines and RESULT: PASS.

## The controls, with their results
**The brief's four named controls** are permanent in the gate, as controls a to g above, and each was reported FAIL or REFUSED by name: the byte change (a, a2), the missing member (c), another format and another arithmetic (e, plus f), and a different problem file under the record's name (g, four ways). Two of the g files are a test particle given a mass of 2^-40 and the `active` line dropped, and neither changes a bit, so only the problem check can refuse them.

**Mutants of the driver (MEASURED).** I made 12 copies of tools/, each with one defect in compare_run.py, and ran each copy's own `check_compare_run --quick`. Every mutant was caught, and the unmutated copy passed. The copies were deleted after their runs; the logs are in `scratchpad\p4\mut2\`.

| Defect in the driver | Caught by |
|---|---|
| M1: compares the record against itself | a, a2, b |
| M2: ignores a wholly missing member | c |
| M3: no `--format`/`--arith` check | both e controls; the genuine fp128 record then **PASSES** at its own format |
| M4: no problem-file check | all four g controls; the 2^-40 and one-ulp files **PASS with rc 0**, because those members are never rerun |
| M5: no trailer compare | b |
| M6: closest approach read from the velocities | case 1's recomputation (off by 6.13 relative) |
| M7: rejecting members not sampled | case 1's sample check |
| M8: reruns member k+1 | case 1 (REFUSED: "it ran member=1, and was asked for 0") |
| M9: prints a fake particles line | the particles assertions in cases 1 and 5 |
| M10: format difference at the same format | case 1 (0.0 for the non-rejecting members 2 and 6) |
| M11: compares only the first sample | a, a2 |
| M12: no initial-state check | g, the one-ulp file (PASSES with rc 0) |

## What I did not do
- **Particles are not sampled.** The place is named and empty, and the tripwire described above is in force.
- **No close-approach sampling** ("plus every wave whose record shows a close approach to a moon", ROUND4.md). It is not in the brief and no threshold is defined; the closest approach is a counter on sampled members only.
- **No steps or passes per orbit.** The record carries no period. P2 measured that a wave's step is set by the shortest orbit in the wave, so "an orbit" would have to say whose.
- **One second format per run** with `--format-diff`, not both format pairs at once.
- **Records run from a dt file are refused.** The file is not in the record.
- **Runs made with a non-default `--adaptive-mode`, `--softening`, `--min-dt` or `--no-flag-abort`** are rerun at the defaults. Such a run passes only if the setting changed no bit.
- **P1's zonal line is held only through the rerun's header lines,** compared verbatim; I do not know P1's record line format.
- **No GPU, WSL or card, and no speed claims.** Nothing changed under src/, nor in check_ensemble.py, check_records.py, any other parcel's file or any integrator-only file.
- **One known over-statement left in place.** The driver's format-difference note for a rejecting member over-states for mid-run rejections (item 5 below). I did not change it after the full suite had passed.

## What the brief or ROUND4.md got wrong
1. **"A record of another format or arithmetic must be refused" is not possible with the brief's three inputs.** A genuine fp128 record reruns at fp128 and agrees; M3 measured exactly that. So the driver requires `--format` and `--arith`, naming the run the comparison holds. P2 also measured that the two arithmetic forms' steps differ by 1.7e-11 on a ring wave, so comparing across forms gives a difference at every line.
2. **"The `# program=` line carries the run's arguments, and check_records.py reads it back as exactly that" is only partly true.** The record does not carry `--adaptive-mode`, `--softening`, `--min-dt` or `--no-flag-abort`, although the corrector schedule's run key names the first three. dt0, epsilon, G and pc_tol are on the `# dt0=` line, not the program line. check_records reads back a subset: it defaults cs and arith, and does not pass engine or pc_tol_shift (MEASURED by reading). `header_args` also returns `{}` for ias15_ref's unspaced `# dt0=` form (MEASURED), so the driver falls back to its own reading.
3. **ias15_ref writes the same first line,** `# cft-rebound ias15 record v1` (MEASURED). A record's first line does not identify its producer.
4. **The sample-line layout is not quite as the brief gives it.** It ends with ` | t_hi t_lo`, which is compared too. The `# columns:` line is not mechanically regular: "system s" is two names for two fields, but "sample" is one name for two. The driver interprets it and asserts the part it relies on.
5. **"A rejection changes the next step's prediction" (ROUND4.md) holds only for a rejection before the first accepted step.** I measured that case: members 0 and 1, replayed from their dt files at fp64, differ from the record by 2.6e-16 and 8.1e-16 in max |dx|/L, while members 2 and 6, with no rejection, replay bit for bit. P3 measured, in its worktree, that a rejection after an accepted step leaves no state bit. So my driver's note for a rejecting member ("the difference includes that") over-states for a member whose rejections all follow an accepted step. The fix is small: the driver already knows whether the first attempt was accepted (the dt file's first step equals the record's dt0 exactly then), so the note can depend on that, with a mid-run-rejection wave added to the gate.
6. **A format difference cannot see a binary64 bottleneck that both formats share** (P1, MEASURED, now in urgent/). `--format-diff` is therefore a counter, not a defect detector; what holds a GPU record is the bit comparison.
7. **The ok-line counts depend on the pattern.** P0's log has 858 lines matching `^\s+ok\b` but 857 matching `^  ok `, because one check_dropin line is indented by a single space. Counts should be compared by one pattern only.
8. **The brief's setup lines need adjusting here.** Its `third_party` clone loop (using `git -C`) was refused by the worktree isolation check as too complex to verify; plain separate git commands worked. "No third_party/" is also slightly off: the worktree has third_party/MANIFEST, just no clones.
9. **A pointer for the P3 x P4 seam.** P3 measured that a rejecting wave's particle sample should include the particle that drove the rejection. The driver already computes each test particle's closest approach per sampled member, which the seam can use to pick it.

**Ledger.** My entries are in `scratchpad\ledger-drop\P4.md`, and the lead has placed them all in `.ledger\P4.md`. One header time was wrong (22:20 for an entry written at 21:57) and is corrected by a later entry, as the ledger rules require. I wrote no urgent file. I read the whole ledger at the start, before editing the Makefile, and again before this report, including P1 to P3's placed files and `urgent\P1-gate4-blind.md`. None of it changes this work.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p4\`:
- check-full.log
- check-light.log
- gate_full_1.log
- gate_quick_2.log
- mutants2.out
- mut2\*.log

---

# P4 follow-up: 517e8d5

Both follow-ups are done and committed as **517e8d5**, on top of c640f65. It changes two files only, tools/compare_run.py and tools/check_compare_run.py, on branch `worktree-agent-a16e2203c9e2b005f`. Nothing was pushed or merged, no full `make check` was run, and the particles are not wired.

**1. The scope (your ruling).** Every `--format-diff` line now ends "(tools/compare_formats.py): the difference shows the narrower format's round-off on these steps; a narrowing both runs share passes it", followed by its note. check_compare_run asserts that exact text on every format-difference line at fp64 and fp128. The gate states the text itself; it does not read it from the driver.

**2. The rejection note follows the first attempt.** The driver decides the note by whether the dt file's first step equals the record's dt0:
- When the first attempt was rejected: "this member's first attempt was rejected, before any accepted step, which leaves state the replay at F2 does not take, so the difference includes that".
- When rejections came only after an accepted step: "this member's N rejected attempts all followed an accepted step, which leaves no state bit, so the replay at F2 follows its path".

**The second branch is held, by a new member 8** appended to the gate's ensemble (now 9 members). Its first particle is retrograde in the moon's plane, 1/128 outside the moon's radius, and meets the moon head on near t = 1.
- **Measured:** its first attempt at dt0 0.3 is accepted, and it then rejects 3 attempts, at fp64, fp128 and fp256.
- **Members 0 to 7 are unchanged (measured):** their 24 sample lines and 8 trailer lines in the new fp64 record are byte-identical to c640f65's eight-member record.
- **How the gate holds it:** it tells the two kinds apart on its own, by running each rejecting member alone for one step, and asserts the exact note for each. It then replays one member of each kind from its own dt file at fp64:
  - member 0 (first attempt rejected): its replayed state matches the record at only 1 of 3 samples, so it does differ, as its note says;
  - member 8 (rejections only after accepted steps): it matches in every value but `dt_next` at all 3 samples.

**A measurement on the way.** I measured on member 8, at fp64 and fp128, what P3 had only believed: after a rejection that follows an accepted step, the replay differs from the run only in `dt_next`, and only on the sample line printed just before the rejected attempt (at fp64, with a sample every step: steps 4, 8 and 10). That is why the gate leaves `dt_next` out of member 8's comparison. With samples every 20 steps it differs at none of them.

## Gate results
- **Full mode:** RESULT: PASS, 54 ok (50 before), 0 FAIL, 658 s on the loaded host.
- **`--quick`:** RESULT: PASS, 34 ok (31 before).

**Gate lines that changed, full mode, verbatim (new or altered against c640f65):**
```
check_compare_run: case 1 at fp64 - the driver on an ensemble of 9 waves, 40 steps, with --format-diff fp128
  ok   fp64: the driver PASSES (rc 0): RESULT: PASS: 6 sampled member(s) of 9, every one identical to this tree's rerun, its counters beside it
  ok   fp64: members [0, 1] reject their first attempt, [8] reject only after an accepted step, and 6 reject nothing (this gate's reading of the record's trailers, and of each rejecting member run alone for one step)
  ok   fp64: the sample [0, 1, 2, 3, 6, 8] holds every rejecting member [0, 1, 8] and one member of each stratum [(0, 2), (3, 5), (6, 8)], and is 6 of 9
  ok   fp64: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 3 IDENTICAL, 6 IDENTICAL, 8 IDENTICAL
  ok   fp64: 36 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 3.29e-7 relative, at the samples they name
  ok   fp64: each sampled member's format difference, fp64 against fp128 on its own steps, is nonzero and below 1e4 units of fp64's round-off, 1.1e-12 (max |dx|/L 0: 8.583e-16, 1: 1.038e-15, 2: 8.777e-16, 3: 1.515e-15, 6: 1.491e-15, 8: 7.152e-17)
  ok   fp64: each of the 6 says its scope beside its number, 'the difference shows the narrower format's round-off on these steps; a narrowing both runs share passes it', and the note its rejections call for: first attempt rejected for [0, 1], rejected only after an accepted step for [8], none for the rest
  ok   fp64: a sampled member that rejected nothing exists ([2, 3, 6])
  ok   fp64: member 6, which rejected nothing, replayed from its dt file at fp64 is the record's member bit for bit (3 samples): so its nonzero difference above is another format
  ok   fp64: member 0, whose first attempt was rejected, replayed from its dt file at fp64: its state is the record's at 1 of 3 samples, so that rejection leaves state, as its note says
  ok   fp64: member 8, whose 3 rejected attempts all followed an accepted step, replayed from its dt file at fp64: every value but dt_next is the record's at all 3 samples (dt_next differs at 0), so they leave no state bit, as its note says
check_compare_run: case 1 at fp128 - the driver on an ensemble of 9 waves, 20 steps, with --format-diff fp256
  ok   fp128: the driver PASSES (rc 0): RESULT: PASS: 6 sampled member(s) of 9, every one identical to this tree's rerun, its counters beside it
  ok   fp128: members [0, 1] reject their first attempt, [8] reject only after an accepted step, and 6 reject nothing (this gate's reading of the record's trailers, and of each rejecting member run alone for one step)
  ok   fp128: the sample [0, 1, 2, 3, 6, 8] holds every rejecting member [0, 1, 8] and one member of each stratum [(0, 2), (3, 5), (6, 8)], and is 6 of 9
  ok   fp128: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 3 IDENTICAL, 6 IDENTICAL, 8 IDENTICAL
  ok   fp128: 36 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 2.57e-7 relative, at the samples they name
  ok   fp128: each sampled member's format difference, fp128 against fp256 on its own steps, is nonzero and below 1e4 units of fp128's round-off, 9.6e-31 (max |dx|/L 0: 1.942e-34, 1: 1.589e-34, 2: 6.023e-34, 3: 2.417e-34, 6: 8.63e-34, 8: 8.886e-35)
  ok   fp128: each of the 6 says its scope beside its number, 'the difference shows the narrower format's round-off on these steps; a narrowing both runs share passes it', and the note its rejections call for: first attempt rejected for [0, 1], rejected only after an accepted step for [8], none for the rest
check_compare_run: case 1 at fp256 - the driver on an ensemble of 9 waves, 20 steps
  ok   fp256: the driver PASSES (rc 0): RESULT: PASS: 6 sampled member(s) of 9, every one identical to this tree's rerun, its counters beside it
  ok   fp256: members [0, 1] reject their first attempt, [8] reject only after an accepted step, and 6 reject nothing (this gate's reading of the record's trailers, and of each rejecting member run alone for one step)
  ok   fp256: the sample [0, 1, 2, 3, 6, 8] holds every rejecting member [0, 1, 8] and one member of each stratum [(0, 2), (3, 5), (6, 8)], and is 6 of 9
  ok   fp256: every sampled member is IDENTICAL: 0 IDENTICAL, 1 IDENTICAL, 2 IDENTICAL, 3 IDENTICAL, 6 IDENTICAL, 8 IDENTICAL
  ok   fp256: 36 closest approaches (each test particle to each active body, at the samples) agree with this gate's mpmath from tools/oracle.py's parse to 2.57e-7 relative, at the samples they name
  ok   the seed chooses: 8 different picks over 10 seeds
  ok   seed 1's plan is case 1's sample ([0, 1, 2, 3, 6, 8])
  ok   fp128: held at its own format and arithmetic, PASS, 5 members IDENTICAL
  ok   fp64 FMA form: held at its own format and arithmetic, PASS, 5 members IDENTICAL
  ok   the FMA form's program-engine record, rerun on the program engine: PASS, 6 members IDENTICAL
  ok   the FMA form's program-engine record, rerun on the loop engine: PASS, 6 members IDENTICAL
  ok   a. one byte of member 6's line 85 (tp2's x, 0x1.e06eaecdb3e7fp-1 for 0x1.e06eaecdb3e7ep-1): FAIL naming member 6, line 85 and the column; the other 5 sampled IDENTICAL (rc 1)
  ok   b. member 2's trailer mean_pc_iterations 3.300 made 3.301 (line 90): FAIL naming member 2 and the counter (rc 1)
  ok   c. member 7's 10 lines deleted, a member not sampled: FAIL naming it missing; the 6 sampled IDENTICAL (rc 1)
  ok   d. the record cut short at line 79: FAIL, all 9 members incomplete, and no trailer (rc 1)
```
Every other line is as before: controls a2, e, f and g, case 5, the particles lines, the counters lines and the first line of case 3. Controls a to d now hit other members and lines because the sample changed with nine members; each still fails where it should.

**Mutants of the driver (measured).** I reran all of them on 517e8d5. The unmutated copy passes and all 14 mutants are caught, including two new ones:
- M13 drops half of the scope text;
- M14 restores c640f65's note, which gave every rejecting member the first-attempt wording.

Both are caught by the format-difference and the scope-and-note verdicts.

## check-light on 517e8d5 (read from its log)
- Ran 02:07:06 to 02:54:24, make rc=0.
- Of 20 legs, 12 ran and each printed RESULT: PASS: check_equivalence, check_program_engine, check_door, check_corrector, check_gravity, check_scalar, check_records, check_ensemble, check_compare_run (34 ok), check_bodycount, check_checkpoint and check_seams.
- The gate cache skipped the other 8, each printed by name with "SKIPPED - inputs unchanged since it passed": constants, check_dropin_light, check_dropin_wide_light, check_archive, gate_real_fp64, gate_real_fp128, gate_real_fp256 and gate_subprocess. Their stamps come from c640f65's full check or the earlier check-light, and none of them takes a file that 517e8d5 changes.
- 387 `^  ok ` lines, 0 FAIL (the six lines containing "FAIL" are my gate's own control descriptions), 0 fork errors.

**Ledger.** I added entries at 01:50 and 02:55; the 01:50 one carries a mistaken 02:02 header, corrected underneath. The ledger has been unchanged since 01:51 apart from my drops, and my watcher is stopped.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p4\`:
- gate_full_2.log
- gate_quick_3.log
- check-light.log
- mutants3.out
- mut3\*.log

---

# P4 after V4: f27f9c6

All four of V4's points are fixed in **f27f9c6**, on top of 517e8d5, on branch `worktree-agent-a16e2203c9e2b005f`. It changes three files: tools/compare_run.py, tools/check_compare_run.py, and the Makefile's input list for my leg. Nothing was pushed or merged, no full `make check` was run, and the particles are not wired.

## What changed
1. **Bits, not binary64 values.** The gate has two new permanent controls, each asserted to FAIL naming the member, the line and the column:
   - **a3:** in the fp64 record, a sampled member's sample-0 `dt_last` is changed from `0x0p+0` to `-0x0p+0`, the sign of a zero.
   - **a4:** in case 4's fp128 record, one hex digit past binary64 is changed (the last digit of tp0's x). The gate also asserts that the edited value has the same binary64 value as before, so this control really is invisible to a binary64 comparison.
2. **NOT WIRED now fails.** When P3's tools are in the tree and the driver does not call them, it ends `RESULT: FAIL` and exits 1, whatever the members did. With P3's tools absent it still exits 0 and prints the same line as before. The gate checks both (control i): a copy of the driver next to an empty stand-in for each of P3's two files must fail, and the copy next to neither must pass.
3. **The cache key.** The leg's input list in all three tiers now has `$(patsubst %,--input %,$(wildcard tools/extract_particle.py tools/check_replay.py))`. I checked this by having make expand the list in a scratch directory, without touching the worktree. It adds `--input tools/check_replay.py` when that file exists, and both inputs when both do.
4. **Text and messages:**
   - The rounding count in the gate's comment is now stated truly: a particle's x takes two roundings, its y, z and vx four, and its vy and vz six.
   - The `# active` refusal now names the field that differs, for example "the `# active` line's pairs a force evaluation is 7 here, and 8 in the record". A new control (h) asserts it.
   - The sample's limit is stated in the driver's header and printed beside the sample. The gate asserts that line exactly.

## Gate
- **Full mode:** RESULT: PASS, 63 ok (54 before), 0 FAIL.
- **`--quick`:** RESULT: PASS, 41 ok (34 before).

These nine lines are new; no earlier line changed:
```
  ok   fp64: beside the sample, its limit, exactly: 'sample: it trusts the trailers it is testing: a member whose trailer under-reports its rejections leaves the sample, and an unsampled member's lines are never rerun'
  ok   fp128: beside the sample, its limit, exactly: 'sample: it trusts the trailers it is testing: a member whose trailer under-reports its rejections leaves the sample, and an unsampled member's lines are never rerun'
  ok   fp256: beside the sample, its limit, exactly: 'sample: it trusts the trailers it is testing: a member whose trailer under-reports its rejections leaves the sample, and an unsampled member's lines are never rerun'
  ok   a3. the sign of a zero, member 0's dt_last 0x0p+0 made -0x0p+0 on line 61: FAIL naming member 0, line 61 and dt_last; the other 5 sampled IDENTICAL (rc 1)
  ok   a4. one hex digit past binary64 (digit 28 of 28, the same binary64 value): member 6's tp0 x -0x1.b89bcdf740562c95c5acaf1dd29dp-3 made -0x1.b89bcdf740562c95c5acaf1dd29cp-3 on line 85 of the binary128 record: FAIL naming member 6, line 85 and the column; the other 4 sampled IDENTICAL (rc 1)
  ok   h. the record's `# active` line saying 8 pairs a force evaluation where this tree's rows make 7: REFUSED, naming the field (rc 2)
  ok   i. the driver's copy beside neither of P3's files: 'particles: not sampled (no particle replay in this tree)', PASS, rc 0
  ok   i. the driver's copy beside a stand-in tools/extract_particle.py: NOT WIRED, RESULT: FAIL and rc 1, though member 0 is IDENTICAL
  ok   i. the driver's copy beside a stand-in tools/check_replay.py: NOT WIRED, RESULT: FAIL and rc 1, though member 0 is IDENTICAL
```

## V4's mutant
V4's mutant, `if float(a[0]) != float(b[0]):` at the comparison in `compare()`, now fails the gate (rc 1). Its driver passed both doctored records with rc 0, so a3 and a4 each fail:
```
      FAIL a3. the sign of a zero, member 0's dt_last 0x0p+0 made -0x0p+0 on line 61: FAIL naming member 0, line 61 and dt_last; the other 5 sampled IDENTICAL (rc 0)
      FAIL a4. one hex digit past binary64 (digit 28 of 28, the same binary64 value): member 6's tp0 x ... on line 85 of the binary128 record: FAIL naming member ...
```
I reran every one-defect copy of the driver against the new gate. All 18 mutants are caught and the unmutated copy passes. Three of the 18 are new, one per fix:
- NOT WIRED made to exit 0: caught by control i;
- the sample's limit not printed: caught by the case 1 assertion;
- the old `# active` message: caught by control h.

## check-light on f27f9c6 (read from its log)
- Ran 04:11:53 to 04:14:10, make rc=0.
- Only check_compare_run ran: 41 ok, RESULT: PASS.
- The gate cache skipped the other 19 legs, each printed by name with "SKIPPED - inputs unchanged since it passed". This commit changes only my two tools and my leg's input list, so their inputs are byte-identical to their last passes: 517e8d5's check-light at 02:07 to 02:54, and c640f65's full check.
- No verdict line is a FAIL (the ten lines containing "FAIL" are my gate's control descriptions), and there were no fork errors.
- If V4 wants a cold check-light with all 20 legs run, it would take about 45 minutes on this host now.

My ledger entry for this is at 04:15 in my ledger drop. urgent/ held nothing new when I checked, and my watcher is stopped.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p4\`:
- gate_full_3.log
- gate_quick_4.log
- mutants4.out
- mut4\*.log
- check-light.log

---

# P4 after V4's second look: 79bd206

The gate now holds every column the record names, so V4's pair-skipping mutant fails it. The fix is commit **79bd206**, on top of f27f9c6, on branch `worktree-agent-a16e2203c9e2b005f`. It changes tools/check_compare_run.py and tools/compare_run.py. Nothing was pushed or merged, no full `make check` was run, and the particles are not wired.

## The fix: control a5
- **What it covers:** the gate reads the record's own `# columns:` line and plants one change in each of 12 columns: t, dt_next, dt_last and E; all six fields of the last body; and t_hi and t_lo. Using the last body means a comparison that stops before the end also fails.
- **How:** each change flips the last hex digit of one value in a sampled member's last sample line. Each member carries one column, so two records of 6 sampled members cover all 12, and every member must FAIL naming its column.
- **Added time, measured:** two extra driver runs, 10.1 s and 9.3 s on this loaded host, about 19 s per run of the leg in any tier.

**One more fix in the driver.** While timing a5, a relative `--exe` written with forward slashes crashed the driver with a traceback. It passed the driver's file check, but Windows could not launch it. The driver now makes `--exe` absolute.

## The new gate line
It is the only change to the gate's output (full mode RESULT: PASS, 64 ok, 0 FAIL, 483 s; `--quick` RESULT: PASS, 42 ok, 142 s):
```
  ok   a5. every column the record names, 12 of them, each one planted change in one sampled member's last line, 6 to a record over 2 records: each FAILs naming its column (t, dt_next, dt_last, E, x of body 4 (tp2), y of body 4 (tp2), z of body 4 (tp2), vx of body 4 (tp2), vy of body 4 (tp2), vz of body 4 (tp2), the exact-time pair's t_hi, the exact-time pair's t_lo)
```

## Mutants
The three you asked for each now fail the gate:

| Mutant | Caught by |
|---|---|
| V4's `zip(rv[:-2], mv[:-2])`, which skips the exact-time pair | a5 alone (see below) |
| V4's `float(a[0]) != float(b[0])` | a3 and a4 |
| Mine: skip the last body's six values, pair still compared | a, a2 and a5 |

For the pair-skipping mutant, a5's failure names what was missed: "NOT: the exact-time pair's t_hi in member 6: IDENTICAL 3 samples, 102 values, …; the exact-time pair's t_lo in member 8: IDENTICAL …". The mutant compares only 102 of each member's 108 values.

I also added a mutant that skips the four fields before the bodies; a3 and a5 catch it. Across the full rerun, all 21 mutants fail the gate, the unmutated copy passes, and every copy was deleted after its run.

## check-light on 79bd206 (read from its log)
- Ran 04:57:24 to 05:00:16, make rc=0.
- check_compare_run ran: 42 ok, RESULT: PASS.
- The cache skipped the other 19 legs, each printed by name with "SKIPPED - inputs unchanged since it passed". This commit changes no input of theirs.
- No FAIL verdict and no fork errors.

My ledger entry is at 05:00 in my drop. urgent/ held nothing new, and my watcher is stopped.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p4\`:
- gate_full_4.log
- gate_quick_5.log
- mutants5.out
- mut5\*.log
- check-light.log
