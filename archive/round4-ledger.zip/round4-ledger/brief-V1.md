You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) adds a second: what it builds is held by physics, not only by bits, because a GPU wave will later be held to it. **That is what this is about: whether a change just weakened either.**

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail ("inert by construction", or one that passes against itself);
- bit-identity taken for validity.

## What to verify

Commit `22ca3de`: parcel **P1** of round 4, which claims:
- **`src/ias15_zonal.inc`** holds the whole term: J2 and J4 of body `zonal_k` about the z axis, in the run's own format, from libcft's correctly rounded operations, with no FMA.
  - **Acceleration:** every other body of each system gets J2 then J4, as vector library calls over all of them.
  - **Reaction on k:** it is `(G*m_j)*prefac*fac*d`, subtracted in ascending body order, from the bodies that act on the active ones only. Under testparticle_type 0, a test particle gives no reaction whatever its mass.
  - **Potential:** in `energy_all`, after the pair terms: each interacting body's J2 part in ascending order, then each one's J4 part.
  - **The record line** names R, J2, J4 and the counts.
  - **`--zonal-selftest`** traces every operation and element move.
  - **`zonal_ready()`** refuses by name, before any output, a zonal line whose body is a test particle. The library half compiles a stub.
- **The order** is REBOUNDx's gravitational_harmonics.c AS RECALLED, not read: REBOUNDx is not pinned.
- **The cost, counted from the trace:** a body costs 3 sub, 21 mul (+13 for a reacting body), 14 add, 1 sqrt and 10 div per force evaluation.
- **src/ias15_cft.c changes only the allowed lines:** P0's refusal is deleted; `--zonal-selftest` gets its declaration, parse and dispatch; the hook `if (zonal_on) zonal_ready();` sits after the active line is applied; and the two comments that described the refusal change.
- **tools/gen_constants.py's check 3** derives the 19 integer coefficients from P2 and P4 and checks them against mpmath's derivative of the potential. The generator emits `zonal[]` and the `IAS15_ZONAL_*` names. The header and JSON change by additions only.
- **data/problems/zonal_saturn.txt:** Saturn, a Mimas-like moon inclined 3 degrees, and a ring particle at the Encke gap inclined 2 degrees, under `active 2`. `check_zonal.py --write-problem` derives it, and the gate holds the committed file to it byte for byte. Its reference radius is R = 60,330 km, BELIEVED (the study's belief), with J2 and J4 from Iess et al. 2019 via GPU-E §4.
- **tools/check_zonal.py**, the gate, has these parts:
  - gate 1: 126 operations and 1382 elements against the golden model, bits and flags, with each operand being the trace's last result, at all three formats;
  - gate 2: 14 points, 10 of them off the plane, plus each system's reaction and potential, against mpmath at 200 digits, with a bound of 1.33e-69 of the term at binary256;
  - gate 3: energy and momentum at every format, and the apsidal and nodal rates at binary64 within the second order's size;
  - gate 4: binary128 against binary256 on the same 120 steps, 3.4e-33 against 1.39e-30, its scope stated per the ruling;
  - both engines; an ensemble against its members; the 2^-40 test-particle case; the record line; the run key's `zonal=` field (a schedule replayed under another J2 is refused); and three refusals.
- **The crossings, by P1's account:** tools/check_gravity.py (P0's refusal case replaced by acceptance, as ROUND4.md says P1 does); tools/check_scalar.py (the recount reads `*.inc` and `zcall()` sites, and the zonal problem is a matrix case); and the Makefile's `IN_SCALAR`.
- **Suites (the parcel's):** the full make check on b3f664b gave rc 0, 20 legs, 977 ok and 0 FAIL. Seventeen existing legs have P0's ok counts exactly; check_corrector has +24 and check_scalar +9, from the new problem file. check_records passes. `make check-light` gave rc 0. 22ca3de changes only tools/check_zonal.py, and its gate passed in full: 87 ok.
- **Controls (the parcel's):**
  - rounded to binary64 in both runs: passes gate 4, fails gates 1, 2 and 3(c);
  - rounded at binary128 only: fails gate 4;
  - J4's z part dropped: fails gate 2 off the plane only;
  - the z sign flipped: fails 3(a);
  - the reaction dropped: fails 3(c) and gate 2's body-k line;
  - one ulp on one traced operation: fails gate 1, naming it;
  - a test particle's reaction taken: fails gate 2's body-k line and the 2^-40 case.

Read `git show --stat 22ca3de`, the diff, and the **P1** section of `ROUND4.md`, which is its brief. The parcel's final report is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\P1-report.md`; its brief as dispatched is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\briefs\filled\P1.md`; its ledger entries are `C:\Users\logan\source\repos\cft-rebound\.ledger\P1.md`. Read the lead's file (`lead.md`) there too, but **do not read the other parcels' files**: you are paid for independence.

You are in an isolated worktree. First `git checkout --detach 22ca3de`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, then verify each pin's HEAD against `third_party/MANIFEST`:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree and run the gate yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` (read it, never write it) or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it after the merge. Run the parcel's own gate, the legs it touches, and `make check-light` if you can, all in the background.

## Specific things to attack

1. **The formula, independently.** Derive -grad of Phi_z = (G M / r) [J2 (R/r)^2 P2(u) + J4 (R/r)^4 P4(u)] yourself and compare it with the C. Does gate 2 differentiate the POTENTIAL, or does it re-evaluate the force's own expression, which would make it a transcription and not a check? Is its mpmath precision enough for the bound it states at binary256?
2. **Off the plane.** Do gate 1's and gate 2's points include |dz| > 0 in both hemispheres? Re-run the "J4's z part dropped" control and confirm it fails only off the plane.
3. **The trace.** Does `--zonal-selftest` trace EVERY library operation the term makes? Count the operations in the C, and count the traced lines for one point. Could an operation escape the trace and so escape the golden model?
4. **The reaction.** Is the reaction on body zonal_k computed from the same terms, in ascending body order, and is it exactly +0 for test particles? Gate 3(c), conservation of momentum: does it use a massive second body, and would it fail with the reaction dropped? Re-run that control.
5. **No FMA, and one order.** Is there no fma in the term, and is the same order used under `--arith rebound` and `--arith fma`, on both engines? Verify it by measurement: the term's own contribution is the same bits on both engines.
6. **Constants.** Are they exact, dyadic and taken from data/ias15_constants.json through the generated header, rather than typed into the include? Does the `constants` leg pass?
7. **Flags.** Can the term raise UNDERFLOW, OVERFLOW or DIVBYZERO at any point the ring will reach: far bodies, a body near the oblate one, or body zonal_k itself (it must be skipped)? A flag aborts the run.
8. **check_scalar.** Its recount reads src/ias15_cft.c alone. Did P1 extend it to the include, or show the term has no site it counts? Does `tools/check_scalar.py` pass?
9. **The reference radius.** Does each problem pair J2 and J4 with a stated R, and give its source?
10. **The format difference (gate 4), under the lead's ruling** (`C:\Users\logan\source\repos\cft-rebound\.ledger\urgent\lead-gate4-ruling.md`). Is it run on the SAME steps (a dt file), and is its bound binary128's round-off rather than binary64's? Re-run both controls: the term rounded to binary64 at binary128 only must fail gate 4; rounded to binary64 in both runs must fail gates 1 and 2, and it passes gate 4, which is the measured blind spot. Does the gate's head state the scope the ruling asks for, and does no line claim more?
11. **The crossings.** P1 changed three files its brief's list did not name. In tools/gen_constants.py it added check 3 and the emitted `zonal[]` names. In tools/check_gravity.py it replaced P0's refusal case with an acceptance. In tools/check_scalar.py the recount now also reads `*.inc` files and `zcall()` sites, beyond its rows. For each change: is it necessary, and is it correct? Is any existing check weakened? Run the constants, check_gravity and check_scalar legs at 22ca3de and at 9a42b1d, and compare their ok lines.
12. **Derived, not transcribed.** Does gen_constants.py's check 3 derive the 19 integer coefficients from P2 and P4 and check them against mpmath's derivative of the potential, or does it compare a typed list with itself? Are the header and JSON changes additions only? The lead measured 0 removed lines; confirm that no existing constant's bytes moved.
13. **The reaction.** On body k P1 computes `(G*m_j)*prefac*fac*d`, with no divide by M. It takes the reaction only from bodies that act on the active ones: under testparticle_type 0, a test particle gives no reaction whatever its mass. Is that exactly REBOUND's meaning of testparticle_type 0? Which control would fail if a test particle's reaction were taken? P1 says the 2^-40 case then reports THEY DIFFER; re-run that control.
14. **Gate 2's bound.** P1's own dropped-reaction control first passed gate 2, because the bound absorbed the error. Is the bound now rigorous, and tight enough everywhere? For each formula-error control, by how many decades does the error exceed the bound at its least favourable point?
15. **"REBOUNDx's order, from memory."** Does any comment, record line or gate output claim that the order IS REBOUNDx's, rather than believed to be? REBOUNDx is not pinned. Do not download it.
16. **The commit after the suite.** The full make check ran on b3f664b, and 22ca3de changes only tools/check_zonal.py. Confirm that by diff, then run the zonal gate in full at 22ca3de.
17. **The new problem file's cost.** data/problems/zonal_saturn.txt makes check_corrector run it at every mode from dt 0.01 s, on a problem in km, and makes check_scalar take it as a case. Measure what it adds to those two legs' time, and whether those runs exercise anything.

The items every verifier checks:

- **The untouched path must be untouched.** Verify it **by measurement, not by reading**. The records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between `9a42b1d` and `22ca3de`. Build the base in a directory of your own. Run tools/check_records.py at `22ca3de` and report its result lines.
- **Re-run at least two of the parcel's negative controls,** independently and from copies. Pick the most load-bearing, and confirm each fails where claimed.
- **Scope.** Check `git diff --stat 9a42b1d 22ca3de` against the brief's "Files you own". Anything outside it is a finding, even if it looks correct.
- **Claims in comments and the commit message.** A sentence that asserts a property, such as "exact", "cannot happen", "derived" or "byte for byte", is checked with the bytes.
- **The usual shapes:** an assertion loosened; a tolerance where exactness was required; a case that cannot fail; a constant transcribed rather than derived; a TODO where work was claimed.
- **Anything else.** Tell me what I did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,500 words.
