You are parcel **P1** of round 4 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `9a42b1d` (main, where round 4's P0 landed; branch `round4-p0` points at it too). **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 9a42b1d` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. At binary64 it is bit-identical to REBOUND. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) builds on the CPU everything a GPU wave will later be held to, op for op. So its second invariant is that **every new thing is held by physics, not only by bits**: a wrong formula is bit-identical everywhere.

## Start here

1. `ROUND4.md`, all of it, then its **P1** section, which is your job's definition.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`: §1 (the one failure mode) and §5 (gates and negative controls). Section 5 names the ways a gate dies; yours must not.
3. P0's seam: `src/ias15_zonal.inc` (empty, yours now), and in `src/ias15_cft.c` the `zonal` branch of `read_problem()` (search `"zonal"`), the call `if (zonal_on) zonal_accel();` at the end of `gravity_body()`, `zonal_potential(epot)` in `energy_all()`, `zonal_record()` in the record header, and the `zonal=` part of `sched_key()`.
4. `CLAUDE.md`: how to build on Windows, the three suite tiers, and the traps.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there before you start, again before you design anything this brief calls shared or forbidden, and again before your report. You can read it but not write it (isolated worktree): write your entries, append only, to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P1.md`, and anything that must not wait as `urgent-P1-<slug>.md` in the same drop; the lead places them. Its README says what clears the bar. **Before anything else, arm the watcher on `.ledger\urgent\`** (the README has the loop, inline).

## Your job

Fill `src/ias15_zonal.inc`. The term is J2 and J4 of body `zonal_k` of every system, about the z axis, in the run's own format, built from the library's correctly rounded operations. It is added to `a` after gravity's fold, so it reaches every call site in both engines. It has four parts:
- **the acceleration** on every other body, added in ascending body order;
- **the reaction** on body `zonal_k`: each body's term times its mass over zonal_k's. It is exactly zero for a test particle;
- **the potential**, in `energy_all`;
- **a record line**.

Then delete P0's one refusal line, add `--zonal-selftest`, and build the gate (tools/check_zonal.py, one leg in each of the Makefile's three tiers).

**No FMA in the term**, as there is none in gravity. Then one order serves both forms, and a later binary64 comparison with REBOUNDx's harmonics can be op for op. The C is the definition of the order: its head says which order it uses and why. Nothing else restates it.

## What reading the code already turned up - verify it, do not trust it

- **The call site.** `gravity_body()` ends with the fold depositing into `a` (its last fold run's output is `a`). P0 calls `zonal_accel()` after it. `step_attempt()` copies `a` into `a0` after the first gravity call and into `at` after each node's. Predict and correct read only those two. **A finding to confirm:** nothing reads `a` between the fold and those copies. If it holds, a term added at the end of `gravity_body()` is seen by both engines at every node. If not, say so.
- **The vector helpers** are in src/ias15_cft.c: `vadd`, `vsub`, `vmul`, `vdiv`, `vsqrt`, `vkmul` (a constant operand), `vbcast`, `vcopy`, `vzero`, `valloc`. Each one is a correctly rounded library call. `energy_all()` shows the host gathering pair coordinates into contiguous vectors with `memcpy` and then one call a vector. Your term can gather the same way, over the E(N-1) bodies that are not zonal_k.
- **Skip body zonal_k itself.** At r = 0 the divide raises DIVBYZERO, and the engine aborts on INVALID, DIVBYZERO, OVERFLOW and UNDERFLOW (`cert_flags`).
- **Constants.** `data/ias15_constants.json` is turned into `src/ias15_constants.h` by `tools/gen_constants.py`, and the `constants` leg checks the header is current. Every coefficient a J2 or J4 term needs (3/2, 5/8, 5, 3, 63, 42, 28, 12 and so on) is a dyadic rational, so each is exact in every format. Add what you need there, rather than computing it at run time.
- **The derivation, for convenience - don't trust it; your gate 2 holds it.** The term is the J2 and J4 part of the potential, Phi_z = (G M / r) [J2 (R/r)^2 P2(u) + J4 (R/r)^4 P4(u)], with u = dz/r, and the acceleration is -grad Phi_z:

      a_J2 = (3/2) J2 G M R^2 / r^5 * ( dx (5u^2 - 1),  dy (5u^2 - 1),  dz (5u^2 - 3) )
      a_J4 = (5/8) J4 G M R^4 / r^7 * ( dx (63u^4 - 42u^2 + 3),  dy (...),  dz (63u^4 - 70u^2 + 15) )

  Here dx = x_j - x_k (j the body acted on, k = zonal_k), M is body k's mass, and G the problem's G. In the ring's units (P2) masses are GM with G = 1.
- **The golden model** is in this tree's pinned clone: `third_party/cft-fp256/python/cft_golden/softfloat.py`. It has `add`, `mul`, `fma`, `div` and `sqrt(fmt, xa, ...)`, each taking bit patterns as ints and returning `(bits, flags)`. Run it with `PYTHONPATH=third_party/cft-fp256/python` and `python -B`, so no `__pycache__` lands in the clone. Find the format objects in its formats module. **mpmath 1.3.0** is in the Windows Miniconda Python.
- **tools/check_scalar.py recounts call sites from src/ias15_cft.c alone** (its `--source`). Calls in your include are invisible to it. Either extend the recount to the include, or show the term has no site it would count. Say which.
- **`energy_all()` sums the pair potential into `epot`** per system, in REBOUND's order. The order in which you add the zonal potential is yours: after the pair terms, ascending body order. State it.

**The trap that would be a silent wrong answer: dz = 0.** Every z term is exactly zero for points in the equatorial plane. So gates 1 and 2 must sample points off the plane, and gate 3 uses an inclined orbit; the J4-z control below proves the off-plane points are there. Second trap: **J2 and J4 mean something only with their reference radius.** The study's J4 has none stated, and it believes 60,330 km. Whatever problem you write states its pair, with its source.

## The gates (tools/check_zonal.py; one leg, in `check`, `check-quick` and `check-light`, with every executed artifact an `--input`)

1. **Arithmetic.** `ias15_cft --zonal-selftest --format F` evaluates the term at a fixed set of points: on and off the plane, near and far, both hemispheres, a test particle and a massive body. It traces every library operation it makes, with operands and result in hex. The golden model checks each traced operation, bits and flags, at all three formats. The trace comes from the C itself, so nothing is transcribed.
2. **Formula.** The same points against -grad Phi_z, evaluated in mpmath at 200 digits from the potential, not from the force's code. Differentiate the potential (`mpmath.diff`, or analytically in mpmath from P2 and P4), never the force expression. The bound at binary256 is a relative 1e-68 or tighter, the format's own rounding across the term's operations; at binary64 and binary128 it is their own. State the bound you derive, and how you derived it.
3. **Physics.** Body k and one inclined, slightly eccentric test particle (and one with a small mass, for the reaction):
   - **(a)** the energy including Phi_z is conserved to the integrator's own level, at every format;
   - **(b)** the apsides advance at n - kappa and the node regresses at n - nu, first-order theory in J2 and J4, within the second-order terms' size (about a percent). Print the measured rates beside theory's, and assert them;
   - **(c)** with a massive second body, the reaction keeps the total momentum constant to the integrator's level.
4. **Format difference.** The same run at binary128 and binary256 on the same steps (`--dt-out` from one, then `--dt-file` with `--epsilon 0`). The positions must differ at binary128's round-off, not binary64's. Print the measured difference and the bound.

Plus the refusal P0 built, replaced. A zonal line is now accepted, and its record line and its run-key part are asserted.

**The run key's `zonal=` field needs a case of its own.** tools/check_corrector.py's walk "every field of the run key is held by a case" sees only the fields a run prints. P0's `zonal=` is printed only for a problem with a zonal line, so no case holds it until yours does. Add to check_corrector.py's walk, or to your gate, a schedule recorded under one J2 and refused under another. Say which you chose.

## Negative controls

Build each from a **copy** (never by patching the tree), run it, confirm it fails, delete it, and **report both results with their numbers**:
- the term rounded to binary64 before it is added: gate 4 fails, at about 1e-16;
- J4's z part dropped: gate 2 fails off the plane and passes on it;
- the force's z sign flipped, with the potential left alone: gate 3(a) fails;
- the reaction on body k dropped: gate 3(c) fails;
- one traced operation's result corrupted by one ulp: gate 1 names it.

## Files you own

- `src/ias15_zonal.inc`, all of it;
- tools/check_zonal.py, and data/problems/zonal_*.txt;
- the constants you need, in data/ias15_constants.json and the header it generates;
- tools/check_scalar.py's rows or recount, if needed;
- in src/ias15_cft.c, **only**: P0's refusal line in `read_problem()`; the `--zonal-selftest` option in `main()` and its function; and any one-line hook P0's three calls need;
- one leg in each of the Makefile's three tiers.

## Files you must NOT touch

- **src/ias15_cft.c outside the lines above.** P3 is editing its dt record, its step loop's replay branch and its run key right now. P2 is reading `read_problem()`.
- **tools/make_ring.py and tools/check_ring.py** are P2's. **tools/check_replay.py and tools/extract_particle.py** are P3's. **tools/compare_run.py** is P4's.
- **Integrator-only:** README.md, ROADMAP.md, CLAUDE.md, docs/VALIDATION.md, docs/HARDWARE.md, PARCELS.md, ROUND3.md, ROUND4.md, third_party/MANIFEST. If one needs a change, say so in your report.
- Anything outside your worktree. In particular, `C:\Users\logan\source\repos\cft-fp256` and `..\ParcelRound` are read only, and `C:\Users\logan\source\repos\cft-rebound-r4` is the lead's.

## Building and testing on this host

Your worktree has no `third_party/`. Clone it locally (no download) from the main checkout, at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
```

Then build, with the PATH line, which is not optional:

```bash
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- Never `make -j` in a fresh tree: it races on libcft.a.
- Run your own gate and `make check-light` (31 minutes cold) while you work.
- Before you report, run a full `make check` in the background. It took 2 h 36 min on 2026-11-06 and runs longer today: the host is shared and was at 100% load.
- Start that suite from PowerShell, with `Start-Process -FilePath "C:\Program Files\Git\bin\bash.exe" -ArgumentList "<your script.sh>" -WindowStyle Hidden -PassThru`. The script's path is the only argument. Inside it, spell TMP and TEMP out as the Windows directory.
- **Read the log, not the exit code.**
- Build only inside your own worktree.

## Working rules this repository learned the hard way

- **Bit-identity is not validity.** Every comparison prints a physics counter beside it, and asserts it.
- **A gate that cannot fail is not a gate.** Run your controls.
- **Derive; never transcribe.** A count or a name list is read from its definition.
- **Label every claim** as MEASURED or BELIEVED.
- **The `--light` scaling rules** are in CLAUDE.md. Your physics runs integrate to a count of steps; say which kind each case is.
- **Never run bare `git stash`.** No WSL, no GPU, no card. **No speed claims.**

## Do not

- push, merge or rebase, or commit to main. Commit inside your worktree only.
- move a committed record line. No problem in data/problems/ has a zonal line, so none should.
- "fix" anything outside your scope. Report it instead.

## Report

- what changed, file by file;
- the gate output, as **actual lines**;
- each control, with its measured numbers;
- the formula and order you chose, with the reference radius and its source;
- what you did not do;
- **anything you found that this brief or ROUND4.md got wrong.**

If something makes the approach unworkable, stop and report it rather than inventing a different design. If you had to cross a boundary this brief drew, say so and say why.
