You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, a multi-precision arithmetic library. Its central invariant: at binary64 the port is bit-identical to REBOUND, every backend gives the same bits, and **no committed record line moves** unless a change means it to. This round (ROUND4.md) adds a second: what it builds is held by physics, not only by bits, because a GPU wave will later be held to it. **That is what this is about: whether a change just weakened either.**

This project's canonical failures are the shapes to hunt. Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for them:
- a seam that belongs to nobody;
- a gate driving a stand-in;
- a gate that cannot fail ("inert by construction", or one that passes against itself);
- bit-identity taken for validity.

## What to verify

Commit `{COMMIT}`: parcel **{PARCEL}** of round 4, which claims:
{CLAIMS}

Read `git show --stat {COMMIT}`, the diff, and the **{PARCEL}** section of `ROUND4.md`, which is its brief. The parcel's own report is in the ledger: `C:\Users\logan\source\repos\cft-rebound\.ledger\{PARCEL}.md`. Read the lead's file (`lead.md`) there too, but **do not read the other parcels' files**: you are paid for independence.

You are in an isolated worktree. First `git checkout --detach {COMMIT}`, then confirm it with `git log --oneline -1`. `third_party/` is not in a worktree: clone it locally (no download) at the pins, then verify each pin's HEAD against `third_party/MANIFEST`:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional.
- No `make -j` in a fresh tree.

## Ground rules

- **Re-run things; do not trust pasted output.** Build from a clean tree and run the gate yourself.
- **Report only.** Do not edit any tracked file. Build controls from *copies* under a scratch directory, never by patching the tree, and delete them when done.
- **"Found nothing" is a completely acceptable answer.** Do not invent findings. State precisely what you ran.
- **Stay out of other trees.** Do not touch any other worktree, `C:\Users\logan\source\repos\cft-rebound` (read it, never write it) or `C:\Users\logan\source\repos\cft-fp256` (another session's: read only).
- **No WSL, no GPU, no network.**
- **Never run bare `git stash`.** Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it after the merge. Run the parcel's own gate, the legs it touches, and `make check-light` if you can, all in the background.

## Specific things to attack

{ATTACKS}

The items every verifier checks:

- **The untouched path must be untouched.** Verify it **by measurement, not by reading**. The records of the problems in data/problems/, at fp64, fp128 and fp256, on the loop engine in both forms and on the program engine, must be byte-identical between `{BASE}` and `{COMMIT}`. Build the base in a directory of your own. Run tools/check_records.py at `{COMMIT}` and report its result lines.
- **Re-run at least two of the parcel's negative controls,** independently and from copies. Pick the most load-bearing, and confirm each fails where claimed.
- **Scope.** Check `git diff --stat {BASE} {COMMIT}` against the brief's "Files you own". Anything outside it is a finding, even if it looks correct.
- **Claims in comments and the commit message.** A sentence that asserts a property, such as "exact", "cannot happen", "derived" or "byte for byte", is checked with the bytes.
- **The usual shapes:** an assertion loosened; a tolerance where exactness was required; a case that cannot fail; a constant transcribed rather than derived; a TODO where work was claimed.
- **Anything else.** Tell me what I did not think to ask.

## Report

For each numbered item, give **the commands you ran**, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**.
- Any defect needs a concrete failure scenario, not a concern.
- Distinguish "the shipped code is right" from "the gate would catch it if it weren't".
- End with **READY** or **NOT READY**, and say plainly if you found nothing.

Keep it under 1,500 words.
