# The parcel-specific attack lists, folded into V-common.md's {ATTACKS} at dispatch

## V1 (P1: J2 and J4 in libcft's format)
1. **The formula, independently.** Derive -grad of Phi_z = (G M / r) [J2 (R/r)^2 P2(u) + J4 (R/r)^4 P4(u)] yourself and compare it with the C. Does gate 2 differentiate the POTENTIAL, or does it re-evaluate the force's own expression, which would make it a transcription and not a check? Is its mpmath precision enough for the bound it states at binary256?
2. **Off the plane.** Do gate 1's and gate 2's points include |dz| > 0 in both hemispheres? Re-run the "J4's z part dropped" control and confirm it fails only off the plane.
3. **The trace.** Does `--zonal-selftest` trace EVERY library operation the term makes? Count the operations in the C, and count the traced lines for one point. Could an operation escape the trace and so escape the golden model?
4. **The reaction.** Is the reaction on body zonal_k computed from the same terms, in ascending body order, and is it exactly +0 for test particles? Gate 3(c), conservation of momentum: does it use a massive second body, and would it fail with the reaction dropped? Re-run that control.
5. **No FMA, and one order.** Is there no fma in the term, and is the same order used under `--arith rebound` and `--arith fma`, on both engines? Verify it by measurement: the term's own contribution is the same bits on both engines.
6. **Constants.** Are they exact, dyadic and taken from data/ias15_constants.json through the generated header, rather than typed into the include? Does the `constants` leg pass?
7. **Flags.** Can the term raise UNDERFLOW, OVERFLOW or DIVBYZERO at any point the ring will reach: far bodies, a body near the oblate one, or body zonal_k itself (it must be skipped)? A flag aborts the run.
8. **check_scalar.** Its recount reads src/ias15_cft.c alone. Did P1 extend it to the include, or show the term has no site it counts? Does `tools/check_scalar.py` pass?
9. **The reference radius.** Does each problem pair J2 and J4 with a stated R, and give its source?
10. **The format difference (gate 4), under the lead's ruling** (`C:\Users\logan\source\repos\cft-rebound\.ledger\urgent\lead-gate4-ruling.md`). Is it run on the SAME steps (a dt file), and is its bound binary128's round-off rather than binary64's? Re-run both controls: the term rounded to binary64 at binary128 only must fail gate 4; rounded to binary64 in both runs must fail gates 1 and 2, and it passes gate 4, which is the measured blind spot. Does the gate's head state the scope the ruling asks for, and does no line claim more?

## V2 (P2: the ring generator)
1. **Determinism.** Same arguments, same bytes; is there any `math.sin`, `math.cos` or float formatting that is not exact? Run the generator twice, and once more under a different `PYTHONHASHSEED`.
2. **The constants against their source.** Every value in make_ring.py against the study's §4 table (C:\Users\logan\source\repos\cft-fp256\docs\studies\GPU-E-mi300x-ring.md, read only). Is each one cited? Is the reference radius paired with J2 and J4?
3. **The physics of the initial state.** The circular speed in the oblate field: check v^2 against r |a_r| with J2 and J4 for a few particles. Is the frame barycentric? Is the Hill-radius exclusion real (count it) and are Epimetheus and Janus far apart in longitude?
4. **Not flat.** Is a wave's largest |z| above zero, asserted, for the particles AND the moons?
5. **The inert claim on the ring.** Does `active 7` against all 64 active compare the whole record at every format? Could it pass if `active` were ignored? (It would not, because the 420 pairs line would be missing; check that it is asserted from the record, not typed.)
6. **The ensemble against its members, and the engines.** Do these use the record's own columns and compare every line, as check_ensemble.py does?
7. **The steps-an-orbit counter.** Is it measured on a wave far from the moons, and is the 36.2 the study's (circular orbit, point mass)? Is the 10% bound asserted, or only printed?
8. **The zonal line.** Does the generator write P0's syntax (`zonal k R J2 J4`, k = 0)? Do the gates run with `--no-zonal`, so nothing breaks when P1 lands?
9. **Cost.** The leg's time in `check`, `check-quick` and `check-light`, measured.

## V3 (P3: a particle replayed out of its wave)
1. **Rejected attempts.** Does the attempts record carry every attempt, with its dt, outcome and passes? On a recorded rejection, does the replay take the same restore and the same prediction from er and br, with the same ratio? Verify by measurement on a wave that rejects (count its rejections), not only by reading.
2. **The run key.** Does it still refuse another wave, other massive bodies, and an old single-system schedule replayed into a sub-system? Does an existing schedule recorded at `{BASE}` replay unchanged at `{COMMIT}`? Measure it: record at the base, replay at the commit.
3. **The massive bodies.** Does the gate compare every massive body at every sample, not only the particle? Build the control with a "test" particle given a tiny mass, and show the gate fails on the massive bodies.
4. **Body order.** Is the sub-system's order (massive bodies first, same order, then the particle) asserted?
5. **`--dt-out`'s existing format.** Is it unchanged byte for byte? Committed CSVs in results/ were produced from it.
6. **check_corrector.py.** Does it still pass? If its matches changed, were they only the refusal text P3 changed?
7. **The controls move a dt or remove a rejection, not a count** (entry 41). Re-run two.

## V4 (P4: tools/compare_run.py)
1. **Can it pass against itself?** Trace what it compares: the RECORD's lines against a RERUN's, or a rerun against a rerun? Plant a difference in the record and confirm it is caught.
2. **Only the record format.** Does the driver read any ias15_cft internal (a debug flag, a dump) that a GPU engine's record would not have?
3. **The particle placeholder.** Is "particles: not sampled" printed and asserted? Is there anything that pretends to sample particles?
4. **The controls are permanent:** a byte changed, a member missing, another format, another problem. Does each fail by name, and is each asserted to fail?
5. **Sampling.** Is it seeded? Does it include every member with a rejected step? Is the closest approach labelled "at the samples"?
6. **Reuse.** Does it import check_ensemble.py's or check_records.py's parsing, or write it again? If again, does it agree with them on a real record?
7. **The format difference.** Is it run on the same steps, through a dt file?
