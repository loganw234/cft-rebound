# lead

## 2026-11-11 17:30 — Round 4 opened: the plan is ROUND4.md, on branch round4-p0

Measured: the round's worktree is C:\Users\logan\source\repos\cft-rebound-r4, branch `round4-p0`, at 7a7a279 (main = origin/main). Its third_party/ is a local clone of the main checkout's third_party/ at the MANIFEST pins (rebound bdfda4bd, cft-fp256 922c2ad): no download. The host has 12 cores and was at 100% CPU load at 17:22, shared with cft-fp256's agents, so suite times will run past 2026-11-06's (make check 2 h 36 min).
Believed: G1B merges to cft-fp256's main on 2026-11-12 (its lead's word, in a message; not in that repository).
For: anyone

## 2026-11-11 17:50 — P0 built at 4b52705 on round4-p0; its gate passes at binary64 and both controls fail where they should

Measured: `tools/check_gravity.py --build build --quick` at 4b52705: RESULT: PASS in 1 min 53 s; part 2b "25 pairs a force evaluation against 28 all active" on the loop engine in both forms and the program engine; part 2c's three refusals. Control (a), the active line parsed but eng_active never set: FAIL at all three engine/form settings (no 25-pair line; the 2^-40 control did not bite). Control (b), the run key never naming active: FAIL, the replay without it accepted (rc 0). Both built from copies in the lead's scratch and deleted; their gate logs are kept there (gpu/p0ctl/control-{a,b}-gate.log).
Measured: a mass of 1e-30, the plan's first control, would be inert at binary64 (below its last bit); the gate uses 2^-40. ROUND4.md says so.
Measured: the full `make check` on 4b52705 started at 17:45:49 from PowerShell (log: the lead's scratch gpu/p0-check.log). V0 dispatched at 17:5x in an isolated worktree, told not to touch cft-rebound-r4.
Believed: `vaugadd` runs every step (src/ias15_cft.c:2933 at 7a7a279), so G1B's AUGADD refusal will meet the default path on hip:N (the plan's GPU half, step 2).
For: anyone

## 2026-11-11 18:50 — V0 on 4b52705: two defects in `active`, fixed at 9a42b1d; the first make check died on MSYS fork failures

Measured (V0, 40 min): the untouched path held. 117 runs of data/problems/ and a 4-member ensemble, fp64/128/256, both engines and forms, were byte-identical between 7a7a279 and 4b52705 once the timing fields (seconds, steps_per_s, t_*, system_steps_per_s) were masked. check_records PASS. The schedule key was byte-identical in 9 of 9 cases. The zonal seam is unreachable in all three builds.
Measured (V0): DEFECT, energy_all() summed every body. REBOUND's reb_simulation_energy (third_party/rebound/src/tools.c:108) counts only the active bodies under testparticle_type 0 (N_interact = N_active). The gate missed it because its test particles were all massless.
Measured (V0): DEFECT, testparticle_type 0 was unheld: a copy at type 1 passed check_gravity --quick. Minor: `active 0` was accepted and then aborted on a 0/0 at the first step, and a second active line silently won.
Measured (lead): fixed at 9a42b1d. The energy now runs REBOUND's loops. Part 2b requires that under active 5 a test particle's 2^-40 mass changes nothing, energy column included, and it runs a two-system ensemble and its member. Part 2c refuses `active 0` and a second line. Controls (c), type 1, and (d), the energy counting every body, each FAIL at all three engine/form rows, built from copies and deleted. check_gravity --quick PASS at 9a42b1d in 2 min 48 s. V0 was sent back to re-verify.
Measured: the first full make check, on 4b52705, ended rc=2 at leg 7 of 19. check_corrector's forced drop-in run (`check_dropin --light` with CFT_REBOUND_ROUTE_REDUCE_SEG=on) returned rc 1 with no cases, and the log ends in MSYS fork failures (child_copy ... Win32 error 299; "couldn't create signal pipe", Win32 error 5). Rerun alone at 18:30-18:37, the same run gave rc 0: 170 ok, every case passed. The host was at 100% CPU, with 27.5 GB of 63.8 free.
Believed: the failure was environmental, fork failures under load. The full make check on 9a42b1d started at 18:49:08, and it must pass that leg.
Measured (V0): tools/make_ensemble.py refuses `active` lines ("unknown line"), so an ensemble with test particles must be written whole. P2's generator does that.
For: P1, P2, P3, P4, and anyone running a full suite on this host today

## 2026-11-11 19:20 — V0: READY on 9a42b1d

Measured (V0): the record's E column equals REBOUND's own sim.energy() (the rebound 5.1.1 wheel, with N_active and testparticle_type 0) bit for bit, at 7 samples, on three problems: kepler `active 1` (the star's kinetic energy alone), outer plus two test particles `active 5` with tp2 at mass 2^-40 (the all-active sum would differ), and kepler `active 2`. This compared energies at the same states; no stepped trajectory went through the wheel. The untouched path: 117 runs, 117 identical between 7a7a279 and 9a42b1d, timing masked. Both new controls bite at all three engine/form rows. check_gravity at every format: RESULT: PASS. V0 saw no MSYS fork failures in its own runs.
Believed (V0): testparticle_type 0 is held as a consequence (a test particle's mass must change nothing), not by an assertion of the type itself.
For: anyone

## 2026-11-11 21:15 — P0 landed: main = origin/main = 9a42b1d, a fast-forward from 7a7a279

Measured: the full `make check` on 9a42b1d, started 18:49:08 from PowerShell, ended rc=0 at 21:08:53 (2 h 20 min; log: the lead's scratch gpu/p0-check.log, 1602 lines). It ran 19 legs, each `--mode full` once. Every leg's own verdict line is present: 11 RESULT: PASS, gate_real: PASS at all three formats, gate_subprocess: PASS, check_dropin "every case passed", check_dropin --wide "passed", check_archive gates 1-3 PASS, and constants "78 constants compared, all match". There were 857 ok lines, 0 FAIL and no MSYS fork errors. check_corrector's forced drop-in run, the one that died on 4b52705, passed: rc 0, every case passed. The one `--` line is gate_subprocess's body_count, as on main. check_gravity part 2b passed at all 9 format × engine/form rows; part 2c passed its 4 refusals and the replay-key case.
Measured: `git merge --ff-only round4-p0` in the main checkout, then `git push origin main`: 7a7a279..9a42b1d. Round 3's P0 also landed as plain commits, with no merge commit. The tree the suite ran is the tree on main. Logan delegated round 4's merges and pushes to the lead on 2026-11-11, on round 3's bar.
Measured: at 21:11 the host's CPU load was 5%, with 29.1 GB of 63.8 GB free.
For: P1, P2, P3, P4. Your base is 9a42b1d.

## 2026-11-11 21:20 — P1, P2, P3 and P4 dispatched together, each in its own isolated worktree, base 9a42b1d

Measured: the four briefs are the lead's gpu/briefs/P1-P4.md with the base filled in as 9a42b1d (gpu/briefs/filled/). Each is told to write to scratchpad\ledger-drop\P<n>.md and to arm the urgent/ watcher first.
Believed: four parcels' builds plus up to four full suites on 12 cores will each take longer than P0's 2 h 20 min. Suites are mostly single-threaded (no -j), so four at once should fit the cores, but the MSYS fork failures seen at 100% load could come back. A parcel whose suite dies on fork errors reruns the leg alone, then the whole suite; it does not report a pass it did not read.
For: P1, P2, P3, P4

## 2026-11-12 01:33 — The drop went unwatched from 21:20 to 01:31; P1's urgent file was placed 3 h 17 min late; the ruling on it is urgent/lead-gate4-ruling.md

Measured: at dispatch the lead armed no watcher on the drop. P1's urgent-P1-gate4-blind.md (written 22:14) and every drop entry before 01:31 reached .ledger/ at 01:31, late by up to 4 h. That includes P3's and P4's entries addressed to each other, and P1's to P2, P3 and P4. All four drops were placed verbatim at 01:31, and urgent-P1-gate4-blind.md as urgent/P1-gate4-blind.md.
Measured: the lead's watcher (gpu/drop-watch.sh in its scratch) now places every author's drop file verbatim every 60 s, by copy and rename. It stops and wakes the lead on any urgent file it has not seen. The lead reads each urgent file before placing it.
Measured: the ruling on P1's finding is urgent/lead-gate4-ruling.md. It amends P1's brief (gate 4's control) and P4's format difference (its stated scope).
For: anyone

## 2026-11-12 01:38 — P2, P3 and P4 reported; V2 and V3 dispatched; P4 resumed for two small changes; what the merges must carry

Measured (the parcels' reports, each read from its own suite log, not yet verified): P2 at 250789e, P3 at 569ee4e and P4 at c640f65 each ran a full make check with rc 0, 20 legs and 0 FAIL, and each existing leg's ok count equals P0's. Each diff touches only the files its brief owns (git diff --stat 9a42b1d; P3's src/ias15_cft.c hunks go to V3 item 8). Their reports are in the lead's scratch, gpu/reports/P2-P4-report.md, extracted from the parcels' own transcripts.
Measured: V2 (P2 at 250789e) and V3 (P3 at 569ee4e) were dispatched at 01:45, each in an isolated worktree with its filled brief (gpu/briefs/filled/V2.md, V3.md). P4 was resumed at 01:40 for two changes: compare_run's --format-diff prints its scope (the ruling), and the rejecting-member note depends on whether the first attempt was rejected. V4 waits for that commit. P1 is still running.
What the merges must carry (from the parcels' measured findings):
- P3 x P4: once both are in the tree, check_compare_run fails until sample_particles() in tools/compare_run.py is wired to P3's extract_particle.extract(). P4 built that tripwire on purpose. The second of P3 and P4 to merge carries the wiring. In a wave that rejects, the sample includes the particle that drove the rejection, the closest approach P4 already computes (P3's 23:00 entry).
- P1 x P2: generate the ring WITHOUT --no-zonal, because each file is circular in its own field (P2). To isolate the zonal line, delete it from that file; do not compare two generated files.
- P1 x P3: the zonal line must ride the replay. extract_particle copies the wave's zonal line verbatim, and the key names it.
- The Makefile: the four new legs (check_zonal, check_ring, check_replay, check_compare_run) take every tier to 23 legs. CLAUDE.md says 19.
For the sweep (integrator-only files) and the GPU half:
- ROUND4.md: P1's gate 4 control (the ruling); "a replay cannot carry a rejected step" holds only for a rejection before the first accepted step (P3, P4), so the whole-wave fallback narrows to those waves; 10^6 particles is 17,544 waves of 57, 1,000,008 particles (P2); the brief's third_party clone loop is refused by the worktree-isolation guard, and plain separate commands work (P2, P4).
- README.md:513's option list lacks --attempts-out and --run-key (P3), and P1's --zonal-selftest when it lands.
- A record names neither --adaptive-mode, --softening, --min-dt nor --no-flag-abort, so a GPU record must name any non-default itself (P4). ias15_ref writes ias15_cft's first line (P4).
- The constants leg (gen_constants.py --no-write) does not check that src/ias15_constants.h is current, so a stale header passes every tier (P1). This is the lead's to decide.
- ok-line counts depend on the pattern: P0's log has 857 by '^  ok ' and 858 by '^\s+ok\b' (P4).
- For cft-fp256, in one message after the verifiers: the format difference cannot see a shared binary64 narrowing (P1, GPU-E §6 item 3(b)); the zonal term in REBOUNDx's order costs a body 10 divides and a square root an evaluation, where GPU-E priced 1 divide (P1); Pan's orbit caps the step of every wave outside it, about 3% more steps over the ring (P2); 1,000,008 particles (P2).
For: P1, P4, V4, and the lead at each merge

## 2026-11-12 01:46 — P1 reported at 22ca3de; V1 dispatched

Measured (P1's report, read from its own suite log, not yet verified): the full make check on b3f664b gave rc 0, 20 legs, 977 ok and 0 FAIL. Seventeen existing legs have P0's ok counts exactly; check_corrector has +24 and check_scalar +9, from the new data/problems/zonal_saturn.txt. 22ca3de changes only tools/check_zonal.py (git diff --stat b3f664b 22ca3de: 1 file), and P1 reran its gate in full on it: 87 ok, PASS. The ruling is applied: gate 4's control is the binary128-only rounding, and the head states the scope.
Measured (the lead, git diff 9a42b1d 22ca3de): 10 files. Three lie outside the brief's list, each named in P1's report with its reason: tools/gen_constants.py (check 3 derives the 19 coefficients), tools/check_gravity.py (P0's refusal case replaced, as ROUND4.md says P1 does) and tools/check_scalar.py's recount (it reads *.inc). src/ias15_constants.h and data/ias15_constants.json lose 0 lines: additions only.
Measured: V1 was dispatched at 02:00 with its filled brief (gpu/briefs/filled/V1.md). V-attacks.md's V1 item 10 now carries the ruling, and seven extra attacks cover the crossings, the derivation, the reaction under testparticle_type 0, gate 2's bound, the "REBOUNDx's order, from memory" claim, the commit after the suite, and the new problem file's cost.
Believed (P1): the term's order is REBOUNDx's gravitational_harmonics.c as recalled, not read. REBOUNDx is not pinned, and ROUND4.md's decision 4 is Logan's.
For: V1, and the lead at P1's merge

## 2026-11-12 02:56 — V2 on P2 at 250789e: NOT READY, one gate gap; P2 sent back

Measured (V2): nothing holds the moons out of the plane. A copy of make_ring.py with the six moons' inclinations set to 0, the particles untouched, passes check_ring: 31 ok, RESULT: PASS, rc 0. On such a ring a moon's J2/J4 z terms and the z of its reaction on Saturn stay exactly zero, and the moons carry all of the ring's reactions. So a wrong reaction z would match bit for bit: inert by construction.
Measured (V2): the rest is confirmed.
- Determinism: ten runs, one sha256. An independent 400-bit recomputation reproduces every value, 399,049 of them in a 57,000-particle zonal ring.
- The constants match GPU-E §4. The orbits are tools.c:972-992, term for term.
- The 420 pairs are read from the record. The steps an orbit are 36.22 by the study's own method.
- The untouched path: 72 runs a build, 315 sample lines, identical. check_records PASS. make check-light rc 0.
Measured (V2), notes: the gate neither checks ias15_ref's impl= nor prints its build time (METHOD §5), so a stand-in binary at that path would pass. PER_WAVE = 57 is a constant, not derived.  never finishes.
Measured: P2 was resumed at 2026-11-12 02:56 with the defect and the notes. V2 re-verifies the change. The report is gpu/reports/V2-report-1.md in the lead's scratch.
For: P2, and the lead at P2's merge

## 2026-11-12 02:57 — Correction to the entry above headed with V2's NOT READY: one note lost its words

Measured: the lead's shell swallowed a backtick-quoted option in that entry, so its notes line reads "...not derived.  never finishes." It should read: "...not derived. `--exclude-hill 1000` never finishes: nothing bounds the exclusion's redraws." Nothing else in it changes.
For: anyone reading V2's notes

## 2026-11-12 02:58 — P4's follow-up at 517e8d5; V4 dispatched

Measured (P4's follow-up report, not yet verified): 517e8d5 changes tools/compare_run.py and tools/check_compare_run.py only (git diff --stat c640f65 517e8d5). Every `--format-diff` line now ends with the ruled scope, "the difference shows the narrower format's round-off on these steps; a narrowing both runs share passes it", and the gate asserts it. The rejection note now follows whether the FIRST attempt was rejected.
Measured (P4): a new member 8 holds the note's other branch. Its first attempt is accepted, then it rejects 3 attempts. Members 0-7 are byte-identical to c640f65's record. Mutants: 14 of 14 caught, including M14, c640f65's old note. The gate in full: 54 ok, PASS. make check-light on 517e8d5: rc 0, 12 legs run and 8 skipped by the gate cache, each skip printed by name.
Measured (P4, on member 8 at fp64 and fp128): after a rejection that follows an accepted step, a dt-file replay differs from the run only in dt_next, and only on the sample printed just before the rejected attempt. That sample carries the rejected attempt's dt. This is what P3 believed, now measured.
Measured: V4 was dispatched at 02:58 on 517e8d5 with its filled brief (gpu/briefs/filled/V4.md). The report file holds both of P4's reports.
For: V4, and the lead at P4's merge

## 2026-11-12 03:03 — V3 on P3 at 569ee4e: NOT READY, a dt file through a pipe; P3 sent back

Measured (V3): D1, a defect. read_dt_file() reads the first line, then calls rewind(f) without checking it. A pipe cannot rewind, and the C runtime drops its 4,096-byte buffer. Through a Windows named pipe, 9a42b1d reads old-form dt files exactly as from a regular file. 569ee4e refuses kepler and outer. On a padded file it exits rc 0 having started from line 129, with all 6 sample lines wrong and nothing printed. No gate covers it.
Measured (V3): F2, a false comment. The head comment at :79-87 says --replay-iters of the same run's schedule replays that run bit for bit. That schedule is refused, rc 3, because its key differs in epsilon and dt_file=attempts.
Measured (V3), confirmed:
- every attempt is recorded, on V3's own waves, the 64-body one included: 6,528 values and 0 mismatches for every particle alone;
- 144 of 144 base schedules replay unchanged;
- no older key moves, in 72 configurations; `--dt-out` is byte-identical in 72; check_corrector's leg is identical to P0's;
- a rejection after an accepted step leaves no state bit, at fp256 on the program engine and at fp64 in the FMA form. Only dt_next moves, on a sample printed just before the deleted attempt;
- the massive-body comparison is load-bearing: with test particles pulling on the massive bodies, only Saturn differs at fp64;
- both controls re-run and fail; the untouched path holds; check_records PASS; make check-light rc 0.
Measured (V3), notes: the head comment's two additions lie outside P3's owned regions. They are comment-only and disclosed, and the lead accepts them. Wave C's deletion case holds only because no sample falls just before the deleted attempt.
Measured: P3 was resumed at 03:03 with D1 (parse the line already read rather than rewinding, plus a case if one can run here), F2, and the fragile case's precondition, asserted. V3 re-verifies. Its report is gpu/reports/V3-report-1.md in the lead's scratch.
For: P3, and the lead at P3's merge

## 2026-11-12 03:20 — P2's fix at 8bb49b9; V2 re-verifies

Measured (P2's report, not yet verified): 8bb49b9 changes only tools/check_ring.py and tools/make_ring.py. The generator's ring is byte-identical to 250789e's (cmp). Each moon's sin i > 0 is asserted, from r x v relative to Saturn. It is sin i, not |z|: Pan's z is exactly 0 at its node. V2's flat-moons control now FAILS by name: 33 ok, 1 FAIL, rc 1 (it passed on 250789e: 31 ok). ias15_ref's `impl=rebound` is asserted and its build time printed. PER_WAVE is derived, N=64 is asserted, and the exclusion's redraws are bounded. The gate in full: 40 ok, PASS. With --quick: 34 ok, PASS.
Measured: V2 was resumed at 03:20 with a scoped re-check: the diff, the generator's bytes, control C, a one-moon-flat control of its own, a stand-in at ias15_ref's path, and the gate.
For: V2, and the lead at P2's merge

## 2026-11-12 03:28 — V1: READY on P1 at 22ca3de; the lead merges it with a fix commit of its own

Measured (V1): READY. The force was derived by hand and compared with `--zonal-selftest` at every format: worst 6.7e-16, 2.5e-34, 1.6e-71. Gate 2 differentiates the potential. 126 operations and 1382 elements, counted by hand, equal the trace. No FMA: the term's own contribution is the same bits on every engine and form. Constants are regenerated byte for byte. 100 untouched-path configurations are identical. check_records PASS. make check-light rc 0, with no cache skips. Seven controls were rebuilt from copies; each fails where claimed, by 9.6 to 150 decades over gate 2's bound.
Measured (V1), findings:
- check_zonal.py:82 says "eleven decades"; it is 18.
- The cost is 34 mul a body an evaluation, test particles included, not "21 (+13 for a reacting body)". The divide and square-root counts stand.
- src/ias15_zonal.inc:16 and :240 state REBOUNDx's order flat; only :38 qualifies it as BELIEVED.
- The selftest's R = 1.5 and check_gravity's R = 1 are synthetic and unlabelled.
- The record's "takes the reaction of N" comes from zonal_ready(), not from the loop that subtracts.
- check_scalar's `bodies.get("zonal_ready", "")` would drop the term's constants silently if the function were renamed.
Measured (V1), P0's seam, now reachable: a second `zonal` line is accepted and silently replaces the first, and a fifth field is ignored. A second `active` line is refused by name.
Plan: merge P1 --no-ff onto an integration branch, round4-int, in cft-rebound-r4. The lead's fix commit there: refuse a second zonal line and any trailing field on `active` and `zonal`, with check_gravity 2c cases; the text findings; check_scalar's hard lookup. Then the full make check on that tree. main fast-forwards only after it passes.
For: anyone

## 2026-11-12 03:34 — V2: READY on P2 at 8bb49b9; P1 merged on round4-int at 4dd53f3 with the lead's fixes, its legs running

Measured (V2's re-check):
- `git diff --stat 250789e 8bb49b9` covers the two tools only.
- The generator's bytes are identical to 250789e's on five rings, one of them 57,000 particles with zonal lines.
- Control C, all six moons flat, fails by name. V2's own control, Pan flat and the other five inclined, fails by name; the check is moon by moon.
- A copy of ias15_cft.exe at ias15_ref's path passes the bit comparison (1940 values) but fails the new identity line: "program=cft impl=libcft-0.18".
- The gate in full: 40 ok, PASS. With --quick: 34 ok, PASS.
Measured (the lead): P1 is merged --no-ff at 4dd53f3 on round4-int in cft-rebound-r4. The lead's fix commit, not yet committed:
- read_problem() refuses a second zonal line, a fifth zonal field and a second active field, by name;
- check_gravity 2c gains those three cases, and its synthetic zonal values are labelled;
- check_zonal.py:82 now says eighteen decades;
- the include's two flat REBOUNDx sentences are qualified as BELIEVED, and the selftest's R = 1.5 is labelled synthetic;
- one function, zonal_gives(), now feeds both the record's reaction count and zonal_apply()'s loop;
- check_scalar requires each CONST_FUNCS body.
The build is clean, with no warnings. --zonal-selftest at all three formats is byte-identical to P1's build, and zonal_saturn on 3 formats x 3 engine/forms gives 9 of 9 identical records, timing masked.
For: anyone

## 2026-11-12 03:46 — V4 on P4 at 517e8d5: NOT READY, the gate cannot tell bits from binary64 values; P4 sent back

Measured (V4): D, the defect. A copy of compare_run.py comparing float(a[0]) != float(b[0]), which is binary64 values without the sign, passes the whole gate in full mode: 54 ok, PASS. It also passes the fp64 record whose sample-0 dt_last is -0x0p+0, and an fp128 record one hex digit off below binary64. The shipped driver fails both. Every byte-change control is on an fp64 record, and none flips a zero's sign.
Measured (V4), confirmed:
- the driver compares the record's own lines against the rerun's: five planted differences, each FAIL by name;
- it reads only the record format: a record rewritten as another producer's passes;
- its controls, the sampling (SHA-256 recomputed independently) and the reuse are as claimed; the first-attempt test cannot misfire (src/ias15_cft.c:2545-2553, :2964, :3001);
- members 0-7 are byte-identical to c640f65's; the untouched path holds, 144 of 144 runs; check_records PASS; make check-light rc 0, cold, with all 20 legs run.
Measured (V4), notes:
- NOT WIRED exits 0, with RESULT: PASS.
- P3's file names are not inputs of the leg's cache key, so check-quick and check-light skip the leg when only P3's files change.
- A comment's count of roundings is wrong.
- The pair-count refusal names the wrong field.
- The sample trusts the trailers it tests: a member whose trailer under-reports its rejections leaves the sample. That is a limit of the briefed design.
Measured: P4 was resumed at 03:46 with D (two permanent controls: a zero's sign flipped at fp64, a digit past binary64 at fp128, and V4's mutant re-run) and the notes. V4 re-verifies. Its report is gpu/reports/V4-report-1.md in the lead's scratch.
For: P4, and the lead at P4's merge (the GPU seam: a record held by bits, not values)

## 2026-11-12 03:48 — The lead's fix committed at 291c99c on round4-int; the full make check on it started at 03:47:45

Measured: on the merged tree with the fix, the touched legs passed:
- gen_constants --no-write: 78 constants compared, all match;
- check_gravity --quick --library: 22 ok, PASS, the three new refusals by name with nothing printed;
- check_zonal --quick: 85 ok, PASS;
- check_scalar --quick --library: 35 ok, PASS.
Measured (control): P1's own build, before the fix, runs all three new problem files with rc 0. With two zonal lines it made body 1, the second line's, the oblate one, which is V1's finding. So the new cases fail without the fix.
Measured: 291c99c is committed on round4-int (5 files, +63/-22). The full make check on it was launched from PowerShell at 03:47:45, pid 23076, logging to gpu/int-check-291c99c.log in the lead's scratch. main stays at 9a42b1d until that log is read.
Next, after it passes: fast-forward main to 291c99c, push, report. Then merge P2 (8bb49b9) with the P1 x P2 seam test, and run the full suite again.
For: anyone

## 2026-11-12 03:59 — P2 merged on round4-int2 (9dd4051) with the P1 x P2 seam test (ecd2b20), waiting behind P1's suite

Measured: a second lead worktree, C:/Users/logan/source/repos/cft-rebound-seam, branch round4-int2 from 291c99c. P2 merged --no-ff at 9dd4051 with no conflict, so every tier has 21 legs. The pins are cloned locally, and the build is clean (the only warnings are pinned REBOUND's simulationarchive.c).
Measured: tools/check_ring_seams.py, round 4's seams, part 1 (P1 x P2), runs a ring with its zonal line and the same file with the line deleted:
- without the line, each particle moves outward as an orbit of eccentricity delta = 3/2 J2 (R/r)^2 - 15/8 J4 (R/r)^4. Full mode: 1169 to 1233 km in 24 steps, within 2.0% of delta r (1 - cos M).
- with the line, P1's field holds every particle's distance from Saturn to 0.18 km, 1.5e-4 of that, under a bound of 1e-3.
- the control, permanent: J4 zeroed in the zonal line moves each particle outward 16.6 to 18.1 km, within 1.8% of J4's share, 18 times the bound.
- the record's zonal line matches the file. Engines agree at fp64, fp128 and fp256 with the zonal line; `active 7` equals every body active (pairs 420 against none, reaction 6 against 63); a two-wave ensemble equals each wave alone.
- energy with the zonal potential: 1.6e-15 over 24 steps.
Full mode 76 s, quick 57 s. Committed at ecd2b20 with its leg in each tier, so every tier has 22 legs.
Next: when 291c99c's suite passes, main fast-forwards to 291c99c and is pushed. Then round4-int fast-forwards to ecd2b20 in cft-rebound-r4, and the full suite runs there.
For: anyone

## 2026-11-12 04:17 — P4's fix at f27f9c6; V4 re-verifies

Measured (P4's report, not yet verified): f27f9c6 changes tools/compare_run.py, tools/check_compare_run.py and the Makefile's input list for the leg (git diff --stat 517e8d5 f27f9c6: 3 files).
- Two permanent controls of bits, not values: a3, a zero's sign flipped in the fp64 record, and a4, a digit past binary64 at fp128 with the same binary64 value. Each fails by member, line and column. V4's float() mutant now fails the gate, and 18 of 18 driver mutants are caught.
- NOT WIRED exits 1 with RESULT: FAIL when P3's tools are present (control i).
- P3's file names are in the leg's cache key in all three tiers.
- The rounding count and the `# active` refusal's field (control h) are fixed. The sample's limit is printed beside the sample.
- The gate in full: 63 ok, PASS. With --quick: 41 ok, PASS.
Measured: V4 was resumed at 04:17 for a scoped re-check: the diff, its own mutants, the cache-key experiment, a4's bits, and the gate.
For: V4, and the lead at P4's merge

## 2026-11-12 04:20 — P3's fix at 2638e72; V3 re-verifies

Measured (P3's report, not yet verified):
- read_dt_file() no longer rewinds: it reads the first line once and continues from it. Through a named pipe, outer's plain, padded and attempts-form files read as from a file.
- A gate case feeds a padded dt file and an attempts record through a pipe, and fails on 569ee4e's program.
- F2 is corrected, and its claim is gated: a whole wave replays through its attempts record with no schedule.
- C's deletion asserts its precondition by name, and B's deletion asserts the bodies differ. "It moved" sums the angle.
- check_replay in full: 303 ok, PASS. check_corrector in full: 278 ok, PASS. make check-light: rc 0.
Measured (P3): P0's read_problem() also rewinds without checking. A problem file through a pipe is refused by name ("read 0 bodies, expected 2", rc 3), not misread. That is the lead's code. It refuses rather than misreads, so it stays as a stated limit for the docs sweep.
Measured: V3 was resumed at 04:20 for a scoped re-check: the diff, its pipe scripts, old dt files from regular files, the new case against the old reader, loosened assertions, and the gate.
For: V3, and the lead at P3's merge

## 2026-11-12 04:34 — V4 on P4 at f27f9c6: NOT READY, the exact-time pair is unheld by the gate; P4 sent back for one control per column

Measured (V4): f27f9c6 is otherwise confirmed.
- The diff is 3 files.
- V4's float() mutant fails, through a3 and a4; a sign-only mutant fails, through a3 alone.
- The cache key: with tools/extract_particle.py added, the leg reruns and fails.
- a4's edited value rounds to the same binary64, checked two ways.
- The gate in full: 63 ok, PASS.
Measured (V4), the defect: a mutant that skips the exact-time pair, `zip(rv[:-2], mv[:-2])` (what check_equivalence.parse_record does), passes the FULL gate. The shipped driver catches a planted t_hi digit, and the mutant passes it with rc 0. That pair comes from vaugadd, the path G1B is expected to refuse on hip:N.
Measured: P4 was resumed at 04:34 to make every column of `# columns:` load-bearing in the gate:
- each head field, each field of the last body's block, and t_hi and t_lo, one planted change each, asserted to FAIL naming its column;
- grouped about one per sampled member, so about three records cover them;
- V4's two mutants and a truncation mutant re-run.
V4 re-verifies after.
For: P4, V4, and the lead at P4's merge

## 2026-11-12 04:38 — V3: READY on P3 at 2638e72

Measured (V3's re-check):
- The diff: src/ias15_cft.c +28/-16 and tools/check_replay.py +228/-34. Lines reach the parser in the base's order, and nothing is rewound.
- Through a named pipe, kepler, outer, kepler_e099 and a padded outer read identically at 9a42b1d and 2638e72; the attempts record too, 0 of 61 lines different.
- Old dt files from regular files: 31 configurations identical, with --dt-out files and schedules byte-identical; 62 of 62 base-recorded schedules replay to the base's run.
- The new pipe case fails on a build with the old reader: 118 ok, 1 FAIL.
- Nothing is loosened: B's deletion is stricter, and C's precondition fails by name if unmet.
- check_replay in full: 303 ok, PASS. With --quick: 119 ok.
P1, P2 and P3 are READY. P4 is on its second send-back. Merges stay serial: P1's suite is running, then P2 with its seam, then P3.
For: anyone

## 2026-11-12 04:49 — P3 merged on round4-int3 (3b69eae) with seam part 2 (21185e1), queued behind P1's and P2's suites

Measured: round4-int3, in the seam worktree off ecd2b20. Merging P3 (2638e72) gave one conflict, in main()'s declarations: P1's `do_zonal` beside P3's `do_key`. Both are kept. The Makefile auto-merged, so every tier has 23 legs. The build is clean. check_replay, check_zonal and check_ring_seams pass with --quick on the merged tree.
Measured: check_ring_seams part 2 (P2 x P3, P1 x P3) runs P2's generated waves with P1's zonal line and replays three particles a wave through P3's extract() (imported). Fifteen replays at fp64, fp128 and fp256, from a first step of 100 s and from 1e5 s (first attempt rejected, asserted). Each gives the wave's bits: the particle, all 7 massive bodies, every head and exact-time pair, and the counters, with the record naming the term felt by 7 and 6 reacting. The control, permanent: a sub-system with its zonal line deleted, re-keyed by hand through --run-key, replays to other bits in 64 of 72 sample-and-body pairs. Both parts in full: 3 min 46 s.
Queue: 291c99c's suite is running. Then ecd2b20 (P2 plus seam part 1), then 21185e1 (P3 plus part 2), then P4 with the P3 x P4 wiring, each with its own full make check.
For: anyone

## 2026-11-12 05:01 — P4's second fix at 79bd206 (every column load-bearing); V4 re-verifies

Measured (P4's report, not yet verified):
- 79bd206 changes tools/check_compare_run.py and tools/compare_run.py.
- Control a5 plants one change in each of 12 columns read from the record's `# columns:` line, one per sampled member over 2 records: t, dt_next, dt_last, E, the last body's six fields, t_hi and t_lo. Each fails naming its column.
- V4's `rv[:-2]` mutant fails through a5 alone. All 21 driver mutants fail.
- --exe is made absolute: a relative forward-slash path had crashed the driver.
- The gate in full: 64 ok, PASS, 483 s. With --quick: 42 ok.
Measured: V4 was resumed at 05:01 for a scoped re-check: the diff, whether a5's columns are derived or typed, its mutants, and the gate.
For: V4, and the lead at P4's merge

## 2026-11-12 05:38 — V4: READY on P4 at 79bd206; the merge order restructured (P2 + P4 under one suite, as ROUND4.md allows); the P3 x P4 seam wired

Measured (V4's third look):
- a5's columns are derived from `# columns:`: a line with three invented columns gave 15, unedited.
- The `rv[:-2]` mutant fails through a5 alone, and V4's own skip-the-velocities mutant fails through a5 alone.
- The gate in full: 64 ok, PASS.
- Not blocking: a5 planted body fields in the last body only, so a skip-body-0 mutant passed.
Measured (the lead, on round4-int4 in the seam worktree):
- 110834f: seam part 1 gains ROUND4.md's precession counter. Each ring particle's node regresses at n - nu (first order in J2 and J4) to 9.0e-4 over 10 orbits; the theory without J4 misses by 2.8e-2, 31 times as far. In --quick, 8.3e-3 over 3 orbits, bound 2e-2, J4 not claimed.
- 801e2be: P4 merged. The Makefile's four conflicts were each "keep both".
- 7d50392: a5 also plants one field in every other body (16 columns, 3 records). A copy skipping body 0 now fails a5 by name, "NOT: x of body 0 (primary)".
- check_compare_run --quick on the P2+P4 tree: 42 ok, PASS. Every tier has 23 legs.
Measured (the lead, round4-int5 on round4-int4):
- 7ece3e3: P3 merged, with the do_zonal/do_key conflict resolved as before; src identical to 3b69eae.
- acf9fff: seam part 2 cherry-picked from 21185e1, the Makefile conflict resolved. Every tier has 24 legs.
- Not yet committed: the P3 x P4 wiring.
  - compare_run's reruns write each member's attempts record and schedule (they move no record line: measured, timing masked).
  - Two particles a member (its least closest approach at the samples, and one by the seed) are replayed alone through P3's extract() and held to the RECORD's lines, values and counters.
  - P3's tools present but not callable FAIL by name.
  - check_compare_run asserts the picks: the least one is the body the gate's mpmath names.
  - Control p, permanent: a digit planted in the sampled particle's x fails exactly its replay, and in the primary's x fails both.
  - check_compare_run --quick: 44 ok, PASS, 329 s, against 163 s before: every driver call now replays 12 particles.
Plan: when 291c99c's suite passes, main fast-forwards to it and is pushed. round4-int fast-forwards to round4-int4 (P2 + seam part 1 + P4 + a5), and that suite runs. Then round4-int5 (P3 + seam part 2 + the wiring), and its suite. Three suites, not four.
For: anyone

## 2026-11-12 05:52 — The P3 x P4 wiring committed at e5636a9; VL dispatched on the lead's own commits

Measured:
- check_compare_run in full on round4-int5 with the wiring: 66 ok, PASS, 646 s. At fp64, fp128 and fp256, 12 particles each are replayed alone and are IDENTICAL to the record. Case 6, the program engine, passes.
- Committed at e5636a9. On the same tree, check_replay --quick gives 119 ok and check_ring_seams --quick gives 19 ok, both PASS.
- 291c99c's suite: leg 17 of 20 at 05:51, with 847 ok and 0 FAIL so far.
Measured: VL, a verifier of the lead's own commits, dispatched at 06:00 with gpu/briefs/filled/VL.md. It covers the fix after V1, both seam parts, the a5 hardening, the P3 x P4 wiring, the four merges and the cherry-pick behind acf9fff, and the untouched path. No parcel verifier saw any of that. It does not block the merges, whose bar is a parcel's READY plus the full suite, but its findings are fixed before the round closes.
For: VL, and anyone

## 2026-11-12 05:55 — A status message to cft-fp256, at Logan's request

Measured: at Logan's word ("send a brief status update back to the session which initiated this work"), one message to cft-fp256 was delivered to its inbox, not yet read there. It gave:
- status: P0 pushed; P1-P4 READY and merging; no GPU, WSL or card used;
- for GPU-E:
  - its §6 item 3(b) cannot fail on a shared binary64 bottleneck;
  - the term costs a body 3 sub, 34 mul, 14 add, 1 sqrt and 10 div an evaluation, where GPU-E prices 1 div;
  - 17,544 waves hold 1,000,008 particles;
  - Pan caps the step of the outer waves, about 3% more steps;
  - only first-attempt rejections leave state;
- also: a record names no non-default --adaptive-mode, --softening, --min-dt or --no-flag-abort; the exact-time pair comes from vaugadd (BELIEVED: on the default path, refused by G1B as AUGADD); R = 60,330 km is still BELIEVED.
This replaces the one message after the verifiers that the 01:4x entry planned. It went before VL's report, so anything VL finds that touches these findings goes to cft-fp256 in a follow-up.
For: anyone

## 2026-11-12 05:59 — cft-fp256's lead answered: finding 1 confirmed and to be corrected in GPU-E; P1's main SHA asked for

Believed (cft-fp256's lead, by message; not in this repository):
- Finding 1 is confirmed: GPU-E §6 item 3(b) is wrong, and its question 4 for Logan leans on it. Both are to be corrected by a new commit on cft-fp256's main, credited as MEASURED in this tree.
- Finding 2: GPU-E's J2/J4 row was an ESTIMATE made before code existed. It becomes P1's operations as read on this tree's main, and cost_model.py is re-run. cft-fp256 asks for P1's main SHA. Its rough estimate: about ten more divides a body raise the force's binary256 cost by about a third.
- Finding 3: its cost model takes ceil(N/57), with a last wave of 49 particles.
- Findings 4 and 5 go in as notes.
- AUGADD on a GPU is round 2 of cft-fp256's GPU plan, not yet scheduled.
- G1B merges with M4's wave 5 under one box gate after night 1111's close, about 08:30, taking 4-5 hours. The main SHA comes after, for decision 7.
- The device divide waits on Logan's decision 3. Neither GPU has a slot until G1B merges, and P5's slot is Logan's.
Measured: the lead replied on item 3. This tree cannot write a 49-particle last wave: an ensemble needs every system at N. So the run is 17,544 full waves, 1,000,008 particles (P2), or padding. The SHA follows P1's landing.
For: anyone; the docs sweep (RING.md: the last wave's fill, and GPU-E's correction)

## 2026-11-12 06:35 — P1 landed: main = origin/main = 291c99c; the P2 + P4 suite on 7d50392 started at 06:35:43

Measured: the full make check on 291c99c ran from 03:47:46 to 06:34:31 (2 h 47 min) on a clean committed tree, rc=0. Log: gpu/int-check-291c99c.log.
- 20 legs, each `--mode full` once. 980 ok, 0 FAIL, no fork errors. Every verdict line is present: 12 RESULT: PASS, constants all match, check_dropin, --wide, archive gates 1-3, gate_real x3 and gate_subprocess.
- Leg by leg, the ok counts are P0's except check_corrector 302 (+24, zonal_saturn), check_gravity 44 (+3, the lead's refusals), check_scalar 99 (+9, the zonal case) and the new check_zonal at 87.
- The one `--` line is gate_subprocess's body_count, as on main.
Measured: `git merge --ff-only round4-int` in the main checkout, then the push: 9a42b1d..291c99c. cft-fp256 was sent the SHA for its GPU-E recount, with V1's 34-mul correction.
Measured: in cft-rebound-r4, round4-int fast-forwarded to round4-int4 at 7d50392: P2, seam part 1, P4 and the a5 hardening, 23 legs a tier. Its full make check was launched from PowerShell at 06:35:43, pid 52024, logging to gpu/int-check-7d50392.log.
For: anyone

## 2026-11-12 06:37 — cft-fp256 acknowledged P1's SHA; its GPU-E correction comes this afternoon at the earliest

Believed (cft-fp256's lead, by message): it received P1 at 291c99c, the 34-mul correction, and the full-waves point (17,544 waves, 1,000,008 particles). GPU-E's correction will read src/ias15_zonal.inc at 291c99c for its count, in a new commit on cft-fp256's main after today's merges and their gate. It sends that SHA once the commit is pushed. Nothing is needed from this side meanwhile.
For: the docs sweep (RING.md cites GPU-E's corrected commit once it exists)

## 2026-11-12 07:22 — VL on the lead's commits at e5636a9: NOT READY, the particle path's comparison is held in two values only

Measured (VL), the defect: a copy of compare_run.py whose particle_compare checks only the particle's x and the primary's x passes check_compare_run --quick: 44 ok, PASS. Control p plants x columns only, so an edit that dropped the exact-time pair from the particle path would ship green. It is the same hole V4 sent P4 back for at 04:34, in the lead's code.
Measured (VL), confirmed:
- 291c99c: 24 of 24 valid files still run (CRLF, trailing blanks); zonal_gives is bit-neutral (12 of 12, plus 9 of 9); the three refusals' cases fail on a build without them.
- Seam part 1: VL derived the excursion and n and nu independently. Its controls fail: J2's x/y factor x1.01 fails circularity (1.17e-2 against 1e-3); J4's z zeroed fails the node counter (3.72e-2 against 5e-3); z negated, nodes advance. The node fit's residual is short-period noise, 31 times below J4's signal.
- Seam part 2: a replay by hand at fp128, 406 of 406 tokens; the zonal-line control bites through the bits.
- a5: a skip-body-1 mutant fails a5.
- The wiring: 30 of 30 configurations unmoved by the rerun's extra outputs; a mutant holding the replay to the rerun fails control p; the picks are right; the not-callable states are caught.
- Merges: each resolution is keep-both and nothing is lost; the leg lists are unions, 24/24/24.
- Untouched path: 60 of 60 identical. check_records PASS. make check-light, cold: 24 legs, 890 ok, 0 FAIL, 63 min.
Measured (VL), text:
- check_ring_seams.py's header gives "about 3e-5", the --quick figure; full mode is 1.53e-4.
- It also credits the 10% no-line check with J4, though J4's share is 1.4%; the J4-zeroed control holds J4.
- compare_run.py's header has two stale lines about P1's zonal line.
- read_problem's comment does not say inline comments are refused on active and zonal lines and ignored on body lines.
Measured (VL), a combination no gate runs: compare_run on P2's generated ring with P1's zonal line, the shape a GPU record will have. By hand it PASSes, and a digit planted in Mimas's x fails the member and both its particles.
Plan, all on round4-int5, not on round4-int4, whose suite is running:
- a planted change in every column the particle path compares (head fields, the particle's and every massive body's fields, the pair, a counter), each failing that particle's replay by name;
- the four text fixes;
- check_ring_seams part 3, compare_run on a zonal ring with a planted control;
- mutants run; VL re-checks.
For: anyone

## 2026-11-12 07:40 — The fix for VL's defect at 7a339d1 on round4-int5; VL re-verifies

Measured:
- check_compare_run p2 plants a change in every column particle_compare compares, read from `# columns:` (24 a particle), plus a trailer counter. All 25 FAIL the member's least-closest particle's replay by column.
- Three mutants of particle_compare each FAIL p2 alone, on exactly what they drop: VL's two-x mutant (2 held), the pair skipped (t_hi and t_lo missed), the counters skipped (the counter missed). Each took about 490 s on the loaded host.
- check_ring_seams part 3 (P2 x P4, P1 x P4): the driver on P2's zonal ring passes, 2 members and 4 particles IDENTICAL. Its moon-x control fails wave 0 and both its particles while wave 1 stays IDENTICAL.
- The four texts are fixed.
- --quick: check_compare_run 45 ok, 428 s; check_ring_seams 21 ok, 182 s.
- Committed at 7a339d1. VL was resumed at 07:40 for a scoped re-check.
- The P2 + P4 suite on 7d50392 was at leg 8 of 23 at 07:36, with 616 ok and no FAIL.
For: VL, and the lead at P3's landing (round4-int5's tip is now 7a339d1)

## 2026-11-12 07:56 — VL re-check of 7a339d1: NOT READY, the particle path held on one sample line only; fixing

Measured (VL): 7a339d1 is confirmed as claimed:
- p2's plan is derived (29 columns from a line with invented ones);
- the two-x mutant fails p2 alone;
- part 3 is not inert: a particle_compare that compares nothing fails its control;
- the four texts are accurate.
Measured (VL), the defect: a particle_compare that compares every column but only the LAST sample line passes the gate, 45 ok, PASS. Control p and all of p2's plants sit on the member's last line. A replay differing only in an intermediate line's dt_next, the one difference P3 and V3 measured can occur alone, would ship green.
Measured (VL), notes: p2 plants one trailer counter of five; part 3's comment says each wave rejects its first attempt where the code asserts at least one rejection.
The lead's fix, in progress on round4-int5:
- p2's plants cycle over each member's sample lines after sample 0. Sample 0 is the problem's initial state, which the problem check refuses on. The gate asserts more than one line is planted.
- Three non-structural trailer counters are planted, one a member. steps_done and steps_rejected stay with the structure checks and the member path, as stated.
- Part 3's comment is corrected.
- Mutants run in parallel with the clean gate: the last line only, and one middle line only.
For: VL, and the lead at P3's landing

## 2026-11-12 08:05 — The lead's first line-mutant run proved nothing: the mutation script did not parse, and the runner ran the copies unmutated

Measured: on the fix for VL's line defect, the clean gate passes. check_compare_run --quick: p2 holds 24 columns on sample lines 1 and 2, plus 3 trailer counters, PASS, 497 s. check_ring_seams --quick: PASS, 182 s.
Measured: the "lastline" and "firstline" mutants both PASSED, but only because they were never mutated. The lead's heredoc edit of mutate_pc.py put a raw newline in a string, the script died on a SyntaxError, and the runner went on and ran the unmutated copies. That is a stand-in passing for a control, the shape this round hunts.
The fix: mutate_pc.py is rewritten with the file tool, and it exits non-zero unless its replacement applies exactly once. The runner now writes "=== NOT MUTATED" and runs nothing when the mutation fails. All five mutants apply cleanly to a copy (checked). The two line mutants are re-running.
For: anyone running mutants from scripts

## 2026-11-12 08:13 — The line fix committed at d9c8c8c on round4-int5; the line mutants, now applied, fail; VL re-verifies

Measured: the two line mutants of particle_compare were re-run, each applied ("mutated ..." first in its log):
- the last sample line only: p2 FAILs alone, 15 of 27 held, missing the line-1 plants;
- one middle line only: p2 FAILs, missing the line-2 plants, and so does control p, whose plants are on the last line.
Committed at d9c8c8c. VL was resumed at 08:13 for a scoped re-check. round4-int5's tip is now d9c8c8c, the commit P3's suite will run.
For: VL, and the lead at P3's landing

## 2026-11-12 08:24 — VL: READY on the lead's commits at d9c8c8c

Measured (VL):
- `git diff --stat 7a339d1 d9c8c8c` is two files, with no source or Makefile change.
- The tree passes: 45 ok, p2 27 held on lines 1 and 2.
- VL's last-line mutant fails p2 alone (15 held). Its new mutant, the particle's fields on every line but the rest on the last line only, fails p2 alone (18 held).
- p2 is neither inert nor self-confirming. Its planting reads `# columns:` independently of the driver's Columns. Each check names its line, its column and both values. Line coverage is enforced, a shifted pick fails, and the trailer plants are isolated.
- Stated limits: steps_done and steps_rejected are not planted; each column is planted on one line.
Every commit of the round now has a verifier's READY: P0 (V0), P1 (V1), P2 (V2), P3 (V3), P4 (V4), and the lead's fixes, seams, wiring and merges (VL).
Plan: land P2 + P4 (7d50392) on its suite. Draft the docs sweep onto round4-int5 before P3's suite starts, so one suite covers P3, the seams, the wiring and the docs.
For: anyone

## 2026-11-12 08:26 — D, a docs drafter, dispatched; P3 and the docs will share one suite

Measured: no gate reads the docs, except tools/check_pins.sh, which needs README.md to name cft-fp256's pin 922c2ad (checked by grepping tools/ for reads of README, ROADMAP, VALIDATION, CLAUDE, ROUND4 and docs/). So the docs sweep can share P3's suite.
Measured: D was dispatched at 08:26, in an isolated worktree, with gpu/briefs/filled/D.md. It drafts on a branch round4-docs off d9c8c8c:
- VALIDATION entries 46-51;
- a new docs/RING.md;
- CLAUDE.md: leg counts derived from the Makefile, measured suite times, up to three traps;
- README.md: options, grammar and tools, with the 922c2ad line kept;
- ROADMAP.md;
- ROUND4.md: status, and what the round found against the plan.
Results that do not exist yet carry one marker each, LEAD-FILL. The lead reviews every line, fills the markers from the logs, and greps for LEAD-FILL before the docs go onto round4-int5.
For: anyone

## 2026-11-12 08:56 — D's draft at 79128a1 (round4-docs); VD verifies it; the plan changes: P3 takes the next suite alone, the docs land after with their own

Measured: D committed 79128a1 on round4-docs, on d9c8c8c. It changes six documents, +1730/-14, and README's 922c2ad line is unchanged. It has two LEAD-FILL markers, both in VALIDATION entry 51, for the P2 + P4 suite and P3's suite. D's report is gpu/reports/D-report.md; it lists every number with its source, and nine open items.
Measured: D's item 8, "int-check-7d50392.log may have stalled", is not so. At 08:54 the log was written at 08:53, the suite in check_checkpoint, 21 of 23 legs started. D read it during a long leg.
Measured, from D's open items, to fix in the lead's docs commit:
- `--zonal-selftest` is missing from src/ias15_cft.c's usage block (a comment);
- tools/check_ring.py:15-16 still says the zonal line is refused until P1 lands (a comment).
Both are text in code files, so they go through the docs commit's suite.
Measured: VD was dispatched at 09:00 to verify 79128a1: every number against its source, the labels, derived counts, the pin line, the markers, consistency, and D's nine items.
Plan: when 7d50392's suite passes, main fast-forwards to it and is pushed. Then round4-int fast-forwards to d9c8c8c (P3, the seams and the wiring), and its suite runs at once, without the docs, so P3 lands sooner. The docs, VD's fixes, the two comments and the ledger's archive then land in one commit with its own suite. Three suites remain in all, counting the running one.
For: anyone

## 2026-11-12 09:11 — P2 and P4 landed: main = origin/main = 7d50392; P3's suite on d9c8c8c started at 09:11:20

Measured: the full make check on 7d50392 ran from 06:35:43 to 09:09:48 (2 h 34 min) on a clean committed tree, rc=0. Log: gpu/int-check-7d50392.log.
- 23 legs, each `--mode full` once. 1097 ok, no fork errors. 15 RESULT: PASS, plus constants, check_dropin, --wide, archive gates 1-3, gate_real x3 and gate_subprocess.
- No verdict line FAILs. Of the 11 lines with the word FAIL, ten are ok lines naming a control, and one is check_compare_run's controls heading.
- Leg by leg, the ok counts are 291c99c's on all 20 legs both ran. The new legs: check_ring 40, check_compare_run 64, check_ring_seams 13 (part 1, at this commit).
- The one `--` line is gate_subprocess's body_count.
Measured: `git merge --ff-only 7d50392` in the main checkout, then the push: 291c99c..7d50392. P2 and P4 merged together under one suite, as ROUND4.md allows: they share no file beyond a leg each. P2 was READY from V2 (8bb49b9), P4 from V4 (79bd206), and the lead's seam part 1, node counter and a5 hardening from VL.
Measured: in cft-rebound-r4, round4-int fast-forwarded to d9c8c8c: P3, seam parts 2 and 3, the P3 x P4 wiring and VL's fixes, 24 legs a tier. Its full make check was launched from PowerShell at 09:11:20, pid 46036, logging to gpu/int-check-d9c8c8c.log.
For: anyone

## 2026-11-12 09:17 — VD on the records at 79128a1: NOT READY, no wrong number; two false statements, stale plan text, minors; the lead fixes them

Measured (VD): more than 120 numbers checked against their sources across RING.md, CLAUDE.md and entries 46-51, with no mismatch. Legs per tier recounted: 24/24/24 at d9c8c8c. README's 922c2ad row is byte-identical. Exactly two LEAD-FILL markers, and no other placeholder.
Measured (VD), required fixes:
- README.md:249-250 says check_ring runs a wave against REBOUND and its ensemble at every format. It does both at binary64 only.
- VALIDATION.md:5813-5816 restates P1's belief that check_corrector's zonal_saturn runs exercise nothing physical. V1 measured its adaptive runs growing to about 1,200 s, roughly an orbit; only the fixed runs, to t = 3 s, are non-physical.
- The second LEAD-FILL marker, "three suites rather than four" (6386) and ROADMAP:862 predate the 08:56 plan, under which P3 takes d9c8c8c's suite alone and the docs take their own.
Measured (VD), minors:
- RING.md:93 says another producer's record is refused; it passes.
- Gate 4's controls were copies run once, not permanent.
- CLAUDE.md:75 "the particle's x": control p planted the primary's x too.
- VALIDATION:6240 describes control i as it was at 79bd206.
- RING.md:104 omits --programs.
- RING.md:46 says counts not divisible by 57 are refused; --one-system is exempt.
- CLAUDE.md's times are not like for like.
- README's times are undated.
- D's item 8 (stalled log) was wrong: 7d50392's suite passed.
Measured (the lead, read only in cft-fp256): `git diff 56006987 be40005b -- docs/studies/GPU-E-mi300x-ring.md` is 0 lines, and 56006987 is an ancestor of be40005b. D's claim that GPU-E is unchanged at be40005b stands.
Plan: the lead fixes all of VD's items on a branch round4-docs-final off 79128a1, in the seam worktree, with the two code comments: the usage block's --zonal-selftest and check_ring.py:14-16. The first marker gets 7d50392's suite. After d9c8c8c's suite, the second gets that suite, and a sentence that the docs commit's own suite is recorded in the ledger. Then the ledger is archived and the commit runs its own suite.
For: anyone

## 2026-11-12 09:20 — VD's fixes made on round4-docs-final (uncommitted, in the seam worktree); three markers wait for d9c8c8c's suite

Measured: on round4-docs-final, off 79128a1, uncommitted: 8 files, +61/-41.
- README: check_ring's line no longer overstates (REBOUND and the ensemble at binary64 only); four suite times dated to 19 legs, 2026-11-06; the 922c2ad row kept.
- VALIDATION:
  - entry 47's corrector line is V1's measurement (adaptive runs to about 1,200 s; fixed runs to t = 3 s);
  - the usage-block limit is now "did not name ... this commit adds it";
  - gate 4's two controls are stated as copies run by P1 and V1, not permanent;
  - control i's row covers both states;
  - entry 51's plan text matches 08:56: four suites after P0's;
  - the 7d50392 row is filled: 23 legs, rc 0, 1097 ok, 0 FAIL, 2 h 34 min, the 20 shared legs at 291c99c's counts, the six digests;
  - the second marker is restated as the d9c8c8c row, plus a sentence that the records' own suite is in the closing report, since a commit cannot record its own suite;
  - entry 46 now says the ledger "is archived".
- ROUND4.md: gate 4's controls stated as copies.
- RING.md: --one-system exempt from the 57 rule; another producer's record held if it carries every field; --programs in the usage; the be40005b claim marked MEASURED by the lead.
- CLAUDE.md: the rows' like-for-like note; "only x (the particle's and the primary's)"; the paragraph rewrapped.
- Code text: --zonal-selftest added to src/ias15_cft.c's usage block, with one line on what it does; check_ring.py:14-16 no longer says the zonal line is refused.
Measured: entry 45's six wide-state digests appear in p0-check.log, int-check-291c99c.log and int-check-7d50392.log alike (e08541 and 5d7cf4 and a10527 twice each, 56bacf and cd16e6 and ba4d44 once each).
To fill after d9c8c8c's suite: LEAD-FILL-D9 (the VALIDATION row), LEAD-FILL-D9-ROADMAP (the digests' list) and LEAD-FILL-D9-CLAUDE (make check's last measured row). Then the ledger is archived, the drop watcher stopped, one commit made, and its own full make check run.
For: anyone

## 2026-11-12 09:32 — Study DEBRIS-A (at Logan's request) returned; two in-repo findings recorded in the pending docs

Measured (DEBRIS-A; study only, nothing built or committed): REBOUND's IAS15 suits debris physics, with drag, a moving Moon and backward runs. REBOUND is not a debris platform: no atmosphere, gravity field, frames, TLE handling or orbit determination, and its state transition matrix omits user forces (one column 44% wrong after a day with J2). cft-rebound is the wrong tool: a 20% density error moves a 400 km object 5.0 km a day against 1.2e-8 m between binary64 and binary128, a factor of 4e11, and the port ran 145 times slower than REBOUND on the same steps. Recommendation (BELIEVED): ESA's cascade (heyoka) for populations, Orekit for single objects and the refit cycle. Study: scratchpad studies/DEBRIS-A-rebound-for-debris.md.
Measured (DEBRIS-A, READ, in this repo):
1. src/ias15_zonal.inc's recalled order is REBOUNDx's of 5406ae5 (2020-04-13). REBOUNDx rewrote it on 2024-10-20 (8402022). This bears on decision 4.
2. tools/state_to_problem.py drops the `active` and `zonal` lines, so tools/reversal.py would reverse on a different problem. The lead confirmed no gate runs either tool.
Both are now on round4-docs-final, uncommitted:
- RING.md (the BELIEVED list and decision 4's row);
- VALIDATION entry 47's limits (the order) and entry 46's (the tool: P0's grammar, unowned, not fixed);
- ROADMAP's new "Still owed from round 4".
Measured (DEBRIS-A): the web tool auto-saved one unreadable ESA conference PDF into the Claude project's tool-results folder, outside every repository.
For: Logan (decision 4), the next round (state_to_problem)

## 2026-11-12 10:47 — Logan: fix tools/state_to_problem.py's gap, with a test, after the round

Measured: asked "Fix the state_to_problem gap, with a test, after round 4 lands?", Logan answered "Yes, after the round".
Plan: once round 4's last commit (the records) has landed, make state_to_problem.py carry the `active` and `zonal` lines from the record's header, and gate it with a reversal case on a zonal, `active` problem. That case shows the backward leg runs the same problem and comes home to round-off, and fails on a copy that drops either line. It goes on its own branch. Round 4's merge delegation ends with round 4, so landing the fix on main waits on Logan's word.
For: anyone

## 2026-11-12 11:50 — P3 landed: main = origin/main = d9c8c8c; every parcel of round 4 is on main; the records commit and the ledger's archive next

Measured: the full make check on d9c8c8c ran from 09:11:20 to 11:47:58 (2 h 37 min) on a clean committed tree, rc=0. Log: gpu/int-check-d9c8c8c.log.
- 24 legs, each `--mode full` once. 1424 ok, no fork errors. 16 RESULT: PASS, plus constants, check_dropin, --wide, archive gates 1-3, gate_real x3 and gate_subprocess.
- No verdict line FAILs. The one FAIL-word line outside an ok line is check_compare_run's controls heading.
- Of the 23 legs 7d50392 also ran, 21 have its ok counts. The other two: check_compare_run 67 (+3, the wiring's controls) and check_ring_seams 34 (parts 2 and 3). The new check_replay: 303.
- Entry 45's six wide-state digests are present, with the same counts.
Measured: `git merge --ff-only d9c8c8c` in the main checkout, then the push: 7d50392..d9c8c8c. P3 was READY from V3 (2638e72). The lead's seams, wiring and fixes were READY from VL (d9c8c8c). The P2 x P3, P1 x P3 and P3 x P4 seams ran inside the suite.
Measured: the drop watcher was stopped at 11:50; every author's drop file equals its placed copy. The records' three markers are filled from the logs, and no LEAD-FILL remains.
Next: the records commit on round4-docs-final, with this ledger archived beside it as archive/round4-ledger.zip, then its own full make check, then the push. This is the ledger's last entry; the round's close is reported to Logan.
For: anyone
