I've read P1's urgent and the ledger files the lead placed at 01:31. Nothing in them changes my results. They add one stated limit, and the `ok` counts are now given in both patterns.

# P3 report: READY on 569ee4e

A test particle now replays out of its wave bit for bit, rejected attempts included. That holds at fp64, fp128 and fp256, on both engines and both forms, with every massive body and every counter matching the wave's.

Branch `worktree-agent-a45030143888b996c`; I confirmed the base is 9a42b1d. There are two commits, 60457ce and 569ee4e. Nothing was pushed, merged or stashed. I wrote five entries to `scratchpad\ledger-drop\P3.md`; the lead has placed them in the ledger.

## The suite (MEASURED, read from the logs)
- **Full `make check` on 569ee4e**, launched from PowerShell, ran 22:52:32 to 01:29:13 (2 h 36 min).
  - rc 0; 20 legs, all `--mode full`; every leg's own verdict line is present.
  - 1,133 lines match `^  ok `: P0's 857 plus my leg's 276. (By `^\s*ok\b` it is 1,134 against P0's 858.)
  - 0 FAIL, 0 fork or Win32 errors. The one `--` line is gate_subprocess's body_count, as on main.
  - Every existing leg's `ok` count equals P0's suite at 9a42b1d (`scratchpad\gpu\p0-check.log`), leg for leg.
  - All 21 wide-state digest lines are identical to P0's.
  - check_corrector, the old replay's gate: 278 `ok`, RESULT: PASS, "every field of the run key is held by a case: 20 of 20".
- **`make check-light` on 60457ce**: rc 0, 20 legs, 0 FAIL.

## What changed, file by file
- **src/ias15_cft.c** (+155/−4), only in the regions the brief gave me:
  - **`--attempts-out FILE`**, beside `--dt-out`'s writer. It writes `# cft-rebound attempts v1`, then `# run <the run's key>`, a legend, one line per attempt (`<dt as exact hex> a` or `... r`), and last `<dt> next`. One system only; an ensemble is refused by name.
  - **The reader.** `read_dt_file()` recognises the attempts form by its first line; `read_attempts()` and `att_line()` sit beside it. The old accepted-steps loop is untouched: the file is rewound and read exactly as before.
  - **The step loop.** A new `else if (att_ok)` branch takes the recorded outcome in place of `choose_timestep()`'s, and the next recorded dt in place of `dt_new`. On a recorded rejection it restores x, v and a and counts it. The skipped end-of-step update and the `er`/`br` prediction are the shared code below it. `if (dtlist && !att_ok)` keeps the accepted-steps advance away from the new form.
  - **`sched_key()`** hashes the outcomes with the dts under the attempts form and names it `dt_file=attempts`. It adds no field, and no older key moves.
  - **Options.** `--attempts-out`; `--run-key`, which prints the key and exits before any file is opened; and a by-name refusal of the attempts form on an ensemble. I also added two usage lines and a paragraph to the file's head comment; a verifier may judge those to be outside "option parsing".
- **tools/extract_particle.py** (new). It writes the wave's `G`, `active` and `zonal` lines and its first N_active body lines, verbatim and in order, then body J. It then re-keys the wave's schedule with the program's own key and prints the replay's arguments. It also handles `--member`, and it refuses by name a body that is not a test particle, a wave with no active line, and a zonal body at or past N_active.
- **tools/check_replay.py** (new): the gate, described below.
- **Makefile**: `IN_REPLAY` (the program, the `programs/out` images, both tools) and one `check_replay` leg in each tier, after check_corrector.
- **tools/check_corrector.py**: not touched; no refusal message it matches changed.

## Gate output (actual lines, from the full suite's check_replay leg: 276 ok, 0 FAIL)
```
check_replay at fp64: the ring from dt0 = 1e5 s (a first dt far too large), on the loop engine, REBOUND's form
  ok   a rejection before any step is accepted: 1
  ok   body 7 replayed alone: 5 samples, the particle and all 7 massive bodies, 240 values, and every sample's step, t, dt_next, dt_last, E and exact-time pair are the wave's
  ok     and its counters are the wave's: steps_done=40 steps_rejected=1 iterations_max_exceeded=0 mean_pc_iterations=3.293 max_pc_iterations=6
  ok   the records are load bearing here: 3 sampled particles take other bits on their own steps, and 3 other passes on their own exit test
  ok   the rejected first attempt deleted from both records and re-keyed: the replay runs and 37 of its 40 sample-and-body comparisons differ (steps_rejected 0, the wave's 1)
check_replay at fp64: the ring and a particle aimed past Janus, from dt0 = 100 s (rejections after accepted steps), on the loop engine, REBOUND's form
  ok   a rejection after an accepted step, the case predicted from er and br: 5
       alone on its own steps its bits differ at 5 of 6 samples; alone on the recorded steps its own exit test takes other passes in 25 of 35 attempts (mean_pc_iterations 2.886, the wave's 4.371)
  ok   attempt 2, a rejection after an accepted step, deleted from both records and re-keyed: every bit is the wave's (0 mismatches) and only the counters see it, steps_rejected 4 against 5
check_replay at fp256: the ring and a particle aimed past Janus, from dt0 = 100 s (rejections after accepted steps), on the program engine
  ok   body 15 replayed alone: 5 samples, the particle and all 7 massive bodies, 240 values, and every sample's step, t, dt_next, dt_last, E and exact-time pair are the wave's
  ok     and its counters are the wave's: steps_done=24 steps_rejected=5 iterations_max_exceeded=0 mean_pc_iterations=17.034 max_pc_iterations=40
  ok   attempt 20's dt moved by one ulp (0x1.4f0360b34cc7cp+10 to 0x1.4f0360b34cc7dp+10): the schedule keyed on the true record is refused by name (rc 3)
  ok     and re-keyed for it, the replay runs and body 7's bits differ at 2 of 5 samples
  ok   body 9 of member 1 (the body moved) replayed alone: 5 samples, 240 values and the counters are member 1's (steps_rejected=1)
  ok   the records replayed for another wave, its particle moved by one ulp: extract_particle refuses by name
  ok     and the program refuses the re-keyed schedule for that wave's particle by name (rc 3)
  ok   the sub-system with a massive body moved (moon 3's x by one ulp): extract_particle refuses by name
  ok     and the program refuses its re-keyed schedule by name (rc 3)
  ok   wave B's attempts record with two outcomes swapped (attempt 0 to a, attempt 40 to r), its dts and its accepted count unchanged: the program refuses its schedule by name, the outcomes being in the key (rc 3)
  ok   --run-key prints exactly the run line --record-iters writes for the replay (rc 0, 0); its dt_file is attempts, and the wave's no
RESULT: PASS
```
- **The three waves** are hand-made: Saturn, six moons and 8 test particles, `active 7`, built only from correctly rounded operations so they are the same bits on any host. A is the ring with no rejection. B starts from a first dt far too large. C adds a particle flying past Janus, which rejects after accepted steps.
- **Each wave** samples three particles at every format. B and C also run on the FMA form and on the program engine.
- **Every replay** is compared value for value against the wave: the particle, all seven massive bodies, t, both dts, the energy and the exact-time pair.
- **`--light`**: the gate has no scaling of its own. The replays are step-sequence cases that run their wave's own `--steps`, and `--quick` (check-quick and check-light) shortens the waves themselves, to fp64 only.

## Controls (each built from a copy, run, shown to fail, then deleted)
1. **One accepted attempt's dt moved by one ulp** (a copy of the gate that edits the record): RESULT: FAIL at fp64, fp128 and fp256, with all three particles of wave A at 26 mismatches each. Without re-keying, the program refuses by name.
2. **A rejected attempt deleted from both records.**
   - First-attempt rejection: the bits differ, 37 mismatches per particle at every format.
   - Rejection after an accepted step: neither refused nor different. Every bit matches, and only the counters fail: `steps_rejected` 4 against 5; at fp256 `max_pc_iterations` 29 against 42. That is why the gate holds the counters.
3. **After a recorded rejection, predicting as after an accepted step** (a source copy built in scratch): RESULT: FAIL at every format, engine and form.
   - Wave B: all particles, 34 to 36 mismatches of 40.
   - Wave C at fp256: all particles, 21 to 22 mismatches.
   - Wave C at fp64 and fp128, REBOUND's form: only the flyby particle fails, 5 mismatches.

## The key design: the tool re-keys
- **Why not a key without the test particles.** Every wave of a ring starts its massive bodies from the same state, and a schedule's key is written before its first attempt. So a key that names only the massive bodies cannot tell one wave from another.
- **What re-keying keeps.** The program's rule is unchanged: a schedule replays only the run whose key it carries.
- **Where the crossing is checked.** The tool asserts, by name:
  - both records' `# run` lines equal the program's `--run-key` for this wave and these arguments;
  - the two records hold the same number of attempts;
  - the sub-system's lines match the wave's, line for line and in order.
- **What the re-keyed schedule covers.** Its key covers the particle, every massive body, and the attempts' dts and outcomes. So it is refused by the program for any other particle, a changed body or other attempts.
- **No second copy of the key.** No Python hashes anything, so nothing can drift from `sched_key()`.

## Measured outside the gate (not gated, fp64)
- **A 64-body wave** (7 massive bodies, 57 particles): 4 particles at 240 values each, 0 mismatches.
- **The flyby wave over 400 steps** (5 rejections): 3 particles at 432 values each, 0 mismatches.
- **The committed `results/horizon/dtfile` replays**, recorded at libcft 0.11, re-run with this build: 0 of 21 sample lines differ, for kepler and for pythagorean.

## What I did not do, and stated limits
- **The gate compares two runs of one build.** A defect in code both runs share (gravity, the corrector, the prediction itself) would cancel. That is the same mechanism P1's urgent describes for format differences. This gate holds the replay against its wave; agreement with REBOUND is check_equivalence's and check_dropin's.
- **The zonal path is untested.** The program refuses every zonal line until P1 lands; the P1 x P3 seam is the lead's. P2's generated waves are not used either; the `--member` path is gated on my own two-wave ensemble.
- **The "moved" counter overstates itself.** It is the net angle and chord between the first and last samples, not the path swept. It fails safe, but a run of a whole number of orbits would fail falsely, and "swept" in the gate's header overstates it. I left it alone because the suite was running on that file.
- **A wider format's record replayed at a narrower one is rounded, not refused**, exactly as the old dt-file form does.
- **The tool's printed replay line is joined with spaces.** A driver should import `extract()`, which returns the arguments as a list.
- **The replay's `flags_seen` and `calls` are not compared.** They can be narrower than the wave's, because the replay runs neither the step control nor the exit test.

## What the brief or ROUND4.md got wrong (MEASURED)
- **"A replay cannot reproduce a rejected step today" is half true.** A rejection after an accepted step leaves no state behind. The old accepted-steps replay, with the rejected lines deleted from the schedule, gives 0 of 7 lines different at fp64 and at fp128. Only a rejection before the first accepted step marks the bits (5 of 5, 7 of 7 and 7 of 7 lines on three problems). The attempts form is needed for that case and for the counters, so the fallback in ROUND4.md of rerunning every wave with a rejection is only needed for first-attempt rejections.
- **Control 1 bites only on accepted attempts.** Moving a rejected-after-accepted attempt's dt changed 0 of 48 comparisons.
- **Bits alone cannot hold the passes.** The sub-system's own exit test took other passes in up to 33 of 64 attempts with identical bits, so the gate also compares the counters.
- **"Its passes" in the attempts record.** I kept the passes in the run's own schedule rather than copying them into the attempts record, so each fact lives in one file.
- **The PATH line is also needed to run the binaries**, not only to build them; without it they exit 127.
- **For the lead's files and the merges:**
  - CLAUDE.md's "19 legs each" is now 20.
  - README.md:513's option list lacks the two new flags.
  - Once both P3 and P4 land, P4's check_compare_run fails until the P3 x P4 seam is wired. P4 made it that way on purpose; my file names match its trigger.
  - For P4's sampling: in a wave that rejects, the particle that caused the rejection must be sampled, because it can be the only one a broken rejection path shows in.

Files are in C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-a45030143888b996c:
- src\ias15_cft.c
- tools\extract_particle.py
- tools\check_replay.py
- Makefile

The suite log is C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P3\full.log.

---

check-light on 2638e72 (MEASURED, read from its log):
- **Result**: `make rc=0`, 03:37:50 to 04:19:08, 20 legs, 678 `ok` lines, 0 FAIL, 0 fork or Win32 errors.
- **Skips**: 18 legs ran. The gate cache skipped two by name, constants and check_archive, whose inputs are unchanged since my full `make check` passed them; no library-half code changed.
- **Counts**: every leg's `ok` count equals my check-light at 60457ce except check_replay (60 to 119).

# P3 send-back: D1 fixed and gated, F2 corrected, the deletion case's precondition asserted

The new commit is **2638e72**, on 569ee4e, in branch `worktree-agent-a45030143888b996c`. Nothing was pushed or merged.

## D1: a dt file through a pipe
- **The fix.** `read_dt_file()` now reads the first line with the same `fgets()` the accepted-steps loop uses. If that line is the attempts form's (new `is_attempts_line()`), that form is read from the next line; otherwise the loop starts from it. Nothing is read twice and nothing is rewound.
- **Measured before and after**, on outer's dt files through a Windows named pipe (`scratchpad\P3\pipe_t.py`):
  - At 569ee4e: the plain file (2,204 bytes) was refused with "has 0 steps"; the padded file (12,832 bytes) ran rc 0 with 6 of 6 lines wrong; the attempts form read correctly.
  - At 2638e72: all three read through the pipe exactly as from a file, 0 of 6 lines different.
- **The gate case** runs on this host. It feeds wave A's `--dt-out` (padded to 385 lines of 32 bytes, 12,320 bytes) and its attempts record through a named pipe.
  - Run against 569ee4e's program, built in scratch and then deleted: **FAIL**, "through a pipe rc 0, 5 of them differ and its counters are NOT the file's". It is the only failing line there.
  - On a POSIX host the case uses `/dev/stdin`. That branch has not been run on this host; BELIEVED, not measured.

## F2: the false comment, now reading
> The run itself replays bit for bit through that record alone, on its own exit test; its schedule is refused there, the replay's key differing in epsilon and dt_file. A test particle alone with the run's massive bodies takes the run's passes too, from the run's schedule re-keyed for it …

The gate now holds that claim: each wave, at every format and form, is replayed whole through its attempts record with no schedule. All 21 lines show 0 record lines different and the wave's counters. Per V3's item 11, the `--run-key` comment now says it opens no *output* file.

## The fragile case
- **C's precondition is now asserted by name.** The deletion takes the first rejection after an accepted step that has no sample line just before it, and fails by name if none qualifies.
- **The other side of the precondition is exercised where it exists.** At `--sample 6` (fp256 in full mode, and `--quick`), attempt 8 has a sample just before it. Deleting it moves exactly one field: that line's `dt_next`, from the deleted attempt's dt to the next attempt's. This holds P4's 02:02 measurement against the program.
- **B's deletion now asserts the bodies' state.** Previously the deletion of the first attempt could pass on the always-moved sample-0 `dt_next` alone; it now fails unless the body values differ (32 of 40 pairs do).
- **"It moved"** now sums the angle sample to sample, which closes my own stated limit. Body 7 reads 6.906 rad in 52,862 s, where it read 0.623 before.

## Changed and new gate lines (actual)
```
  ok   the whole wave through its attempts record alone, on its own exit test and with no schedule: 0 of 5 record lines differ, and its counters are the wave's
  ok     it moved: 6.906 rad about Saturn, summed sample to sample, 793225 km of chords, over the run's 52862 s
  ok   the rejected first attempt deleted from both records and re-keyed: the replay runs, and its bodies differ in 32 of its 40 sample-and-body pairs: the state, not only the dt_next of the sample printed before the attempt (37 comparisons in all; steps_rejected 0, the wave's 1)
  ok   the deletion case's precondition, by name: attempt 2 has no sample line just before it (it follows accepted attempt 1, which brings the accepted count to 2, not a multiple of --sample 6), so no sample carries its dt as dt_next; attempts [8] would have, and are not chosen
  ok   attempt 8, a rejection after an accepted step WITH a sample line just before it (the step-6 line), deleted the same way: only that line's dt_next moves, from the deleted attempt's dt 0x1.647f777e…p+8 to the next attempt's 0x1.2ecb7d29…p+3; every body and every other field is the wave's (1 fields differ: [('6', 4)])
       (no rejection after an accepted step has a sample line just before it at --sample 7 here, so the deletion of one is not exercised at this format)
check_replay at fp64: a dt file through a pipe, which cannot be rewound
  ok   the accepted-steps file (--dt-out), padded to 385 lines of 32 bytes, 12320 bytes in all: as a file its replay gives the wave's 5 record lines (0 differ), and through a pipe rc 0, 0 of them differ and its counters are the file's
  ok   the attempts record, 1507 bytes: as a file its replay gives the wave's 5 record lines (0 differ), and through a pipe rc 0, 0 of them differ and its counters are the file's
```

## Runs (MEASURED, from their logs)
- **check_replay at every format**: 303 `ok`, 0 FAIL, RESULT: PASS, 592 s.
- **check_replay `--quick`**: 119 `ok`, 0 FAIL, RESULT: PASS, 74 s.
- **check_corrector in full, `--library`**: 278 `ok`, 0 FAIL, "20 of 20", RESULT: PASS, 447 s.
- **check-light on 2638e72**: as above.
- **No full `make check`**, as you asked.

## Ledger, and what is not done
- **Ledger drop.** My corrections are appended, and the heading times now come from `date`:
  - my 21:58 entry's "an older dt file reads exactly as before" was false through a pipe, and `--run-key` reads its inputs;
  - D1 is fixed and gated at 2638e72.
- **P0's `read_problem()`, not changed.** It also rewinds unchecked. MEASURED: a problem file through a pipe is refused by name, "read 0 bodies, expected 2", rc 3. It is shared code and refuses rather than misreads, so it is reported here, not touched.
- **`ATT_MAGIC` is kept as a hand copy in the tool.** It fails loudly if it drifts; V3 accepted that.

Files are in C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-a45030143888b996c:
- src\ias15_cft.c
- tools\check_replay.py

Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P3\:
- gate-full2.log
- gate-quick3.log
- corr-full2.log
- light2.log
