# audit-fp256

## 2026-09-11 14:2x — R8 is model-only, and every other layer refuses the image rather than diverging

Context: my brief pointed at a cft-rebound worktree; see
`urgent/audit-fp256-wrong-worktree.md`. Everything below was read
**read-only** from `C:\Users\logan\source\repos\cft-fp256` at
`refs/heads/main` = `0617424d583b2b6b07c4dc1c5253633f45ec547c`, which is
the SHA the brief named. No file anywhere was edited.

Measured — `FLAG_SCRATCH_STRICT` / `STATUS_SCRATCH_RANGE` appear in
exactly two files in the whole tree, both Python:
`python/cft_golden/seq.py` and `python/tests/test_seq.py`. Confirmed by
a full-tree grep excluding `build*/`, `.venv/`, `.Xil/`, `Data/`.

Measured — the important part, and it is the reassuring answer: **a
strict image is refused by every non-model layer, before execution.**
There is no silent divergence and the card cannot return a different
answer, because it will not run the program at all.

- `host/src/program.c:153` `SEQ_FLAGS_KNOWN` is `BANK_EXT|SCRATCH_IO`
  only. `:833` `if (flags & ~SEQ_FLAGS_KNOWN) return CFT_ERR_ARTIFACT;`
  and that check sits inside `cft_program_load` (`:791`), which is the
  single public ingress for every backend — software, XRT and remote
  all refuse client-side before dispatch.
- `rtl/cft_seq.sv:1533` tests `hdr_q[223:194] != 30'b0`. The flags word
  is `hdr_q[223:192]`, so that slice is exactly `flags[31:2]` and bit 2
  is refused in **code**, not merely in the comment at `:40`.
- `host/tools/cft-asm.c:78` has its own `FLAGS_KNOWN` without the bit;
  it refuses on assemble (`:1293`) and on disassemble (`:1441`), and has
  no directive that could set bit 2 at all.

So the claim in `seq.py:127-130` — "a tile that cannot honour it
refuses the image rather than running it with the old meaning" — is
**true today**, via the generic reserved-bit guard rather than via a
capability bit.

Believed, and this is what I think decides what gets built next: the
semantics landed in the authority but the **negotiation** did not.
Consequences a builder should weigh —

1. There is no way for a caller to ASK whether a device honours strict.
   No `CFT_SEQ_FEAT_*`, no CAPS2 bit. The failure is discovered by
   trying, and `CFT_ERR_ARTIFACT` is indistinguishable from a corrupt
   image — where the project's own "refused by name" discipline would
   want `CFT_ERR_UNSUPPORTED`.
2. `CAPS2[6]` is free and is the natural home. Measured:
   `rtl/cft_krnl.sv:493-496` builds `caps2` as `{[5] SCRATCH_IO,
   [4] SCRATCH, [3:0] log2 SCRATCH_D}`, and `docs/SEQUENCER.md:621`
   already says the CAPS[7:4] nibble is full and the next sequencer
   feature takes a CAPS2 bit. `CFT_SEQ_FEAT_SCRATCH_STRICT 0x400u`
   follows `SCRATCH 0x100u` / `SCRATCH_IO 0x200u` in `host/include/cft.h`
   (`:585`, `:593`).
3. **`STATUS` bit 5 is claimed by the model alone.** `seq.py:199` takes
   `1 << 5`; `host/include/cft.h:2061` publishes only
   `CFT_STATUS_DEPOSIT_OVERFLOW (1u << 4)` and nothing reserves bit 5.
   The model's own note at `seq.py:191-197` says the deposit bit was
   moved to 4 while the word "had never crossed a device boundary,
   which is the last moment moving it was free". Bit 5 is in that same
   position now and nothing outside the model is holding it — worth
   reserving in `cft.h` before something else takes it.
4. **No gate would catch any of this.** `verify/`, `tb/`, `host/tests`
   and `host/fuzz` contain zero mentions of the flag; the only coverage
   is `python/tests/test_seq.py:1292`, which is model-against-model.
   The `make libcft-seq` C-against-model fuzz does not build strict
   images, so the model/host disagreement is invisible to the suite.

For: whoever lands R8 in the RTL, the host or the assembler; and the
lead, since item 3 is cheap now and expensive after a bitstream.

## 2026-09-11 14:4x — two cft-fp256 doc facts that reach outside cft-fp256

Still read-only at cft-fp256 `main` = `0617424d58…`. No edits made.

### The IAS15 speedup on cft-fp256's front page disagrees with its own docs

Measured: `README.md:247-250` says the tile "saturates around 2.7 to
2.9 times" one CPU core on the IAS15 workload. `docs/INTEGRATION.md:164`
and `docs/ROADMAP.md:2561` both put the same workload at **1.99x a
core**, with 3.1x named explicitly as a *projection* conditional on a
device-side scatter that does not exist. The values 2.7, 2.9 and 4.6
appear nowhere else in the cft-fp256 tree, and the README table gives
no date, tool or run.

This matters here because the workload is REBOUND/IAS15 — i.e. it is a
claim about what cft-rebound does. Whoever is auditing cft-rebound's
README and docs/VALIDATION.md should know that the sibling repo's front
page carries a number ~40% above the two in-repo figures for what
appears to be the same measurement, so "it matches cft-fp256's README"
is not evidence.

Believed: the README figure is stale or is an unlabelled projection. I
did not run anything — `README.md` is the integrator's file and I was
not permitted to edit it, only to report it.

For: the cft-rebound doc auditor, and the lead.

### Which VERSION the card-day images are is inconsistent across the tree

Measured, four sources say **0x600**:
`docs/CARDDAY.md:82` ("the pair below stays the proven 0x600 pair"),
`docs/CARDDAY.md:122`, `docs/SEQUENCER.md:975`,
`docs/COMPATIBILITY.md:448`.

Measured, two say **0x410**:
`host/src/backend_xrt.cpp:195` ("The card-day images are 0x410 and
predate all of it") and `docs/ARCHITECTURE.md:252` ("the card-day
images were already built at 0x410").

Measured, and the clearest defect: `docs/ARCHITECTURE.md:253`
contradicts **itself** in one cell — it says the card-day images
*publish* log2 IMEM_D = 10 (1024), and also that "the card-day 0x410
images" read zero in all three capacity fields. Those cannot both hold.

Why it is load bearing rather than cosmetic:
`host/src/backend_xrt.cpp:208` sets `SEQ_VERSION = 0x600` as "first map
with PROG_PTR", so whether the card-day images can run a sequencer
program AT ALL turns on this. `docs/SEQUENCER.md:578` separately says
the card-day images "hold" IMEM_D 1024, which only makes sense if they
have a sequencer — i.e. 0x600.

Believed: 0x600 is right and the two 0x410 mentions are stale, but I am
not certain enough to have changed either, and would not have changed a
source comment on a majority vote. Someone who was there should settle
it; it is a one-line fix in two places once settled.

For: the lead, and anyone reasoning about what the shipped bitstream
can run.
