# lead

Seeded from round 2's first five parcels, whose findings arrived in
final reports rather than here because this file did not exist yet.
Everything below is what a parcel starting now would want to know.

## 2026-09-11 — a fresh worktree does not have `third_party/`

Measured: three parcels each discovered this independently and each
copied the pinned clones in from the main checkout. `third_party/` is
gitignored and reproduced by `tools/fetch_third_party.sh`; nothing
builds until it is there.

Copy `rebound` and `cft-fp256` in from
`C:\Users\logan\source\repos\cft-rebound\third_party\`, then **verify
both against `third_party/MANIFEST`** before trusting a build — read
`.git/refs/heads/main` or `.git/HEAD` in each. The pins are
`bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93` (rebound) and
`ca19fe3efe77e78b66f28f3f69b6a39eb7ecad98` (cft-fp256; moved from 40ce35e3 on 2026-09-13, docs/VALIDATION.md entry 34).

For: anyone.

## 2026-09-11 — verify the commit your worktree is actually on

Measured: one parcel's worktree was a merge behind the SHA its brief
named. It noticed and reset before starting. `git log --oneline -1`
first; if it does not match the brief, say so here and reset.

For: anyone.

## 2026-09-11 — `gravity_ignore_terms` never reaches gravity under IAS15

Measured: `reb_integrator_ias15_step()` writes `NONE` over
`r->gravity_ignore_terms` at the top of **every** step
(`third_party/rebound/src/integrator_ias15.c:875`). No value a user sets
survives to `reb_gravity_basic_calculate_acceleration()`. The port's
refusal was therefore refusing a run that would have been correct; the
row is gone and the three bounds are implemented and gated against
REBOUND's gravity directly, which is the only way to reach the field at
all.

For: anyone touching the refusal table or gravity.

## 2026-09-11 — massless test particles make `N_active` bit-inert

Measured: with strictly massless test particles, setting `N_active`
changes **no bits**. Every pair the skip removes contributes
`prefact * 0 = ±0`; the sum starts at `+0` (a memset) and can never be
`−0`; and the real contributions keep their order because the massive
particles are the low indices.

Consequence, and the reason this is here rather than in a report: the
obvious gate — star, planets, massless dust — **passes with nothing
implemented**. Any case meant to show a pair-selection change reached
the arithmetic must use **massive** semi-active bodies.

For: anyone writing a gate that turns something off.

## 2026-09-11 — `N_active > N` is a heap overread in REBOUND

Measured: `reb_gravity_basic_calculate_acceleration()` runs its outer
loop to `N_active` regardless of `N`. There is no bit-identity to claim
against undefined behaviour, so the port refuses it rather than
reproducing it.

For: anyone tempted to reproduce a REBOUND behaviour without checking it
is defined.

## 2026-09-11 — the force hook REPLACES, and the wide ceiling is real

Measured: `r->additional_forces` returns only a binary64 total —
REBOUNDx does `ax += f` and there is no addend to recover. The delta
form `a_wide += promote(out − in)` is **not** bit-identical at binary64
(`fl(u + fl(w−u)) ≠ w`; `u = 1`, `w = 2⁻⁶⁰` gives 0) and flips a `−0`
component to `+0` even for a do-nothing routine.

What ships is replacement narrowed by a **`memcmp`** against what was
handed over, so a component the routine did not touch keeps its wide
value exactly. The `memcmp` is load bearing: a control swapping it for
`!=` breaks signed zero and **passes the entire suite**.

So: a component a force routine writes is binary64 from that node on,
even in a binary256 run. Gravity stays wide.

For: anyone touching the force path or reasoning about wide precision.

## 2026-09-11 — `r->t` moves at every Gauss-Radau node

Measured: `integrator_ias15.c:408` sets `r->t = t_beginning + r->dt*h[n]`
before each node's acceleration call and `:608` restores it. It must be
that binary64 expression, **not** the wide clock rounded — the two
differ in the last bits and a time-dependent force sees it. The port's
derived `KH[n]` rounds to REBOUND's `h[]` literal bit for bit
(`tools/gen_constants.py` checks all 78).

For: anyone calling back into REBOUND mid-step.

## 2026-09-11 — the subprocess API has no coverage in `make check`

Measured: `cft_rebound_check()` and `cft_rebound_steps()` are exercised
only by `examples/roundtrip.c` and `examples/dropin.c`, which run under
`make example`. It is a shipped public entry point (`libcft_rebound.a`,
`include/cft_rebound.h`) that the suite never touches.

Believed to be how this went unnoticed: `cft_rebound_steps()` never
passes `--adaptive-mode` to the standalone program, so a simulation with
AARSETH85 is **accepted** and then silently integrated at PRS23. The
lead is writing the forwarding and a gate.

For: anyone adding a flag the standalone program takes.

## 2026-09-11 — `csx` and `csv` strand a tail too

Measured: the stranded-tail problem across a particle-count change is
not confined to the seven coefficient levels, as ROADMAP and the briefs
said. `csx` and `csv` strand one as well, and the predictor reads it
before writing it — carrying only the coefficient families still failed
the regrow case, in the last bit of exactly `z` and `vz`, which is the
signature of a stale compensation carry. `x0`, `v0`, `a0`, `csa0`,
`csb` and `g` are written at the top of every attempt and are genuinely
dead above the live region.

For: anyone reasoning about what survives a count change.

## 2026-09-11 12:5x — round 2 is merged and pushed; the docs were swept an hour ago

Measured: main is at bbdcaac. All five parcels plus a follow-up are in,
the full suite is 15 verdict lines and 211 ok assertions, and README.md
and docs/VALIDATION.md were rewritten from cft_support_rows as it now
stands (21 rows; 14 drop-in, 16 subprocess).

So: if you are auditing docs against code, README.md, ROADMAP.md,
docs/VALIDATION.md, PARCELS.md and docs/PARCEL-ROUNDS.md were all
touched TODAY and are the least likely to be stale. The other docs -
ENSEMBLE, HARDWARE, HORIZON, INTEGRATORS, PYTHON - have not been
reviewed since before this round and are where to look.

For: anyone auditing documentation.

## 2026-09-11 15:0x — SETTLED: the card-day images are 0x600

You were right not to settle it on a 4-to-2 count, and right that it is
load bearing. Here is the evidence that decides it.

**Measured — `docs/CARDDAY.md:118-122` is a dated staging record, not a
passing mention:**

> **THE PAIR FOR THE DAY: 2026-09-07, from ed752dd, both halves at
> 135 MHz, verified and staged** … The library on the card host may be
> newer than the images: ABI 0.9 … **still accepts VERSION 0x600
> images** and refuses by name any program that needs what they lack

and `:82`, choosing between two builds: *"the pair below stays the
proven 0x600 pair."*

A dated entry naming the source commit, the clock and the staging
outranks a comment written in passing. **The card-day pair is 0x600.**

**Believed, and it explains how the 0x410 mentions got there:** 0x410
was a real earlier vintage — `docs/ARCHITECTURE.md:253` itself says
"reductions bumped 0x410 to 0x500", so 0x410 predates 0x600 by two
bumps. Those two comments were almost certainly true when written, when
0x410 *was* the newest thing on a card, and were never revisited when
card day moved on. Stale rather than wrong-at-the-time, which is the
usual way.

**This also dissolves the self-contradiction you found in
`ARCHITECTURE.md:253`.** Both halves of that cell are true of different
tiles, and only the label is wrong:

- card-day images at 0x600 **do** publish log2 IMEM_D = 10 (1024) —
  consistent with `docs/SEQUENCER.md:578` saying they hold IMEM_D 1024,
  and with their being able to run a sequencer program at all;
- "reads zero in all three capacity fields" is true of a tile predating
  those fields, which is **not** the card-day pair.

So the fix in that cell is to stop calling the zero-capability tile "the
card-day 0x410 images" — it is an older tile, and the card-day pair is
the one that publishes 1024.

The fp256 auditor finished before this could reach it, and made no
edits anywhere, so the two one-line corrections are unmade:
host/src/backend_xrt.cpp:195 and docs/ARCHITECTURE.md:252-253.
Do NOT touch KNOWN_VERSIONS or SEQ_VERSION - 0x410 is still a
legitimately accepted version and those constants are right. Only the
prose is wrong.

For: whoever re-dispatches the cft-fp256 doc audit.
