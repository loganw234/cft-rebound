# The fp256 doc-audit parcel was dispatched into a cft-rebound worktree

For: the lead, and anyone whose brief names a repo other than cft-rebound.

## 2026-09-11 14:1x — my worktree is cft-rebound, not cft-fp256

Measured, four independent ways:

- `.git` in `.claude/worktrees/agent-a0966693c04e153cb` reads
  `gitdir: C:/Users/logan/source/repos/cft-rebound/.git/worktrees/agent-a0966693c04e153cb`.
- `git remote -v` is `https://github.com/loganw234/cft-rebound`.
- `git log --oneline -1` is `bbdcaac` — the cft-rebound main tip this
  file names two entries up. My brief said to expect `0617424`,
  "Sequencer revision 4, R8: an out-of-range scratch index is reported".
- Every path my brief names is **absent** here and **present** in
  `C:\Users\logan\source\repos\cft-fp256`: `python/cft_golden/seq.py`,
  `host/include/cft.h`, `rtl/cft_krnl.sv`, `docs/SEQUENCER.md`,
  `docs/COMPATIBILITY.md`, `docs/COMPLIANCE.md`, `docs/BENCHMARKS.md`,
  `docs/SCALING.md`. My `docs/` is ENSEMBLE, HARDWARE, HORIZON,
  INTEGRATORS, PARCEL-ROUNDS, PYTHON, VALIDATION — cft-rebound's set.

`third_party/` here holds only `MANIFEST`, so there is no vendored
`third_party/cft-fp256` to audit either. The target is absent in every
form.

## Why this is urgent rather than a report line

The brief also says "nothing in `C:\Users\logan\source\repos\cft-rebound`
— a sibling audit is running there". My worktree **is** inside
cft-rebound. So the parcel as written is not merely pointed at the wrong
tree, it is pointed at the tree it was told to stay out of, and a
sibling is working there now. Anyone who follows such a brief without
checking `git log` first will either audit the wrong repo or collide.

Believed (not measured): the worktree was created under the wrong parent
repo at dispatch. The brief's content is internally consistent and
clearly written for cft-fp256; only the checkout is wrong.

## What I am doing about it

I am making **no edits anywhere** — not here, not in cft-fp256's main
checkout, which is a live working tree with `.venv/`, `build*/` and
`.Xil/` in it and is not mine to write to.

I am proceeding with the audit **read-only against
`C:\Users\logan\source\repos\cft-fp256`**, on the reading that my
assigned repo is cft-fp256 and it is the worktree pointer that is
broken, not the assignment. Everything the brief said I "may fix
directly" will come back as a reported correction with file:line
instead. If the lead wants the fixes applied, re-dispatch with a
worktree of cft-fp256 and they can be made in one pass.

Note for whoever re-dispatches: cft-fp256's main checkout is at
whatever commit it is at now, which is **not** guaranteed to be the
`0617424` the brief named. My findings will state the state I actually
read.

For: the lead, and anyone whose brief names a repo other than cft-rebound.
