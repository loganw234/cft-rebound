# audit-rebound

The documentation-vs-code audit of round 2 (base bbdcaac).

## 2026-09-11 14:0x — a watcher script can be edited out from under you

Measured: I armed the `urgent/` watcher from a script in my own
scratchpad at 14:06:25. At 14:07:2x the file on disk had been replaced
with a different, shorter version (stdout instead of a log file, no
heartbeat, no iteration bound). My process survived — heartbeats
continued — but bash reads a script by byte offset and this repository
already has the receipts for what a mid-run edit does
(`feedback-never-edit-a-running-script`).

If you armed the README's loop from a file, check it is still the file
you wrote, and check your watcher is still beating. I re-armed a second
watcher under a distinct filename rather than trust one.

For: anyone running the `urgent/` watcher from a script file.

## 2026-09-11 14:2x — the two public headers still describe the pre-round refusal list

Measured, against `cft_support_rows` (src/cft_supported.c:435-460) and
the gate cases that exercise them:

`src/cft_ias15.h:31-41` ("WHAT IS REFUSED") names as out of scope, for
the DROP-IN, five things the drop-in now does:

- additional forces — row is `CFT_PATH_SUBPROCESS` only;
- velocity-dependent forces — `CFT_PATH_SUBPROCESS` only;
- non-zero softening — **no softening row exists at all**, and
  tools/cases_core.c:254 gates the drop-in at `r->softening = 0.01`;
- test particles (`N_active`) — refused only for `N_active > N`;
- a non-zero `min_dt` — **no min_dt row exists**, and
  tools/cases_core.c:270 gates it at `min_dt = 0.5`.

Plus: collisions are listed flatly but are refused only at
`format != FP64 && !accurate`; `adaptive_mode` other than PRS23 is
listed as refused but all four are implemented; `fma_veldep` is a fifth
drop-in state refusal the paragraph does not name; and line 63-66's
"r->gravity_custom and r->N_odes ... Both are refused above now" is
half wrong — `odes` is `CFT_PATH_SUBPROCESS` only, because REBOUND's
own driver integrates attached ODE sets between steps.

`include/cft_rebound.h:88-89` says PRS23 is "the only one the port
implements; an ias15 state asking for another is refused". Both halves
are false since `cft_rebound_run.c:341-352` began forwarding
`--adaptive-mode` unconditionally.

Why this is here rather than only in my report: **these are the files a
user reads**, and they say that capabilities this round shipped do not
exist. Anyone who writes a doc, a README table or an example from the
headers will inherit the pre-round list. I am fixing both headers.

Believed (not measured): nothing else in the repo re-states the refusal
list in prose except `reb_integrator_cft.c`'s `.documentation` string,
which is right except for one item (test particles).

For: the lead, and anyone writing user-facing prose from the headers.

## 2026-09-11 14:5x — `examples/roundtrip.c` shipped a false bug report, and `make example` passed

Measured: `make example` exits 0 while `examples/roundtrip.exe` prints

    r->softening = 0.01        -> NOT REFUSED, which is a bug

`show_refusals()` (examples/roundtrip.c:156) held a list of five things
it assumed `cft_rebound_check()` refuses, and printed that line for any
that came back accepted. `src/cft_rebound_run.c:321-325` forwards
`r->softening` as `--softening` now, so the accept is correct and the
example is the thing that is wrong. It accused the library of a defect
in its own worked output, and nothing failed.

The shape is the point: a case that only PRINTS what the library answers
will go on printing whatever it answers and look fine. I rewrote it so
each case states the answer it expects and says so loudly when the
refusal list moves under it.

Anyone adding or retiring a refusal: `make example` will not catch you,
and did not.

## 2026-09-11 — GLOBAL + a velocity-dependent force is ungated, and the reason it was safe is gone

Measured: REBOUND's GLOBAL step controller reads `particles[].v` after
the node loop (`integrator_ias15.c:632`). Under a velocity-dependent
`r->additional_forces` that array holds the h[7]-PREDICTED velocities
(`:446-449`) and nothing restores them. The port keeps its predicted
velocities in `FVP` and leaves the wide `v` at the step start
(`choose_timestep()` runs at ias15_cft.c:1557, `vcopy(v, v0)` at :1609),
so the two build `v2` from different numbers. The comment that said this
was safe - "neither is supported here" - was true until this round put
velocity-dependent forces on the drop-in.

Measured, and this is why it is not a bug report: `v2` feeds ONLY the
skip predicate `fabs(v2*dt*dt/x2) < 1e-16`, never the error estimate. I
scanned 260 configurations tuned to sit on that threshold (a distant
slow body, drag from 0.5 to 200) and found **no** flip - every one
bit-identical to REBOUND. So the divergence is latent, not demonstrated.

Nothing gates the combination: `tools/cases_forces.c:675` pins
`adaptive_mode = 2`, and `tools/cases_modes.c` sets no force. A case
running GLOBAL with a velocity-dependent routine is what would settle
it. I changed no code - only the comments, which now say this.

For: whoever owns the force path or the mode cases.

## 2026-09-11 15:0x — `calculate_megno` without variational particles is accepted by the subprocess API

Measured, with `cft_rebound_check()` against `build/libcft_rebound.a`:

    plain two-body               -> ACCEPTED
    reb_simulation_init_megno()  -> refused: "variational particles are
                                    not supported (r->N_var = 2)"
    calculate_megno=1, N_var=0   -> ACCEPTED

The `megno` row is `CFT_PATH_DROPIN`, so on the subprocess path MEGNO is
caught only as a side effect of the `variational` row, which fires on
`N_var` and not on `calculate_megno`. `reb_simulation_init_megno()` adds
variational particles, so the ordinary route is covered; setting the
flag by hand is not, and such a run is handed to the standalone program,
integrated as plain gravity, and reports no MEGNO and no refusal.

This is a hole in the table's `paths` mask, not in the docs. I changed
no code. If it is worth closing, the one-word fix is `CFT_PATH_BOTH` on
the megno row - but note the gate walks drop-in rows only, so a
subprocess case would be needed too.

For: whoever owns cft_support_rows.

## 2026-09-11 — two documented citations point at gates that do not exist

Measured:

- `docs/HORIZON.md:247` credited `tools/check_ensemble.py` with the
  `--dt-file` replay property. That file has no `--dt-file` case, and
  `grep -rn dt-file tools/ Makefile` finds only a comment in
  divergence.py. The replay is a one-off measurement in VALIDATION
  (2026-09-10), not something `make check` runs. Fixed the citation.
- `docs/INTEGRATORS.md:21` cited `docs/HARDWARE.md` for "256
  format-width slots a lane". HARDWARE.md never says 256 - the number
  is cft-fp256's `docs/SEQUENCER.md:294`, and `SEQ_SCRATCH_D` in its
  `host/src/program.c:535`. The number is right, the pointer was not.
  Fixed.

For: anyone citing a gate for a property. If `make check` does not run
it, say "measured" rather than naming a tool.
