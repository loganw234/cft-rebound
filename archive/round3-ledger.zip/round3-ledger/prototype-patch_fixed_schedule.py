"""A fixed corrector schedule, to measure what the convergence test costs
and to test a claim exact reproducibility uniquely allows.

IAS15's corrector iterates until `predictor_corrector_error` stops
improving. Computing that error is `pc_error`, which is two vector
absolute values, two classify calls whose results come back to the HOST,
and then a scalar loop over every coordinate doing width-one comparisons
and copies. Width one is the worst shape for the tile - the fixed
per-call cost is the whole cost - and there are about 2*N3 of them per
pass, 14 to 21 passes a step.

A tolerance-based integrator has no choice: the count is data-dependent,
so it must test every pass. Here the arithmetic is exactly reproducible,
so the count is a FUNCTION of the input and can be recorded once and
replayed. The same passes over the same bits give the same bits, so a
replay must produce an identical record - and that identity is the proof
the optimisation is sound, not an approximation of it.

    --record-iters FILE   write one corrector count per step attempt
    --replay-iters FILE   run exactly those counts, skip the test entirely

Applied to the BOX clone only. The desktop working tree is being edited
by an agent. This is a measurement, not a proposed repository change;
what it finds goes in the report."""
import pathlib, sys

p = pathlib.Path("src/ias15_cft.c")
if not p.exists():
    sys.exit("run from the cft-rebound repository root")
s = p.read_text(encoding="utf-8")
edits = 0


def patch(old, new, what):
    global s, edits
    if s.count(old) != 1:
        sys.exit(f"{what}: anchor count {s.count(old)}")
    s = s.replace(old, new)
    edits += 1
    print(f"  {what}: ok")


# ---- state -----------------------------------------------------------
patch("static long iterations_max_exceeded = 0, steps_rejected = 0;\n",
      "static long iterations_max_exceeded = 0, steps_rejected = 0;\n"
      "/* The corrector schedule: recorded from a checked run, replayed to\n"
      " * skip the convergence test. See the header of patch_fixed_schedule. */\n"
      "static FILE *iter_rec = NULL;\n"
      "static long *iter_play = NULL;\n"
      "static long  iter_play_n = 0, iter_play_i = 0;\n",
      "schedule state")

# ---- the test is not computed when its answer is already known -------
patch("    if (n == 7) pc_error(tmp);\n",
      "    if (n == 7 && !iter_play) pc_error(tmp);\n",
      "host-loop corrector skips the test on replay")
patch("    if (n == 7) pc_error(prog_dep);\n",
      "    if (n == 7 && !iter_play) pc_error(prog_dep);\n",
      "program corrector skips the test on replay")

# ---- the loop --------------------------------------------------------
old_loop = """    vcopy(pce, K1E300, 1);
    vcopy(pce_last, K2, 1);
    int iterations = 0;
    while (1){
        if (trace_pc && iterations > 0){
            char buf[160]; size_t len = 0;
            cft_to_decimal_char(dev, F, CFT_RNE, pce, 6, buf, sizeof buf, &len, NULL);
            fprintf(stderr, "  step %ld iteration %d: predictor_corrector_error %s\\n", steps_traced, iterations, buf);
        }
        if (s_lt(pce, TOL)) break;
        if (iterations > 2 && s_le(pce_last, pce)) break;
        if (iterations >= max_iter){ iterations_max_exceeded++; break; }
        vcopy(pce_last, pce, 1);
        vzero(pce, 1);
        iterations++;
        for (int n = 1; n < 8; n++){
            if (engine_program) predict_positions_program(n); else predict_positions(n);
            gravity();
            vcopy(at, a, N3);
            if (engine_program) correct_program(n); else correct(n);
        }
    }
"""
new_loop = """    vcopy(pce, K1E300, 1);
    vcopy(pce_last, K2, 1);
    int iterations = 0;
    if (iter_play){
        /* Replay: run exactly the number of passes the checked run took
         * and never compute the convergence test. The passes are the
         * same over the same bits, so the record must come out
         * identical; that identity is the whole proof. A schedule that
         * runs out is a schedule for a different run, and zero passes
         * would silently change the answer, so say so and stop. */
        if (iter_play_i >= iter_play_n)
            die("the replay schedule ran out at step attempt %ld: it was "
                "recorded from a different run", iter_play_i);
        long want = iter_play[iter_play_i++];
        for (iterations = 0; iterations < want; iterations++){
            for (int n = 1; n < 8; n++){
                if (engine_program) predict_positions_program(n); else predict_positions(n);
                gravity();
                vcopy(at, a, N3);
                if (engine_program) correct_program(n); else correct(n);
            }
        }
    }else{
    while (1){
        if (trace_pc && iterations > 0){
            char buf[160]; size_t len = 0;
            cft_to_decimal_char(dev, F, CFT_RNE, pce, 6, buf, sizeof buf, &len, NULL);
            fprintf(stderr, "  step %ld iteration %d: predictor_corrector_error %s\\n", steps_traced, iterations, buf);
        }
        if (s_lt(pce, TOL)) break;
        if (iterations > 2 && s_le(pce_last, pce)) break;
        if (iterations >= max_iter){ iterations_max_exceeded++; break; }
        vcopy(pce_last, pce, 1);
        vzero(pce, 1);
        iterations++;
        for (int n = 1; n < 8; n++){
            if (engine_program) predict_positions_program(n); else predict_positions(n);
            gravity();
            vcopy(at, a, N3);
            if (engine_program) correct_program(n); else correct(n);
        }
    }
    }
    /* Every attempt, accepted or rejected, in the order they happen. */
    if (iter_rec) fprintf(iter_rec, "%d\\n", iterations);
"""
patch(old_loop, new_loop, "the corrector loop")

# ---- the options -----------------------------------------------------
patch("        else if (!strcmp(argv[i], \"--trace-pc\") && i + 1 < argc) trace_pc = atoi(argv[++i]);\n",
      "        else if (!strcmp(argv[i], \"--trace-pc\") && i + 1 < argc) trace_pc = atoi(argv[++i]);\n"
      "        else if (!strcmp(argv[i], \"--record-iters\") && i + 1 < argc) iters_out = argv[++i];\n"
      "        else if (!strcmp(argv[i], \"--replay-iters\") && i + 1 < argc) iters_in = argv[++i];\n",
      "the two options")

# ---- their variables, beside the other option variables --------------
patch("    if (st != CFT_OK) die(\"cft_open(%s): %s (%s)\", artifact ? artifact : \"software\", cft_strerror(st), cft_last_error());\n",
      "    if (st != CFT_OK) die(\"cft_open(%s): %s (%s)\", artifact ? artifact : \"software\", cft_strerror(st), cft_last_error());\n"
      "    if (iters_out && !(iter_rec = fopen(iters_out, \"w\"))) die(\"cannot write %s\", iters_out);\n"
      "    if (iters_in){\n"
      "        FILE *f = fopen(iters_in, \"r\");\n"
      "        if (!f) die(\"cannot read %s\", iters_in);\n"
      "        long cap = 1024; iter_play = malloc((size_t)cap * sizeof *iter_play);\n"
      "        long v;\n"
      "        while (fscanf(f, \"%ld\", &v) == 1){\n"
      "            if (iter_play_n == cap){ cap *= 2; iter_play = realloc(iter_play, (size_t)cap * sizeof *iter_play); }\n"
      "            iter_play[iter_play_n++] = v;\n"
      "        }\n"
      "        fclose(f);\n"
      "        if (!quiet) fprintf(stderr, \"replaying a corrector schedule of %ld step attempts; \"\n"
      "                            \"the convergence test is not computed\\n\", iter_play_n);\n"
      "    }\n",
      "opening the schedule files")

# ---- declare the two option strings ---------------------------------
patch("    const char *problem = NULL, *artifact = NULL, *fmtname = \"fp64\";\n",
      "    const char *problem = NULL, *artifact = NULL, *fmtname = \"fp64\";\n"
      "    const char *iters_out = NULL, *iters_in = NULL;\n",
      "the option variables")

p.write_text(s, encoding="utf-8", newline="\n")
print(f"{edits} edits written")
