# P4: the step control as a program (the first to drop if the day runs short)

*The lead, at dispatch, 2026-11-02.*

You are parcel **P4** in cft-rebound. You work in a git worktree of
`C:\Users\logan\source\repos\cft-rebound`, branched from main at
**`af2f400`**. **Check that you are on that commit** with `git log
--oneline -1`. If you are not, say so in the drop and reset to it. Your
branch is `round3-p4`.

Read `brief-common.md` (beside this file) first. Then read ROUND3.md's
P4 section, which is your plan.

## Your job

`predict_next_step`'s sixteen compensated additions per coordinate are
still elementwise calls.
- Make them one sequencer program over the scratch block, on the
  `--engine program` path, in the shape of `correct_n`.
- It must give the elementwise route's bits at every format.

## What reading has turned up: verify it, do not trust it

Measured at `af2f400`:
- **The function.** `predict_next_step_vec()` is at :1467, and is called
  at :2191.
- **The program engine** is `--engine program` (`engine_program`, :767).
  - It requires `--arith fma` (:2808) and Kahan's `add_cs` (:2809).
  - The library half never uses it: `ias15_engine_open()` sets
    `engine_program = 0` (:3113).

  So your gate is the program's.
- **The existing gate.** `tools/check_program_engine.py` compares
  `--engine program` against `--engine loop`, both at `--arith fma`.
  - It runs fp64, fp128 and fp256.
  - Its problems are kepler fixed, kepler adaptive and outer fixed
    (:42-44).
  - It has no ensemble case.
- **The ensemble path.** An adaptive ensemble under the program engine
  already has a special path. `use_ens_predict` (:1363, :2863) loads
  `predict-ens`, because "dt rides in the scratch block, not the bank":
  each system has its own step.

**The trap that would be a silent wrong answer: the step ratio is per
system.**
- `predict_next_step_vec()`'s `rb` holds each lane's own ratio (the
  comment above it, from :1463).
- A program that takes the ratio from the constant bank is right for one
  system. It is also right for an ensemble whose systems happen to share
  a step. It is wrong otherwise.
- No case in `check_program_engine.py` can see that.
- So your case must be an adaptive ensemble whose systems' ratios
  differ, and it must assert that they differ.

## Files you own

- `predict_next_step_vec()`;
- a new section in `tools/gen_programs.py`, with one entry in its
  `main()`;
- one `load_one()` line in `load_programs()`;
- your case in `tools/check_program_engine.py`.

## Files you must NOT touch

- **P2's, which P2 is editing now:**
  - the line `if (n == 7) pc_error(prog_dep);` at :1457, ten lines above
    your function;
  - `pc_error()` and `correct*()`;
  - `step_attempt()`'s exit test.
- **P1's, which P1 is editing now:** `gravity_body()`,
  `build_scatter()`, `alloc_state()` and the indexed wrapper.
- **Nobody's this round:** `dtnew_*()` and `choose_timestep()`. Leave
  them.
- **P3's, which P3 is editing now:** the archive files.
- **The shared one-liners.** `gen_programs.py`'s `main()` and
  `load_programs()` each get one line from you and one from P1. The lead
  resolves it at merge.

## Gate

The program route's records equal the elementwise route's at every
format. That is checked through `check_program_engine.py`'s existing
comparison, plus your ensemble case.

**Negative control.** A program with one compensated addition dropped
must change the record.
- Find a problem where it does first, and name it. On a problem where
  the compensation is zero, the control is inert by construction
  (METHOD.md §5).
- Report both results.

You are the first parcel to drop if the day runs short. If you hit
something that makes the program route unworkable, stop and report.
