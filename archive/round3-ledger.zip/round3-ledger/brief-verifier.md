# Round 3: the verifiers' brief (V1 to V4)

*The lead, 2026-11-02. Your dispatch message names your parcel, its
branch, and the exact commit you verify.*

You verify one parcel's work. **You disconfirm; you never fix.** You are
paid for independence, so build your own view from the code and the
measurements, not from the parcel's report. A parcel's report is a list
of claims to test, not a description to trust.

"Found nothing" is an acceptable answer, if you looked.

## What you hold the parcel to

- `brief-common.md`, and the parcel's own brief, `brief-P<n>.md`. Both
  are in this directory, `C:\Users\logan\source\repos\cft-rebound\.ledger\`.
- ROUND3.md's section for the parcel, and its "Rules for every parcel".
- The parcel's report, which the lead places here as `report-P<n>.md`.

## Your tree

Work in your own worktree.
- Check out the commit you were given, detached: `git checkout --detach
  <sha>`. Then check it with `git log --oneline -1`.
- Clone `third_party/` from the main checkout, exactly as
  brief-common.md's "Setting up your tree" shows. Never fetch from
  GitHub.
- **Build from clean in your own tree.** Never reuse the parcel's
  `build/`. A suite is only as prebuilt as its least-compiled component
  (CLAUDE.md).
- The build line and the host's traps are in brief-common.md. The PATH
  line goes in every Bash call that builds.

## What to do, in this order

1. **Diff the change against the ownership lists.** Start with `git diff
   --stat af2f400..<sha>`, then read every hunk. For each one, name the
   function or file and say whether the brief gave it to this parcel.
   - A crossing that the report declares, with its reason, is a note.
   - An undeclared crossing is a finding.
   - Check the "expected small edits" are only those.
2. **Re-run the gate from your clean build.**
   - Run `make check-light`, then the parcel's own gate legs at every
     format.
   - The full `make check` is the lead's, after the merge. Run it only
     if you have reason to doubt the parcel's own run.
   - Read the logs, not the exit codes.
3. **Hold the records to the base.** Compare the parcel's commit against
   `af2f400` on integrations of your own choosing, on the software
   backend, at binary64, binary128 and binary256. Every non-comment
   record line must be identical. A routed parcel's new route runs by
   default on software, so the default runs are its new route against
   the base's old one.
   - Choose problems where the change could show: order-sensitive
     ones, merges, `N_active`, test particles, ensembles, rejected
     steps.
   - Say how many integrations you ran, and which.
   - Your controls must see a difference, or the comparison proves
     nothing.
4. **Re-run each named control yourself.**
   - Build the sabotage from the report's description, in a scratch
     copy.
   - Confirm it fails at the check meant for it, and that the clean
     tree passes.
   - A control that fails for some other reason is not that control.
5. **Try to break it.** Aim your own sabotages at what the gate claims,
   starting with the brief's named trap.
   - Each sabotage is one defect, put into a scratch copy and run
     through the gate.
   - Report which ones pass the gate. Each one that passes is a gate
     that cannot see that defect.
6. **Check every "measured" in the report** against what you can
   reproduce. A claim marked measured that you cannot reproduce is a
   finding. So is a claim that is believed but stated as measured.

## The ledger

- Read every file in the ledger before you start, and again before you
  report.
- Write your entries to the drop:
  `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\V<n>.md`.
  Append only, in the README's entry format. If that write is refused,
  use `.ledger/V<n>.md` in your own worktree, and say so in your
  report's first line.
- **Watch the lead's file only:** `lead.md` and `urgent/lead-*.md`. A
  stream of "the parcel says this is fine" erodes exactly what you are
  for.
- Your scratch directory is
  `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\V<n>\`.

## Do not

- Fix anything, in the parcel's tree or your own. Report it instead.
- Push, merge, rebase, or commit to any branch. Your worktree is for
  building and sabotage copies.
- Touch the card or amd-arc-box. Another session holds the card.
- Write to `../cft-fp256` or `../ParcelRound`.

## Report

Your final message is your report.

Its first line is your verdict: **READY**, or **SENT BACK** with the
count of (a) findings.

Then:
- **(a) findings that block the merge.** Each one gives:
  - the defect;
  - the evidence: a command and its actual output lines;
  - the property it breaks.
- **(b) findings that should be fixed but need not block.**
- **Notes.**
- **What you ran:**
  - the integrations held to the base;
  - the controls, each with its result;
  - your sabotages, each caught or passed;
  - with times.
- **What you did not check, and why.**

READY means a gate, or a stated limit, for every claim the parcel makes.
A limit is stated by the behaviour it concedes.
