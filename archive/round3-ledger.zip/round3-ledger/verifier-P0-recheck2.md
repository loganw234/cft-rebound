## 2026-10-31 11:55 — V0's second re-check of d7d964b: the four gaps are closed and nothing legitimate is refused; the data check proves low bits exist, not where they are or that zeros survive

Scope: `d7d964b` on `round3-p0-v1`, against my re-check of `90e6f3f`. My worktree was detached at `d7d964b`, `check_pins.sh` gave three `ok`, and I rebuilt `build/` and `programs/out` from clean (`make all programs`). The only warnings are REBOUND's own five. Logs and scripts are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v0r2\`. The sabotaged and instrumented copies were deleted after their logs were kept, and nothing tracked was edited. Everything below was measured, except where it says "believed".

**Bottom line.**
- **Records.** 51 of 51 integrations are identical to the pre-P0 records saved on my first pass (`v0r2/ab3.py`), with both controls caught.
- **The gate.** `check_door --build build` passes at all three formats: 50 `ok` lines, 0 `FAIL`, and 131 of 131 cases at each format. The data check reads 0 of 9,424,829 nonzero values at fp64, 9,422,984 of 9,422,984 at fp128, and 9,425,290 of 9,425,290 at fp256.
- **Sabotages.** I re-made all of the lead's seventeen, and all fail the gate.
- **Answers.** The new refusals reject no call the engine will make. The data check can be fooled, in three ways (item 1).

### The coordinator's two questions

**Can the data check be fooled? Yes, but not through zero or sign handling.**

*Through zero or sign: no.*
- The check skips ±0, and narrowing and widening preserve the sign.
- So for the data's exponents (2^-20 to 2^20, inside binary64's range), a nonzero value's round trip differs exactly when it holds a bit below binary64's reach.
- F17 (zeros given random low bytes too, so they become tiny values) is caught, but by the flag abort: at fp128 the scalar family raises underflow, 0x18. The data check itself would have counted those values as passing.

*It proves that every value has some low bit. It does not prove that every such bit is exercised, or that zeros remain.* Each sabotage was run through `check_door` at fp64, fp128 and fp256:

| sabotage | data check | gate |
|---|---|---|
| F15: `door_low_bytes()` under-reports, 4 of 7 bytes at fp128 and 12 of 23 at fp256 | 9,423,905 of 9,423,905 and 9,425,067 of 9,425,067 | PASS |
| F15R: F15, plus today's gather losing exactly the bytes left unrandomised | satisfied | PASS |
| F16, on the shipped data: today's gather clearing binary128 fraction bits 56-59 | satisfied | PASS |
| F18: `door_fill` makes no zeros at all | 10,052,757 of 10,052,757 | PASS, 131 of 131 |

So yes: a sabotage can randomise the low bytes and still leave a route blind to them. F15R is that sabotage.

F16 needs no sabotage of the data. At binary128, p - 53 = 60 bits, and 7 whole bytes are only 56 of them. Bits 56-59, the low nibble of byte 7, are always zero in the data, so a route that loses only those bits is invisible. At binary256 the 184 bits are exactly 23 bytes, so there is no such gap.

F18 removes the vector data's signed-zero coverage, including the segments where `maximum(+0,-0)` decides. Nothing notices it.

Each gap could be closed (believed, not built):
- assert that every byte position below binary64's reach is nonzero in some value, and include the nibble at fp128;
- count both zeros, and require some of each.

**Do the new refusals reject a call the engine will legitimately make? No (measured).**
- **Gravity's pair shape.** I ran `dx = x[3i+k] - x[3j+k]`, with both operands through tables into the WHOLE coordinate vector and d a separate pair buffer, on both routes. Shapes: N=2; N=32 at E=4; N=32 at E=1057 (524,272 pairs from a 101,472-element x); N=1024. Formats: fp64 and fp128. No call was refused, and every one equalled today's host loops plus one dense `vsub`, with 0 differing (`v0r2/probe_chunk3.c`).
- **Zero-element source.** libcft itself, past the wrapper, refuses a table beside a zero-element source even when every index is `CFT_IDX_NONE` and even at n=0: "idx_a is set and idx_a_src is zero, so no index could be in range". So the new rule is libcft's, and the comment saying `cft_run_ex` refuses it is true.
- **n=0.** A table with a real source at n=0 is accepted by libcft and by both routes.
- The one natural shape that is refused is an in-place accumulate, with d aliasing a dense operand beside a table. That is libcft's own rule, from `90e6f3f`, and not new here.

### Per fix

1. **F4: fixed, with three residuals.** F4, and F4 together with N8, now FAIL at the data check. The residuals are F15/F15R, F16 and F18 above.
2. **F6: confirmed.** F6 FAILs, and the gate's misspelled `CFT_REBOUND_HIDE_FEATURE` is refused, rc 3.
3. **F11: confirmed.** F11 FAILs. `CFT_DOT` runs over all six shapes, with `b` passed to both routes and to the reference: 131 cases, 19 reduce_seg calls.
4. **The two new `vrun_ix` refusals: confirmed.**
   - F12 (the NULL-table refusal removed) and F13 (the zero-source refusal removed) FAIL at their `--door-refuse` cases, on both routes.
   - `ix-table-on-null` and `ix-zero-source` are refused, rc 3, with the route forced on and off.
5. **The unread operand: confirmed as a stated limit** in `vrun_ix`'s comment.
6. **README and docs/PYTHON.md: confirmed.** They state both limits (typos inside the prefix; msvcrt's start-up environment on Windows), and the wording matches what I measured.
7. **The misspelling message: confirmed.** It now reads "…which are CFT_REBOUND_ROUTE_SCALAR, CFT_REBOUND_ROUTE_INDEXED and CFT_REBOUND_ROUTE_REDUCE_SEG, plus CFT_REBOUND_HIDE_FEATURES; a name must match exactly, case included". That also settles the lower-case wording point from my last entry.

### Sabotages run

All 29 copies went through `v0r2/sabotage3.py`, built from `d7d964b`.

- **The lead's seventeen, all FAIL.** S1-S5, N1-N4, N7, N8, F4, F4+N8, F6, F11, and my own copies of F12 and F13.
- **My first re-check's six, all FAIL.** F1, F2, F3, F5, F9 and F10.
- **Six new ones:**
  - FAIL: F14 (the reference and today's broadcast drop the same low word, and only the new route sees it) and F17 (by the flag abort);
  - PASS: F15, F15R, F16 and F18.

The fp-independent copies ran at fp64. N7, N8, F4, F4+N8 and the six new ones ran at all three formats.

`make check-light` was not re-run: `d7d964b`'s source changes are confined to the door and `check_door`, and the A/B and the three-format `check_door` cover them.

For: lead, before `round3-p0-v1` merges. The residuals are gate gaps, not record defects.
