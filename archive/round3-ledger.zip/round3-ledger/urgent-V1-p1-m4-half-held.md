V1: P1's cases_gravity holds M4 only on software with no door variable set; under any HIDE value, or on a card, it accepts `off by=device`
For: lead (session B's plan for P1), P1 if resumed. V1's full report follows; this is the one item that changes what the card day can trust.

Measured, at round3-p1 d4e710b, software backend, my own clean build:
- The lead's sabotage, built as asked (`route_on[ROUTE_INDEXED] = route_on[ROUTE_PAIR_GATHER] = 0;` after `engine_routes()` in `ias15_engine_open()`, so the library half takes today's routes and still reports `by=device`):
  - no door variable: `check_dropin --light` rc 1, "2 FAILURES": `FAIL route indexed=off by=device calls=0 fallbacks=234027 (the software backend, unforced: on by=device is required)`, and the same for pair_gather. So the first half of urgent/lead-p1-route-case.md holds.
  - with `CFT_REBOUND_HIDE_FEATURES=scalar` (an unrelated route hidden): rc 0, `check_dropin: every case passed`, with `ok   route indexed=off by=device calls=0 fallbacks=234027` and `ok   route pair_gather=off by=device calls=0 fallbacks=234078`.
  - The clean tree under the same variable: rc 0, `on by=device calls=234027 fallbacks=0`. So the variable itself changes nothing.
- By reading tools/cases_gravity.c:91-104: the by= check runs only when `software && unforced`, and `unforced` is false if CFT_REBOUND_ROUTE_INDEXED, CFT_REBOUND_ROUTE_PAIR_GATHER or CFT_REBOUND_HIDE_FEATURES is set to anything. `software` is false whenever CFT_REBOUND_ARTIFACT is set.

Believed, not run (no card): on a card, `off by=device` therefore passes the library half's gravity case. `off by=device` is impossible on every device (by=device means the bit decided, unforced, so the route is on), so the second half of the lead's ask, "off only with by=forced or by=hidden, under the variable that forced or hid it", is not held. The program half's check_gravity does reject it on a card (it accepts off only with by=absent there).
