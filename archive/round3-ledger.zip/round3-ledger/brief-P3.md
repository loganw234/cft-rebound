# P3: the archive's last two members, and who made it

*The lead, at dispatch, 2026-11-02.*

You are parcel **P3** in cft-rebound. You work in a git worktree of
`C:\Users\logan\source\repos\cft-rebound`, branched from main at
**`af2f400`**. **Check that you are on that commit** with `git log
--oneline -1`. If you are not, say so in the drop and reset to it. Your
branch is `round3-p3`.

Read `brief-common.md` (beside this file) first. Then read ROUND3.md's
P3 section, which is your plan.

## Your job

This is one on-disk change, with three items:
- **The wide clock.** Archive the engine's wide clock, so a checkpoint
  resumes bit for bit at binary128 and binary256.
- **The restore field.** Add the field that says whether a loaded state
  was restored exactly or promoted from binary64.
- **Identity.** Record the library build and the device image that made
  the archive.

Old archives still load.

## What reading has turned up: verify it, do not trust it

Measured at `af2f400`:
- **P0 gave you what you read**, so `src/ias15_cft.c` is forbidden
  entirely:
  - `struct ias15_engine_view`'s `t`, `t_hi` and `t_lo` are the wide
    clock, read and written in place (`src/ias15_engine.h`:50-56);
  - `ias15_engine_build_id()` and `ias15_engine_image_digest()` are at
    :300-309. The second returns -1 where the device refuses to name
    its image, which the software backend always does.
- `adopt_loaded_state()` is at `src/reb_integrator_cft.c`:314, and is
  called at :553.
- **On load, order matters.** The header comment at
  `ias15_engine.h`:50-55 says that `ias15_engine_put_t_f64()` rebuilds
  all three from a binary64 `t`, losing what binary64 cannot carry.
  Anything that calls it after your wide bytes are written puts the ulp
  back. Find every path that does.
- `tools/check_checkpoint.py`:48: the dump's last line is a digest of
  the wide state. Compare that, not `t`'s binary64 view.

**There are two traps.**
1. **A checkpoint case that compares `t`'s binary64 view is vacuous**
   through the observable (ROUND3.md). Compare the wide bytes.
2. **Identity differs between builds, by design**, as the `# identity`
   line does.
   - If anything compares whole archives across builds or pins, it now
     differs in your member. Entry 38's cross-pin checkpoint check, 12
     of 12, is one to look at.
   - Exclude your member there, by name, and say so.

**The name.** "provenance" collides with cft-fp256's certificate
vocabulary, where Provenance means the device lines (its
`docs/CERTIFICATES.md`).
- Propose a name in the drop as soon as you have read how
  `cft_archive.c` names things. I will answer in `urgent/`.
- If you need it before I have answered, use yours and carry on.
  Renaming it at merge is cheap, provided no archive has been
  published with it.

## Files you own

This is ROUND3.md's P3 list:
- `src/cft_ias15.h`, appending fields only;
- `src/cft_ias15_fields.h` and `src/cft_ias15_fields.c`;
- `src/cft_archive.c`;
- `src/reb_integrator_cft.c`, only where the state is filled for a save
  and adopted on load;
- `tests/gate_*.c`;
- `tools/check_checkpoint.py` and `tools/check_archive.py`.

## Files you must NOT touch

- **`src/ias15_cft.c`, entirely.** P1, P2 and P4 are all editing it now.
  If you need another accessor, ask in the drop, and the lead adds it.
- **The rest of `src/reb_integrator_cft.c`**, outside the save and load
  paths. That includes the refusal path, whose two defects are filed
  for the next round.
- **The integrator-only files.**

`CFT_N_SCALARS` and `CFT_N_BLOBS` stay derived, not transcribed (round
2's rule).

## Gate

ROUND3.md's P3 gate:
- **the 2-of-40 case** at binary128 and binary256:
  - **watched failing** on this tree before your fix, with the numbers
    recorded: which splits, and which bytes;
  - then passing with the fix;
- **the new field** asserted on both load paths;
- **a software-backend archive** carries the build id and records the
  image as refused. A card-written archive is the card day's;
- **an archive written before your change** still loads. Say what it
  does, and why.

**Negative control.** With the new field's load removed, the 2-of-40
case fails again. Report both results.
