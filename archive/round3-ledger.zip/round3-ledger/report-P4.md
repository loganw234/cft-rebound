# P4's final report, placed verbatim by the lead (2026-11-02, 09:0x)

round3-p4 at `cae9916`. My ledger entries are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P4.md`: three entries, all placed by the lead. One escalation, `urgent-P4-no-compensated-adds.md`, was answered in `urgent/lead-p4-scope.md`.

**Summary.** Under `--engine program`, `predict_next_step_vec()` is now one program run instead of 69 elementwise calls per step. The full `make check` passes: 15 legs, 281 `ok`, 0 FAIL. Every control failed the gate where it should, and was inert exactly where the gate says it would be.

## What changed, file by file
- **`src/ias15_cft.c`**
  - `predict_next_step_vec()` (:1486): under `engine_program` it now runs `nextstep-<fmt>` and returns. Stream a is `rb`, each lane's own ratio. The 14-slot scratch block holds e0..e6 and b0..b6 in, and the predicted e and b out, in place. The bank is filled from KBIN by the loop's own walk, each distinct binomial once. Each run increments `ncalls_nextstep` (:1485). The elementwise body is unchanged.
  - One declaration line, `prog_nextstep` (:1364), and one `load_one("nextstep")` line in `load_programs()` (:1390).
  - **Crossing:** one row, `nextstep_calls`, at the end of P0's `trailer_keys[]` (:2346). The gate needs it, because two engines that both skip the program give identical records (control N3 below).
  - **Crossing:** the comment on `engine_program` (:767). Comment only.
- **`tools/gen_programs.py`:** adds `nextstep_bank()`, `nextstep(fmt)`, one entry in `main()`, and the header listing.
- **`programs/nextstep-{fp64,fp128,fp256}.cfta`** (new, checked in like the other 27):
  - 119 instructions, 11 external constants, scratch 14 in and 14 out, no deposits.
  - `cft-asm -i` features: BANK_PTR, SCRATCH, SCRATCH_IO, the same as `predict-<fmt>`.
  - The 21 binomial products use only 11 distinct values. Deduplicating them keeps the bank inside the port's 16-slot allocation and the plain constant form, so no `kx` is needed.
- **`tools/check_program_engine.py`:**
  - New case: the "spread" Kepler ensemble, E=5, adaptive, dt0 = 0.6, unscaled in every tier. It asserts that the systems' step ratios differ by more than 2^-40 relative, and that the first attempt is mixed.
  - Every case now holds the trailer's step counters and `flags_seen` equal to the loop's.
  - Every case holds `nextstep_calls`: 0 on the loop engine, and on the program engine between the most steps any system accepted and the total attempts.
  - Every case states and asserts its ratio: exactly 1 for fixed steps, not 1 somewhere for adaptive.
- **`Makefile`** (crossing): the `check_program_engine` leg's inputs (:592, :617, :645) gain `tools/make_ensemble.py`, which the new case runs, and `tools/check_equivalence.py`, which the leg already imported but never named.

## The gate's output (`cpe-2-all.log`; the full-suite log has the same lines)
```
check_program_engine at fp64: --engine program against --engine loop, both --arith fma
  ok   kepler fixed dt=0.05: 5 samples, 80 values identical (steps_rejected=0, max_exceeded=0)
       counters and flags the loop's; nextstep ran 200 times; ratio 1 at all 4 sampled steps, so q is inert here
  ok   kepler adaptive eps=1e-9: 5 samples, 80 values identical (steps_rejected=0, max_exceeded=0)
       counters and flags the loop's; nextstep ran 200 times; ratio not 1 at 4 of 4 sampled steps
  ok   outer fixed dt=40: 4 samples, 160 values identical (steps_rejected=0, max_exceeded=0)
       counters and flags the loop's; nextstep ran 60 times; ratio 1 at all 3 sampled steps, so q is inert here
  ok   kepler spread E=5 adaptive from dt0=0.6 (mixed rejection): 20 record lines identical, 5 systems x 4 samples
       counters and flags the loop's; nextstep ran 121 times; the systems' ratios differ at 3 of 3 sampled steps (1.078295 to 1.112737 at the last); a mixed attempt: steps_rejected=[1, 1, 1, 1, 0]
```
fp128 and fp256 print the same 12 lines with the same counts. Each format block also carries the existing "fma form vs REBOUND's sequence" drift line. The run ends `RESULT: PASS`.

## Other runs
- **Full `make check`** at `cae9916`: log `...\scratchpad\P4\check-full.log`. rc 0 in 4,753 s; 15 legs run, none skipped; 281 `ok` lines, 0 FAIL lines.
  - The six `gate_real` wide-state digests equal entry 38's.
  - `check_door`'s forced-off comparison still says "vacuous for now". That is correct: P4 is not a door route, and that comparison runs the loop engine.
- **A/B against `af2f400`** (measured, run twice, the second on the committed binary, sha256 `c88bafc9…`): 12 problems, both engines, three formats, 72 integrations, 72 ok.
  - Every record line identical, and every step counter and `flags_seen`.
  - On the program engine, `calls=` falls by exactly 68 and `program_calls=` rises by exactly 1 per run. On the loop engine neither moves.
- **`make check-light`:** rc 0 in 930 s, 15 legs run, 226 `ok`, 0 FAIL.
- **`make check-python`:** "IDENTICAL: 13 values". Its control: "DIFFERS: 9 of 13".

## Controls (logs `...\P4\sab-*.log`; the sabotaged trees are deleted)
The lead amended the control to "one plain addition or multiplication dropped".

| sabotage | property it is named for | result with the sabotage | without |
|---|---|---|---|
| N1: level 0's `mul en, q1, s` replaced by a copy (all formats) | a dropped multiplication changes the record | FAIL on Kepler adaptive and the ensemble. **Inert** on Kepler fixed and outer fixed, where every ratio is exactly 1 | PASS |
| N1a: level 0's `+ be` dropped (fp64) | a dropped addition changes the record | FAIL on Kepler adaptive and the ensemble. On Kepler fixed the records are identical, and only `mean_pc_iterations` catches it (2.455 vs 2.460). Inert on outer fixed | PASS |
| N2: ratio taken from the bank, lane 0's (all formats) | the per-system ratio | the three single-system cases **pass**; the ensemble FAILs at system 1. This confirms the brief: no existing case could see it | PASS |
| N3: the program never runs (fp64) | the program route actually ran | records identical in all 4 cases; caught only by `nextstep_calls` (0, must be 200 to 200) | PASS |
| N4: bank order reversed (fp64) | the host's bank order matches the generator's | FAIL; on outer fixed only through the counters (2.283 vs 3.933) | PASS |

## Not done, and stated limits
- **Not done:**
  - The end-of-step update, by the lead's decision.
  - No card work and no speed claims.
  - No compiled-in image for the library half. It is not needed, because the library half never takes the program engine.
- **Program engine only.** `ias15_engine_alloc()` sets `engine_program = 0` (:3156). So a drop-in or Python user always gets the elementwise route, and no library-path gate can exercise this program.
- **Not run on a card.** Believed only that it works there: it needs nothing beyond what `predict-<fmt>` needs. cft-fp256 records zero-deposit programs with scratch I/O matching software on revision-7 and round-2 tiles.
- **Fixed-step cases cannot see a fault in q's powers.** The ratio is exactly 1 there, and the gate prints that on each fixed case.
- **The "it ran" check is exact only on the single-system cases.** There it pins the count to `steps_done`; on the ensemble it is a range (120 ≤ 121 ≤ 604). An ensemble that fell back to the elementwise route on some predicting attempts would pass, with the same bits.
- **No case predicts after a mid-run rejection.** Prediction from `er`/`br` with dt/dt_last_done is never reached: no gate problem, and none of seven longer runs I probed, rejects after the first step. Believed equivalent anyway, because the program sees only PE, PB and RB, which the caller fills the same way for both engines.
- **`outer fixed dt=40`'s records cannot see a wrong corrector start;** only its pass counts can. This is in the ledger.
- **`staged_bytes` over-counts this program.** `run_program()` counts streams b and c and a deposit window it does not use, as it already does for `correct_n`. Nothing compares `staged_bytes`.

## What the brief and ROUND3.md got wrong
1. **"Sixteen compensated additions".** `predict_next_step` has none (69 plain operations a coordinate). The compensated additions are the end-of-step update's 17. Escalated and confirmed; the lead corrects ROUND3.md and ROADMAP.md.
2. **The negative control as written could not exist.** The lead amended it.
3. **The brief names the wrong function.** `engine_program = 0` at :3113 is in `ias15_engine_alloc()`, not `ias15_engine_open()`.
4. **ROUND3's "existing comparison" is not enough on its own.** N2, N3 and N4 each pass it somewhere, which is why the gate now holds the counters and `nextstep_calls`.
5. **The bank limit was not anticipated.** The brief did not foresee that the 21 binomials overflow the 16-slot bank.

## Integrator-only docs that should change
- README.md:241 and :681-685: the program count is now 30, with `nextstep-<fmt>`.
- docs/HARDWARE.md:152: "predict_next_step, elementwise again" is now one program run under `--engine program`.
- docs/ENSEMBLE.md:42-61 (not integrator-only, not mine) could say the program takes the ratio per lane.

## Disclosed and pre-existing items
- My first build used `make -j6`, before the lead's warning about it. It did no harm: `libcft.a` has sha256 `1c18ac85…`, the same as V0's serial build, and the 27 existing program images are byte-identical to the main checkout's.
- **Pre-existing, not fixed:**
  - The `check_ensemble` leg runs `make_ensemble.py` without naming it as an input (Makefile:595/620/648).
  - The subprocess API keeps the trailer line in a 512-byte buffer (`src/cft_rebound_run.c`:175). The E=1 trailer is 394 bytes now, and the keys it reads are near the start.
- **For the merge:** P1 and P2 also add rows at the end of `trailer_keys[]`, so that conflict is trivial.
