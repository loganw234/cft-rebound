# lead

Round 3 (ROUND3.md). Seeded before dispatch with what a parcel starting
now would want to know.

## 2026-10-31 — the base: main is the re-pin, and P0 is not on it yet

Measured: main and origin/main are `ebaeaa1`, cft-fp256 pinned at
`922c2ad` (libcft ABI 0.18; docs/VALIDATION.md entry 38). P0 is being
built on branch `round3-p0`. No parcel starts until P0 is verified,
merged and pushed; your dispatch message names the exact base, and
`git log --oneline -1` must match it.

For: anyone.

## 2026-10-31 — a fresh worktree has no `third_party/`

Measured: it is gitignored and reproduced from `third_party/MANIFEST`.
The main checkout's two clones are at the pins as of 2026-10-31
(`rebound` bdfda4bd, `cft-fp256` 922c2ade), so a local clone of each is
enough and nothing needs downloading. Then run `tools/check_pins.sh` and
read all three of its lines: it prints FAIL for a clone at the wrong
commit.

For: anyone.

## 2026-10-31 — on Windows, an import table that names a `lib*.dll` is a library Python cannot load

Measured: from 24900ee (2026-09-14) the trailer's `clock_gettime()`
made every Windows `build/libcft_ias15.dll` import
`libwinpthread-1.dll`, and `ctypes` refused it. Fixed on `round3-p0`
(47f0bc3): winpthreads linked static, and the link rule now refuses a
library that imports any `lib*.dll`. If your change adds a call that
mingw-w64 takes from a runtime DLL, `make python-lib` will now say so
by name.

For: anyone touching the engine's C on Windows, P0, P3.

## 2026-10-31 10:30 — V0 sent P0 back; its fixes are on `round3-p0-v1`

`verifier-P0.md` in this directory is V0's own entry. The lead placed it
verbatim, because worktree isolation refused V0's write here.

Measured by V0: no record line moved across 51 integrations. Measured by
the lead: the first P0 (`971f93d`) passed the full `make check` on
Windows, 15 legs, 0 FAIL, with the six wide-state digests unchanged.

The send-back items that bind a parcel, all measured here and fixed:
- **The gate cache keys on every `CFT_REBOUND_` variable**, by prefix
  (`--env-prefix`). Before this fix, a pass with every route hidden
  satisfied the next default run.
- **`staged_bytes` depends on the route.** The card-day normalisers now
  drop it. They also print each card run's routes, which they used to
  drop unseen.
- **`vrun_k` reads a scalar once, before any element is written**, on
  both routes. libcft's software backend reads element 0 again after
  writing it (cft-fp256 `host/src/device.c`, 2068-2086). Whether that
  is libcft's intended contract is a question for cft-fp256.
- **Once any operand has a table, `vrun_ix` refuses a result that
  overlaps any operand**, on both routes, as `cft.h` does.
- **`--door-selftest` holds both routes against a reference computed
  outside the wrappers.** Each wrapper call's accounting is checked. At
  binary128 and binary256 the data uses full-width mantissas.
- **The library half can now see its routes**, through
  `ias15_engine_route()`. A library gate that routes a call reads it.
- **A misspelled `CFT_REBOUND_ROUTE_*` or `CFT_REBOUND_HIDE*` variable is
  refused by name.**
- **Ensembles have no width cap.** `CFT_MAX_BODIES` bounds the bodies of
  one system, not the number of systems. So no shape is "the largest
  the integrator presents". The self-test covers past every width that
  has been run.

Measured: the new gate fails on all 11 sabotaged engines: the 5 it
caught before, and the 5 V0 found passing (with N7 at both binary128
and binary256).

Believed, pre-existing and not P0's: on the drop-in path the refusal
sentence prints twice and `steps_done` becomes 1. Pre-P0 did the same
for a missing artifact. It is in `src/reb_integrator_cft.c`, so P3's
brief carries it.

For: anyone; P1, P2 and P5 especially, for the wrappers' rules.

## 2026-10-31 11:06 — V0's re-check: the fixes hold, four gaps closed, two limits stated

`verifier-P0-recheck.md` is V0's own entry, placed verbatim by the lead.

Measured by V0 on `90e6f3f`:
- records unchanged, 51 of 51;
- `check-light` with 15 legs and 0 FAIL, and the Python legs passing;
- every fix confirmed against its finding;
- reading a scalar once is correct across five aliasing shapes, so no
  hole there.

Four of its ten new sabotages passed the gate. Each now fails, measured
by the lead:
- F4: the data's low bytes were never checked. The data now checks
  itself by a round trip through binary64.
- F6: the misspelled hide variable was untested.
- F11: no two-operand reduction was tested; the dot product is added.
- F4 combined with N8.

Also fixed: `vrun_ix` refuses a table on a NULL operand, or beside a
zero-element source, on both routes. Measured: 17 of 17 sabotaged
engines fail the gate.

Stated, not closed:
- **Arity.** A table on an operand the opcode does not read. libcft
  exports no arity. Today's route ignores the operand, so its result is
  still the opcode's own.
- **Prefix typos.** A typo inside the prefix makes an unrelated
  variable, which nothing reads.
- **Python on Windows.** The library half inside a Python process sees
  the msvcrt environment as it was at start, so a variable set through
  `os.environ` is not seen. That holds for the door's variables and for
  `CFT_REBOUND_ARTIFACT`.

For: P1, P2, P5 (the arity limit and the routes accessor), and anyone
documenting Windows use.

## 2026-10-31 11:34 — V0's second re-check: the data's self-check is closed three ways

`verifier-P0-recheck2.md` is V0's own entry, placed verbatim by the
lead.

Measured by V0 on `d7d964b`:
- records unchanged, 51 of 51;
- every fix confirmed;
- the new refusals reject no call the engine makes. Gravity's pair
  shape, with both operands indexing the whole coordinate vector and d
  a separate pair buffer, ran on both routes up to 524,272 pairs.

Three ways the data check could be fooled, now closed:
- **The partial byte (F16).** binary128 has 60 bits below binary64's
  reach, and whole-byte randomising left bits 56-59 always zero. That
  was a gap in the shipped data, not only a sabotage. The data now
  fills every bit, partial byte included.
- **An under-counted width (F15).** Every bit position below binary64's
  reach must now be set in some value, and the positions are measured
  by widening 1 + 2^-52 rather than computed.
- **No zeros (F18).** Zeros of both signs must now occur.

Measured: 21 of 21 sabotaged engines fail the gate, each at the check
meant for it.

For: anyone writing a test whose data has to reach a format's low bits.

## 2026-11-02 06:38 — Dispatch: P1 to P4 from af2f400, through the drop, with no card

The briefs are in this directory: `brief-common.md`, which every parcel
reads first, then `brief-P1.md` to `brief-P4.md`. Where a brief and
ROUND3.md differ, the brief wins. ROUND3.md was written before P0
landed.

Measured:
- main is `af2f400`, P0, merged and pushed on 2026-10-31. Every parcel
  branches from it, onto its own branch, `round3-p<n>`.
- The main checkout's pinned clones are at `bdfda4bd` (rebound) and
  `922c2ade` (cft-fp256). A parcel clones those locally, never from
  GitHub. `brief-common.md` has the lines.
- An isolated agent can read this directory but cannot write it (V0,
  2026-10-31). So entries go to the drop that README.md names, and the
  lead places them here verbatim, saying so.
- The one-tile f128 image that entry 37 used is on amd-arc-box, at
  `~/cardday-f128s/cft_hw_f128_1x.xclbin`. It was found today with a
  read-only `find`.

Decided at dispatch:
- **P1 gets one extra `route_def[]` row.** The card day must switch the
  accumulate fold and the pair gather separately. One `indexed` route
  cannot express both choices, which ROUND3.md left inconsistent.
- **P3 proposes the restore field's name**, and the lead answers in
  `urgent/`.

From the owner, 2026-11-02: **the card is held by another session.** No
parcel touches it or amd-arc-box. The lead stays off it too until the
owner gives a time.

For: every parcel.

## 2026-11-02 06:58 — P4's brief was wrong about what it converts; the scope stands

P4 found that ROUND3.md's P4 premise ran two things together.
`predict_next_step_vec()` has no compensated additions. The 17 `add_cs`
a coordinate are `step_attempt()`'s end-of-step update.

Measured by P4; checked by the lead at `af2f400`:
- `predict_next_step_vec()` (:1467-1486) has no `add_cs`;
- the end-of-step update (:2124-2136) has the `add_cs`;
- docs/HARDWARE.md:147 keeps the two apart.

Decided, and sent to P4 in `urgent/lead-p4-scope.md`:
- P4 builds `predict_next_step_vec()` as the program, as its brief's
  ownership and trap say.
- Its control drops one plain addition or multiplication instead of a
  compensated one.
- The end-of-step update stays out. It is in `step_attempt()`, which P2
  is editing.

`P4.md` is P4's own entry, placed here verbatim from the drop. Each of
its later entries is placed the same way.

For: anyone reading ROUND3.md's P4 section, and P5's recount of the
broadcast sites.

## 2026-11-02 07:06 — Program images in the library half: one way, P2's; P1's route names fixed

`P1.md` and `P2.md` are the parcels' own entries, placed here verbatim
from the drop.

Measured by P2 (read at `af2f400`): the library half has no program
loader. P2 compiles its `normalabs` images in, through a generated
header assembled from the pinned tree and checked against the pinned
MANIFEST.

Decided, and sent in `urgent/lead-program-images.md`:
- That mechanism is the round's one way. P2 keeps it general.
- P1 does not write a second one. P1 either keeps its routes
  program-only, with honest route lines in the library half, or builds
  the same shape and says so.
- The lead folds everything together at merge.

Fixed by P1, for the card scripts:
- `indexed` is the accumulate fold.
- `pair_gather` is a new row, `CFT_REBOUND_ROUTE_PAIR_GATHER`, for the
  pair program's inputs.
- Both read `CFT_SEQ_FEAT_INDEXED`. The hide hook hides a bit, so it
  hides both.

Believed by P1, from docs/BITSTREAM.md: entry 37's f128 image publishes
`seq_features 0xf1f`, the scalar bit only. The card session runs the
parcels' routes on rev8a (`0x7ff1f`), and its probe leg measures both
images.

For: P1, P2, and anyone planning the card day.

## 2026-11-02 07:11 — Compiled-in images: one type and one generator interface, before the two parcels drift

P1's 07:14 entry (placed) takes option B, its own generated header, because a program-only route would leave the shared `indexed` row lying in the library half. So P1 and P2 each generate a header that, at merge, lands in one translation unit. The lead fixed the interface in `urgent/lead-embedded-images.md`:
- **One type,** `struct cft_embedded_image`, in a checked-in `src/cft_embedded_image.h` whose exact content both parcels add.
- **One generator interface,** `tools/embed_programs.py --asm --name --out`. It writes the header only when its bytes change, and it prefixes every symbol with the family.
- **P1 owns the generator.** P2 writes a stand-in with the same interface, which the merge replaces.

Measured by P1: on Windows, relinking an unchanged engine changes its bytes (the PE TimeDateStamp, byte 137), so every gate-cache key naming it moves.

For: P1, P2, and the merge.

## 2026-11-02 07:21 — P3's accessor, built by the lead; P3's brief was wrong twice; two build traps go to everyone

The latest entries in `P2.md`, `P3.md` and `P4.md` are placed here verbatim.

**P3's brief was wrong twice** (measured by P3, read at `af2f400`):
- The restore field exists. It is `provenance`, from `7fbbd1f` (2026-09-11), set on both load paths and asserted by three gates.
- An adaptive checkpoint above binary64 resumes inexactly, and archiving the clock will not fix it. The step control's `dt` and `dt_last` are wide too. At binary128, epsilon 1e-9, 20 steps, a save and 20 more, 4 of 18 dump lines differ.

Decided, and sent in `urgent/lead-p3-answers.md`:
- **The accessor.** The lead built it: commit `9b1744ea` on `round3-p3-accessor`, which P3 cherry-picks. The view gains read-only `dt` and `dt_last`, written through `ias15_engine_put_dt_wide()` (with the broadcast) and `put_dt_last_wide()`. Measured: both halves compile clean, and gate_real passes at all three formats. P3's adaptive gate is what tests it.
- **The name stays.** `cft_provenance` remains, because renaming it costs every archive since 2026-09-11. The comments fix the collision with cft-fp256's word.
- **Compatibility is measured in both directions.** ROADMAP's "tolerates strangers" and P3's reading of binarydata.c disagree.
- **The 2-of-40 setup was never recorded.** P3 uses s = 1..40 with 40 steps after each, and records it this time.

**Two build traps** (measured by P3), sent to everyone in `urgent/lead-build-traps.md`:
- `make -j` races two sub-makes on `libcft.a` in a fresh tree.
- A binary run without mingw64 first on PATH exits 0xC0000139.

**P2 conforms to the images interface** (measured by P2). `src/cft_embedded_image.h` has SHA-256 `4f8dfa60...`. The pin check moved from P2's generator into its gate, through `cft_program_digest`. The program's compile line also needs `-Isrc`.

**P4** (measured by P4): 72 integrations, with every record line and every physics counter identical. On `--engine program`, `calls=` falls by exactly 68 and `program_calls=` rises by exactly 1 per predicting attempt. A new key, `nextstep_calls`, counts those runs.

For: everyone (the traps), P3 (the answers), and the merge (`trailer_keys[]` gets rows from P1, P2 and P4; the three Makefile compile lines conflict trivially).

## 2026-11-02 07:25 — For P2's replay control: one problem in check_program_engine hides a wrong corrector start

P4's 07:30 entry, placed verbatim, was measured at fp64 on `outer fixed dt=40`. A sabotaged predictor left all 160 record values identical, and only `mean_pc_iterations` moved. A dropped correction left even the counters identical. The Kepler cases show both.

Believed, by P4: on that problem the corrector reaches the same fixed point bit for bit from any reasonable start.

So a control that only moves where the corrector starts, or adds or drops a pass, is inert through the record there. P2's control ("one count changed by one must change the record") needs a problem shown to bite first, or it must assert the counters too.

For: P2.

## 2026-11-02 07:33 — The first card session is ready: hw/cardday-round3.sh, dry-run five times, no card touched

The script is on lead branch `round3-cardday` (`61ea0d4`). It is not pushed. It runs at P0's commit, `af2f400`, plus the script itself, so it measures the "before". The parcels' routes are a second session, after they merge.

Its legs, in order of what they decide:
1. `probe`;
2. `pin-f128s`;
3. `split-f128s`;
4. `door-rev8a`;
5. `door-f128s`;
6. `split-rev8a`;
7. `tiles`;
8. `gates-rev8a`;
9. `mixed`.

Measured in the cft2204 distro, with XRT and no card, against fake images, across five dry runs. Each of these was found by a dry run and fixed:
- `--build` claimed XRT for a tree built without it.
- The session checked the link before sourcing XRT.
- An image that does not open reads to the benches as one with no format, and they exit 0. Each bench leg now counts its card rows from the CSV.
- `die()` exits 3, as an unopened image does. The binary256 refusal is now told apart by its sentence.
- `compare-images.sh`'s software rows ate card time, with one 512-body binary128 row over 7 minutes. The session no longer uses it.

The guard now names exactly this port's planted programs, by argument and by environment, and passes over a shell naming an image and an idle shell with the variable set. STOP ends the session before its next leg.

Believed: cft-fp256's own guard does not count this port's programs, so the window needs its scheduler held (`cft-sched hold u50-0`).

For: the owner (the window), and the card day.

## 2026-11-02 07:34 — ROUND3.md's replay control was inert by construction; P2's replacement is accepted

Measured by P2 (`P2.md` 07:33, placed verbatim; its escalation is in the drop as `urgent-P2-replay-control.md`):
- 0 of 122 one-count mutations changed a record line, over 61 uncapped attempts, 8 configurations and three formats;
- every uncapped count lowered by one at once left 12 of 12 runs identical;
- the replay does run the moved counts: `mean_pc_iterations` moves by exactly the change.

Believed by P2: the exit test stops on the first pass that changes nothing, so that pass is a confirmation, and a schedule moved by one either stops at the same fixed point or repeats it.

Decided, and sent in `urgent/lead-p2-replay-control.md`, as P2's controls:
- the first attempt's count set to 1 changes the record or is refused by name;
- a capped count moved by one is refused by name;
- the replay's counters move by exactly the change, asserted in the case;
- a sabotaged replay that runs the test is caught.

**For the next round:** the last corrector pass of an attempt changed no record bit in every run P2 measured, about 30% of passes at fp64. P2 does not exploit it.

For: P2, V2, the card day's item 4 (a replay against its recording is an identity, unaffected), and ROADMAP's corrector items.

## 2026-11-02 07:46 — Correction to this file's replay-control entry: the last pass is NOT removable in general, and nothing is filed as exploitable

P2 corrected its own 07:33 entry. Both are placed verbatim; the escalation is `urgent-P2-correction.md` in the drop.

Measured by P2 at fp128 (Kepler adaptive, dt 0.01, epsilon 1e-9, 30 steps):
- one count moved by one changes the record in 4 of 60 moves, at attempts 25 and 28, each at +1 and -1;
- lowering every uncapped count by one changes it too, in 1 of 16 runs at fp128 and fp256.

The 0-of-122 figure covered only the first 8 attempts of each configuration.

So this file's entry above was too strong in two places:
- the brief's control is inert on most attempts, not by construction;
- "the last corrector pass changed no record bit, about 30% of passes at fp64" is FALSE as a general statement. It is withdrawn as a next-round item.

The share of passes that were an attempt's last is 27-44% at fp64, 11-16% at fp128 and 4-7% at fp256. That is a description of the runs, not a saving.

P2's accepted controls do not rest on either claim, and they stand: the first attempt cut to one pass, a capped count refused by name, and the counters moving by exactly the change.

For: V2, and the next round's corrector work.

## 2026-11-02 08:11 — check_door.py part 4 will hold program_calls too, from the first routed merge

Measured by P2, by sabotage (`P2.md` 08:20, placed): an engine whose device route counts its `normalabs` run in `program_calls` passes `check_door.py`. Part 4's `COUNTERS` (:58) are eight keys, and `program_calls` is not one. Yet every card-day normaliser keeps `program_calls`. So on a card without the bit, such a route would read as differing from software. P2's own gate holds the count equal across its routes, and it caught that sabotage.

Decided: before the first routed parcel merges, the lead adds `program_calls` to part 4's `COUNTERS`, as a lead commit with its own sabotage. It enforces P0's rule, that a route counts the same whichever half carries it, for program runs as well as calls.

Believed: no parcel's design breaks it. P1's two routes run the same program with a different gather, P2 holds it already, and P4 is not a route. A parcel whose route changes `program_calls` must say so now.

For: P1, P2, P5.

Measured on the card (session r3a, 08:10): libcft 0.18 opens entry 37's f128 image. `gate_real` passes at binary64 and binary128, and binary256 is refused by name ("carries fp32 fp64 fp128"). That is entry 38's missing row.

## 2026-11-02 08:13 — The docs sweep so far: what the parcels found the integrator-only files got wrong

Collected so the end of the round loses none. Each item is measured by the parcel named, and `P<n>.md` holds the line numbers.
1. **P4:** ROUND3.md and ROADMAP.md name `predict_next_step`'s "sixteen compensated additions". It has none. The 17 `add_cs` a coordinate are `step_attempt()`'s end-of-step update, as docs/HARDWARE.md:147 already says.
2. **P3:** the restore field exists, as `cft_provenance`, since `7fbbd1f` (2026-09-11). ROADMAP's "still owed" lines (:18-19, :409-413, :426-431, :698-699), PARCELS.md:257-260 and ROUND3.md:672-676 are stale.
3. **P3:** ROADMAP's "What round 2 leaves open: the wide clock" closes with P3's merge. The 2-of-40 setup is now recorded in the case: s = 1..40, then 40 steps after each.
4. **P3:** "the Simulationarchive tolerates strangers" needs its qualifier. An older build loads a newer archive, and REBOUND prints `Error! Could not find field descriptor for name.` once it reaches the first unknown field.
5. **P2:** ROUND3.md's replay control ("one count changed by one") is inert on most attempts.
6. **P2:** ROADMAP's "its four anchors still exist" is wrong on both counts. The prototype has seven, three are gone at `af2f400`, and its replay never counted `iterations_max_exceeded`.
7. **The card:** ROUND3.md's believed claim that 0.18 opens this repository's f128 image is now measured, in session r3a.

For: the lead, at the end of the round.

## 2026-11-02 08:15 — Filed for the next round: a body-count change truncates the wide clock and steps

Measured by P3 (`P3.md` 08:31, placed). `did_add_particle` and `will_remove_particle` set `view_valid = 0` (src/reb_integrator_cft.c). The next step's guard (:841-846) then rebuilds `t`, `t_hi`, `t_lo`, `dt` and `dt_last` from binary64. That happens in a straight run as well as a resumed one, so no gate can see it.

Believed by P3: at `accurate = 1` with an adaptive step above binary64, it costs `dt`'s tail at every merge. The fix is for the guard to keep the wide values when only the count changed.

It is outside P3's files, and outside every parcel's this round. It joins the drop-in refusal path's two defects on the next round's list.

For: the next round.

## 2026-11-02 08:50 — Measured on the card: the gravity split's "before", entry 37's one-tile f128 image, libcft 0.18, af2f400

Session r3a, leg `split-f128s`, `hw/bench-workload.py`. All 12 card rows are byte-identical to software. Each figure is a share of the row's wall clock. The gravity buckets nest: `t_gravity` is about `t_g_lib` plus `t_g_copy`, and `t_g_lib` holds `t_g_accum`, `t_g_divsqrt` and the pair arithmetic.

| problem | format | wall s | gravity | host gather (`t_g_copy`) | accumulate | divide and sqrt in gravity | passes |
|---|---|---|---|---|---|---|---|
| kepler | fp64 | 22.4 | 59.0% | 0.0% | 2.4% | 9.0% | 3.43 |
| kepler | fp128 | 46.2 | 71.8% | 0.0% | 2.9% | 11.0% | 8.56 |
| outer | fp64 | 11.3 | 60.4% | 0.1% | 10.4% | 8.5% | 3.03 |
| outer | fp128 | 25.4 | 74.3% | 0.1% | 12.7% | 10.7% | 8.42 |
| pythagorean | fp64 | 10.4 | 58.0% | 0.0% | 4.5% | 8.6% | 3.08 |
| pythagorean | fp128 | 20.1 | 70.7% | 0.0% | 5.5% | 10.7% | 7.36 |
| nbody64 | fp64 | 9.1 | 82.1% | 1.2% | 36.6% | 30.0% | 3.20 |
| nbody64 | fp128 | 24.2 | 89.6% | 1.1% | 34.5% | 39.0% | 7.95 |
| nbody256 | fp64 | 27.0 | 73.3% | 2.1% | 18.0% | 48.6% | 4.00 |
| nbody256 | fp128 | 51.9 | 86.2% | 1.7% | 16.6% | 60.4% | 7.60 |
| nbody512 | fp64 | 69.9 | 59.2% | 2.2% | 9.7% | 44.7% | 4.00 |
| nbody512 | fp128 | 139.2 | 79.0% | 2.4% | 10.5% | 60.9% | 7.67 |

Believed, reading the table (no route has run on a card yet):
- **The host's gather is at most 2.4%** of a step at every body count. So `pair_gather` on, the device gather at 310-340 ns an element on cft-fp256's card, has almost nothing to win, and may lose.
- **The accumulate is the indexed fold's target.** It is 10-37% at 64-512 bodies, and 2-13% for the small problems.
- **The divide and square root in gravity are the largest single cost** at 256 and 512 bodies: 45-61% of the step. P1 does not touch them. P1's "priced, not built" whole-program divide and square root is therefore the item to weigh next, against cft-fp256's measurement that it is slower per element.

For: P1 (its report's priced item), session B's plan, ROADMAP item 4.

## 2026-11-02 09:03 — P4 reported; V4 dispatched on cae9916; one seam item for the merges

P4's final report is `report-P4.md`, placed verbatim. It covers `round3-p4` at `cae9916`:
- the full `make check`: 15 legs, 281 ok, 0 FAIL, the digests equal to entry 38's;
- the A/B against `af2f400`: 72 of 72 identical;
- five controls with their numbers.

V4 verifies that exact commit, under `brief-verifier.md`.

**The seam item: the trailer's length.** P4 notes that the subprocess API keeps the trailer line in a 512-byte buffer (`src/cft_rebound_run.c`:175), and that the E=1 trailer is 394 bytes at `cae9916`. P1, P2 and P4 each add keys at the end of `trailer_keys[]`. Before the last of those merges, the lead measures the merged trailer's length and what the subprocess API reads from it.

For: the merges.

## 2026-11-02 09:30 — P2 reported; V2 dispatched on 0b5e17e

P2's final report is `report-P2.md`, placed verbatim. It covers `round3-p2` at `0b5e17e`:
- the full `make check`: 16 legs, 531 ok, 0 FAIL, the digests unchanged;
- the A/B against `af2f400`: 87 of 87 identical, counters included;
- `check_door`'s forced-off comparison, live for the first time and passing at all three formats;
- seven controls, each failing where it should.

V2 verifies that exact commit.

Merge notes from P2:
- it adds no `trailer_keys[]` row;
- its branch lacks P1's `$(ASM): $(CFTLIB)` line, which the lead carries in if P2 merges first;
- P0's comments at :166-167 and :470-475 are stale for `reduce_seg`.

For: V2, the merges.

## 2026-11-02 09:35 — The owner delegates round 3's merges and pushes to the lead

The owner wrote in chat: "You have permission to merge and push at your discretion."

The lead's bar for each merge:
- the parcel's verifier says READY, its send-backs re-verified;
- the full `make check` on the merged tree passes, read from the log;
- the merge's seam test passes;
- one merge at a time, never while a suite runs.

A push follows each green merge, and the owner is told what landed. Parcels and verifiers still never merge or push.

For: everyone.

## 2026-11-02 09:37 — Measured on the card: the gravity split on rev8a, the image the parcels' routes will run on

Session r3a, leg `split-rev8a`. All 12 card rows are byte-identical to software, and every call count equals the f128 tile's. Each figure is a share of wall clock. The f128 tile's wall is shown for comparison.

| problem | format | wall s (rev8a / f128) | gravity | host gather | accumulate | divide and sqrt in gravity |
|---|---|---|---|---|---|---|
| kepler | fp64 | 25.9 / 22.4 | 58.3% | 0.0% | 2.2% | 11.6% |
| kepler | fp128 | 53.1 / 46.2 | 69.7% | 0.0% | 2.6% | 14.5% |
| outer | fp64 | 13.0 / 11.3 | 59.5% | 0.0% | 9.7% | 10.9% |
| outer | fp128 | 31.0 / 25.4 | 72.2% | 0.1% | 11.6% | 13.9% |
| pythagorean | fp64 | 13.0 / 10.4 | 57.3% | 0.0% | 4.1% | 11.9% |
| pythagorean | fp128 | 24.3 / 20.1 | 68.8% | 0.0% | 5.0% | 14.0% |
| nbody64 | fp64 | 9.0 / 9.1 | 81.2% | 1.2% | 38.8% | 26.4% |
| nbody64 | fp128 | 23.8 / 24.2 | 88.7% | 1.2% | 38.3% | 33.3% |
| nbody256 | fp64 | 24.8 / 27.0 | 64.7% | 2.1% | 20.0% | 37.6% |
| nbody256 | fp128 | 50.6 / 51.9 | 82.2% | 2.1% | 20.4% | 51.0% |
| nbody512 | fp64 | 60.0 / 69.9 | 46.7% | 2.0% | 10.2% | 31.4% |
| nbody512 | fp128 | 115.4 / 139.2 | 71.0% | 2.8% | 12.9% | 48.6% |

Measured:
- rev8a is 12-25% slower than the f128 tile on the three small problems.
- It is about even at 64 bodies, and 14-17% faster at 512.

Believed: per-call cost dominates the small problems, so the rev8a single's clock and staging cost there. Its revision-8 sequencer and divide win at large N. Neither is measured here.

The reading for P1 is the same as on the f128 tile:
- the host gather is at most 2.8%;
- the accumulate is the indexed fold's target;
- the divide and square root are the largest single cost at 256 and 512 bodies.

For: P1, session B, ROADMAP item 4.

## 2026-11-02 09:41 — Measured on the card: CFT_XRT_TILES=1 on the rev8 quad, against the rev8a single

Session r3a, leg `tiles`, `bench-workload.py --quick`. Every card row is byte-identical to software, and its call count and pass count equal the single tile's.

| problem | format | rev8q, `CFT_XRT_TILES=1` | rev8a single | difference |
|---|---|---|---|---|
| kepler | fp64 | 27.95 s | 25.85 s | +8% |
| kepler | fp128 | 56.55 s | 53.05 s | +7% |
| outer | fp64 | 14.27 s | 13.01 s | +10% |
| outer | fp128 | 31.87 s | 31.00 s | +3% |
| pythagorean | fp64 | 13.14 s | 13.04 s | +1% |
| pythagorean | fp128 | 26.15 s | 24.25 s | +8% |

Believed, not separated here: some of the gap may be the two images' kernel clocks, not the subset open. The probe printed no clock.

For CLAUDE.md, at the round's end: "or the quad with one tile opened, which cost 1-10% against the one-tile image on the small problems (measured 2026-11-02)."

For: the lead's CLAUDE.md sweep.

## 2026-11-02 09:49 — The card is the lead's until 17:00; session B runs today, per parcel, on each verified commit

The owner extended the window: the card is clear until 17:00.

Session r3a finishes as launched (`UNTIL=12:40`). The `deep` leg on rev8d follows. Then session B measures each parcel's routes on rev8a, on the exact commit its verifier passed, as each passes:
- P2: the device test against the host loop, and a replay against its recording on the card, including a software recording replayed on the card;
- P4: the program against the loop engine;
- P3: the identity in a card-written archive;
- P1: the four route combinations at 64 to 512 bodies.

Measuring a verified tip rather than a merge commit is the lead's choice, made to fit the window. The merge changes only shared one-liners. Each VALIDATION entry says which commit the card ran.

For: everyone.

## 2026-11-02 10:16 — P3 reported; V3 dispatched on 3861a7b, the lead's accessor included

P3's final report is `report-P3.md`, placed verbatim. It covers `round3-p3` at `3861a7b`. Its three commits are the lead's accessor (`d492c32`, a cherry-pick of `9b1744ea`), the gate alone (`a8d7a63`), and the fix.

Measured by P3:
- the 2-of-40 case, watched failing on the unfixed tree at binary128 and binary256 (r->t on splits 29 and 30), and 40 of 40 identical with the fix;
- the adaptive case, failing and then passing;
- `CFT_REBOUND_NO_CLOCK` and `CFT_REBOUND_NO_STEP` bringing the failures back;
- the full suite: 15 legs, 0 FAIL, the six digests unchanged.

V3 verifies the whole branch. That includes the lead's own commit, because the lead's changes go to a verifier like anyone's.

Two more items for the docs sweep:
- `README.md`:203-207: the archive's counts are derived now;
- ROADMAP's "only its clock differs" is false through `reb_simulation_integrate()`.

For: V3, the merges, the docs sweep.

## 2026-11-02 10:30 — V4: READY on P4. P4 merged onto staging; the suite runs; P4's session-B build is staged

`V4.md` is placed verbatim. V4 measured:
- 180 of 184 integration pairs against `af2f400` identical, and the other 4 stopping identically on both builds;
- 34,338 nextstep runs compared element by element with the elementwise route, 0 different;
- P4's five controls reproduced;
- 12 of V4's 13 sabotages caught.

Its two (b) findings went to P4 as one follow-up commit:
- a mid-run-rejection case, since V4 showed the path is reachable;
- V11, the nextstep run's flags dropped, stated as a limit.

That commit lands with a later merge, after V4 re-checks it.

`round3-staging`, in the lead's worktree, is `main` (`af2f400`) plus `round3-cardday` (`32dc962`) plus P4 (`00f89b2`). Its full `make check` is running from clean. `libcft.a` there is `1c18ac85`, V4's build. Main moves only after that log is read.

Session B's P4 build is staged on amd-arc-box, in `~/cft-rebound-r3-p4` (`0ee7a18`, which is `cae9916` merged with `round3-cardday`), linked against XRT. It runs on the card after session r3a ends.

For: everyone.

## 2026-11-02 10:48 — V2 sends P2 back once; P1 reported and V1 dispatched; P1's library case already holds M4

`V2.md` is placed verbatim: **SENT BACK, 1 (a)**. V2 measured:
- no record line moved, 258 pairs against `af2f400`;
- P2's seven controls reproduce.

The (a) is M2. A replay that keeps every system in the corrector to the attempt's last count passes the gate at every format, because the extra passes land on fixed points. V2's separating control is to cut one non-longest system to 1 pass, in a mixed attempt.

Two (b)s:
- M3 and M3s: the run key's epsilon and state hash are unheld;
- M4: the library-path case accepts whichever route opened.

All three went back to P2, resumed with its context, as follow-up commits on top of `0b5e17e`. V2 re-checks.

P1's final report is `report-P1.md`, placed verbatim. It covers `round3-p1` at `d4e710b`:
- the full suite: 16 legs, 320 ok, 0 FAIL;
- the A/B: 170 of 170 identical;
- six controls, including both of the brief's traps.

Its library case already requires "on by=device" unforced (`cases_gravity`'s own line says so). So `urgent/lead-p1-route-case.md`, which arrived after P1 finished, asks for what is there. V1 checks it, and is pointed at V2's shapes too.

For: P2, V1, V2.

## 2026-11-02 10:49 — P4's follow-up, 0c7ad74, goes to V4

P4 closed V4's two (b) findings in one commit, `0c7ad74`, on top of `cae9916`. Measured by P4:
- **the case:** Kepler e = 0.99, epsilon 1e-2, 40 steps, with 11 rejections at each format that predict from er/br;
- **its control:** N5 fails it at every format and leaves the other four cases ok;
- **V11:** stated as a limit in the gate's header.

V4 re-checks the delta. Staging's suite runs at `00f89b2`, which merges `cae9916`. So `0c7ad74` lands with the next merge, once V4 passes it.

For: V4, the merges.

## 2026-11-02 11:19 — V4: READY on P4's follow-up 0c7ad74; it lands with the next substantive merge

`V4.md`'s second entry is placed verbatim. V4 measured:
- the diff is one file, `tools/check_program_engine.py`, so no record can move;
- the new case passes at all three formats;
- N5 fails it, and only it;
- its own assertion fails when nothing predicts after a rejection, both at epsilon 1e-9 and with two rejections before the first accepted step;
- every earlier sabotage keeps its verdict, and V11 is stated as a limit.

Because `0c7ad74` changes only a gate script, it goes into the next staging merge beside P3 or P2, under that merge's full suite, rather than buying a suite of its own. The two share no file.

For: the merges.

## 2026-11-02 12:13 — P2's fixes, faa9f22 and 53ffd5f; V1's urgent on P1's library case; a host fact that slows every suite

**P2** (`P2.md` 11:45 and its addendum, placed) closed V2's send-back in two commits on top of `0b5e17e`. Measured by P2:
- `faa9f22` holds each system's own exit and all 20 run-key fields;
- `53ffd5f` makes the library case derive the route state its environment allows;
- M2, M3, M3s and M4 each now fail;
- every derived branch is exercised.

V2 re-checks when P2's report lands.

**V1**, by urgent in the drop (`urgent-V1-p1-m4-half-held.md`): P1's `cases_gravity` holds "on by=device" only on unforced software. Under any hide variable, even an unrelated one, or on a card, it accepts the impossible `off by=device`. Measured with `HIDE=scalar`. V1's full report follows, and then P1 goes back with everything at once. P2's `53ffd5f` is the shape to follow.

**The host** (measured by P2): processes launched through the Bash tool run at BelowNormal priority. With the host at 100%, two of them gained about 6 s of CPU in 10 minutes. That is why today's suites take 1.5 to 2 hours. The lead launches merge suites through PowerShell at Normal priority from now on.

**V3**, on hazards (`V3.md` 12:08, placed): two `gate_real` processes in one directory corrupt each other's `gate_real.bin`. Serial `make check` and the card's separate clones are safe.

For: P1, V1, V2, and anyone launching long runs.

## 2026-11-02 12:21 — Merged and pushed: P4 and the card tooling. main = origin/main = 00f89b2

The full `make check` on `round3-staging` (`00f89b2`) passed. The log is in the scratchpad, `merge/check-p4.log`. It ran from 10:29 to 12:20, from a clean build, at BelowNormal priority under load. Read from the log:
- 15 legs, all in full mode;
- 281 ok, 0 FAIL;
- the only skip is the deliberate `body_count`;
- every `RESULT: PASS`, `check_dropin` every case passed, and `gate_real` passing at all three formats;
- the six wide-state digests unchanged;
- `check_door`'s forced-off comparison still "vacuous", as it must be with no routed call merged.

`main` was fast-forwarded to `00f89b2` and pushed. `origin/main` is `00f89b2`.

It holds:
- `32dc962`, which merges `round3-cardday`: the card script and bench-workload's software cache;
- `00f89b2`, which merges P4's `cae9916`.

P4's follow-up `0c7ad74` (V4: READY) goes with the next merge.

Next merge: P3 (once V3 says READY), with `0c7ad74`. Its suite runs at Normal priority, through PowerShell.

For: everyone. Branches cut from here start at `00f89b2`.

## 2026-11-02 12:41 — Card: check_dropin --wide and the ensemble gate deferred to a later window; nothing killed

Measured: `check_dropin` on rev8a was at 84 of the 131 ok lines it prints on software after 2 h 32 min, so it ends about 13:35. The leg's last two gates, `check_dropin --wide` (115 ok lines on software) and `tools/check_ensemble.py`, would have run past 17:00. That leaves session B no card time.

Decided, with nothing killed, because killing a card process can leave the tile unusable:
- In the box clone, `~/cft-rebound-r3`, the running `build/check_dropin` was renamed to `check_dropin.real`. Its process, 2700426, runs on from the same inode, as `/proc/2700426/exe` shows.
- `build/check_dropin` is now a stub that prints "deferred by the lead" and exits 3.
- `tools/check_ensemble.py` is the same kind of stub. The original is saved in `~/r3-card/check_ensemble.py.orig`.
- `~/r3-logs-r3a/STOP` ends the session after this leg.
- Both files are restored once the leg ends, and the clone checked clean.

The two deferred gates are the pin on the card at binary128 through the drop-in, and HARDWARE.md's owed ensemble gate on a tile. They run in a later window, with `gates-rev8a` split as the deferral shows.

For: the card day, and the owner.

## 2026-11-02 12:45 — V3 sends P3 back once; session B is chained on the box

`V3.md` and `verifier-report-P3.md` are placed. V3's verdict is **SENT BACK, 2**:
- **A1:** `dt_last`'s restore is ungated. S4, S4b and S22 pass every leg, and S22 is the lead's `put_dt_last_wide()` made a no-op. The cause is that no case rejects the first attempt after a load.
- **A2:** four shipped sentences understate the older-build limit. They miss lost appends, a refused post-removal snapshot and a lost function-pointer warning.
- **B1:** the "reached memory" refusal has no case.
- **B2:** the 2-of-40 count is printed, not asserted.

V3 measured nothing moving against `af2f400` across 312 integrations, and the named control reproduces. It also confirmed that the lead's `d492c32` is tree-identical to `9b1744ea`, and that `put_dt_wide` is exercised by S3, S19 and S21. All four went back to P3, resumed with its context.

**Session B** is staged and chained on amd-arc-box.
- The builds:
  - `~/cft-rebound-r3-p4` at `c3471bc`, which is `0c7ad74` with `round3-cardday`;
  - `~/cft-rebound-r3-p2` at `aa3aa7e`, which is `53ffd5f` with `round3-cardday`;
  - `~/cft-rebound-r3-p1` at `afc83d8`, which is `d4e710b` with `round3-cardday`.
- `~/r3-card/r3b-chain.sh` waits for session A's end marker and restores session A's clone. It then runs `p4-program`, `p2-replay`, `p1-gravity` and `p2-corrector`, each with `UNTIL=16:50`. Its log is `~/r3-card/r3b-chain.log`.
- P1's build is the reported commit. If V1's send-back touches the engine, P1's numbers are re-measured.

For: P3, V3, the card day.

## 2026-11-02 12:52 — V2's re-check of P2's fixes: SENT BACK, 1 (M2b); P2 resumed

`V2.md`'s 12:52 entry is placed. On P2's two fix commits (`0b5e17e..53ffd5f`), V2 measured:
- the engine is byte-identical;
- M2, M3, M3s and M4 each fail where meant, and an inert cut fails;
- the library case's derivation is right in all 14 reachable states.

**The (a) is M2b.** A system frozen one pass late passes the per-system cut at every format, since a 2-pass cut moves lines just as a 1-pass cut does. The fix is to compare the cut system's lines with an exact reference, the member run alone with the same cut (clean: 0 differ; M2b: 6 of 7 at fp64).

**The (b):** `state` is one composite hash, and its velocity, mass and dt-file components are unheld (M3v, M3m and M3dt pass).

**A hazard:** two check_corrector runs sharing a `--build` directory clobber each other.

All of it went back to P2, as one more follow-up commit on top of `53ffd5f`. V2 re-checks.

For: P2, V2.

## 2026-11-02 13:15 — V1 sends P1 back once (M4, test-only); session B's P1 measurement at d4e710b stands

`V1.md` and V1's urgent are placed. V1's verdict is **SENT BACK, 1**. V1 measured:
- no record line moved, in 228 program-half pairs and 42 library-half pairs against `af2f400`;
- P1's six controls reproduce with P1's numbers;
- the priced divide and square root reproduce.

**The (a):** `cases_gravity.c` holds M4 only on unforced software. The fix is in that test case, P2's `53ffd5f` shape. V1 confirms nothing in the engine changes.

**The (b)s:**
- three sabotages pass: a read past a table's source, `vprog_ix`'s NULL-source and zero-source refusals, and counters reporting the new route;
- P1's wide-format-swap limit is wrong at binary128, where `check_records` and `check_door` catch the swap. Only binary256 has no automated catch.

All of it went back to P1, resumed with its context.

So the engine at `d4e710b` is what merges. The `p1-gravity` leg runs at `d4e710b` on the card this afternoon, and its numbers stand for the merged code.

For: P1, V1, the card day.

## 2026-11-02 13:29 — P2's second fix, 8006820, goes to V2

P2 closed V2's re-check in `8006820`, which changes only `tools/check_corrector.py`. Measured by P2:
- **M2b:** the cut is now held to its member run alone. M2b fails at each format, where it passed `53ffd5f`'s gate.
- **The state hash:** its position, velocity, mass and dt-file parts each have a case, and M3v, M3m and M3dt each fail.
- **The shared directory:** each run works in `<build>/corrector/<pid>`, and three concurrent runs passed.

V2 re-checks the delta. The engine has not changed since `0b5e17e`. So session B's `p2-replay` and `p2-corrector` legs, built at `53ffd5f` with `round3-cardday`, measure the code that merges.

For: V2, the merges.

## 2026-11-02 13:40 — P3's fixes, dd51e21 and d8ae085, go to V3; the way to launch a suite at Normal priority

P3 closed V3's A1, A2, B1 and B2 in `dd51e21` (the gate) and `d8ae085` (the comments), on top of `3861a7b`. P3's latest entries are placed. Measured by P3:
- **sequence 6:** a rejected first attempt after a load, on V3's lifted problem. S4, S4b and S22 fail, and S22 was inert on the planar problem;
- **sequence 7:** the per-family memory refusals;
- **the sweep:** the asserted 2-of-40;
- **the comments:** the older-build limit stated by its three behaviours, in one place.

V3 re-checks the delta.

**The launch:** `make` run straight from PowerShell fails, because msys make cannot launch `gate_cache.py`'s command (measured by P3). PowerShell running `C:\Program Files\Git\bin\bash.exe -c "..."` works, at Normal priority. The lead's next merge suite runs that way.

For: V3, the merges.

## 2026-11-02 13:41 — Measured on the card: the whole drop-in gate passes on rev8a through libcft 0.18; session A ends; session B starts

Session r3a, leg `gates-rev8a`:
- `check_dropin` on rev8a: rc 0, **131 ok, 0 FAIL, "every case passed"**, in about 3 h 34 min. That is the registered integrator bit for bit REBOUND's own at binary64, every case and every refusal, on a tile, through the new library. Entry 27 ran it on the quad at the old pin.
- `gate_real`: PASS at binary64, binary128 and binary256 earlier in the same leg.
- `check_dropin --wide` and `check_ensemble`: deferred, as the lead's 12:40 entry says. Both stubs logged rc 3 "deferred".

The leg took 14,439 s against a 110-minute estimate. The session ended "8 of 9 legs ran", with the STOP file before `mixed`. Over the day, session A's legs ran from 156 s to 4 h, against estimates of 2 to 110 minutes, and the log has each actual beside its estimate.

The chain then restored session A's clone, with 0 changed files, and started session B with `r3b-p4` (`p4-program`) at 13:41.

For: the card day, and VALIDATION.

## 2026-11-02 13:58 — V2: READY on P2 (8006820). Merge 2 is staged, with check_door holding program_calls; its suite runs at Normal priority

`V2.md`'s 13:50 entry is placed: **READY on `8006820`**. One should-fix, Rboth, went to P2 as a follow-up commit, to land later: two refusals for an unrelated reason satisfy the cut checks, so the gate should require that the cut replays run.

`round3-staging` now holds:
- `3159d92`, which merges P4's follow-up `0c7ad74`;
- `42b4863`, which merges P2's `8006820`, with no conflicts;
- `ce593f7`, the lead's commit: `check_door` part 4 holds `program_calls`, and a failing line names what differed.

Measured on that tree:
- the clean build passes `check_door` at fp64, "all 9 counters identical", with the comparison live;
- P2's S6, built apart into `build9`, fails: "(DIFFER: program_calls 344 against 0)";
- the gate before `ce593f7` passes the same S6 binary.

Its full `make check` started at 13:58, from clean. It was launched from PowerShell through Git's bash, so it runs at Normal priority, and `Get-Process` shows Normal. The log is `merge/check-p2.log`.

No seam test applies to P2 against P4 (ROUND3.md's list). P2's seams are with P1 and P3.

For: everyone.

## 2026-11-02 14:27 — V3: READY on P3 (d8ae085); P3 merges next, with a seam test the lead wrote

`V3.md`'s 14:30 entry is placed: **READY on `d8ae085`**. V3 measured:
- the delta changes no shipped object;
- A1, A2, B1 and B2 are closed, each sabotage failing where meant;
- the full sweep passes, with "r->t on 2 [29, 30] (the case's 2, asserted)".

Two should-fixes went to P3 as one more commit, to land later:
- two comment phrasings, on single snapshots and on adaptive resumes;
- sequence 6's rejection counter, which S5 fools though it is caught elsewhere.

**The P2 x P3 seam.** ROUND3.md's "a replay across a checkpoint" cannot exist. The replay is the program's and the checkpoint the drop-in's. So the seam is the route across a checkpoint: save with `reduce_seg` forced one way, resume with it forced the other, and require the straight run's dump.
- It is `tools/check_seams.py`. It imports `check_checkpoint`'s runner, comparison and sequences, and copies none of them.
- Its control is `CFT_REBOUND_NO_ADOPT`.
- It becomes a suite leg with P3's merge.
- P1's two routes join it when P1 merges, which is the P1 x P3 seam.

For: the merges.

## 2026-11-02 14:37 — Measured on the card: P4's program engine matches the loop engine on rev8a

Session r3b-p4 ran leg `p4-program` on the clone built at `c3471bc`, which is P4's `cae9916` and its follow-up `0c7ad74`, merged with `round3-cardday`. P4's `tools/check_program_engine.py` ran with `CFT_REBOUND_ARTIFACT` set to the rev8a single:
- rc 0, **15 ok, 0 FAIL, `RESULT: PASS`**;
- `--engine program` against `--engine loop`, at fp64, fp128 and fp256, on a tile;
- the nextstep program, the corrector and the predictor programs all included;
- also the rejection case added after V4, whose predictions come from er/br.

It took 56 min against a 20-minute estimate.

For: VALIDATION (P4's entry, the card row).

## 2026-11-02 14:42 — P1's fix, 3a00e18, goes to V1; the lead accepts the door_refuse() edit

P1 closed V1's send-back in `3a00e18`, on top of `d4e710b`. Measured by P1:
- `cases_gravity`'s `expected()` derives each route's state, and M4 fails in all 10 states that require on;
- six `--door-refuse` cases, each route in its own words, so m4_lie, no_src_check, no_null_zero, no_null_a and no_no_block fail;
- the swap limit restated: binary64 and binary128 caught in the full tier only, binary256 not caught;
- `steps_rejected > 0` asserted.

**Decided.** The refusal cases edit `src/ias15_cft.c` inside `door_refuse()` only. P1 measured the library object identical in all 78 functions, and the program in 61 of 62, the 62nd being `main()`, where `door_refuse()` is inlined. The lead accepts the edit. The integration code is unchanged, so the card's `p1-gravity` numbers at `d4e710b` stand for the merged engine, provided V1 confirms the object identity, which the re-check asks.

For: V1, the merges, the card day.

## 2026-11-02 14:51 — Measured on the card: P2's replay reproduces its recording bit for bit on rev8a, and a software schedule drives the card

Session r3b-p2a ran leg `p2-replay` on the clone built at `aa3aa7e`, which is P2's `53ffd5f` merged with `round3-cardday`. The engine is byte-identical to `8006820` and `9539f1d` (V2). Each run was binary128, `--engine program --arith fma`, on the rev8a single.

| problem | card recording | its replay | change | replay against recording | software recording replayed on the card |
|---|---|---|---|---|---|
| kepler, 200 steps | 55.64 s | 53.95 s | -3.0% | data identical; counters equal | data identical |
| outer, 100 steps | 34.48 s | 32.24 s | -6.5% | data identical; counters equal | data identical |
| nbody64, 20 steps | 25.77 s | 25.45 s | -1.2% | data identical; counters equal | data identical |
| nbody256, 5 steps | 50.46 s | 50.92 s | +0.9% | data identical; counters equal | data identical |

The counters compared are `steps_done`, `steps_rejected`, `iterations_max_exceeded` and `mean_pc_iterations`.

Measured: the replay's byte-identical record is the proof that skipping the exit test is exact, on a tile. A schedule recorded on the software backend replays on the card to the card's own recording.

Believed: the saving, 1 to 6.5% on the small problems and nothing measurable at 256 bodies, is the exit test's share of a step. cft-fp256 measured 4-9% for removing the test outright. One run per row; timing noise is not measured.

For: VALIDATION (P2's entry), ROUND3.md's card-day item 4.

## 2026-11-02 15:18 — Correction to this file's 13:40 entry: the PowerShell-to-Git-bash launch must use a script file, not -c

P3 measured it (`urgent-P3-launch-quotes.md`, placed): `bash.exe -c "..."` from PowerShell 5.1 re-splits on embedded quotes.
- A quoted value with a space drops the make target and every later command.
- A value without a space loses its backslashes, so `TMP` arrived as `C:UsersloganAppDataLocalTemp`.

The safe form is a `.sh` file whose path is the only argument. The lead's merge suites already run that way (`merge/run-check.sh`). Every agent still running is told in `urgent/lead-launch-correction.md`.

For: V1, P3.

## 2026-11-02 16:05 — V1: READY on P1 (3a00e18); V3: READY on c957eb2. Merge 3's suite runs; merge 4 is resolved, and its seams are written

**The verdicts, placed.**
- `V1.md`, the 15:36 entry: **READY on `3a00e18`**.
  - The library object is byte-identical to `d4e710b`'s. The program differs only in `main()`, where `door_refuse()` is inlined.
  - The A/B pairs are identical: 47 of 47 on the default routes, and 55 of 55 on the four forced combinations.
  - So the card's `p1-gravity` numbers at `d4e710b` stand for the merged engine, which was the condition the 14:42 entry set.
- `V3.md`: **READY on `c957eb2`**.
  - All six library objects are byte-identical to `d8ae085`'s.
  - S5 fails the new sequence 6 counter at every format.
  - V3 headed the entry 15:50, but it was in the drop by 15:45.

**Merge 3 is staged** at `4291740` on `round3-staging`:
- `ea8d690` merges P2's follow-up, `9539f1d`;
- `9103ab6` merges P3 at `d8ae085`;
- `b231398` is the lead's seam test;
- `4291740` merges P3's follow-up, `c957eb2`.

Nothing conflicted. Its full `make check` started at 15:49, from clean, at Normal priority. The log is `merge/check-p3.log`.

**The seam test needed a physics counter.** The 14:27 draft compared dumps only. A crossing whose forced route carried nothing would then compare two runs of today's route.
- `gate_real --routes` now prints, on stderr after each phase, each family's route from `ias15_engine_route()`.
- `check_seams` asserts that the forced route was taken, by=forced, and that it carried the run: calls and no fallback when on, fallbacks and no call when off.
- Measured on the merged tree before the suite, in 171 s:
  - 12 of 12 crossings at all three formats, each carried on both sides. At binary256 the plain sequence carried 1,214 calls at the save and 2,400 fallbacks at the resume.
  - Every resume gave the straight run's 17 values, and every `CFT_REBOUND_NO_ADOPT` control differed.
- What it cannot see: `reduce_seg` keeps no state from one step to the next, so the route has nothing for an archive to drop. The seam can catch only a restore that depends on the route that wrote it. No sabotage of that kind was built, so that it would show is believed, not measured.

**Merge 4.** Against merge 3, P1 conflicts in five files. They were resolved in a separate worktree, `.claude/worktrees/round3-merge4` on branch `round3-staging-p1`, which is under no suite. The merge is `5c525b4`. In all five, both sides had added at the same place:
- `Makefile`, `tools/check_dropin.c` and `tools/dropin_cases.h`: both sides' lines.
  - The program's include order is main's.
  - No header name is shared between `src/`, `build/` and libcft's `include/`, so the order is immaterial.
- `tools/gen_programs.py`: both generators, P4's nextstep before P1's gravity.
  - **Measured:** the merged generator writes 66 programs, exactly the union of the two sides' 30 and 63.
  - Each file is byte-identical to what its own side writes, and to the committed `programs/`.
- `tools/embed_programs.py`: P1's, whole. P2's copy said in its own header that it was a stand-in for P1's tool.
  - **Measured:** the normalabs header from P1's tool carries the same three images as P2's, byte for byte: sha256 `63d241ba…`, `831e9a73…` and `a6c9f6b5…`.
  - Only the table's order differs, and the engine looks its image up by format.

The merge-4 tree builds from clean in 54 s, with only REBOUND's five warnings. Its pinned clones were cloned locally from the main checkout's, as the agents' were, not fetched.

**The trailer's length, the 09:03 entry's seam item: measured, nothing to fix.**
- The longest merged trailer found is 455 bytes after the "# ", at binary256 with a 16-member ensemble.
- The subprocess API keeps 511 bytes (`src/cft_rebound_run.c`:175), and the six keys it reads all end by byte 159.
- A trailer that outgrew the buffer would lose only timing keys.

**Merge 4's seams**, in its `tools/check_seams.py`:
- **P1 x P3.** `indexed` and `pair_gather` join `reduce_seg` across a checkpoint, over all three of `check_checkpoint`'s sequences. The regrow sequence now runs too, so gravity's tables are rebuilt on both sides of the save.
- **P1 x P2.** A schedule is recorded with both gravity routes forced one way and replayed with both forced the other. Asserted:
  - the recording's record lines and per-system counters;
  - no exit test computed (`reduce_seg` carried nothing);
  - each gravity route carrying its run on both sides;
  - the rejection, on the case that is there for one.
- **P1 x P4.** The program engine, with gravity forced on and then off, against the loop engine on today's gravity. Asserted: the loop engine's record and counters, and `nextstep_calls` above zero and equal in both runs.
- Measured at binary64 on the merge-4 tree, in 32 s: 18, 6 and 3 crossings pass, every forced route carrying.

For: the merges, VALIDATION.

## 2026-11-02 16:08 — Merge 4 is ready at 2b497a6; its seams pass at every format

`round3-staging-p1` holds `5c525b4`, which merges P1, and then `2b497a6`, the lead's seam commit.

Measured on that tree, at all three formats, in 389 s with merge 3's suite running beside it: `check_seams` gave **84 ok, 0 FAIL**.
- The forced routes carried both sides of 54 of 54 checkpoint crossings, 18 of 18 replays and 9 of 9 program-engine pairs.
- At binary256, `indexed` carried 4,309 calls at the save and 8,520 fallbacks at the resume of the plain sequence.
- Every program run made one nextstep call a step (40, 30 and 10).
- kepler e=0.99 had its rejection at every format.

Merge 4's full `make check` runs once merge 3 is on main, through `merge/run-check-m4.sh`, in the merge-4 worktree.

For: the merges.

## 2026-11-02 16:55 — Measured on the card: P1's gravity routes give the same bits on rev8a, and each makes a step slower at 64 to 512 bodies. The card is free at 16:52

Session r3b-p1, leg `p1-gravity`, on the clone built at `afc83d8` (P1's `d4e710b` merged with `round3-cardday`), with the rev8a single tile.
- `check_gravity` with `CFT_REBOUND_ARTIFACT` set to rev8a: rc 0, **23 ok, 0 FAIL**.
- Then `bench-workload.py` once per route combination, each route forced. Every card row of all four is **identical to software**: 12, 12, 12 and 6 rows.
- The route check before each bench shows the forced state, and the route that ran carried its calls.

Card seconds, and the change against both routes off. One run per row, so timing noise is not measured:

| problem | format | both off, s | indexed only | pair_gather only | both on (what auto picks on rev8a) |
|---|---|---|---|---|---|
| kepler | fp64 | 22.44 | -5.6% | +0.9% | not run |
| kepler | fp128 | 44.06 | -7.4% | -2.2% | not run |
| outer | fp64 | 11.08 | +3.7% | -0.3% | not run |
| outer | fp128 | 22.72 | +3.7% | -0.4% | not run |
| pythagorean | fp64 | 10.92 | +1.3% | +5.6% | not run |
| pythagorean | fp128 | 19.39 | +4.5% | -0.5% | not run |
| nbody64 | fp64 | 6.57 | +22.2% | +22.7% | +47.2% |
| nbody64 | fp128 | 15.93 | +25.2% | +24.5% | +52.1% |
| nbody256 | fp64 | 23.14 | +40.0% | +37.7% | +73.7% |
| nbody256 | fp128 | 47.45 | +32.8% | +31.7% | +62.2% |
| nbody512 | fp64 | 64.86 | +29.6% | +28.2% | +60.5% |
| nbody512 | fp128 | 118.29 | +30.3% | +29.8% | +59.3% |

Measured:
- On the card, each gravity route costs 22-40% at 64 to 512 bodies. With both on, the costs about add, to 47-74%.
- On two and three bodies, each is within -7% to +6%.
- An earlier reading in chat, that the two shared one cost, is withdrawn: the both-on row is about the sum.

What this means: on a card that publishes `CFT_SEQ_FEAT_INDEXED`, auto turns both routes on. So P1 merged as it is makes a default card run at 64 to 512 bodies 47-74% slower, with identical bits. The owner decides how merge 4 lands.

**The both-on bench was trimmed by the lead** to fit the window. At 16:43 three lines in the clone's `hw/bench-workload.py` dropped kepler, outer and pythagorean, for the both-on environment only. The bench before it had already loaded the file, so it was unaffected. The file was restored from `~/r3-card/bench-workload.py.p1-orig`, and the clone is clean.

**The chain ended** at 16:52:32: `R3B-CHAIN-COMPLETE`.
- `p2-corrector`, the device exit test against the host loop, was skipped by `UNTIL`: "its estimate, 60 min, would end past 16:50".
- Not run on the card today: `p2-corrector`; `p3-identity`, never chained, because P3 was sent back at 12:45; `check_dropin --wide` and `check_ensemble`, deferred at 12:40; `mixed`; and `deep`.
- No card process is left running, and all four session-B clones are clean.

For: the owner (merge 4's default), VALIDATION (P1's entry, the card rows), ROADMAP item 4.

## 2026-11-02 17:02 — The owner: P1's gravity routes become opt-in before merge 4. P1 is resumed for it

Given the 16:55 table, the owner chose "opt-in first". Under auto, `indexed` and `pair_gather` stay off even where the device publishes the bit, and say `by=opt_in`. `on` and `off` are unchanged. `scalar` and `reduce_seg` keep auto as it is.

P1 was resumed with the change. It is one commit on `round3-p1`, covering:
- the door's `route_def[]` and `engine_routes()`, which the lead asked P1 to cross into;
- `cases_gravity.c`'s `expected()`;
- `check_gravity.py`, whose default combination now expects `off by=opt_in`, and whose `--library` run now forces both routes on, so that M4 still fails `make check`;
- `check_door.py`, which gets a forced-on comparison for the opt-in routes beside part 4's forced-off one.

V1 re-checks it. Then the lead re-merges `round3-p1` into `round3-staging-p1` and runs merge 4's suite. The merge lands tomorrow at the earliest.

Checked before the brief: `check_door --formats fp64` passes on the merge-4 tree as it stands, with gravity on by default against all routes forced off: "3 sample lines and all 9 counters identical". So `program_calls` does not count gravity's program runs, and there is no seam between P1 and `ce593f7`.

For: P1, V1, the merges.

## 2026-11-02 17:04 — Merged and pushed: P2's follow-up, P3 and its follow-up, and the seam test. main = origin/main = 4291740

Merge 3's full `make check`, from clean at `4291740`, ran from 15:49:00 to 17:01:40, with `make check rc=0`. The log reads:
- 17 legs, all `--mode full`, with no cache skips;
- **584 ok, 0 FAIL**, no DIFFER and no traceback;
- 9 `RESULT: PASS` lines, "78 constants compared, all match", "check_dropin: every case passed", "check_dropin --wide: passed", "check_archive: all archive gates pass", `gate_real: PASS` three times, and `gate_subprocess: PASS`;
- the six `gate_real` digests unchanged (`e08541bc0af9b3ec`/`56bacf3bf63f19a7`, `5d7cf4588fad050e`/`cd16e6dc29aa0589`, `a1052750e206bebe`/`ba4d447c8e58bd20`);
- `check_door`'s forced-off comparison at every format: "all 9 counters identical";
- `check_seams`: "12 route crossings carried by the route on both sides, of 12".

`main` was fast-forwarded to `round3-staging` and pushed: `ce593f7..4291740  main -> main`.

Merge 4 is `round3-staging-p1`, on top of `4291740`. It waits for P1's opt-in commit and V1's check.

For: everyone.

## 2026-11-02 18:16 — P1's opt-in commit, 0a0d96d, goes to V1; merge 4 takes it, and its suite runs

`P1.md`'s 18:10 entry is placed. P1 measured, against `3a00e18`:
- every forced combination identical, 136 of 136;
- the default identical to the both-off run, 34 of 34;
- the self-test unchanged but for its two route lines.

M4 now requires the route on in 5 of the 14 door-variable states, down from 10. The suite's own `check_dropin` leg no longer sees it, so `check_gravity --library` forces both routes on and catches it. P1 also measured `check_door` 80 ok, `check_gravity --library` 24 ok, and `make check-light` green.

V1 re-checks `0a0d96d`. The re-check covers the diff, a sample A/B, and four sabotages of the opt-in itself:
- O1: auto ignores opt_in;
- O2: the line says opt_in while the route is on;
- O3: forced on is silently ignored;
- O4: the forced-on comparison is blind to a counter.

It also re-runs M4.

**Merge 4 now holds it.** `round3-staging-p1`:
- `e77486e` merges `round3-p1` at `0a0d96d`. One conflict, in `tools/check_door.py`: main's `COUNTERS` (with `program_calls`, `ce593f7`) is kept beside P1's new `OPT_IN`.
- `e47b04e` is the lead's: `hw/cardday-round3.sh`'s `routes()` read `by=([a-z]+)`, which cannot match `opt_in`. P1 fixed the same regex in the three hw/ scripts its branch has; this one came to main with the card tooling.

Measured on that tree at binary64 before the suite:
- `check_door`: 50 ok, 0 FAIL, "all 9 counters identical; the default leaves indexed and pair_gather off by=opt_in (fallbacks 1254/1254), forced on they carry calls 1254/1254 and no fallback";
- `check_seams --quick`: 30 ok, 0 FAIL.

Merge 4's full `make check` started at 18:15:45, from clean, at Normal priority, with TMP and TEMP spelled out as the Windows temp directory. The log is `merge/check-p1.log`.

**On the temp directory, P1's finding.** Git bash started from PowerShell has `TEMP=/tmp`, and msys64's make hands that to a native child as `C:\msys64\tmp`. Merges 2 and 3 ran that way and passed; their checkpoint files were written under `C:\msys64\tmp`. `merge/run-check-m4.sh` now spells the directory out.

**The docs sweep gains** (P1's list):
- README.md:469, "auto, the default, lets the device decide", needs the exception for indexed and pair_gather;
- the list at README.md:466 lacks `CFT_REBOUND_ROUTE_PAIR_GATHER`;
- ROUND3.md:252, "the device decides";
- ROUND3.md:270's `by=` list lacks `opt_in`.

For: V1, the merges, the docs sweep.

## 2026-11-02 19:30 — V1: READY on P1's opt-in commit (0a0d96d); two follow-ups for the lead

`V1.md`'s entry is placed: **READY on `0a0d96d`**.

V1 measured:
- **No integration function changed.** In the library 75 of 78 functions are identical, and in the program 60 of 63. Those that differ are `route_list`, `ias15_engine_route` and `door_selftest`, whose `route_def[]` entry grew from 0x20 to 0x28 bytes, and the two functions with `engine_routes()` inlined.
- **Records:** "AB2: 115 of 115 pairs identical".
  - 92 forced pairs, against the same environment.
  - 23 defaults, against `3a00e18` with both routes forced off, `staged_bytes` included.
- **The sabotages, each built apart:**
  - O1 (auto ignores opt_in) and O2 (by=opt_in while on) fail `check_door`, `check_gravity` and `check_dropin`.
  - O3 (forced on ignored) fails `check_door` and `check_gravity`, `--library` included.
  - O4 (a counter that moves only when forced on) fails `check_door`'s part 4b: "(DIFFER: divsqrt_calls 18245 against 20753)".
  - M4 fails only `check_gravity --library`, in the full tier.
- **The card branches**, by reading: right.

**Follow-ups, not blocking, the lead's:**
- `make check-light` can no longer see M4. Its `check_dropin` leg runs unforced, which is now M4's own state, and its `check_gravity` runs without `--library`. At `3a00e18` the light tier did catch it. The fix is a forced-on `check_dropin --light` leg in check-light, a Makefile change after merge 4.
- A failing line from part 4, and from P1's part 4b, still opens with "all 9 counters identical", and the truth is only in the suffix. The fix is to say "counters differ" when they do, in both parts. It goes with the docs sweep.

For: the merges.

## 2026-11-02 20:25 — Merged and pushed: P1, with gravity's routes opt-in, and P1's three seams. main = origin/main = e47b04e. The first wave is in

Merge 4's full `make check`, from clean at `e47b04e`, ran from 18:15:45 to 20:21:21, with `make check rc=0`.
- **The tally:** 18 legs, all full, with no cache skips. **715 ok, 0 FAIL**, no DIFFER, traceback or make error.
- **The verdicts:**
  - 10 `RESULT: PASS`, `check_gravity`'s now among them;
  - "78 constants compared, all match";
  - "check_dropin: every case passed" and "check_dropin --wide: passed";
  - "check_archive: all archive gates pass";
  - `gate_real: PASS` three times, and `gate_subprocess: PASS`;
  - the six `gate_real` digests unchanged.
- **The door:** at every format, `check_door` reads "auto leaves only the opt-in routes off: indexed=off by=opt_in, pair_gather=off by=opt_in, reduce_seg=on by=device, scalar=on by=device". Its forced-on comparison reads "all 9 counters identical … forced on they carry calls 1254/1254 and no fallback" at binary64, with 3032 and 4250 at the wide formats.
- **Gravity:** `check_gravity --library` reads "check_dropin --light, gravity forced onto the new routes: rc 0, every case passed; indexed=on by=forced calls=236346 fallbacks=0, pair_gather=on by=forced calls=236397 fallbacks=0".
- **The seams:** `check_seams` carried 54 of 54 checkpoint crossings, 18 of 18 replays and 9 of 9 program-engine pairs.

`main` was fast-forwarded to `round3-staging-p1` and pushed: `4291740..e47b04e  main -> main`.

**Main now holds** P0, P1 (opt-in), P2, P3 and P4, each with its follow-ups, the card tooling, and the seam test. Each merge passed its verifier's READY, the full suite read from its log, and its seams.

**Still owed:**
- P5, the second wave, now unblocked;
- V1's two follow-ups: check-light's forced-on leg, and part 4's failing wording;
- the VALIDATION entries, 40 onward;
- the docs sweep, this file's list;
- ROUND3.md's status lines;
- archiving this ledger;
- on the card: p2-corrector, p3-identity, `check_dropin --wide`, `check_ensemble`, `mixed`, and `deep`.

For: everyone.

## 2026-11-03 — Paused for the day at the owner's word; the round resumes 2026-11-04

The owner paused work for 2026-11-03. P5 was not dispatched, and the question of sending it the night before stays open.

The state at the pause, checked:
- `main` = `origin/main` = `e47b04e`. The first wave is in: P0 to P4, each with its follow-ups.
- No round process is running on this host or on amd-arc-box, and no agent is working.
- The card is idle, and the four session-B clones on the box are clean.
- The lead's worktrees, `round3-p0-v1` (at `4291740`) and `round3-merge4` (at `e47b04e`), have no uncommitted change.

On resuming, in order:
1. Ask the owner whether to dispatch P5. Recommend that its route be opt-in until a card measures it winning; it is one flag.
2. V1's two follow-ups: a forced-on `check_dropin --light` leg in check-light, and part 4's failing wording.
3. The VALIDATION entries from 40, then the docs sweep, as this file lists it. That includes README.md:466-469 and ROUND3.md:252 and :270 for `opt_in`.
4. The card leftovers, in an owner-booked window: p2-corrector, p3-identity, `check_dropin --wide`, `check_ensemble`, `mixed`, and `deep`.

For: the lead, on resuming.

## 2026-11-06 06:40 — The round resumes. P5 dispatched from e47b04e, opt-in. The card is the lead's from 08:00 to 17:00

The owner cleared work to resume, and gave the card until 17:00, past 08:00, when its nightly run ends.

**Measured at resuming:** `main` = `origin/main` = `e47b04e`, nothing changed since the pause.

**P5 went out at about 06:30.** The open question was only whether to send it the night of 2026-11-02, and the owner's word to resume answers it. Its brief is `brief-P5.md`.
- It branches from `e47b04e`, as `round3-p5`.
- Its route is opt-in from the start, set by the lead: a route no card has measured does not go on by default.
- Its named trap: `DTB`, `RB` and the vectors built from them look like scalars with one system and are not.

**The scratchpad moved** when the session restarted. The old one is still there, but the drop is now the new scratchpad's `ledger-drop/`, and README.md says so.

**Staging.** `round3-staging-c`, in the worktree `round3-merge4`, carries three lead commits on `e47b04e`:
- `b5f31cb`: session C in `hw/cardday-round3.sh`, and `check_corrector` running one process at a time on a card. It ran four at once, which would have shared the one tile.
- `f9d2187`: V1's second note. `check_door`'s failing lines now say what they found.
- `e90d5df`: V1's first note. Both light tiers pass `check_gravity --library`, so they see M4 again.

**Session C's order is by what it decides.** `reduce_seg` is the one new route auto still turns on, and the card has never compared it with the host loop, because session B skipped `p2-corrector`. So `p2-bench` runs third, after the probe and the door on the merged tree. Its second bench is also the merged tree's default route, so it is the round's "after" beside `split-rev8a`'s "before".

For: everyone.

## 2026-11-06 07:10 — Two corrections to the 2026-11-02 entries: what "both off" is, and program_calls

**Correction to the 17:02 entry.** It said "`program_calls` does not count gravity's program runs". That is wrong; P1 measured 0 becoming 12,112 on Kepler fixed at binary64. Measured this morning at `e47b04e`: Kepler, binary64, 40 steps, gravity forced on and forced off both give calls=90138, divsqrt_calls=14847, program_calls=4080. The two routes run the same programs and differ only in who gathers their inputs, so `check_door`'s 9 counters agree. The conclusion, no seam between P1 and `ce593f7`, stands; its reason was wrong.

**Correction to how the 16:55 table reads.** "Both off" is not the gravity the port issued before P1. It is P1's new form, program runs with the host's gather. The 22-call gravity survives only as the self-test's reference. So the table compares P1's two device gathers with P1's host gather, and the lead's statement to the owner, that opt-in keeps a default card step as fast as before, undersold it and was not measured. Against `split-rev8a` at `af2f400`, the round's real "before", `d4e710b`'s both-off rows read:

| problem | format | af2f400, s | d4e710b both off, s | change |
|---|---|---|---|---|
| kepler | fp64 | 25.9 | 22.44 | -13.4% |
| kepler | fp128 | 53.1 | 44.06 | -17.0% |
| outer | fp64 | 13.0 | 11.08 | -14.8% |
| outer | fp128 | 31.0 | 22.72 | -26.7% |
| pythagorean | fp64 | 13.0 | 10.92 | -16.0% |
| pythagorean | fp128 | 24.3 | 19.39 | -20.2% |
| nbody64 | fp64 | 9.0 | 6.57 | -27.0% |
| nbody64 | fp128 | 23.8 | 15.93 | -33.1% |
| nbody256 | fp64 | 24.8 | 23.14 | -6.7% |
| nbody256 | fp128 | 50.6 | 47.45 | -6.2% |
| nbody512 | fp64 | 60.0 | 64.86 | +8.1% |
| nbody512 | fp128 | 115.4 | 118.29 | +2.5% |

One run per row, at different commits, on different days' sessions of the same bench. Believed until session C's `p2-bench` gives the merged tree's rows: the program form is worth 6-33% up to 256 bodies, and costs a few percent at 512.

The VALIDATION draft's agent found both. For: the owner, VALIDATION (entry 43), ROADMAP.

## 2026-11-06 07:15 — V1's first follow-up, shown to work: the light tiers see M4 again

`check_gravity --quick --library`, the command both light tiers now run:
- with M4 built apart: `RESULT: FAIL`, 9 ok, 1 FAIL, "check_dropin --light, gravity forced onto the new routes: rc 1, NOT every case passed; indexed=off by=forced calls=0 fallbacks=236346, pair_gather=off by=forced calls=0 fallbacks=236397";
- on the clean tree: `RESULT: PASS`, 10 ok, in 352 s.

Software times of the three gates with no card time on record, to size session C (with P5 running beside them): `check_dropin --wide` 301 s, `check_ensemble` 2,084 s, `check_corrector` 154 s with four workers.

For: the merges, the card day.

## 2026-11-06 08:02 — Session C is staged and armed behind the nightly's last stage

`~/cft-rebound-r3c` on amd-arc-box is `round3-staging-c` at `e90d5df`, built with XRT in under a minute: `e47b04e`'s engine, plus the session script, `check_corrector`'s one-at-a-time, and the two follow-ups.

At 08:00 the guard's own definition found no card user, but `hw/test-card-stress.sh --no-plants`, the nightly's, was still running under a 1,500 s timeout from 07:52. It uses stand-ins. The session waits for it to leave, at the latest about 08:18, rather than collide with the nightly's tail.

Legs, in order: probe, door-rev8a, p2-bench, p3-identity, deep, p2-corrector, ensemble, mixed, dropin-light, p1-gate, dropin-wide. `UNTIL=16:50`, `GUARD_WAIT=1800`.

For: the card day.

## 2026-11-06 09:06 — Measured on the card: the merged tree's door passes, reduce_seg is slower than the host loop on all 12 rows, and the round's before and after

Session r3c, clone at `e90d5df`, `e47b04e`'s engine, on the rev8a single tile. The probe opened all four images in 18 s.

**`door-rev8a`:** `check_door` rc 0, **77 ok, 0 FAIL**, in 766 s; "164 of 164 cases identical to the reference on both routes" at each format. The opt-in branches, right by reading until now, are measured: at binary64, "the default leaves indexed and pair_gather off by=opt_in (fallbacks 1254/1254), forced on they carry calls 1254/1254 and no fallback", "all 9 counters identical".

**`p2-bench`:** every card row of both benches is identical to software, 12 and 12. Card seconds, one run per row, so noise is not measured. `before` is `split-rev8a` at `af2f400`. `reduce_seg on` is what `main` does by default on rev8a.

| problem | format | before, s | reduce_seg off, s | reduce_seg on, s | on against off | on against before | off against before |
|---|---|---|---|---|---|---|---|
| kepler | fp64 | 25.9 | 20.93 | 21.35 | +2.0% | -17.6% | -19.2% |
| kepler | fp128 | 53.1 | 37.97 | 42.16 | +11.0% | -20.6% | -28.5% |
| outer | fp64 | 13.0 | 9.45 | 10.53 | +11.4% | -19.0% | -27.3% |
| outer | fp128 | 31.0 | 21.38 | 22.35 | +4.5% | -27.9% | -31.0% |
| pythagorean | fp64 | 13.0 | 9.52 | 10.37 | +8.9% | -20.2% | -26.8% |
| pythagorean | fp128 | 24.3 | 18.01 | 19.40 | +7.7% | -20.2% | -25.9% |
| nbody64 | fp64 | 9.0 | 6.30 | 6.48 | +2.9% | -28.0% | -30.0% |
| nbody64 | fp128 | 23.8 | 15.55 | 16.30 | +4.8% | -31.5% | -34.7% |
| nbody256 | fp64 | 24.8 | 23.38 | 24.22 | +3.6% | -2.3% | -5.7% |
| nbody256 | fp128 | 50.6 | 47.48 | 47.86 | +0.8% | -5.4% | -6.2% |
| nbody512 | fp64 | 60.0 | 62.58 | 64.36 | +2.8% | +7.3% | +4.3% |
| nbody512 | fp128 | 115.4 | 116.84 | 118.72 | +1.6% | +2.9% | +1.2% |

Measured:
- **The device's exit test is slower than the host loop on all 12 rows,** by 0.8-11.4%. `reduce_seg` is the one new route auto still turns on where a card publishes its bit, so `main`'s default takes it.
- **The round's result on a card,** against the "before": 18-32% faster up to 64 bodies, 2-5% faster at 256, 3-7% slower at 512, with the exit test on. With it off, 19-35%, 6%, and 1-4% slower. The 07:10 entry's believed reading holds on the merged tree.

Believed: P1's program form and P4's program together are that gain. No bench separates them on one commit.

**`p3-identity` stopped at once on a defect of the lead's script.** It looked for `cft_identity`, a name the field does not have. Fixed in `85fd0aa`, which also logs the words a card-written archive carries. The clone is fast-forwarded to it, which changes only the script, so the binaries stand. `~/r3-logs-r3c/STOP` ends r3c after `deep`, and session r3d runs what is left, `p3-identity` first.

For: the owner (reduce_seg's default), VALIDATION, ROADMAP.

## 2026-11-06 09:10 — Measured on the card: the deep image; and what its rows say about noise

Leg `deep`, session r3c, at `e90d5df`, default routes (so `reduce_seg` on). The probe reads `max_scratch: 8192`, `seq_features: 0x7ff1f`, the single's bits. All 6 card rows are identical to software.

| problem | format | deep, s | rev8a, `REDUCE_SEG=on`, s | difference |
|---|---|---|---|---|
| kepler | fp64 | 21.29 | 21.35 | -0.3% |
| kepler | fp128 | 42.66 | 42.16 | +1.2% |
| outer | fp64 | 9.72 | 10.53 | -7.7% |
| outer | fp128 | 22.34 | 22.35 | 0.0% |
| pythagorean | fp64 | 10.19 | 10.37 | -1.7% |
| pythagorean | fp128 | 19.56 | 19.40 | +0.8% |

Measured: the deep image neither costs nor saves anything measurable on these rows, as its header's reading expected; the port's programs use 10 to 22 slots.

**Read beside the 09:06 table.** These are two images on the same routes, so five rows within 2% and one at 7.7% is the closest thing to a noise estimate this session has. So a single row can move by several percent. The direction of `reduce_seg`'s cost, 12 rows of 12, stands. The magnitudes do not: outer fp64's +11.4% is the row the deep run questions, since deep's 9.72 s is +2.9% on rev8a's 9.45 s with the test off.

For: the owner, VALIDATION.

## 2026-11-06 09:35 — P5 reported at e98dbb1; one change before V5, which closes its limit and its finding 1

`P5.md` is placed. P5 converted 24 sites on an opt-in `scalar` route. Measured by P5:
- 93 of 93 integrations identical to `e47b04e`'s binary on all three routes, at every format.
- Its full `make check`: 19 legs, 822 ok, 0 FAIL, the digests unchanged, `check_seams` 54, 18 and 9.
- 9 of the 24 sites run on the card's configuration, `--engine program --arith fma`. There the bytes fall 0.2-0.8% at binary128 for 2 to 64 bodies.

**Its best finding.** The brief's route comparison cannot see the trap. `vrun_k()`'s fallback also broadcasts element 0, so both routes give the same wrong answer: on T1, forced on against forced off differs in 0 of 15 lines, while 8 of 15 differ from the correct engine. P5's gate holds each ensemble to its members run alone instead, and that fails T1 to T4 with every E = 1 case passing.

**The lead's change, sent back before V5.** With `vmulk()` and `vfmak()` always going through `vrun_k()`, the default route copies element 0 n times at every site, which `e47b04e` did not, and which P5 states as a limit. So the off branch becomes today's call on the prebuilt vector. That makes the default path `e47b04e`'s exactly, so an opt-in route costs nothing to have merged. And it makes the route comparison able to see the trap after all: off reads the whole vector, on reads element 0. P5 adds that as a second oracle beside the members.

For the docs sweep, P5's list: ROADMAP item 2's "~300 staged vectors a step" is 50 an attempt on the card's engine, and its 24 sites are not these 24. `KY4` and `KY5`'s only sites are in `dtnew_prs23()`, which stayed out of scope.

For the next round: 194 of 285 constant vectors are now read only at element 0 and are still `NMAX` wide; about 813 MB at N = 1024, binary64, by arithmetic, unmeasured.

For: P5, V5, the merges.

## 2026-11-06 09:58 — Measured on the card: a card-written archive says who made it, and the digest is the image file's own

Session r3d, leg `p3-identity`, clone at `85fd0aa`, `e47b04e`'s engine, rev8a single tile, in 3,111 s.
- `gate_real` at binary64, binary128 and binary256: rc 0, `gate_real: PASS` at each. That includes `identity_ok()`'s card branch, which holds the words to a 64-digit digest, written and never run until now.
- A binary128 save and resume on the card reads: `written on "libcft_build=commit=922c2ade78fad995a0871bf07cebf8b9fbcb2b9f,tracked=clean,untracked=none image_sha256=0639248e9c66f779e7c126f4449062af646d3d7e8abd0173926812790bc80450 image_bytes=40076366 image_version=0xb00`.
- `sha256sum` of the xclbin gives `0639248e9c66f779e7c126f4449062af646d3d7e8abd0173926812790bc80450`, the same digest.

For: VALIDATION (entry 42's `[CARD]`).

## 2026-11-06 10:25 — P5's 777f160 goes to V5; merge 5 is staged, and its suite runs beside V5; the rest of the card moves onto the tree that merges

`P5.md` and `report-P5.md` are placed. `777f160` makes the off route today's call, and P5 measured: a default run is `e47b04e`'s byte for byte except the `# route scalar=` line (66 integrations, 1,407 stdout lines), and T1 to T4 now fail route against route, with the members as a second oracle.

P5's three points for the lead to weigh. V5 is asked to judge each:
1. Only `check_scalar` sees the trap now, because today's route is right under it. The defect exists only with the route forced on, so that is the right trade.
2. The 09:35 "next round" note on memory no longer holds. With the route off every K vector is read whole, so none can shrink while the route is opt-in.
3. The helpers' off branch is held by the recount's text alone.

**Merge 5** on `round3-staging-c`, at `c785263`:
- `fcfe4bb`, the README;
- `c893e5a`, merging P5 at `777f160`. Two conflicts, both from staging's own commits: the Makefile's light tiers, and `check_door`'s part 4, keeping `compared()` and P5's rule that a comparison nothing carried fails;
- `c785263`, `scalar` in `check_seams`: 36 ok at binary64.

The suite runs now, beside V5. Main moves only after V5's READY.

**The card.** `~/cft-rebound-r3p5` is `c785263`. Its software rows are running at nice 19, touching no card. `~/r3-logs-r3d/STOP` ends r3d after `p2-corrector`. Session r3e then runs `p5-scalar`, `ensemble`, `mixed`, `dropin-light`, `p1-gate` and `dropin-wide` there, so the rest of the day measures the tree that merges.

For: V5, the merges, the card day.

## 2026-11-06 10:56 — Measured on the card: P2's whole gate passes on a tile

Session r3d, leg `p2-corrector`, clone at `85fd0aa`, `e47b04e`'s engine, rev8a single tile, its runs one at a time: `tools/check_corrector.py` rc 0, **277 ok, 0 FAIL, `RESULT: PASS`**, in 3,467 s. That is the count software gives. It holds the device's exit test against the host loop on every configuration, the replays, the cuts, and the run key's refusals, on a tile.

For: VALIDATION (entry 41's `[CARD]`).

## 2026-11-06 11:05 — The owner: reduce_seg becomes opt-in too. So auto takes none of the four routes

Given the 09:06 table and the 09:10 noise caveat, the owner chose "make it opt-in".

The change is on its own branch, `round3-optseg`, from `c785263`, because merge 5's suite is running in the staging worktree. It is:
- `route_def[]`'s flag and the door's comment;
- `check_door`'s `OPT_IN`;
- `cases_corrector.c`'s `expected()`;
- `check_corrector.py`: the self-test's `by=opt_in`, and a new `--library` that runs `check_dropin --light` with the route forced on, because with the route opt-in nothing else in the suite takes the device's test in the library half, and M4 would pass every tier;
- the Makefile's three `check_corrector` legs, which pass `--library` and name `check_dropin` as an input;
- the README.

`--corrector-selftest` needed nothing: it loads its image when the route is published, not when it is on.

`round3-optseg` merges after merge 5, as merge 6. It goes to a verifier first, like P1's flip. With all four routes opt-in, `auto` takes no new route on any device today. Each leaves the list when a card measures it winning.

For: V5, the merges, VALIDATION.

## 2026-11-06 11:15 — Measured on the card: the scalar route is neutral, and the first real noise figure

Session r3e, leg `p5-scalar`, clone at `c785263`, rev8a single tile, in 814 s. The software rows came from the cache, computed beforehand with no card. All 24 card rows are identical to software. `SCALAR=on` carried 106 calls and no fallback on the route check.

| problem | format | scalar off, s | scalar on, s | on against off |
|---|---|---|---|---|
| kepler | fp64 | 22.15 | 21.67 | -2.2% |
| kepler | fp128 | 42.68 | 42.33 | -0.8% |
| outer | fp64 | 9.92 | 10.45 | +5.3% |
| outer | fp128 | 21.70 | 22.12 | +1.9% |
| pythagorean | fp64 | 10.93 | 10.65 | -2.6% |
| pythagorean | fp128 | 20.50 | 18.08 | -11.8% |
| nbody64 | fp64 | 6.50 | 6.28 | -3.4% |
| nbody64 | fp128 | 16.21 | 15.89 | -2.0% |
| nbody256 | fp64 | 24.07 | 23.82 | -1.0% |
| nbody256 | fp128 | 48.44 | 47.65 | -1.6% |
| nbody512 | fp64 | 65.58 | 64.62 | -1.5% |
| nbody512 | fp128 | 118.87 | 119.28 | +0.3% |

**The noise, measured.** `SCALAR=off` here and `REDUCE_SEG=on` at 09:02 are the same route, and P5 measured the off route to be `e47b04e`'s calls. So those two benches are one configuration run twice. Row against row they differ by:
- kepler, outer and pythagorean: -5.8% to +5.7%;
- nbody64 to nbody512: -0.6% to +1.9%.

So a single row is good to about 6% on the small problems and about 2% on the n-body rows.

Measured, read with that noise: the scalar route is faster on 9 rows of 12, with a median of -1.5%, and no row moves outside the noise except pythagorean fp128's -11.8%, which that row's other runs (18.01 to 20.50 s) put down to noise. So the route neither wins nor loses measurably on a card. It stays opt-in: a route leaves the list when a card measures it winning. As ROADMAP said, it is for the memory and the honesty of having asked.

**`reduce_seg`, re-read with the same noise:** +0.8% to +4.8% on the n-body rows, above their 2%, and +2.0% to +11.4% on the small ones. 12 rows of 12 the same way. The direction is measured; "a few percent" is the fair size.

For: VALIDATION, ROADMAP item 2.

## 2026-11-06 12:30 — V5: READY on P5 (777f160). Three should-fixes back to P5; one for the next round

`verifier-report-P5.md` is placed, from V5's final message, and `V5.md`. **READY, 0 (a), 4 (b).**

V5 read all 24 sites, and an instrument in every helper held each constant uniform over the whole run. With the helpers undone, the tip disassembles to `e47b04e`'s code in both halves. Held to the base: 171 program rows, 4,272 lines, 0 differ, and 15 `gate_real` sequences. The whole `check-light` passes with the route forced on, and `check-python` too.

- **b1, for the next round.** P5's claim that the memory is blocked is wrong. A K vector is `NMAX` wide, and only `G` is read past N3. With the K vectors N3 wide, on the default route, 66 of 66 integrations are identical, and the peak falls 80.6% at N = 256 and 90-95% from N = 512 up: 1,206 MB to 97 MB at N = 1024, binary64. The library half is not built. This is the cheapest large win the round found.
- **b2, b3, b4, to P5, one small commit, with merge 6.** State the `m4_lie` limit; tighten the recount so H4, H6 and H7 fail; fix two sentences that go stale at merge 5.

The bar for merge 5 is the suite, which is still running.

For: the merges, ROADMAP.

## 2026-11-06 12:42 — Merge 6 is staged on round3-optseg, at 6b2b5f0, and goes to V5

- `eb6976a`, the lead's: `reduce_seg` opt-in, with `check_corrector --library`. Measured before the commit: M4 passes `check_door` and the default drop-in, and fails the new run; O1 fails all three.
- `6b2b5f0`, merging P5's `9335a59`: b2, b3 and b4. P5 measured H4, H6 and H7 failing with their own source, and both halves disassembling identically to `777f160`. P5 also corrected its report's memory claim on the record.

V5 re-checks both. Merge 5 lands first, on its own suite. Merge 6 then gets the docs and its own suite.

For: V5, the merges.

## 2026-11-06 13:20 — Merged and pushed: P5, V1's two follow-ups, session C's script, the README. main = origin/main = c785263

Merge 5's full `make check`, from clean at `c785263`, ran from 10:22:54 to 13:17:54, beside V5 and P5, with `make check rc=0`. The log reads:
- 19 legs, all full, with no cache skips;
- **840 ok, 0 FAIL**, no DIFFER, traceback or make error;
- 11 `RESULT: PASS`, "78 constants compared, all match", "check_dropin: every case passed", "check_dropin --wide: passed", "check_archive: all archive gates pass", `gate_real: PASS` three times, `gate_subprocess: PASS`;
- the six digests unchanged;
- forced-on library runs: "gravity forced onto the new routes: rc 0, every case passed", and "scalar=on by=forced calls=5815433 fallbacks=0";
- `check_seams`: 72 of 72 crossings, 18 of 18 replays and 9 of 9 program-engine pairs carried.

`main` was fast-forwarded to `round3-staging-c` and pushed: `e47b04e..c785263`.

For: everyone.

## 2026-11-06 13:25 — The card's last part moves to the final tree

`check_ensemble` is at binary256 after 2 h 7 min, well past its 90-minute estimate, and would crowd out what follows. So `~/r3-logs-r3e/STOP` ends r3e after it, nothing killed. `~/cft-rebound-r3f` is `round3-optseg` at `6b2b5f0`, all four routes opt-in. Session r3f then runs `door-rev8a`, `dropin-light`, `mixed`, `p1-gate` and `dropin-wide`, as `UNTIL=16:50` allows. The door comes first, a short leg, because it is the only card check of the final default. `dropin-light` comes before `mixed`, because the merged engine's drop-in on a tile decides more than the price of idle lanes.

For: the card day.

## 2026-11-06 14:30 — V5: READY on 6b2b5f0. Its follow-ups are in, the forced-on leg is on the card, and merge 6's suite runs

`V5.md` and its second report are placed: **READY on `6b2b5f0`, 0 (a), 5 (b).**

- `148bb50` closes b1 to b5: the stale text; `check_door`'s part 4 says what it now holds; `check_corrector` reads the route's state as well as its by=; both gates hold `nextstep_calls`, so 10 counters; `check_corrector`'s header states its `m4_lie`. V5 reads that diff.
- `e830230` adds `dropin-forced`. V5 caught that at this tree an unforced drop-in on a tile takes no device route, so `dropin-light` would have held the default only. That would have looked like a pass for the routes, and was not one.

Merge 6's full `make check` started at 14:25:04 on `148bb50`, from clean, with little else on the host, so its time is the first clean one since the suite grew.

**Session order on the card:** r3e ends after `check_ensemble`, nothing killed; r3f then runs `door-rev8a`, `dropin-forced`, `mixed`, `dropin-light`, `p1-gate`, `dropin-wide` at `e830230`, as `UNTIL=16:50` allows.

A `pkill -f` on the box matched its own `bash -c` and killed that shell, again. The pattern needs a bracket, `r3f-launc[h]`.

For: the merges, the card day.

## 2026-11-06 15:45 — Measured on the card: the ensemble gate passes on a tile, in 4 h 27 min; the window's last hour goes to mixed and the seam gate

Session r3e, leg `ensemble`, clone at `c785263`, rev8a single tile: `tools/check_ensemble.py` rc 0, **27 ok, 0 FAIL, `RESULT: PASS`**, in 16,005 s, against an estimate of 90 minutes (the script's later figure was 210). Last line: "outer jupiter E=3 adaptive eps=1e-9: 3 members, 504 values identical, steps_rejected=[0, 0, 0], mean_pc_iterations=20.750 pc_lane_efficiency=0.993". That closes docs/HARDWARE.md's "What to do first" item 1 and ROADMAP's first still-owed half.

It ended at 15:38, so r3f's door ends about 15:52 and 58 minutes of `UNTIL=16:50` are left. By their estimates every leg after the door is skipped: `dropin-forced` 100, `mixed` 60, `dropin-light` 80, `p1-gate` 70, `dropin-wide` 150. A drop-in run cannot be stopped between cases, and light against full is 0.27 on software, so on a card about an hour: too tight to start, since it would run into the nightly job with nothing to stop it. So `dropin-forced` and `dropin-light` do not run today.

What does fit, in session r3h, armed behind r3f:
- **`mixed`.** Priced from `docs/bench/ensemble.csv`: 64 and 512 members are 11 and 25 s on a tile and 12 and 94 s on software at binary128. So 8 card rows and 8 software rows come to under half an hour, far under the 60-minute estimate. A software dry run of the `--vscale` perturbation passed on the box.
- **`check_seams --quick`, on a tile for the first time.** It is the nearest thing to `dropin-forced` that can stop: each opt-in route forced through the library half across a checkpoint, with `carried()` asserting the route ran, and the replay and program-engine crossings. `~/r3-card/seams-bounded.py` ends it between two processes at 16:50, through `subprocess.run`, so no card process is ever killed. Stopping the Python parent instead would have left a card process writing to a closed pipe.

`hw/cardday-r3h.sh` is r3h's copy of the script, untracked in the clone, because r3f's own file must not change under a running bash.

For: VALIDATION (entry 45), the card day.

## 2026-11-06 15:53 — Measured on the card: the final tree's door passes with all four routes forced on

Session r3f, leg `door-rev8a`, clone at `e830230`, all four routes opt-in, rev8a single tile: `check_door` rc 0, **77 ok, 0 FAIL, `RESULT: PASS`**, in 780 s; "164 of 164 cases identical to the reference on both routes" at each format. At binary64: "the default leaves indexed and pair_gather and reduce_seg and scalar off by=opt_in (fallbacks 1254/1254/344/24985), forced on they carry calls 1254/1254/344/24985 and no fallback", with "3 sample lines and all 9 counters identical". The ninth-counter wording is `e830230`'s; `148bb50` adds the tenth after this ran.

As predicted, every later leg was skipped by its estimate, and r3f ended at 15:51:50. r3h started `mixed` at 15:51:55.

For: VALIDATION (entries 43 and 45).

## 2026-11-06 16:10 — Measured on the card: an ensemble beats software on a tile, and idle lanes cost nothing measurable at the spread the bench reached

Session r3h, leg `mixed`, clone at `e830230`, rev8a single tile, in 905 s against an estimate of 60 minutes. All 8 card rows are identical to software.

| members | format | together: card s, against software, lane efficiency, passes | apart: same |
|---|---|---|---|
| 64 | fp128 | 6.46, 1.82x, 0.943, 8.062 | 6.32, 1.82x, 0.940, 8.039 |
| 64 | fp256 | 14.56, 2.21x, 0.976, 18.247 | 14.68, 2.17x, 0.975, 18.180 |
| 512 | fp128 | 17.77, 4.74x, 0.910, 8.056 | 17.06, 4.84x, 0.907, 7.887 |
| 512 | fp256 | 50.10, 4.75x, 0.966, 18.258 | 49.25, 4.78x, 0.940, 17.633 |

Measured: "apart" moved lane efficiency by at most 2.6 points and card seconds by -4.0% to +0.8%. Idle lanes are 2.4-9.3% of lane-passes.

Not measured: the spread docs/HARDWARE.md's item 4 names, 10 and 23 passes in one step. This perturbation over 20 steps moved the mean by at most 0.6 of a pass, so item 4 is half closed.

`check_seams --quick` started at 16:07:00. A `--regrow` process takes over 35 s on a tile, so believed: it needs about 40 minutes, which fills the window.

For: VALIDATION (entry 45), ROADMAP, HARDWARE.

## 2026-11-06 16:40 — Measured on the card: the seam gate passes on a tile, complete

Session r3h, leg `seams`, clone at `e830230`, rev8a single tile: `tools/check_seams.py --quick`, binary64, rc 0, **36 ok, 0 FAIL, `RESULT: PASS`**, in 1,823 s. It finished at 16:37:23, before its 16:50 deadline, so the wrapper never stopped it. "24 of 24 route crossings of a checkpoint", "6 of 6 replays", "3 of 3 program-engine pairs" carried by the forced routes on both sides. Plain sequence at binary64: `reduce_seg` 248 calls at the save and 482 fallbacks at the resume, `indexed` and `pair_gather` 928 and 1,807, `scalar` 19,012 and 37,093, each "17 values identical to the straight run; CFT_REBOUND_NO_ADOPT differs, so the comparison bites". So each opt-in route, forced through the library half, crosses a checkpoint on a tile, and a card-recorded schedule replays over them.

`check_seams` forces one route at a time. With 12 minutes left, `~/r3-card/r3i-launch.sh` runs `gate_real --fp64` once with all four forced on at once, at 16:38:50. It took 6 min 47 s unforced this morning, and its digests are the suite's if the routes hold.

For: VALIDATION (entry 45).

## 2026-11-06 16:47 — Measured on the card: all four routes forced on at once give the default's digests; the card is free

`~/r3-card/r3i-launch.sh`, clone at `e830230`, rev8a single tile, `CFT_REBOUND_ROUTE_{SCALAR,INDEXED,REDUCE_SEG,PAIR_GATHER}=on`:
- `gate_real --fp64 --straight --routes`: rc 0, `scalar` 56,105 calls, `indexed` 2,735, `pair_gather` 2,735, `reduce_seg` 730, each by=forced with no fallback;
- `gate_real --fp64`: rc 0, `gate_real: PASS`, in 6 min 46 s, against 6 min 47 s unforced. All 8 digests equal r3d's default on this tile, `e08541bc0af9b3ec` and `56bacf3bf63f19a7` among them.

That is the nearest a tile came today to `dropin-forced`: the library half with all four routes on at once, over a real integration, against the default's bits.

Ended at 16:46:15, and no card process is left. **Session C is over. Not run on a tile:** `dropin-forced`, `dropin-light`, `dropin-wide`, `p1-gate`, and `check_seams` above binary64.

For: VALIDATION (entry 45), the owner.

## 2026-11-06 17:03 — Merge 6's suite is green, read from its log; the tip runs the light tiers

Merge 6's full `make check`, from clean at `148bb50`, ran from 14:25:04 to 17:01:25, **2 h 36 min**, with `make check rc=0` and little else on the host: the first near-clean time since the suite grew. The log reads:
- 19 legs, all full, with no cache skips;
- **841 ok, 0 FAIL**, no DIFFER, traceback or make error;
- 11 `RESULT: PASS`, "78 constants compared, all match", "check_dropin: every case passed", "check_dropin --wide: passed", "check_archive: all archive gates pass", `gate_real: PASS` three times, `gate_subprocess: PASS`;
- the six digests unchanged;
- forced-on library runs: "5 cases carried 574 maxima" on the device's exit test, `indexed` 236,346 calls and `pair_gather` 236,397, and `scalar` 5,815,433;
- `check_seams`: 72 of 72 crossings, 18 of 18 replays and 9 of 9 program-engine pairs carried.

V5's two comment fixes are applied: `check_door`'s part 4 says what it holds, and `check_corrector`'s header says ten counters. So are the two cosmetic ones, and `hw/cardday-round3.sh` gains `seams`, with `mixed` and `ensemble` at their measured times. Comments and that script only, since `148bb50`. `make check-light` and `make check-quick`, each from clean, now run on that tree, for the time and as the last check before it lands.

For: the merges, CLAUDE.md and README's timing lines.

## 2026-11-06 17:35 — Correction: the round's before and after mixed two timers; on one, 21-36%, about 8%, and +0.2% to +2.6%

A read-only check of the new docs against the raw logs found this, and the lead confirmed it from the CSVs.

**The 07:10 and 09:06 tables are wrong by their "before" column.** It is `wall_seconds` from `r3-logs-r3a/split-rev8a/decompose.csv`, the program's own clock. Every other column is `seconds` from `workload.csv`, the parent's clock around the process, which is 0.6 to 1.2 s more. On `seconds` throughout, against `af2f400`, with the exit test off:

| problem | format | before, s | after, s | change |
|---|---|---|---|---|
| kepler | fp64 | 26.57 | 20.93 | -21.2% |
| kepler | fp128 | 53.87 | 37.97 | -29.5% |
| outer | fp64 | 13.66 | 9.45 | -30.8% |
| outer | fp128 | 31.78 | 21.38 | -32.7% |
| pythagorean | fp64 | 13.82 | 9.52 | -31.1% |
| pythagorean | fp128 | 24.96 | 18.01 | -27.8% |
| nbody64 | fp64 | 9.66 | 6.30 | -34.8% |
| nbody64 | fp128 | 24.45 | 15.55 | -36.4% |
| nbody256 | fp64 | 25.57 | 23.38 | -8.6% |
| nbody256 | fp128 | 51.33 | 47.48 | -7.5% |
| nbody512 | fp64 | 61.00 | 62.58 | +2.6% |
| nbody512 | fp128 | 116.56 | 116.84 | +0.2% |

So 21-36% up to 64 bodies, about 8% at 256, and +0.2% to +2.6% at 512, where the lead told the owner 19-35%, 6%, and 1-4% slower. `d4e710b`'s both-off rows, on the same timer: -15% to -35%, -8% to -10%, +1.5% to +6.3%. The direction of every row stands. The owner is told.

**The same check found, and the lead confirmed and fixed in the docs:**
- "the largest single cost from 256 bodies up" holds inside gravity only: `t_elem` is larger at binary64;
- "a few percent" for `reduce_seg`: kepler fp128's +11.0% repeats, four test-on runs at 42.16-42.68 s against one off at 37.97 s;
- "about 6% and 2%" is what two runs differ by; four alike span up to 13.4% and 3.5%;
- entry 45's first draft said no tile had met REBOUND since the engine changed. `gate_real` does at binary64, and printed "the resume is REBOUND's own ias15" twice under all four forced;
- the 8 forced digests are now compared with software's in merge 6's log, all equal. The morning's default had `reduce_seg` on;
- the not-run list lacked `check_scalar`, `check_program_engine` at a merged tree, and `gate_real` above binary64 after `85fd0aa`;
- at 512 bodies the buckets do say where the gain goes: at binary64 `t_elem` 39.24 to 31.47, `t_program` 0.21 to 6.52, `t_divsqrt` 19.26 to 22.20 on the same 268 calls. Calls a step rise about 6.4x from 256 to 512 bodies, on 4x the pairs. Why is not measured, and it is the next round's lead;
- legs ran 0.15x to 3x their logged estimates, with 13 of 22 under, not "1.1 to 4 times".

**V5's read of `148bb50`, which the 14:30 entry got ahead of.** That entry says `148bb50` closes b1 to b5. V5 measured: 4 of 5 closed, b2 not, and b1 with one new stale line; neither touches code or a gate. b3: O2 now fails `check_corrector` with 1 FAIL. b4: the `nextstep_calls` sabotage fails, 35 and 2 FAIL. b5 closed. Clean tree: `check_corrector --quick` 187 ok, `check_door --formats fp64` 50 ok. `148bb50`'s engine is `6b2b5f0`'s with comments and whitespace out. Both comment fixes are in the 17:03 entry's tree.

For: the owner, VALIDATION, ROADMAP.

## 2026-11-06 17:50 — Correction to the 17:35 entry: "calls a step rise 6.4x" is an artifact, and a row at 256 bodies and up is not a step. The card is the weekend run's

**The owner:** the card is now on the weekend run; the box may be read and otherwise used, only the card is busy. Nothing of this session has touched the card since 16:46.

**The docs check's second pass found its own first pass wrong, and the 17:35 entry with it.** `energy_all()` runs at each sample, inside the timed loop (`src/ias15_cft.c`, the `while (1)` in `main()`), and sums with one width-one `vadd` a body and one `vsub` a pair. A bench row samples twice. So 2(P+N) calls a row are the energy: 65,792 of 68,584 at 256 bodies, and 262,656 of 264,517 at 512. What is left is 558 and 620 calls a step, 1.1x. The 6.4x was 4x the pairs times 5/3, the two rows' step counts. It is not the next round's lead.

At those rows' 112-119 us a call, about 7.4 s of the 256 rows and 31 s of the 512 rows is energy, in both columns: 33% and 51% of the binary64 rows, 16% and 27% of the binary128 ones. Estimated, with that cost on both sides:

| row | format | step before, s | step after, s | change | divide and square root, before | after |
|---|---|---|---|---|---|---|
| nbody256 | fp64 | 17.36 | 15.20 | -12.4% | 54% | 74% |
| nbody256 | fp128 | 43.20 | 39.31 | -9.0% | 60% | 74% |
| nbody512 | fp64 | 28.77 | 30.34 | +5.5% | 67% | 73% |
| nbody512 | fp128 | 84.44 | 84.76 | +0.4% | 67% | 73% |

So the shares quoted at 17:35 were of the row, and the first-pass claim that `t_elem` is larger at binary64 tested the wrong quantity. Inside a step the divide and square root are the largest cost, as the docs first said. The next round's lead is what it was: the divide and square root, about 73% of a step.

The same pass: `seams` ran 6.1x its placeholder estimate, so the range in 17:35 lacks it; the 13.4% and 3.5% spans are set by `SCALAR=on`'s rows alone, the route under test, and without them 8.3% and 1.9%; `decompose.csv` has a third clock, its `seconds`, the trailer's CPU `clock()`; -15.53% rounds to -16%. All fixed in the docs.

**New, unmeasured until now: the software backend got slower on the small problems.** The second pass noted software rows rising 1.5-2.2x between `af2f400` and `e90d5df`. On this desktop, best of 3, beside `make check-quick`, 4291740 against c785263: kepler 200 steps, program engine, 1.08 to 1.42 s at binary64 and 2.50 to 3.42 s at binary128; REBOUND's form 2.78 to 3.19 s. `t_program` rises and `t_elem` barely falls. `af2f400` is building beside the tip, to time the round's whole effect on software on one host.

For: VALIDATION, ROADMAP, the owner.

## 2026-11-06 19:25 — The light tiers pass from clean on the tree that lands; the software backend's cost, measured

`make check-light`, from clean with its build, 17:02:32 to 17:33:41, 31 min: rc 0, 19 legs, 550 ok, 0 FAIL, 11 `RESULT: PASS`. `make check-quick`, from clean, 17:33:41 to 18:15:59, 42 min, beside the `af2f400` build and the first timing: rc 0, the same counts. Warm, 13 s. CLAUDE.md, README and the Makefile now quote these and `make check`'s 2 h 36 min.

**The software backend, `af2f400` against the tip, this desktop, nothing else running after 18:16, best of 5 and of 3 from 64 bodies up:**

| problem | REBOUND's form, fp64 | fp128 | program fma, fp64 | fp128 |
|---|---|---|---|---|
| kepler | 2.44 to 2.94 s, +20.5% | 7.55 to 9.03 s, +19.7% | 0.98 to 1.38 s, +39.7% | 2.41 to 3.31 s, +37.7% |
| outer | 3.11 to 3.64 s, +17.0% | 11.30 to 12.78 s, +13.1% | 1.47 to 1.91 s, +29.9% | 4.28 to 5.41 s, +26.3% |
| pythagorean | 1.56 to 1.86 s, +19.0% | 4.64 to 5.34 s, +15.1% | 0.69 to 0.92 s, +34.1% | 1.62 to 2.16 s, +32.7% |
| nbody64 | 17.52 to 18.70 s, +6.8% | 56.12 to 56.45 s, +0.6% | 12.48 to 13.50 s, +8.1% | 41.48 to 42.34 s, +2.1% |
| nbody256 | 61.36 to 62.91 s, +2.5% | 166.12 to 161.47 s, -2.8% | 57.09 to 59.88 s, +4.9% | 153.64 to 157.67 s, +2.6% |

`swtime2.py`'s "records DIFFER" column is a defect of that script: a stripped `#` line leaves one more blank line at the tip. `sample` lines diffed directly on Kepler at three settings: 0 differ.

This has been on main since merge 4. Merge 6 does not change it, so it does not hold the landing. It goes to the owner, entry 45, and ROADMAP's next-round list as item 2.

For: the owner, VALIDATION, ROADMAP.

## 2026-11-06 19:35 — Merged and pushed: merge 6, the round's records. main = origin/main = 9e9879f. Round 3 is finished

`main` was fast-forwarded to `round3-optseg` and pushed: `c785263..9e9879f`. Its bar: V5's READY on `6b2b5f0` and its read of `148bb50`; `make check` at `148bb50`, 841 ok, 0 FAIL, read from its log; `check_seams` in that suite; `make check-light` and `make check-quick` from clean on the tree, 550 ok each; comment lines only in `tools/` since `148bb50`.

**Main holds** P0 to P5, each with its follow-ups, all four routes opt-in, and entries 39 to 45.

**Open, on ROADMAP's next-round list:** the K vectors; what the program form costs on software; the divide and square root; timing a step apart from `energy_all()`; the end-of-step update; residency; the wide clock across a body-count change; the drop-in's refusal path; the identity in two places; and what the card did not reach (entry 45): `dropin-forced`, `dropin-light`, `dropin-wide`, `p1-gate`, `check_scalar` and `check_program_engine` at a merged tree, and `check_seams` above binary64. `~/cft-rebound-r3f` on the box is the tree for those.

The merge and push delegation was for round 3, and ends here.

This ledger goes to `archive/round3-ledger.zip`.

For: everyone.
