# P5's reports on round3-p5, placed verbatim by the lead (2026-11-06)

## Report 1 of 2

Branch `round3-p5`, tip `e98dbb1b57042f9cb5fc629f51cd44e101d5e4e2`, ledger entries in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P5.md`.

**P5 is finished: the base was e47b04e as briefed, the full `make check` passes, and no record line moved.** The most important finding is that comparing the two routes cannot see the trap, so the gate rests on a different oracle.

## What changed
- **`src/ias15_cft.c`**
  - `scalar`'s `opt_in` flag is set, and `vrun_k()`'s `DOOR_UNUSED` is off.
  - New helpers `vmulk()` and `vfmak()`.
  - 24 sites converted, with three door comments updated.
  - `energy_all()`'s local `halfb` is gone.
- **`tools/check_door.py`**
  - `scalar` is in `OPT_IN`.
  - A comparison that nothing carried now fails, instead of saying "vacuous".
  - Part 4b now forces each published opt-in route. It used to skip all of them if any was unpublished, which by reading would have cost `door-f128s` the scalar comparison that leg exists for. Measured on an emulation of that image: scalar is still compared (24,985 calls).
- **`tools/check_scalar.py`** (new): the gate, one line in each tier, `--library` in all three.
- **`tools/cases_scalar.c`** (new): the library case.
- **Expected small edits:** `CASES_SRC` and `IN_SCALAR` in the `Makefile`, `tools/check_dropin.c`, `tools/dropin_cases.h`.

## Site count per engine
These come from the gate's recount of the source. There are 24 sites in all. Call counts are per corrector pass, step attempt, prediction and energy evaluation.

| run | sites | pass | attempt | prediction | energy |
|---|---|---|---|---|---|
| `--engine loop --arith rebound` | 11 | 133 | 21 | 21 | 3 |
| `--engine loop --arith fma` | 15 | 98 | 50 | 21 | 3 |
| **`--engine program --arith fma` (the card)** | **9** | 0 | 50 | 0 | 3 |
| library half, REBOUND's form | 12 | 133 (+105 with a velocity-dependent force) | 21 | 21 | 0 |

- **Left as they are:**
  - 9 divides: `cft_div` is not an opcode and takes no mask.
  - 14 sites in `dtnew_*()` and `choose_timestep()`, as the brief ordered.
  - 2 E-wide compares: `vcmplt()` counts no staged bytes, so `vrun_k()` would move today's route.
- **Bytes on the card's configuration (measured, not a speed claim):** at binary128 the fall is 0.2-0.8% of `staged_bytes` for 2 to 64 bodies, against 2.8-7.4% on `--engine loop --arith fma`.

## Gate output (the full leg: 90 ok, 0 FAIL, 8 min 7 s)
```
ok   24 sites: every site is a row of the gate's table, each scalar a constant and never its own result, and no constant left on a call that could take it (44 constants; per system, so never a scalar: DTB, DTDB, RB; 10 sites' results alias their vector operand, which cft_run allows)
ok   kepler e=0.99, rejections that predict: the same record, schedule and counters on all three routes; 40 steps, 11 rejected, 51 attempts, 1470 passes; 11 rejected attempts predicted; the route carried 2559 calls and staged_bytes fell by 408096, both as derived
ok   kepler spread x5, steps that differ and a mixed attempt: the same record, schedule and counters on all three routes; 60 steps, 4 rejected, 61 attempts, 1241 passes; the systems' steps differ at 3 of 3 samples (0.0600094 to 9.73214 at the widest), rejected [1, 1, 1, 1, 0]; 5 of 5 systems equal themselves run alone, forced on; the route carried 3062 cal… [cut in my extract]
ok   check_dropin --light, forced onto the new route: rc 0, every case passed; scalar=on by=forced calls=5815433 fallbacks=0
ok   fp256: 17 dump lines identical, wide 4270b7a92d53b15e; on calls=55811 fallbacks=0, off calls=0 fallbacks=55811 (rc 0/0)
```
The second and third lines are binary256 on `--engine program --arith fma`.

**A/B against e47b04e's binary (measured):** 93 of 93 integrations are identical on all three routes at every format, covering all four adaptive modes, `--cs augmented`, softening and min-dt. `staged_bytes` matches on default and forced off, and forced on moves nothing else.

## Full `make check`
- **Log:** `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P5\check.log`
- **Run:** `make clean` then `make check` at the tip, launched through PowerShell's Start-Process with the script path as the only argument, 07:35:36 to 09:23:43, `make check rc=0`. My controls and the lead's card work ran beside it, so 1 h 48 is not a clean time.
- **From the log:** 19 legs, all full, no cache skips. **822 ok, 0 FAIL**, no DIFFER, traceback or make error, 11 `RESULT: PASS`.
- The six `gate_real` digests are unchanged, and `check_seams` carried 54 of 54, 18 of 18 and 9 of 9.

## Controls
Each sabotage was built apart; the sabotaged binaries are deleted. Controls ran from an engine that differs from the tip by one comment. The scripts remain beside the log as `sab.py` and `ctl.py`.

| property | sabotage | with it | without it |
|---|---|---|---|
| The trap | T1: `DTDB` as a scalar at 21 sites, `KD`'s 21 handed back so every count holds | 24 ok, 6 FAIL: only the two adaptive ensembles, on all 3 engine combinations. Every E=1 case passes, 0 route or derivation lines. All formats: 68 ok, 18 FAIL | 90 ok |
| The trap | T2 `DTB`, T3 `D1B`, T4 `RB`'s powers, same way | 2, 2 and 4 FAIL, E=1 all passing | 90 ok |
| `staged_bytes` derived | T5: `DTDB` at one site, not count-neutral | 28 FAIL, E=1 included: "17290 on, 17290 off, and the sites derive 17250" | the same line reads 17250, "both as derived" |
| `staged_bytes` derived | R1: `KC`'s site out; R2: the energy `G` site out | 19 and 28 FAIL. On two bodies P-1 is 0, so R2 moves no bytes and only the count sees it | as above |
| `staged_bytes` derived | R3: the new route counts today's bytes | 27 FAIL: "fell by 0, and the sites derive 689664" | as above |
| The route's policy | O1: auto takes it; O2: on while saying opt_in; O3: forced on ignored; O4: counters swapped | `check_scalar` 27, 27, 27, 28 FAIL; `check_door` 3, 3, 2, 4 FAIL | both pass |
| Library half (P1's M4) | M4a: runs today's route while saying on; M4b: opens off by=opt_in | unforced 170 ok, 0 FAIL; forced on 7 FAIL. The real leg fails on its suite line and its `gate_real` line | passes forced on, off and hidden |
| Library sites | L1: a `predict_velocities()` site out | every REBOUND case passes; 2 FAIL: "added 4284 calls, and 68 passes of 105 are 7140" | 170 ok |
| Read-once rule | A1: a site's result is its own scalar | the recount names it, `correct:1636` | no such site |

## Not done, and stated limits
- **Not done:**
  - No card, no speed claims.
  - No Linux run, no `check-python`.
  - `check_dropin --wide` not run forced on; `gate_real` covers the wide formats there.
  - `hw/` and `check_seams.py` untouched.
- **Seam dry run for the merge (scratch copy):**
  - `check_seams --quick` with `scalar` in `ROUTES` gives rc 0, 36 ok, at binary64.
  - Schedules replayed across the route: 36 of 36 identical, at all three formats.
- **Limit: shared defects.** The gate's runs cannot see a defect that both routes, E=1 and the members all share. Measured with a wrong mask on the `G` site: the runs pass (30 ok), the recount names it, and `check_equivalence` fails it.
- **Limit: library FMA form.** It is held by its call counts only, because the engine opens once a process.
- **Limit: the recount.** It reads only the wrappers it names, so a site behind a new wrapper would not be seen.
- **Limit: default route cost.** It is no longer exactly e47b04e's: `vrun_k()` copies n elements into scratch at every call, inside `t_elem`. Bits and bytes are unchanged, and only a card can say whether the copy shows.
- **Not taken: memory.** 194 of 285 constant vectors are now read at element 0 alone but are still `NMAX` wide. By arithmetic, unmeasured, that is about 813 MB at N=1024 binary64, against a 1,118 MB peak. It needs `make_constants()`, which is outside my files.

## What the brief or ROUND3.md got wrong
1. **The first gate bullet cannot see the trap.** `vrun_k()`'s fallback also broadcasts element 0, so both routes give the same wrong answer. On T1, forced on against forced off differs in 0 of 15 lines, while 8 of 15 differ from the correct engine, at every format. The gate instead holds each ensemble to its members run alone. `check_ensemble` misses T3; `check_program_engine` catches it.
2. **`KY4` and `KY5` are listed, but their only sites are in `dtnew_prs23()`, which the brief forbids.** With `KY3` that is 5 sites, 17 calls an attempt, on the card's engine too. `K5040` is not a site: it only runs at n = 1.
3. **"Must pass every E = 1 case" holds only for a count-neutral sabotage.** A plain one fails E=1 on the derived count (T5).
4. **"That is one flag" is four edits:** the flag, `OPT_IN`, `expected()` in `tools/cases_scalar.c`, and `want_default` in `tools/check_scalar.py`. O1 is that flip without the other three: `check_scalar` and `check_door` fail it by name, and `expected()` is written to.
5. **ROADMAP's "~300 staged vectors a step"** is 50 an attempt on the card's engine, and its 24 sites are not these 24.

## For the merge and the docs sweep
- **Conflicts with `round3-staging-c`, by read-only trial merge, both trivial:**
  - `Makefile`: keep both adjacent lines.
  - `tools/check_door.py`: take your `compared()`, and re-add `carried > 0` and the VACUOUS suffix in part 4.
- **Docs sweep:** `README.md:466-469`, ROADMAP item 2, `ROUND3.md:252` and `:294-295`, `docs/HARDWARE.md:365-370`.
- **Ledger:** the 07:06 entry's `check_ensemble` claim was wrong and is corrected by two appended entries. The times on those two (08:03, 08:06) are a few minutes ahead of the clock.

## Report 2 of 2

Branch `round3-p5`, tip `777f160f439ae91ed5b39a4d6dbb1125e18fe9ad`, one commit on `e98dbb1`, ledger entries in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P5.md`.

**The change is in, and both of your predictions held. The default run is e47b04e's byte for byte except the `# route scalar=` line, and T1 to T4 now fail route against route.** It also has two consequences you should weigh, under "New" below.

## The commit
- **As you specified:** `vmulk()` and `vfmak()` take today's call with the route off, counting one fallback.
- **One step beyond your instruction:** `energy_all()`'s three sites called `vrun_k()` directly, so with those two helpers alone `G` and `K0` would still copy on the default route. They now go through two new helpers, `vkmul()` and `vaddk()`, and `halfb` is back. All 24 sites take today's call when off.
- **`tools/check_scalar.py`:**
  - The route comparison is now a stated oracle beside the members.
  - The recount fails if a helper loses its off branch or a site calls `vrun_k()` directly.
- **Stale text fixed:** `vmulk()`'s comment, the door comment, the gate's header, `tools/cases_scalar.c`'s header, and the reason printed for the two compares.

## Is the default run byte-for-byte e47b04e's in its counters?
**Yes.** I compared 66 integrations at three formats, 1,407 stdout lines, whole stdout with only the wall-clock fields removed. Default and forced off each differ from e47b04e in one line a run: `# route scalar=`. `staged_bytes` and every counter are equal.

In code, each site gains one branch and one counter increment; the call and the vector are e47b04e's. With `vrun_k()`'s fallback made to abort, every default and forced-off run still completes (H2), so that fallback is now reached only by `--door-selftest`.

## The lines
```
check_scalar, every format, --library: 90 ok, 0 FAIL, RESULT: PASS
check_door, every format: 80 ok, 0 FAIL, RESULT: PASS
make check-light from clean at 777f160: rc=0, 19 legs, 542 ok, 0 FAIL, 11 RESULT: PASS, no DIFFER or traceback
ok   kepler spread x5, steps that differ and a mixed attempt: the same record, schedule and counters on all three routes; 60 steps, 4 rejected, 61 attempts, 1241 passes; the systems' steps differ at 3 of 3 samples (0.0600094 to 9.73214 at the widest), rejected [1, 1, 1, 1, 0]; the two oracles: forced on equals forced off, and 5 of 5 systems equal themselves run alone, forced on; the route carried 3062 cal… [cut in my extract]
ok   check_dropin --light, forced onto the new route: rc 0, every case passed; scalar=on by=forced calls=5815433 fallbacks=0
```
The spread line is binary256, `--engine program --arith fma`. Accounting: `calls=` and the fall match the derivation on every case at every format. The full `make check` was not re-run, as you said; its 822 ok was at e98dbb1.

## T1 to T4 against both oracles
`check_scalar --quick`, count-neutral sabotages, the gate's source unsabotaged. Every E=1 case passes in all four, and so does the fixed-step ensemble.

| sabotage | lines where the routes differ | members |
|---|---|---|
| T1 `DTDB` | 6 of 6 (all 3 engine combinations) | 1 of 5 and 1 of 3 systems equal themselves |
| T2 `DTB` | 2 of 2 (loop, rebound) | 1 of 3; spread dies by flag abort on the new route alone |
| T3 `D1B` | 2 of 2 (loop, fma) | 1 of 3; spread dies the same way |
| T4 `RB`'s powers | 4 of 4 (loop, both forms) | 1 of 5 and 1 of 3 |

- **T1 at every format:** 68 ok, 18 FAIL, and all 18 name both oracles: "forced on DIFFERS FROM forced off, and 1 of 5 systems".
- **H1 (helpers back through `vrun_k()`):** the runs alone pass (30 ok); only the recount catches it.
- **H3 (T1 on top of H1):** the routes see 0 lines and the members still fail it, which is what the off branch buys.
- **The other controls:** T5, R1-R3, O1-O3, M4a, M4b and L1 give the same results as before. O4 is now 5 FAIL in `check_door` instead of 4, because its sabotage moved into the helpers.
- **Seam dry run at the tip:** 36 of 36 replays across the route; `check_seams` with `scalar` in `ROUTES` gives 36 ok.

## What changed in my limits
**Closed:**
- The default route's host copy.
- Finding 1 (the routes could not see the trap). Both held at e98dbb1 and no longer hold.

**Narrowed:**
- A wrong mask is now on one route, so the routes catch it (X1: 28 FAIL).
- What both routes still share is a site given the wrong constant (X2): no route or member line. Four cases fail only incidentally, on a lost rejection and a flag abort, and `check_equivalence` catches it directly.

**New, for you to weigh:**
1. **Only `check_scalar` sees the trap now.** `check_ensemble` and `check_program_engine` pass T1 to T4, because today's route is right under this defect. I think that's the right trade, since the defect then exists only with the route forced on, but the trap now has a single gate.
2. **The memory half is now blocked, and your 09:35 "for the next round" note no longer holds.** With the route off, every K vector is read whole, so none of the 194 can shrink while the route is opt-in. Taking that memory needs the route on by default, or the copy back.
3. **The helper branch is held only by text.** H1 shows no run can tell, so only the recount holds it.

**Unchanged:** the library FMA form is held by its counts only; the recount reads only the wrappers it names.

## Notes
- **Merge conflicts:** expect the same two with `round3-staging-c`, in `Makefile` and `tools/check_door.py`, with the same resolution as before; this commit touches neither file.
- **Controls:** the sabotaged binaries are deleted. `sab.py`, `ctl.py` and `rebuild.sh` beside the logs rebuild them.
- **Ledger:** the new entry states which earlier ones this supersedes.

Logs:
- `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P5\check-light2.log`
- `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P5\final.log`
- `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P5\ab3.log`
- `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P5\ctl2-trap.log`

