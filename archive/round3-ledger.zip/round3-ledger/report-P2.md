# P2's final report, placed verbatim by the lead (2026-11-02, about 09:40)

**Branch `round3-p2`, tip `0b5e17e` (one commit on `af2f400`).** Ledger entries went to the drop, `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P2.md`, plus `urgent-P2-replay-control.md` and `urgent-P2-correction.md`. The lead has placed them.

## What changed, file by file

**`src/ias15_cft.c`**
- **`pc_error()` (:1381), the device route.** Each maximum (over normal values, from +0) is now cft-fp256's `normalabs-<fmt>` program followed by `CFT_MAXALL` through `vreduce_seg()`, which is `cft_reduce_seg` where the device publishes CAPS2[8].
  - Today's host loop is the fallback.
  - All four modes take it. INDIVIDUAL's divide runs first on both routes, and the pair reads its quotients.
  - Each maximum counts as one `reduce_seg` operation: as `calls=` on the device route, as `fallbacks=` on today's.
  - Each maximum costs two library calls on either route. The `normalabs` run is timed in `t_elem` and not counted in `program_calls`, so neither `calls=` nor `program_calls=` depends on the route.
- **`vreduce_seg()` (:649)** loses `DOOR_UNUSED`.
- **The image is loaded at open** by `corrector_open()` (:1465), called from `main()` (:3411) and `ias15_engine_open()` (:3649). A device that publishes the bit but refuses the image is refused by name.
- **Both `pc_error` call sites (:1317, :1582)** are skipped on a replay.
- **The exit test inside `step_attempt()` (:2289).**
  - On a replay, `sched_pass()` stands in for the test, and a cap the recording hit is counted in `iterations_max_exceeded`.
  - When recording, the cap is noted.
  - The schedule helpers (`sched_line`, `sched_begin`, `sched_pass`, `sched_end`) sit at :2143-2246.
- **`main()`**
  - Parses `--record-iters`, `--replay-iters` and `--corrector-selftest`.
  - Refuses both schedule flags together, and `--trace-pc` with a replay.
  - Writes a run-key line into each schedule (`sched_key`, :3259) and refuses a schedule from any other run.
  - Refuses a schedule that is cut short, too long, or holds a malformed field, a wrong system or an impossible count.
- **`--corrector-selftest` (:3132)** holds `pc_error()` on both routes against a reference built from REBOUND's definition with libcft's own calls. It uses 11 crafted systems (one set per property) plus 53 random ones, and prints the loaded image's `cft_program_digest`.

**Other files**
- **`src/cft_embedded_image.h`** (new): byte-identical to the lead's block, SHA-256 `4f8dfa60…`.
- **`tools/embed_programs.py`** (new): the lead's interface. It is my stand-in for P1's generator, which replaces it at merge.
- **`tools/check_corrector.py`** (new): the gate.
- **`tools/cases_corrector.c`** (new): the library-path case, reading `ias15_engine_route()`. It is a step-count case, scaled under `--light`.
- **`tools/dropin_cases.h`, `tools/check_dropin.c`**: one line each.
- **`Makefile`**
  - The `$(B)/normalabs_images.h` rule, built from the pinned `.cfta` files by the pinned `cft-asm`.
  - The three compile rules gain the header as a prerequisite and `-I$(B)`; the program's rule also gains `-Isrc`.
  - `CASES_SRC`, `IN_CORRECTOR`, and one `check_corrector` line in each of `check`, `check-quick` and `check-light`.

**How a second family uses the mechanism.** It adds its own rule, `embed_programs.py --asm $(ASM) --name <family> --out $(B)/<family>_images.h <its .cfta>`, plus its header as a prerequisite on the same three rules. It looks up `<family>_images[]` by format, and its own gate checks the image with `cft_program_digest`.

## The gate's output (from the full `make check`; actual lines)
```
ok   8 of 8 mode-and-route results equal the reference in every system, bits and flags (rc 0)
ok   the data holds every class, as libcft classifies it: normal 368, +0 62, -0 65, subnormal 83, infinite 100, NaN 90, and 18 of 64 systems out of the corrector
ok   the image the engine loaded, normalabs-fp256.cftp, is the pinned tree's: sha256 a6c9f6b5ccebff81, and its MANIFEST says a6c9f6b5ccebff81
ok   route lines: reduce_seg on ('on', 'forced', 208, 0), off ('off', 'forced', 0, 208); wanted 208 maxima (104 passes x 2) as calls, then as fallbacks
ok   it computed no test: reduce_seg carried nothing; divsqrt_calls 87 fewer (87 passes x 1); calls 495 fewer (wanted 495: 3 a pass, and two compares at each of 117 tests); flags 0x11 within 0x11
ok   fp256: the replays crossed 4 runs with a rejected step, 4 with a capped attempt (each counted as iterations_max_exceeded), 1 ensembles whose systems left at different passes, 1 with some members rejecting and some not
ok   attempt 1's 22 passes moved +1: the replay ran them, mean_pc_iterations 22.846 (wanted 22.846; the recording's 22.769), and 0 of 4 record lines differ
ok   the first attempt's 60c passes cut to 1: 3 of 4 record lines differ
```
- The routes were compared on every problem in `data/problems/` in all four modes at fp64, and on a set of problems at fp128 and fp256 (measured).
- `check_door`'s forced-off comparison is now live and passes at all three formats. Its line reads "…all 8 counters identical; forced-off run reports every route off by=forced", where P0's log added "(vacuous for now…)".
- In the library path (`check_dropin`, full), all 5 cases were bit for bit REBOUND's ias15, and each read "reduce_seg=on by=device carried this case's 261…696 maxima on the device route, and no fallback".
- **A/B against `af2f400`'s binary: 87 of 87 integrations identical** at all three formats. That covers every record line, every counter including `calls=` and `program_calls=`, and each system's trailer. The A/B's own control saw 2 of 3 lines differ.
- `check-python` reported `IDENTICAL: 13 values`, and its control `DIFFERS: 9 of 13`.

## The full `make check`
- The log is `…\scratchpad\P2\check-full.log` (my leg alone: `check-full-corrector.log`), run at `0b5e17e`.
- **16 legs, all in full mode; 531 `ok`; 0 FAIL.** The only skip is the deliberate `body_count` one.
- The six `gate_real` wide-state digests equal P0's (`e08541bc…`, `56bacf3b…`, `5d7cf458…`, `cd16e6dc…`, `a1052750…`, `ba4d447c…`).
- My leg: 243 `ok`, 0 FAIL.
- It took about 80 minutes under load.
- `check-light` (`check-light1.log`): 16 legs, 394 `ok`, 0 FAIL.

## Controls
All are measured at `0b5e17e` through the full gate. Logs are in `…\P2\sab\<name>\gate.log`, and `sabotage.py` rebuilds each sabotage. Their artifacts were deleted afterwards. **Without any sabotage, the gate gives 243 `ok` and 0 FAIL.**

| control | property | sabotage | with the sabotage |
|---|---|---|---|
| Replay drives the run | a replay runs the recorded counts | S0: the replay ignores its counts and runs the test | **59 FAIL at every format**: `mean_pc_iterations 3.656 (wanted 3.672)`; the first attempt cut to 1 changes 0 lines; "computed no test" fails |
| +0 identity | no normal coordinate gives +0 | S1a: masked lanes become −0; S1b: they become −inf | 6 FAIL each: the self-test fails at all three formats on the crafted "no normal coordinate" systems (`-inf where the reference is inf`), plus the image digest |
| normal-only | subnormals are masked | S2: the exponent-zero test is dropped | 6 FAIL: `0x1.3028p-1027 where the reference is 0x0p+0` on the "only subnormal or zero" systems, plus the digest |
| 1/1 | a system that has left the corrector is given 1/1 | S3: the device branch's 1/1 is removed; S3b: INDIVIDUAL's shared lane 1/1 is removed | 3 FAIL each, at the self-test on the "left the corrector" systems (`nan where the reference is 0x1p+0`); S3b fails on both routes |
| (extra) the cap counter | a replay counts a recorded cap | S4: the prototype's bug | 14 FAIL: replays with `iterations_max_exceeded=0` |
| (extra) the unit | the schedule is per step attempt | S5: keyed on accepted steps | 47 FAIL: replays are refused ("the schedule ends after 60 step attempts…") |
| (extra) the counter | `program_calls` does not move | S6: the normalabs run counts as a program call | 50 FAIL |

**Measured: S1a, S1b, S2, S3 and S3b each left all 237-240 integration-level checks passing.** Records, counters and replays cannot see these three properties: they are inert by construction there, which is why the self-test exists.

## What I did not do, and the stated limits
- **No speed claims.** I touched no card and no amd-arc-box.
- **I did not exploit the corrector's confirming pass.** The replay runs exactly the recorded counts.
- **Limit: a replay's `flags_seen` can be narrower than its recording's.** It does not raise flags that only the test raises. Measured: Kepler, fixed step, INDIVIDUAL, `0x10` within `0x11`. The gate asserts the replay's flags are within the recording's.
- **Limit: a device that publishes CAPS2[8] but refuses the image** is refused at open, not fallen back. That path is unreachable on software, because every format the port runs is embedded, so it is unexercised.
- **Limit: INDIVIDUAL's data movement stays host work on both routes**, as it is today. These are the `tmp`/`at` copies and the 1/1 lanes of a system out of the corrector. No per-coordinate test work remains, so the stop line was not reached.
- **Limit: a schedule names its run but not the backend or the library build.** That way a software recording replays on a card.
- **Limit: the library half's route is fixed per process.** The drop-in case asserts whichever route its process opened. Its fallback is the same `pc_error()` code that the program's forced-off runs hold.
- **Boundary crossings, declared:**
  - a third program flag, `--corrector-selftest`;
  - one call in `ias15_engine_open()`;
  - the three compile rules, which the lead approved.
- **For the merge:**
  - P2 adds no row to `trailer_keys[]`.
  - My header makes `make all` run the `cft-asm` sub-make, so P3's `-j` race reaches `make -j all`. P1's `$(ASM): $(CFTLIB)` fixes that for both branches; mine does not carry the line.
  - P0's comments at :166-167 and :470-475 are now stale for `reduce_seg`.

## What the brief and ROUND3.md got wrong
1. **"The library half takes the device route like everything else."** At `af2f400` it had no program loader at all. Images now compile in, through the mechanism the lead adopted.
2. **The replay control "one count changed by one" is inert on most attempts.**
   - 0 of 122 moves in the first 8 attempts of 8 configurations changed a record.
   - It does bite sometimes: 4 of 60 moves at fp128 (Kepler, 30 steps).
   - The lead accepted my replacements: the first attempt cut to one pass, a capped count refused by name, and the replay's own counters moving by exactly the change.
3. **My own first claim was wrong, and I corrected it.** I said an attempt's last pass changes no record bit. Removing every last pass did change one fp128 record. The lead withdrew the claim.
4. **ROADMAP's "its four anchors still exist" is wrong.** The prototype has seven anchors, and three are gone at `af2f400`.
5. **"If the pair cannot express INDIVIDUAL's divide…"**: it can, because the divide comes first on both routes.
6. **The three property controls cannot bite through records**, so a third flag was needed for the self-test.
