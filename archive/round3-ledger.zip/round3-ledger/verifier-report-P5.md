# V5's report on P5 (777f160), placed by the lead (2026-11-06, about 12:25)

READY, 0 (a) findings, 4 (b). V5 verified 777f160 on a clean build. Ledger entries are in the drop, as V5.md, placed.

The code holds. No converted operand is per-system, the default path is `e47b04e`'s, and P5's numbers reproduce. Of its three "new" points, the second is wrong.

## (a) findings that block the merge
None.

## (b) findings that should be fixed but need not block

**b1. P5's second new point is wrong: the memory half is not blocked.**
- **Defect:** report 2 and P5.md's 09:47 entry say every K vector is read whole with the route off, so none can shrink without the route on or the copy back.
- **Why it fails:** a K vector is `NMAX` wide, and NMAX = max(N3, P). Only `G` is read at P; every other constant is read at N3, NB, E or 1. So from N = 8 up a site reads N3 of NMAX elements.
- **Evidence (measured):** a variant with the K vectors N3 wide, route untouched, run on the default route.
```
66 same, 0 DIFFER, with every line of the record and staged_bytes
N=1024 fp64: rc 0/0; tip 1206 MB, K vectors N3 wide 97 MB, fall 1109 MB (92.0%); records the same
N=1024 fp256: rc 0/0; tip 4682 MB, K vectors N3 wide 249 MB, fall 4433 MB (94.7%); records the same
```
- The fall is 80.6% at N = 256 binary64, and 90-95% from N = 512 up. The variant also passes `check_scalar --quick` (30 ok) and `check_door` (50 ok).
- 13 of the 194 run at n = 1 on either route, so they could be one element today.
- **Believed:** one-element vectors would free only about 7 MB more at N = 1024 binary64. The library half needs `valloc()`'s `cap_elems` floor kept off these vectors; not built.
- **Property:** a claim stated as fact and false when measured. The lead's 09:35 note stands in a better form, and memory is no reason to turn the route on.

**b2. A route that says on and is not passes every tier, and P5 does not state that limit.**
- **Defect:** `m4_lie_both` has `vrun_k()`'s on branch run today's `cft_run`, still counting `route_calls` and tallying one element. `cft_run_ex` is never called for a scalar. `m4_lie_lib` does this in the library half alone.
- **Evidence:** for each, `check_scalar.py --quick --library` gives rc 0, 32 ok, 0 FAIL, `RESULT: PASS`, and `check_door --formats fp64` gives 50 ok.
- **Property:** `staged_bytes` is the door's own tally, not anything libcft reports. P5's M4a fails only because it leaves the fallback counter honest. This is P1's `m4_lie`, which P1 stated as a limit after V1; P5 does not.
- **Fix:** one sentence in `tools/check_scalar.py`'s header and in VALIDATION.
- **Believed:** a `--door-refuse` case on a reserved mask bit would catch the program half. The library half stays a limit.

**b3. The recount's hold on the off branch is thinner than "fails if a helper loses its off branch".** Each of these passes the whole gate with its own source: `check_scalar --quick --source`, 30 ok, `RESULT: PASS`.
- **H4:** each off branch keeps its shape and calls `vmul(d, a, copy_k(1, k, n), n)`. The regex at `tools/check_scalar.py:268` accepts any arguments.
- **H6:** a broadcast in a statement before the `if`. Nothing reads the body outside the branch.
- **H7:** one of KH's three sites through `vrun_k` behind a macro. The gate prints `ok   23 sites`; the count and each row's site count are never asserted.
- **H5 (T1 on top of H4):** the routes see 0 lines, and only the members fail it. So H4 silently removes one of the two oracles.
- **Property:** "the default path is today's call" has no gate in these forms. Only cost and an oracle are at stake, never bits.
- **Fix:** match the exact arguments and the two-statement body, and hold per-row site counts.
- **Believed:** counting `vrun_k`'s own fallback apart would hold H1 and H7 by a run.

**b4. Two sentences go stale at merge 5.** `src/ias15_cft.c:598` ("Only that gate can see this") and `tools/check_scalar.py:70-72` ("Nothing else in the suite can see it"). Evidence is under point 6.1 below.

## The six aims

**1. The trap: clean.** All 24 sites read. Every scalar is `kderived`/`kint` output (KHF, KNUM, KH and H, KRINV, KC, KBIN, KVNUM, KD, K0), a one-element quotient broadcast to NMAX (KHALF, KPOSR, KVELR), `halfb` broadcast each call, or `G` broadcast whole. A scan finds no write to any of them after they are built. `DTB`, `DTDB`, `RB`, `D1B` and `D2B` are only ever vector operands. Measured at run time: an instrument in every helper asserted the constant is one value over the whole run. Under `check_scalar --quick --library` it gave 32 ok. Its control, T1 under the instrument, died: `vmulk: the constant differs at lane 6 of 30`.

**2. The default path: holds.** With the helpers undone in the tip's source it disassembles to `e47b04e`'s code in both halves, every object section equal; a control with one wrong index differs. Whole-stdout A/B against `e47b04e`: 0 differ beyond `# route scalar=`.

**3. Derived `staged_bytes`.** Independent of the sites and of the tally's arithmetic: T5 and R1-R3 fail. Not independent of whether the tally is true: one defect fools both (b2). `SITES`' multiplicities are typed; the recount's counts only print.

**4. The library half.** M4a, M4b and M4c (V1's form) pass unforced `check_dropin` at 170 ok, and fail the `check_scalar` leg with 30 ok, 9 FAIL. By real `make` on M4b, `check-light` stops at Makefile:712 and `check-quick` at Makefile:680, which are that leg. The full tier was held by the leg's own command, not by `make check`: 86 ok, 11 FAIL, with `gate_real` failing at all three formats. The form that fakes the counter passes every tier (b2).

**5. The recount, what it misses.**

| defect | recount | runs |
|---|---|---|
| macro wrapper (W1, H7) | not seen | W1: 6 FAIL. H7: pass |
| new function wrapper (W2) | seen: `vscale:2779: vmulk passes q as a scalar` | 6 FAIL |
| off-branch operands (H4), statements before it (H6) | not seen | pass |
| reassigned alias (W3) | not seen | 3 FAIL |
| write to a K vector (W4) | not seen | 6 FAIL |
| constant's index (X2) | not seen | 4 incidental FAIL; `check_equivalence` 6 FAIL |
| `vrun_k`'s body (b2) | not seen | pass |

**6. P5's three points.**
1. Right at 777f160, and the trade is right. T1 to T4 and T3b pass `check_ensemble` and `check_program_engine`, and T1 passes `check_door`. On c785263 it no longer holds, since parts 2 and 3 force `scalar` on an adaptive ensemble. Staging's `check_seams --quick` is 36 ok clean, and fails T1 (3 FAIL), T2 (2) and T4 (2). T3 passes it, so T3 still has only `check_scalar`.
2. Wrong (b1).
3. Right, and the text hold is thinner than it reads (b3).

## Notes
- **Ownership:** every hunk is in scope. Declared crossings are `vkmul`/`vaddk`, `check_door` part 4b and `IN_SCALAR`. The forbidden files are untouched.
- **Reproduced exactly:** 24 sites, per-engine counts 11/15/9/12, 9/14/2 left, the card byte falls (0.22-0.82%, 2.76-7.36%), `calls=5815433`, `wide 4270b7a92d53b15e`.
- **Stale count:** report 1's "10 sites alias" reads 11 at the tip.
- **Gate logic, both fail closed:** `#ifdef`'d braces derail `functions()`, so M4a's source exits with "no make_constants()". `consts` is not minus `per_system`.
- **Moot:** P5's merge-conflict note, since staging already carries 777f160.
- **Ledger:** V5's two entries' times run about two minutes ahead, and a third corrects the first's headline. It holds from N = 512 up.

## What V5 ran
Everything ran beside the lead's suite, so times are not clean.

| run | window | result |
|---|---|---|
| clean build + `check-light` | 10:20-10:52 | rc 0, 19 legs, 542 ok, 0 FAIL, 11 `RESULT: PASS` |
| `check_scalar --library`, every format | 10:52-11:10 | 90 ok, 0 FAIL |
| `check_door`, every format | to 11:17 | 80 ok, 0 FAIL |
| whole `check-light`, route forced on | 11:17-12:00 | rc 0, 542 ok, 0 FAIL |
| `check_dropin`, forced on, full steps | to 12:15 | 170 ok, `calls=16596777` |
| `check_dropin --wide`, forced on | after that | passed |
| `check-python`, default and forced on | after that | IDENTICAL, 13 values; control DIFFERS |

**Held to the base.** Program: 171 rows, 19 setups x 3 engine/form pairs x 3 formats; 165 compared and 6 refused alike, 4 runs each; 4,272 lines, 0 differ, and forced on equal to forced off. Library: 15 `gate_real` sequences, 1,284 lines, 0 differ. `--probe`, `--dump-constants` and `--corrector-selftest` identical; `--door-selftest` differs in one line. A/B control: X2's binary gives 38 DIFFER of 55 rows. Random comparison: 102 runs of 14 ensembles and nbody 9, 33 and 64, at two formats on all three pairs: forced on equals forced off and the ensembles' members equal themselves; 66 runs had systems' steps differing.

**P5's controls, reproduced:** T1 6 FAIL, every format 68 ok, 18 FAIL, all naming both oracles; T2, T3, T4 2, 2, 4 FAIL; T5, R1, R2, R3 27, 18, 27, 27 FAIL; O1-O4 `check_scalar` 27, 27, 27, 28, `check_door` 3, 3, 2, 5; L1 2 FAIL; A1 recount names `correct:1662`; X1 27 FAIL plus the recount; H1 runs 30 ok, recount fails it; H2 30 ok, `check_door` dies rc 3; H3 6 FAIL, routes 0 lines, members fail it; E1 scalar compared, 24985 calls.

**V5's own sabotages.** Passed the gate: `m4_lie_lib`, `m4_lie_both`, H4, H6, H7. Caught: T3b, M4c, W1 to W4, H5, and U2, the instrument's control.

## What V5 did not check
- The card, amd-arc-box and Linux.
- `make check`, either at the tip or on M4.
- The library FMA form across the routes (P5's stated limit).
- The memory variant in the library half.
- The uniformity instrument above binary64.
- The merged tree beyond `check_seams.py` at c785263.

# V5's second report, on 6b2b5f0 (reduce_seg opt-in, and P5's 9335a59), condensed by the lead (2026-11-06, about 14:30)

READY on 6b2b5f0, 0 (a), 5 (b).

**`eb6976a`.** M4 and O1 reproduce. O3, and `calls=`, `program_calls=` and `divsqrt_calls=` moving only forced on, each fail `check_corrector` and `check_door`. O2 fails `check_door` (3) and `check_dropin` (5), and passed `check_corrector`. `nextstep_calls` and `staged_bytes` moving only forced on passed both. Held against `c785263`: 171 rows, 7 runs a row, 165 compared, 6 refused alike, 0 differ, 4,272 lines a run. The tip's default equals `c785263` forced off in every line, `staged_bytes` included, except `by=opt_in` for `by=forced`. All four forced on equals the default in records and counters. `staged_bytes` on the default falls by exactly ESZ x (N3 + E) per maximum against `c785263`'s default, in all 165 rows. The self-test and the replay do not change: six recordings a row from both builds and every route state are byte-identical.

**`9335a59`.** H4, H6 and H7 fail; the clean tree passes; comment-only, measured by disassembly and every object section.

**(b):** b1 stale text; b2 `check_door` part 4 inert with every route opt-in; b3 `check_corrector` read by= and not the state; b4 `nextstep_calls` and this route's `staged_bytes` have no gate; b5 `reduce_seg`'s own `m4_lie` passes and no limit is stated.

**Time-bound:** at this tree an unforced `check_dropin` on a tile takes none of the four routes, so `dropin-light` would hold the default and no device route. On software, all four forced on gives 170 ok.

Ran: clean `make check-light`, 19 legs, 550 ok, 0 FAIL; `check_door` every format 80 ok; `check_corrector --library` every format 278 ok; `check_scalar --library` every format 90 ok; `make check-light` with all four forced on, 550 ok, 0 FAIL.
