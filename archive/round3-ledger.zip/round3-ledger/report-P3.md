# P3's final report, placed verbatim by the lead (2026-11-02, about 10:20)

**Branch `round3-p3`, tip `3861a7b`.** My nine ledger entries are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P3.md`, and you have placed all nine in `.ledger\P3.md`. The one escalation is `urgent-P3-accessor-and-name.md` in the same drop.

P3 is done. A checkpoint now resumes bit for bit at binary128 and binary256, adaptive runs included. The archive records the library build and the image, and says when an older archive's clock and steps came from binary64. The full `make check` passes. Nothing is pushed or merged.

All figures below are measured unless marked "believed".

## Commits on the branch
- **`d492c32`**: your accessor (`9b1744ea`), cherry-picked as you instructed. It is the only change to `src/ias15_cft.c` and `src/ias15_engine.h`.
- **`a8d7a63`**: the gate alone, so it can be watched failing on the unfixed tree.
- **`3861a7b`**: the fix and the rest of the gates.

## What changed, file by file
- **`src/cft_ias15.h`**
  - Appended members: `t`, `t_hi`, `t_lo`, `dt`, `dt_last` (one wide element each) sharing `clock_bytes`, which counts bytes; and `identity` with `identity_bytes`.
  - New value `CFT_PROV_EXACT_CLOCK_STEPS64`.
  - The `provenance` comments now say it records how the state was restored, and that it is not cft-fp256's Provenance. The name stays, on disk and in C, as you decided.
- **`src/cft_ias15_fields.h` / `.c`**
  - A byte-field macro `CFT_FD_B` (`element_size` 1), so the length comes back right through the binary64 list without the `n_elem` repair.
  - The clock and identity families go last, before `cft_n_elem`. `CFT_OFF_APPENDED_2026_11_02` marks where the appended members start.
  - All counts are now derived from their lists. Before, they were literals checked by the self-test.
  - The new value's string.
- **`src/cft_archive.h`**: a declared crossing (it is not on my list, but `cft_archive.c` needs it). It gains `CFT_ARCHIVE_EXACT_CLOCK_STEPS64`, the probe's clock and identity fields, and `cft_archive_state_clock()`.
- **`src/cft_archive.c`**
  - A new NOTE 6.
  - The self-test gains the two families, a check that appended fields follow every older one, and the clock walker.
  - The probe and its overlay read the clock and identity.
  - `finish_load()` treats the clock as optional, but whole and at the format's width when present, and checks that it reached memory. With no clock it returns the new status.
- **`src/reb_integrator_cft.c`**
  - `publish_state()` publishes the clock, the steps and the identity. The identity is the record's `# identity` words; measured byte-identical to the program's line, 101 bytes.
  - `adopt_loaded_state()` adopts each wide value only where its binary64 view still equals REBOUND's `r->t`, `r->dt` or `r->dt_last_done`. That matches the step guard, and `reb_simulation_integrate()` rewrites `r->dt` and zeroes `r->dt_last_done`.
  - New controls `CFT_REBOUND_NO_CLOCK` and `CFT_REBOUND_NO_STEP`.
  - A declared crossing: `cft_ias15_free()`'s never-bound branch frees the loader-allocated new members.
- **`tests/gate_real.c`**
  - Every comparison includes the engine's clock and steps as bytes. `wide_digest()` is unchanged, so the six recorded digests stay comparable.
  - New: sequence 4 (adaptive, epsilon 1e-9, with a counter asserting dt moved off 0.01) and sequence 5 (`integrate()` to 0.3 then 0.6, and an `r->t` edit, each across a checkpoint).
  - New flags for the sweep: `--epsilon`, `--dump-from`, `--save-each`, `--old-list`.
  - Also checked:
    - the identity;
    - provenance on both load paths;
    - an old-format archive, loaded and appended to.
- **`tests/gate_restart.c`, `tests/gate_promote.c`**: the stub (not mine) keeps no clock, so its archives load as "restored exactly, its clock and steps from binary64", and the gates assert that.
- **`tools/check_checkpoint.py`**
  - New sequences: `old` and `adaptive`.
  - The 2-of-40 sweep, with its setup written into the case: gate_real's four bodies, fixed dt 0.01, checkpoint after s = 1..40 steps, then 40 more.
  - Each control is required only where it can bite.
  - `--quick` skips the sweep by name.
- **`tools/check_archive.py`**: its docstring records the compatibility measurements and the one stated limit.

## The gate's output
Before the fix (`a8d7a63` on the unfixed tree), `RESULT: FAIL`:
```
fp64   splits   FAIL  35 of 40 resumes DIFFER (r->t differs on 0 [], the clock or steps on 35, other lines on 0)
fp128  splits   FAIL  34 of 40 resumes DIFFER (r->t differs on 2 [29, 30], the clock or steps on 34, other lines on 0)
fp256  splits   FAIL  34 of 40 resumes DIFFER (r->t differs on 2 [29, 30], the clock or steps on 34, other lines on 0)
fp128  adaptive FAIL  the continued run DIFFERS - line 5: straight 'p1 x  0x1.ef3d04630a0acp-1 0x1.1181227b2e8f4p-2 0x0p+0', resumed '... 0x1.1181227b2e8f5p-2 ...'
```
The differing bytes:
- **Binary128 and binary256:** only t and t_hi differ, below binary64's reach. At split 30, binary128: `3ffe6666666666666880000000000000` against `...6600000000000000`, which shows as r->t `0x1.6666666666667p-1` against `...666p-1`. t_lo is +0 in both.
- **Binary64:** only t_lo differs, because a resume zeroes it.

After the fix (`make check`):
```
fp64   splits   PASS  40 of 40 resumes identical (r->t differs on 0 [], the clock or steps on 0, other lines on 0); with CFT_REBOUND_NO_CLOCK, 35 of 40 differ: r->t on 0 [], the clock or steps on 35
fp128  splits   PASS  40 of 40 resumes identical (...); with CFT_REBOUND_NO_CLOCK, 34 of 40 differ: r->t on 2 [29, 30], the clock or steps on 34
fp256  splits   PASS  40 of 40 resumes identical (...); with CFT_REBOUND_NO_CLOCK, 34 of 40 differ: r->t on 2 [29, 30], the clock or steps on 34
fp128  adaptive PASS  17 values identical, CFT_REBOUND_NO_ADOPT and CFT_REBOUND_NO_CLOCK and CFT_REBOUND_NO_STEP differ
fp64   old archive load: restored exactly, its clock and steps from binary64, state says "restored exactly, its clock and steps from binary64"
fp64   archive: clock and steps 5/5 at 8 bytes, identity "libcft_build=commit=922c2ade78fad995a0871bf07cebf8b9fbcb2b9f,tracked=clean,untracked=none image=none"
```
The six `gate_real` digests are unchanged: `e08541bc0af9b3ec`/`56bacf3bf63f19a7`, `5d7cf4588fad050e`/`cd16e6dc29aa0589`, `a1052750e206bebe`/`ba4d447c8e58bd20`.

## Full `make check`
- **Log:** `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P3\make-check.log`
- **Result:** rc 0, 15 legs, 0 FAIL lines, 306 lines matching my `ok` pattern. The only skip is the deliberate `body_count`. All 15 `check_checkpoint` rows pass.
- **Time:** 08:33 to 10:12, on a host shared with two other parcels' suites. The `check_checkpoint` leg took 28 minutes of that.
- **Light tier:** `make check-light` also passed: 15 legs, 0 FAIL.

## Controls
- **The named control** ("with the new field's load removed, the 2-of-40 case fails again").
  - Property: the sweep sees a clock that was not restored.
  - Sabotage, in two forms: `CFT_REBOUND_NO_CLOCK` (permanent, in the suite), and a scratch copy with the clock's load replaced by `if (0)`, deleted after the run.
  - With it: binary128 and binary256 each show "34 of 40 resumes DIFFER (r->t differs on 2 [29, 30])"; binary64 shows 35 of 40.
  - Without it: 40 of 40 identical at every format.
- **`CFT_REBOUND_NO_STEP`**.
  - Property: the adaptive steps are restored.
  - With it: binary128's wide digest is `85173733207ae8fd` straight against `7bebb83a206f476b` restarted.
  - Binary64 passes even with it, because dt is binary64 there; the control is required only at the wide formats.
  - Without it: identical.
- **Nine more sabotages**, all caught:
  - dt written without its broadcast;
  - the clock not published;
  - the identity missing;
  - the identity claiming an image;
  - a clockless load saying "restored exactly", caught by gate_real and gate_restart;
  - the probe ignoring clock fields that only an appended snapshot carries;
  - the `r->t` check dropped;
  - the `r->dt` check dropped;
  - the steps' load removed in source.

## Not done, and stated limits
- **An older build reading a new archive.** Measured: af2f400 loads all 9 test archives and calls them "restored exactly". REBOUND prints `Error! Could not find field descriptor for name.` and `Warning! Unknown field found in binary file.`. That build gets only what it always got: the clock and steps from binary64, so its adaptive resumes diverge above binary64. I added no workaround, as you asked.
- **Old archives in this build.** Measured: they load, 6 of 6, and say so. Each resumes exactly as a new archive does with the clock's and steps' loads removed, and differs from the straight run only in the clock.
  - `--old-list` archives match af2f400's field for field, except for four fields: `walltime`, `walltime_last_steps`, `rand_seed`, and the pointer bytes in `particles`. Two separate af2f400 runs differ in exactly those four too.
- **The card branch of the identity check** (an xclbin must yield a 64-digit image digest) is written but not run, since no card. That is your session B's.
  - Its `gate_real` grew by about 330 steps a format. At the per-call cost gate_real's own comment assumes, that is about 2 more minutes a format on a card (believed).
- **The identity is formatted in two places**: the program's `main()` and the shim. Their equality was measured once, not gated; gating it would need a Makefile change outside my list.
- **A particle add or remove truncates the wide clock and steps to binary64** in every run. This is pre-existing and you have filed it.
- **Suite cost.** The full-tier checkpoint leg now takes 28 minutes on this host. If that is too much, running the sweep's control at one format would roughly halve it.

## What the brief or ROUND3.md got wrong
1. The restore field already exists, as `provenance` (`7fbbd1f`, 2026-09-11). The "still owed" lines in ROADMAP, PARCELS and ROUND3 are stale.
2. The clock alone was not enough above binary64: an adaptive step keeps dt and dt_last wide too. That is why your accessor was needed.
3. The 2-of-40 setup was never recorded. The natural guess, 180 steps split at 1..40, gives 0 of 40. s = 1..40 with 40 steps after gives exactly 2 of 40, at both formats.
4. A rename was not cheap: every archive since 2026-09-11 carries `cft_provenance`.
5. The counts were literals checked by the self-test, not derived. They are derived now, and `README.md`:203-207 is stale.
6. `src/cft_archive.h` is missing from my file list.
7. ROADMAP's "tolerates strangers" needs the qualifier the measurement above gives.
8. Entry 38's cross-pin check compared `gate_real`'s dumps, not archives, and a dump carries no identity. Nothing needed excluding there; anything that compares whole archives must leave `cft_identity` out.
9. ROADMAP's "only its clock differs" is false through `reb_simulation_integrate()`. There the clock sets the last, shortened step, so the trajectory moves too. Measured: with only the clock's load removed, binary128's wide state is `aef452b28324dcc0` against `79f1ba5270547e09`.

For your end-of-round sweep, the integrator-only files that should change:
- ROADMAP's "the wide clock" section can close;
- the stale `provenance` lines (item 1);
- `README.md`:203-207 (item 5);
- the "tolerates strangers" qualifier (item 7);
- a VALIDATION entry for this work.
