Lead: compiled-in program images — one type, one generator interface, fixed now so P1's and P2's fold at merge without edits
For: P1 and P2. P1.md's 07:14 entry is placed in the ledger now.

P1 takes option B, `build/gravity_images.h` from `tools/embed_programs.py`,
for a sound reason: the `indexed` row is shared with `vrun_ix()`, so a
program-only route would leave the library half reading `on by=device`
while gravity ran elementwise. So you both generate a header, and at
merge both land in one translation unit. That breaks two ways unless
fixed now: two generators, and two definitions of the table's type.

1. **The type is defined once**, in a new checked-in file,
   `src/cft_embedded_image.h`. Both of you add it with exactly this
   content, byte for byte, so the merge sees one file. Nothing else goes
   in it.

```c
/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright 2026 the cft-rebound contributors.
 *
 * A sequencer program image compiled into the binary, for the library
 * half, which loads nothing from disk. Each family's table is generated
 * into build/ by tools/embed_programs.py and includes this header; the
 * type is defined here once, so that two families can share one
 * translation unit. */
#ifndef CFT_EMBEDDED_IMAGE_H
#define CFT_EMBEDDED_IMAGE_H
#include <stddef.h>
struct cft_embedded_image {
    const char *stem;            /* the .cfta's name before -<format> */
    const char *format;          /* fp32, fp64, fp128 or fp256 */
    const unsigned char *bytes;  /* the assembled image */
    size_t length;
};
#endif
```

2. **The generator is `tools/embed_programs.py`**, and its interface is:

       $(PYTHON) tools/embed_programs.py --asm <cft-asm> --name <family> --out <header> <stem>-<fmt>.cfta ...

   - It assembles each file with the given cft-asm.
   - It writes `<header>` only when the bytes it would write differ from
     what is already there. That is P1's reason: `make programs` rewrites
     every `programs/*.cfta` on each suite run, and on Windows a relink
     changes the engine's bytes, so `check-quick` could never skip.
   - The header includes `"cft_embedded_image.h"`.
   - It defines `static const struct cft_embedded_image <family>_images[]`
     and `static const size_t <family>_images_n`. Every other symbol it
     defines begins with `<family>_`.
   - **P1 owns it.** P2 writes one of the same name and interface in its
     own tree, as small as it can be. At merge the lead keeps P1's, so
     P2's Makefile rule needs no edit.

3. **The families** are `gravity` (P1) and `normalabs` (P2). Their headers
   are `build/gravity_images.h` and `build/normalabs_images.h`.

Each image is still checked against its own source of truth by its own
parcel: P1's against `programs/out/`, and P2's against the pinned
MANIFEST.

If either of you has already built something this contradicts, say what
in the drop rather than reworking it silently. If conforming would cost
more than an hour, say so, and the lead folds it at merge instead.
