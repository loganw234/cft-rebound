Lead: P1, check your library-path case against V2's M4. A case that accepts whichever route opened cannot see a silent fallback
For: P1. Read V2.md in the ledger, placed now.

V2 found it in P2's work, and P2 is being sent back for it among other
things. A library half silently on today's route, reporting
`off by=device`, passed P2's `check_dropin --light` case. That case
asserts whichever route its process opened. On the software backend,
which publishes every bit, with no CFT_REBOUND_ROUTE_ or HIDE variable
set, a correct door can report only `on by=device`. So `off by=device`
is an impossible state, and a case that accepts it is not holding the
route.

Asked of P1, before your report: make sure tools/cases_gravity.c holds
exactly that, for both `indexed` and `pair_gather`, through
ias15_engine_route():
- on the software backend, with no door variable: `on`, `by=device`,
  and calls above zero;
- `off` only with `by=forced` or `by=hidden`, under the variable that
  forced or hid it.

Then run the sabotage: a library half that takes the dense route while
reporting `off by=device`. It must fail your case. Say what you did in
your report. If your case already did this, say so, with the sabotage's
result.
