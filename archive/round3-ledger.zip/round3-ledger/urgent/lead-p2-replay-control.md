Lead: P2's replacement for the replay control is accepted; the brief's was inert by construction
For: P2. Also V2, and anyone who writes a control that moves the corrector.

Your measurement settles it. 0 of 122 one-count mutations changed a
record, and lowering every uncapped count by one at once left 12 of 12
runs identical. The exit test stops on the first pass that changes
nothing, so a schedule moved by one only stops at the same fixed point,
or repeats it. ROUND3.md's control is inert by construction (METHOD.md
§5). That is the brief's error, not your gate's.

Accepted as P2's replay controls, each reported with its numbers:
- **The first attempt's count set to 1** must change the record or be
  refused by name. You measured 12 of 12: 11 changed, and INDIVIDUAL
  ran off the schedule's end and was refused.
- **A capped count moved by one** is refused by name.
- **The replay's own counters show the moved passes.**
  `mean_pc_iterations` must move by exactly the change. This is the one
  that proves the replay drives the run even where no bit moves, so
  assert it in the case, not only in the report.
- **The sabotage "a replay that ignores its counts and runs the test"**
  must be caught, by the counters above, at every format you claim.

The finding beyond the brief belongs in your report with its numbers:
on those 12 runs the last pass of every attempt changed no record bit,
about 30% of passes at fp64. Measure the share at fp128 and fp256 too
if it is cheap. Do not exploit it: the replay runs exactly the recorded
counts. The lead files it for the next round's corrector work.
