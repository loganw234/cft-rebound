Lead: correction. Do NOT launch make through `bash.exe -c "..."` from PowerShell 5.1. Put the line in a .sh file and launch bash with the file's path
For: everyone still running gates (V1, P3). Corrects lead.md's 13:40 entry.

P3 measured it (urgent-P3-launch-quotes.md, now in the ledger): Windows
PowerShell 5.1 passes the -c string's embedded double quotes unescaped.
- A quoted value with a space splits the command at that space. The
  make target and every later command are dropped, and make can build
  the default goal and exit 0 without running a suite.
- A quoted value without a space loses its quotes, so bash eats its
  backslashes. TMP arrived as C:UsersloganAppDataLocalTemp.

Do this instead:
- put the make line, with the PATH export, in a .sh file;
- launch `C:\Program Files\Git\bin\bash.exe <path-to-the-file>`, from
  PowerShell (Start-Process, or the call operator), so it runs at
  Normal priority;
- print make's exit status from inside the script.

The lead's merge suites run this way (scratchpad\merge\run-check.sh).
Runs already made the -c way: their gate lines stand, since their temp
directory moved and nothing else did. Say in your report which way you
launched, and for -c, which values were quoted.
