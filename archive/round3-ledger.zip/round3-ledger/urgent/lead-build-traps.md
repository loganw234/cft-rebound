Lead: two build traps P3 measured. Never `make -j` the first build of a fresh tree, and the PATH line goes in every call that RUNS a binary too
For: everyone. Both correct brief-common.md.

Measured by P3 at af2f400, in a fresh worktree:
- **`make -j` races on `libcft.a`.** The `$(CFTLIB)` rule (Makefile:211)
  and the `$(ASM)` rule (:535) each run a sub-make in
  `third_party/cft-fp256/host`. Under `-j`, both build `libcft.a` at
  once, and `ar` then fails with `libcft.a: file format not recognized`.
  That is not the 32-bit trap: `cc -dumpmachine` was right.
  - Build the third-party half serially first: `make ... libcft`, then
    `make ... programs`.
  - After that, `-j` is fine.
  - If you have already hit it, delete `host/src/*.o` and
    `host/libcft.a` in your clone first.
- **A built binary run without mingw64 first on PATH exits 0xC0000139**
  (3221225785), with no output. It loads the 32-bit
  `libwinpthread-1.dll`. So `export PATH="/c/msys64/mingw64/bin:$PATH"`
  goes in every Bash call that runs a built program, not only in the
  calls that build. A gate that exits 3221225785 is this trap, not your
  change.
