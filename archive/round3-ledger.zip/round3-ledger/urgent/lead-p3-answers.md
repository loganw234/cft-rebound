Lead: P3's answers. Cherry-pick the accessor 9b1744ea; keep `provenance` on disk; measure both directions of compatibility
For: P3. Nothing here changes P1, P2 or P4.

1. **The accessor is built.** It is commit
   `9b1744ea61c9a9952caa6d459b114525e61654ce` on lead branch
   `round3-p3-accessor`, a child of af2f400. Take it with
   `git cherry-pick 9b1744ea61c9a9952caa6d459b114525e61654ce` on
   `round3-p3`. That is the lead's commit in your branch, and it is the
   only change you make to those two files.
   - `struct ias15_engine_view` gains
     `const unsigned char *dt, *dt_last`, which are SDT and SDTLAST. They
     are read only: writing them in place would leave the copy that
     every lane reads stale.
   - Write them with `ias15_engine_put_dt_wide(const unsigned char *)`,
     which is a copy plus `bcast_sys(DTB, SDT)`, and
     `ias15_engine_put_dt_last_wide(const unsigned char *)`, a copy.
   - Measured: both halves compile with no new warning, and gate_real
     passes at all three formats.

   Your adaptive gate is what tests the calls. So the adaptive case is
   in scope now: archive dt and dt_last beside the clock, and gate an
   adaptive split at binary128 and binary256. That case too must be
   watched failing first.
2. **The name: your recommendation stands.**
   - Keep `provenance` and `cft_provenance`, in C and on disk.
   - Fix the collision in the comments: say it records how this state
     was restored, and that it is not cft-fp256's certificate
     Provenance.
   - Name the new value for everything it concedes. With the accessor,
     that is the clock and both steps from binary64, not the clock
     alone.
3. **Measure compatibility in both directions; do not believe either
   reading.** ROADMAP says the Simulationarchive "tolerates strangers".
   Your reading of binarydata.c says an unknown name abandons the rest
   of the snapshot. Run both:
   - an archive written at af2f400, loaded by your build. This is the
     brief's "old archives still load". Say what it does.
   - an archive written by your build, loaded by af2f400's build. Entry
     38 measured checkpoints crossing the pin in both directions, 12 of
     12.

   If the second breaks, state it as a limit, by the behaviour it
   concedes. Do not work around it with extra names without asking.
4. **The 2-of-40 setup was never recorded.** The lead searched
   VALIDATION, ROADMAP, PARCELS and round 2's ledger; there are only the
   bare words. Use your s = 1..40 with 40 steps after each split. Record
   the exact setup in your report and in the case itself, so the next
   round can reproduce it.
5. **The stale "still owed" lines** in ROADMAP, PARCELS and ROUND3 are
   the lead's to sweep. Your report lists them, as your entry already
   does.
