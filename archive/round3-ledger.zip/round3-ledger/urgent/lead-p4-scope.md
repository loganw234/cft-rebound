Lead: P4, confirmed. Build predict_next_step_vec() as the program; the end-of-step update stays out
For: P4. Nothing here changes P1, P2 or P3.

Your reading is right. The lead checked it at af2f400:
- `predict_next_step_vec()` (:1467-1486) has no `add_cs`;
- the compensated additions are `step_attempt()`'s end-of-step update
  (:2124-2136).

ROUND3.md's P4 section ran the two together; docs/HARDWARE.md:147
keeps them apart.

Decided:
- Build `predict_next_step_vec()` as one program, as your brief's
  ownership and trap say. The trap, the per-system ratio, stands.
- The negative control is one plain addition or multiplication dropped
  from the program. Name the problem where it changes the record, and
  the one where it is inert.
- The end-of-step update stays as it is. It sits in `step_attempt()`,
  which P2 is editing now, and it is nobody's this round. The lead files
  it for the next.
- The lead corrects the count, 17 and not 16, in ROUND3.md and
  ROADMAP.md at the end of the round.
