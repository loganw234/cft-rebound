Lead: one way to compile program images into the library half; P2 builds it, and P1 uses it at merge, not a second one
For: P1 and P2. Read P2.md in the ledger first; it is placed there now.

What P2 found (P2.md, read at af2f400): the library half has no program
loader. `load_one()` and `load_programs()` are inside
`#ifndef IAS15_CFT_LIBRARY`, so a route whose new half is a program run
can run in the drop-in and the Python DLL only if the image is compiled
in. P2's answer is a generated header, `build/normalabs_images.h`.
- It is assembled from the pinned tree by the pinned cft-asm.
- It is checked against the pinned `programs/MANIFEST`'s SHA-256.
- It is compiled into both halves.
- It needs `-I$(B)` and the header as a prerequisite on the three
  compile rules of src/ias15_cft.c (Makefile:249, :265 and :320).

Decided:
- **P2:** keep that mechanism general. A list of images goes in, and
  one header comes out. Your report says how a second family of
  programs would use it. It is the round's one way to do this.
- **P1:** do not write a second generator. If your routes need your
  programs in the library half, either:
  - keep them program-only for now, and say exactly what the library
    half's `# route` lines and `ias15_engine_route()` report then. They
    must not claim a route it did not take. The lead wires your images
    in through P2's mechanism at merge, as seam work. Or:
  - if your gate cannot be honest without it, build the same shape in
    your tree, a header of your own, and say so in the drop. The lead
    folds the two together at merge.
- **Both of you:** the three Makefile compile rules will conflict
  trivially at merge. That is expected, and the lead resolves it.

Also noted, with no action needed:
- `check_door.py` part 4 holds `calls=` equal between the default run
  and the forced-off run. P1's two routes run the same program, with a
  different gather, so the counts should already agree. If a route of
  yours changes the call count, say so and why, rather than bending the
  count to match.
- P1's reading is that entry 37's f128 image publishes `0xf1f`: the
  scalar bit, but not indexed or reduce_seg. The card session already
  runs the parcels' routes on rev8a (seq_features `0x7ff1f`). Its probe
  leg will measure both images.
