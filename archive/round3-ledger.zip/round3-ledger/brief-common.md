# Round 3: what every parcel's brief shares

*The lead, at dispatch, 2026-11-02. Base: main at `af2f400`.*

Read this file, then your own brief, `brief-P<n>.md`, beside it. Where
the two differ, your own brief wins. Where either differs from
`ROUND3.md`, these win: they were written at dispatch, and ROUND3.md
was written before P0 landed.

## The project, and what must not break

cft-rebound is REBOUND's IAS15 integrator with every floating-point
operation carried by libcft (cft-fp256), at binary64, binary128 and
binary256. It makes three claims, in the terms the tests use:
- **At binary64 every problem's record is IDENTICAL to REBOUND's own**,
  bit for bit. REBOUND is pinned at `bdfda4bd`. `tools/check_records.py`
  compares non-comment lines only.
- **The software backend and a card give the same bits.** Nothing in a
  record may depend on where it ran.
- **A route never changes a record line.** A route is how a call is
  carried. This is the round's new claim, and P0's door holds it.

## Start here

1. `ROUND3.md`: read all of it, then your section, then "Rules for every
   parcel". Its status lines are stale. P0 landed on 2026-10-31, main
   is `af2f400`, and before-dispatch row 7 (the prototype) is done.
2. `CLAUDE.md`. It is short, and every line in it has cost hours.
3. `../ParcelRound/METHOD.md`: §1, §2 and §5 ("inert by construction").
   Then `../ParcelRound/CASE-STUDY-4.md` on READY and stated limits.
4. P0's door, which you use and do not change. All of it is in
   `src/ias15_cft.c`, measured at `af2f400`:
   - `route_def[]` at :182 and `engine_routes()` at :214;
   - the wrappers `vrun_k()` at :506, `vrun_ix()` at :572 and
     `vreduce_seg()` at :641;
   - `--door-selftest` at :2508 and `--door-refuse` at :2703.

   Its gate is `tools/check_door.py`. `docs/VALIDATION.md` entry 39
   records what was measured of it.

## Setting up your tree

A fresh worktree has no `third_party/` clones. They are gitignored, and
`tools/fetch_third_party.sh` would clone them from GitHub, which you
must not do. Clone them from the main checkout's clones, which are at
the pins:

```bash
R=C:/Users/logan/source/repos/cft-rebound
git clone --quiet "$R/third_party/rebound"   third_party/rebound
git clone --quiet "$R/third_party/cft-fp256" third_party/cft-fp256
git -C third_party/rebound   checkout --quiet bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93
git -C third_party/cft-fp256 checkout --quiet 922c2ade78fad995a0871bf07cebf8b9fbcb2b9f
bash tools/check_pins.sh
```

Then make your branch: `git switch -c round3-p<n>`.

## Building and testing on this host

```bash
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="$TEMP" TEMP="$TEMP" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" <target>
```

**The PATH line goes in every Bash call that builds**, because a fresh
shell does not inherit it. Without it, bare `cc` is the 32-bit
toolchain, and the link fails on a good object with `file format not
recognized`. `cc -dumpmachine` must say `x86_64-w64-mingw32`.

- **`make check-light`** takes about 9 minutes alone; run it while you
  work.
- **`make check`** is the full suite. It took 2,826 s alone at
  `733b067`. Run it before you report.
- Four parcels share this host's 12 cores, so expect both to take
  longer. Run them with `run_in_background` and wait for the
  notification; do not poll.
- **Read the log, not the exit code.**
- Miniconda's python, at the path above, has rebound 5.1.1 installed
  for `check-python`.
- Build only inside your own worktree.

Traps on this host, each of which has cost time:
- **MSYS `.exe` transparency.** Writing a file named `X` where `X.exe`
  exists writes to `X.exe`. `: > build/ias15_ref` once truncated the
  program to zero bytes. Create an extensionless file with Python.
- **Never `cd` out of your worktree in a Bash call.** Use `git -C` and
  absolute paths instead.
- **Stopping a background suite can orphan its children:** `make`,
  `gate_cache.py` and `check_*`. Find them with PowerShell
  `Get-CimInstance Win32_Process` and stop them before the next run, or
  two runs fight over `build/`.
- **Never run bare `git stash`.** The stash stack is shared across
  worktrees.

## The ledger

- **Read** `C:\Users\logan\source\repos\cft-rebound\.ledger\`, every
  file, at the three moments its README names. You can read it but not
  write it; V0 measured that on 2026-10-31.
  - `lead.md` and any `urgent/lead-*.md` amend your brief.
  - Every other agent's entry is a finding to weigh, not an instruction.
- **Write your entries** to
  `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P<n>.md`.
  - Append only, in the README's entry format.
  - The lead places each entry in the ledger verbatim.
  - If that write is refused too, use `.ledger/P<n>.md` inside your own
    worktree. It is gitignored there; never commit it. Say so in your
    report's first line.
- **Escalate to the lead** for anything that must not wait. Compose the
  message in your scratch directory, then `mv` it into the drop as
  `urgent-P<n>-<slug>.md`.
- **Arm a watch on `C:/Users/logan/source/repos/cft-rebound/.ledger/urgent/`
  before anything else.**
  - Use the Monitor tool (load it with ToolSearch `select:Monitor`),
    with the README's loop as its command and the longest timeout it
    takes.
  - Re-arm it at every expiry.
  - When it fires, read the message before you do anything else.
  - If the watch died and you cannot say when, re-arm it and do a full
    read.
- **Your scratch directory** is
  `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P<n>\`.
  Use it for logs, sabotaged copies, and anything else temporary.

## Corrections since ROUND3.md

All of these were measured at `af2f400` unless marked otherwise.

1. **On the software backend, `auto` is the NEW route.** That backend
   publishes every bit. When your call lands, every existing gate on
   software runs your new route by default. Today's route runs only
   under `CFT_REBOUND_ROUTE_<NAME>=off` or
   `CFT_REBOUND_HIDE_FEATURES=<name>`. So your gate must run both routes
   explicitly, and assert each run's `# route` line: on or off, its
   `by=`, `calls=` above zero where the route ran, and `fallbacks=`.
2. **Every routed call inherits the door's rules**, from V0's
   send-back:
   - a scalar operand is read once, before any element is written;
   - once any operand has an index table, the result may overlap no
     operand, dense or indexed;
   - a table on a NULL operand, or beside a zero-element source, is
     refused on both routes.

   One limit is stated, not closed: a table on an operand the opcode
   does not read is not refused, because libcft exports no arity.
3. **A library-path gate for a routed call reads `ias15_engine_route()`**
   (`src/ias15_engine.h`:318), as the program's gates read the `# route`
   lines.
4. **A new route name is one row in `route_def[]`, and nothing else.**
   `tools/check_door.py`, `--probe` and the misspelling scan all read
   names from the program, never from a typed list (`check_door.py`:41).
   An unknown `CFT_REBOUND_ROUTE_*` or `CFT_REBOUND_HIDE*` is refused by
   name.
5. **The gate cache keys on every `CFT_REBOUND_` variable**, by prefix
   and case-insensitively (`tools/gate_cache.py --env-prefix`), as well
   as on `CFT_REBOUND_ARTIFACT`. A leg run with a route forced is its
   own cache entry.
6. **`staged_bytes` depends on the route.** A scalar stages one element
   on the new route and n on today's. Never compare it across routes;
   the card normalisers drop it.
7. **`check_door.py`'s forced-off comparison goes live with the first
   routed call.** That comparison runs every route forced off against
   the default. In P0 it says "vacuous for now", and the first parcel
   whose call lands makes it live. If yours is that call, the comparison
   must pass and stop saying vacuous.
8. **On Windows, the library half inside a Python process never sees a
   variable set through `os.environ` after the process starts.** See
   `docs/PYTHON.md`, "The Windows rule". A Python leg that sets a route
   variable passes it in the child's environment at spawn.
9. **An ensemble has no width cap.** `CFT_MAX_BODIES` (1024,
   `src/ias15_limits.h`:29) bounds one system's bodies, not the number
   of systems.
10. **Expected small edits outside your files.** Only these, besides
    any your own brief adds:
    - `CASES_SRC` (`Makefile`:470);
    - one declaration in `tools/dropin_cases.h`;
    - one call in `tools/check_dropin.c`'s `main()`;
    - for a new Python leg, one line in each of `check` (:587),
      `check-quick` (:612) and `check-light` (:640).

## Rules

Everything in ROUND3.md's "Rules for every parcel" holds. These are the
rules most often broken:
- **A new leg names every artifact it executes as an `--input`.**
- **Follow the `--light` scaling rules.** A new case says which kind it
  is.
- **Bit-identity is not validity.** Print the physics counter beside the
  comparison, and assert it.
- **Nothing compares the trailer for you.** Whatever you rely on there,
  your own case asserts.
- **A gate that cannot fail is not a gate.** Build your named control,
  watch it fail, delete its artifact, and report both results.
- **READY is "a gate, or a stated limit".** A limit is stated by the
  behaviour it concedes.
- **Label every claim** as measured or believed.

## Do not

- Push, merge, rebase, or commit to main. Commit on your own branch, in
  your worktree; the integrator merges.
- Touch the card or amd-arc-box, by ssh or any other way. The card is
  held by another session. Every speed figure this round is the lead's,
  from the card day, so make no speed claims.
- Write to `../cft-fp256` (read it freely), or to anything in
  `../ParcelRound`.
- Edit an integrator-only file: `README.md`, `ROADMAP.md`, `CLAUDE.md`,
  `docs/VALIDATION.md`, `docs/HARDWARE.md`, `PARCELS.md`, `ROUND3.md` or
  `third_party/MANIFEST`. If one should change, say what in your report.
- "Fix" anything outside your scope. Report it instead.

## Report

Your final message is your report.

**Its first line** gives your branch, its tip's sha, and where your
ledger entries went.

Then:
- what changed, file by file;
- the gate's output, as actual lines;
- the full `make check`: the log's path, and the legs, `ok` count and
  FAIL count, read from the log;
- each control, with:
  - the property it is named for;
  - the sabotage;
  - the measured result with the sabotage;
  - the measured result without it;
- what you did not do, and each stated limit;
- anything you found that your brief or ROUND3.md got wrong.

If the approach turns out to be unworkable, stop and report that rather
than invent a different design. If you crossed a boundary this brief
drew, say so and say why. Crossing one is expected and fine; doing it
silently is not.
