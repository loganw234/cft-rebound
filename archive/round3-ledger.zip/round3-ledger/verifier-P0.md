# verifier-P0

## 2026-10-31 10:05 — V0 on P0 (971f93d, 20c05d8) and 47f0bc3: no record line moved; the door's gate can pass with nothing compared, and two wrappers answer differently by route on aliased calls

What was checked: `971f93d` (code), `20c05d8` (ROUND3.md "P0 - one door to the new library" and every line number it and the parcel sections cite), `47f0bc3` (the Windows DLL). Pre-P0 tree `21579ee`, in a second detached worktree (now removed). Both trees built clean and serial from fresh local clones at the pins (`check_pins.sh`: three `ok`); `libcft.a` is byte-identical between them (sha256 `1c18ac85...`). Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v0\`. The sabotaged and instrumented copies were deleted after their logs were kept. Nothing tracked was edited.

Everything below was measured, except where it says "believed".

**Bottom line.** The shipped code is right for everything P0 changes today: records, counters, trailer, wide-state digests, drop-in bits, refusals, normalisers, the DLL. What is wrong is all in what P0 hands to the parcels:
- the gate cannot fail in four shapes;
- two wrappers give route-dependent answers for call shapes the engine's rules allow;
- three claims are false.

### 1. No record line moved: confirmed

**Ran.** `v0/ab.py` put 51 integrations through both `ias15_cft.exe` builds. At fp64, fp128 and fp256:
- Kepler fixed, four ways: REBOUND, fma loop, fma program, `--cs augmented`;
- Kepler adaptive, two ways: plain, and fma on the program engine;
- outer fixed; Pythagorean adaptive; Kepler e=0.99 adaptive;
- a 16-member mixed-pass Kepler e=0.9 ensemble on the fma program engine.

At fp64 and fp128:
- 16-body fixed;
- adaptive modes 0, 1 and 3;
- the 16-member ensemble on the loop engine, and its `--member 5`;
- `--dt-out`;
- outer with `--min-dt` and `--softening`.

Five more:
- a 4-member ensemble on the loop engine at fp128, and on the fma program engine at fp256;
- `--max-iter 60` at fp256;
- `--trace-pc`;
- `--no-flag-abort --pc-tol-shift 2`.

**Compared.**
- Every non-comment line, byte for byte.
- The 8 counters.
- The trailer's key sequence: it must be pre's, with `t_reduce` inserted after `t_g_divsqrt`.
- Each value's printf class.
- The whole output with timings normalised, where only `# identity`, the three `# route` lines and ` t_reduce=` may differ.
- stderr, modulo seconds.
- The `--dt-out` files.

**Result: 51 of 51 identical on all of it.** None of the runs is trivial:
- the e=0.99 runs carry a rejected step and a capped corrector;
- fp256 Kepler is capped on 200 of 200 steps;
- the ensemble is capped 16 times at fp128 and 960 at fp256;
- library calls per run range from 12,430 to 1,687,050.

**Controls, both caught.**
- fp256 `--max-iter` 12 against 60: 4 of 5 lines and 5 counters differ.
- Loop against program engine (fma, fp64): every line identical, but `calls` 142,742 against 69,032 is caught by the counter check.

**The library path.** `make check-light` at P0 exits 0. All 15 legs ran (fresh cache), with 207 `ok` lines, 0 `FAIL` and only the deliberate `body_count` skip. Its `gate_real` digests equal the pre-P0 build's and entry 38's at all three formats: `e08541bc0af9b3ec`/`56bacf3bf63f19a7`, `5d7cf4588fad050e`/`cd16e6dc29aa0589`, `a1052750e206bebe`/`ba4d447c8e58bd20`.

**One precision.** In an ensemble trailer, `t_reduce` sits before `E=`, so it is not at the end of the line. No reader is positional (item 5), so this is harmless.

### 2. The library path's refusal: confirmed, and surfaced

**Ran.**
- `v0/shimprobe.c`, a drop-in in the shape of `examples/dropin.c`, linked against each tree's `libcft_ias15.a`, driven by `v0/shim.py`.
- `v0/pyrefuse.py`, through `build/libcft_ias15.dll`.

**A C user.** REBOUND prints the whole sentence on stderr:

> Error! ias15_cft: CFT_REBOUND_ROUTE_SCALAR=on asks for the scalar route, and the software backend does not publish CFT_SEQ_FEAT_SCALAR (CAPS2[7], ABI 0.12) (it is hidden by CFT_REBOUND_HIDE_FEATURES). Refused rather than run…

After it:
- `r->status` is 1;
- `t` stays 0 and the particles are untouched;
- the engine is not open.

The same holds for INDEXED, for REDUCE_SEG, for `=bogus` and for `HIDE=no_such_route`.

**A Python user.** They get a `RuntimeError` carrying the sentence, cut at 254 characters by REBOUND's `reb_string_size_max` (256). The last clause is lost: ", which gives the same bits but is not what was asked for."

**Unset, auto, empty, off, on and all-hidden.** 30 drop-in runs (fp64/128/256 fixed, fp64/128 adaptive) are bit-identical to the pre-P0 library. The control, fp64 against fp128, differs.

Not P0's: the sentence prints twice, and `steps_done` becomes 1. The pre-P0 build does both for a missing artifact.

The comment at `src/reb_integrator_cft.c:497` ("The device opened and lacks the format") now names only one of -4's causes.

### 3. The self-test's method: defect

**Ran.** An instrumented copy (`v0/mkprobe.py`, `v0/probe_chunk.c`), at all formats.

**What is right.**
- Each case takes each route once. The counts 62/60, 13/12 and 13/12 are the cases plus one control on the new route.
- `flags_union` is zeroed before every call.

**On the software backend, the self-test tests the port's wrappers, not libcft.** Each new route there is libcft composing the same primitive the fallback composes (`host/src/device.c`):
- a scalar is a stride-0 load inside the same loop;
- `reduce_seg` runs slice by slice;
- an indexed run gathers, then runs dense.

Believed, from `cft.h`'s text: on a card with CAPS2[8], `cft_reduce(MAXALL)` is itself the tile's streamed pass. Then the maxall cases there would compare the tile with itself.

**Largest shapes: false.** `read_problem()` caps N, not E.
- I ran E=8192 Kepler (49,152 lanes) and E=1057 × N=32 (524,272 pairs, 101,472 lanes, and a gather source of 101,472: gravity gathers from the whole N3), one fp64 step each, rc 0.
- The self-test's largest are 24,577 lanes, 523,777 pairs and a 3,072-element source.
- The probe found the routes identical at 49,152 lanes and at a 27,648-element source. So the routes hold at those sizes; the claim about them does not.
- Entry 37's "the widest vector this integrator can present" is where the claim comes from, and it is false too.

**Aliasing is not exercised, and two divergences exist.** Both were measured at all three formats.
- **`vrun_k`, with d aliasing the SCALAR operand.**
  - Lanes that differ between the two routes, of 4,096: 3,838 for `mul d=a`, 4,095 for `add d=c`, 4,095 for `fma d=a` (a and b scalar).
  - With d aliasing a dense operand, 0 differ.
  - The cause: the fallback broadcasts element 0 before the run. The software backend reloads element 0 on every lane, after `d[0]` has overwritten it (`device.c:2068-2086`).
  - Nothing refuses this call, and the engine's own rule at `:376` is "d may alias any input".
  - Believed: a tile reads the scalar once (its ONE BEAT), so it would agree with the fallback, and the software backend would be the odd one out. If so, that is a libcft question: `cft.h` says a scalar computes "exactly what an array of copies would have".
- **`vrun_ix`, with d aliasing a DENSE operand while another operand is indexed.**
  - The new route dies on libcft's refusal: "d overlaps operand c, and a run with an index table may not write over any of its operands".
  - The fallback computes.
  - The wrapper guards only indexed sources. Its comment at `:483-486` says it refuses what `cft.h` refuses "on either route", but `cft.h` refuses more.

**Signed zero.**
- Indexed: about 32,800 NONE indices in each large table. In sub at n=523,776, 2,899 lanes have a NONE meeting `c = +0`, and 1,034 have one meeting a real -0.
- Maxall: 5 and 7 segments where `maximum(+0,-0)` decides, all in the six-lane shapes.
- Scalar: the scalar operand is a zero in 1 case of 60 (-0, mul mask=2 n=3072). It is never +0, and never a zero in add, sub or fma.

**Inert by construction at fp128 and fp256.** The data is binary64 widened exactly, so every operand's low 60 bits (fp128) or 184 bits (fp256) are zero. A route that loses them is invisible; this is sabotages N7 and N8 in item 9.

### 4. `engine_routes()`'s parsing: minor defect

**Ran.** `v0/parse.py`, 32 cases.

**Accepted silently, and harmless.** Empty list elements are ignored:
- `scalar,,indexed` hides both;
- `scalar,`, `,scalar`, `,`, `,,,` and the empty string are all accepted.

**Refused by name.**
- Names: `SCALAR`, `' scalar'`, `'scalar, indexed'`, `scalar;indexed`, `scalar,bogus`, `reduce`.
- Values: `AUTO`, `On`, `' on'`, `'on '`, `1`.
- An empty value means auto.

**Silent: a misspelt variable name.** `CFT_REBOUND_ROUTE_SCALER=on`, `CFT_REBOUND_ROUTE_REDUCESEG=off` and `CFT_REBOUND_HIDE_FEATURE=scalar` each run rc 0 with every route unchanged. `CFT_REBOUND_ROUTE_INDEX=on`, with indexed hidden, runs rc 0 with indexed `off by=hidden`, unrefused.

Windows honours `cft_rebound_route_scalar=off` (`by=forced`); Linux would ignore it.

**Scenario.** On the card day, "indexed against dense" with one misspelt variable, on an image without CAPS2[9], is dense against dense. The only witness is the `# route` line, which the shell card scripts delete (item 10).

### 5. Every reader of a record: confirmed

**Readers.** Every reader in `tools/`, `python/`, `hw/`, `examples/`, `ref/`, `tests/` and `src/cft_rebound_run.c` selects lines by prefix. None reads by position, by line number or by whole-line equality, and nothing compares whole record files. `gate_subprocess` passes.

**Normalisers.** All four were read out of the scripts, not retyped (`v0/norm_check.sh`, `v0/norm_py.py`). Each drops exactly the identity line and the three route lines, and nothing else. On three records, the new normaliser applied to the P0 record equals the old one applied to the pre-P0 record, byte for byte. So does `bench-workload.py`'s `normalise()`, on four records.

### 6. The Windows Python DLL (`47f0bc3`): confirmed

- Imports: `KERNEL32.dll`, `msvcrt.dll`, `librebound.cp312-win_amd64.pyd`.
- `make check-python`: "IDENTICAL: 13 values, bit for bit."
- `make check-python-control`: "DIFFERS: 9 of 13 values".
- `make python-lib SHSTATIC=`, with the DLL removed first: refused, naming `libwinpthread-1.dll`, rc 2, nothing left behind.
- No leak: `make -n -B OS= SHSTATIC=-lLEAKCHECK build/libcft_ias15.so` prints a link line without it.

The guard's limits, as written:
- it catches `lib*.dll` only, so a non-lib DLL such as `zlib1.dll` would pass it;
- with no objdump it prints a warning and passes.

Outside the commit: `ias15_cft.exe`, the program the subprocess API and `make install` ship, still imports `libwinpthread-1.dll`. Run without mingw64 on PATH, it exits 127.

### 7. Scope: confirmed

`git diff --stat 21579ee 971f93d` touches exactly the nine files ROUND3's P0 section names, and the shim is untouched.

Stale or missing docs:
- `docs/BITSTREAM.md:248`, "normalise exactly those two fields", no longer describes the normalisers;
- no user doc names the door's variables, `--door-selftest` or the new lines.

### 8. Claims in comments and commit messages: three false

**True, by bytes or runs.**
- "Nothing else in the engine reduces". `pc_error`'s maxima are `bits_gt` selections.
- `calls=` goes up by 1 per wrapper call on both routes, at every format, including the 512-segment fallback.
- "The software backend publishes every bit": it publishes `0x7ff1f`, which covers every defined bit (`0x7ff0f`).
- All 43 line numbers in ROUND3.md hold at `20c05d8` (`v0/lines.py`).
- `bench-workload --quick`: 9 rows, 0 failures, 36 columns. `report.py` renders the extra table.

**False.**
- (a) `src/ias15_cft.c:154-156` says each family has "a route this port already takes ... and one cft_reduce a segment". The port has never called `cft_reduce`; `:306` of the same file says so. The fallback costs n/seg round trips where today's host loop costs none, and `cft.h` (`:1307-1313`) names this port's corrector as exactly that case.
- (b) "The largest shapes the integrator presents" (item 3).
- (c) `vrun_ix`'s "and so does this, on either route" (item 3).

**Loose.** "Every key its trailer carried" is not quite true: `trailer()` drops each route line's `by=`, so `decompose.csv` cannot tell absent from forced.

### 9. The sabotage controls: the five confirmed, and six new ones pass the gate

Each sabotage was built from a copy (`v0/sabotage.py`) and run through `tools/check_door.py`.

**The lead's five, rebuilt independently.** Each failed at its own assertion:

| sabotage | where the gate failed |
|---|---|
| S1, broadcast from element 1 | DIFF on the scalar cases |
| S2, CFT_IDX_NONE reads element 0 | DIFF on the indexed cases |
| S3, a segment drops one element | DIFF on the reduce_seg cases |
| S4, the hide hook ignored | the hidden check, and 3 refusals |
| S5, a forced route not refused | 3 refusals |

**Mine.** Six of the eight passed the gate:

| sabotage | gate result |
|---|---|
| N1, `scalar_mask` ignored on both routes | PASS, 84/84 and 3/3 controls |
| N2, the scalar route's calls and fallbacks counters swapped | PASS, so the `# route` line would report the opposite of what ran |
| N3, the reduce fallback counting every segment in `calls=` | PASS |
| N4, the probe reporting every bit absent | PASS: "0 of 84 cases identical", "controls: 0 of 0", three `note` lines |
| N5/N6, the low 8 bytes of a wide operand dropped | caught at fp128 and fp256 |
| N7/N8, the low 32-bit word dropped at fp128 and the low 128 bits at fp256, in the broadcast or the gather | PASS at fp64, fp128 and fp256 |

N4 matters most. On the software backend, which publishes all three bits in every build, the gate cannot fail when the probe reads nothing.

### 10. What the list did not ask

- **The gate cache ignores the door's variables.** `GATE_CACHE` passes only `--env CFT_REBOUND_ARTIFACT`. In a scratch cache, a leg run with `CFT_REBOUND_HIDE_FEATURES=scalar,indexed,reduce_seg` stamped a pass. The same leg run without the variable was "SKIPPED - inputs unchanged", under the same key (`09c46df13067`). Once calls are routed, `check-quick` and `check-light` would certify the fallback for later default runs.
- **`staged_bytes` depends on the route.** This follows from the door's own accounting. At fp128:
  - `vrun_k` stages 196,608 bytes on the fallback against 131,088 on the new route;
  - `vrun_ix` stages 196,608 against 983,040;
  - `vreduce_seg` stages the same on both.

  Every card-day normaliser keeps `staged_bytes`. So once P1 or P5 routes calls, a card that lacks a bit will be reported as differing from software: a false alarm, in the safe direction.
- **The three shell card scripts delete the `# route` lines and never print them.** "A card run that fell back would pass every gate unseen" stays true for those three scripts.
- **The library half has no route observable at all**, neither an accessor nor a trailer. `check_dropin`, `gate_real` and Python will pass unseen on a card that falls back.
- **`check_door` part 4 has two weaker checks.** It reads its counters through `dict.get`, so a renamed counter compares None with None and passes. It also never asserts the default run's route states.

**Believed.**
- A tile reads a scalar operand once, so under aliasing it agrees with the fallback and not with the software backend.
- On a CAPS2[8] tile, the maxall cases compare the tile's streamed maximum with itself.

For: lead, before `round3-p0` merges. Also P1, P2 and P5, who use the door; and cft-fp256, through the owner, for the aliased scalar.
