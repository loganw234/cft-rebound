# V3's report on P3 (3861a7b, the lead's d492c32 included), placed by the lead (2026-11-02, about 12:50)

V3's final message, condensed only where it repeats its ledger entry (V3.md, 12:40). Every figure is V3's, and it is measured unless marked believed. V3's scripts and logs are in ...\scratchpad\V3\.

SENT BACK, 2

## (a) A1. Nothing gates how dt_last is restored. Three single defects in it pass every leg.

The defects, each put into a scratch copy on its own:
- S4: the r->dt_last_done guard dropped (src/reb_integrator_cft.c:554-556).
- S4b: dt_last not restored at all (lines 553-556 removed).
- S22: the lead's ias15_engine_put_dt_last_wide() made a no-op.

Each passes:
- gate_real at fp64, fp128 and fp256, each run in a separate directory: rc 0;
- check_archive: rc 0;
- check_checkpoint. For S4 the full sweep ran, 2089 s, RESULT: PASS. For S4b and S22, --quick, plus the sequence functions at fp128 and fp256.

Evidence that each is a real defect. V3's driver runs 4 bodies at epsilon 1e-9 for 37 steps, takes a checkpoint, then sets r->dt = 0.75, so the first attempt after the load is rejected.
- After the load, integrate(t+1):
  - P3's build gives a resume identical to the straight run at all three formats.
  - S4: "fp64 s4 resume DIFFERS in 10 of 12 lines". At fp128, wide f273b85ce02997a2 against 98fb4f12648ac76a.
- After the load, 20 plain steps:
  - S4b: "fp64 s4b resume DIFFERS in 11 of 12 lines". At fp128, wide 4efaafc9d8a76290 against 07417b80f2c10bb1.
  - S22 at fp128: wide 4efaafc9d8a76290 against 87be20170d978eaf. S22 is identical at fp64.
- Against REBOUND's own ias15 (vs_rebound.py):
  - REBOUND's resume across its own checkpoint equals its straight run.
  - P3's build matches REBOUND at fp64 in both flows.
  - S4 and S4b give a resume that is not REBOUND's.

Why the gate cannot see it. SDTLAST is read only after a rejected attempt (ias15_cft.c:2179), and no case rejects the first attempt after a load. Sequence 5's integrate(0.6) starts from the controller's own last full step, which is accepted.

## (a) A2. The af2f400 compatibility limit is understated: four shipped sentences are false.

The sentences:
- tools/check_archive.py:59-60: "Everything it knows comes before cft_t, and its finish_load repairs cft_n_elem, the one field after".
- tools/check_archive.py:63-64: "gets only what that build ever got".
- src/cft_ias15_fields.h:164: "all it loses is cft_n_elem".
- NOTE 6 in src/cft_archive.c:158: "so it loses only cft_n_elem".

Measured, at fp64 and at fp128 where stated:
1. **af2f400 appending to an archive P3's build wrote.** The file grows: 11202 B to 18926 B at fp64, 16042 B to 28374 B at fp128.
   - Neither build can read the appended snapshot.
   - Loading the last snapshot returns snapshot 0, t = 0.3, not t = 0.6, and says "restored exactly".
   - REBOUND prints its "The binary file seems to be corrupted" warning.
   - Controls: base to base, and P3 to P3, both reload at t = 0.6.
2. **af2f400 loading a snapshot that P3's build appended after a removal** is refused: "rc 3: # load failed: refused: unreadable or inconsistent archive".
3. **REBOUND's function-pointer warning** is missing when af2f400 loads an archive P3's build wrote with a force or a merge set. functionpointers is written after the integrator's fields.

Believed: any appended field costs these three, so they are limits to state as a class.

## (b) B1. No case triggers the clock family's "reached memory" refusal (S11).

- Removing that refusal passes gate_real at three formats, check_archive and check_checkpoint --quick.
- Without it, a load whose clock never reached memory would say "restored exactly", with its clock rebuilt from binary64. That is the overclaim CFT_PROV_EXACT_CLOCK_STEPS64 exists to prevent.
- It is reachable only through a descriptor registration that does not match the file.
- The older families' equivalent checks are equally untested.

## (b) B2. The sweep's NO_CLOCK control asserts only that some resume differs.

"r->t on 2 [29, 30]" is printed, not asserted. So the 2-of-40 count the case is named for is held by nothing.

## Notes

- **The lead's d492c32** is tree-identical to 9b1744ea and lies wholly inside #ifdef IAS15_CFT_LIBRARY. P3's gate exercises put_dt_wide: S3 (the broadcast dropped), S19 and S21 are caught. put_dt_last_wide is not exercised: that is A1's S22.
- **Reproduced:**
  - P3's measured claims: the unfixed lines, split 30's bytes, NO_STEP's digests, the six digests, the 101-byte identity, --old-list against af2f400, and items 3 and 9;
  - 312 library-half integrations against af2f400 with nothing moved;
  - the standalone program, 9 of 9 records identical.
- **Caught:** S1, S2, S3, S5, S6, S7, S8, S9, S13, S14, S19 and S21.
- **Passed:** S4, S4b and S22 (A1); S10 and S11 (B1). The memory check refuses S10's files anyway.
