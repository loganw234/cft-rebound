## 2026-10-31 11:05 — V0 re-check of 90e6f3f: the eleven sabotages now fail and no record moved, but fix 8 does not reach a Python process on Windows, and vrun_ix still has two route-dependent refusals

Scope: `90e6f3f` (branch `round3-p0-v1`, base `20c05d8`), checked against my findings on P0. My worktree was detached at `90e6f3f`, `check_pins.sh` gave three `ok`, and I rebuilt `build/` and `programs/out` from clean (`make all programs`). The only warnings are REBOUND's own five. Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v0r\`. The sabotaged and instrumented copies were deleted after their logs were kept, and nothing tracked was edited. Everything below was measured, except where it says "believed".

**Bottom line.**
- **Records.** Still unmoved. 51 of 51 integrations are identical to the pre-P0 records I saved on the first pass, with both controls caught.
- **The gate.** `check_door` passes at all three formats. All eleven of the lead's sabotages fail, and so do six of my ten new ones.
- **Gate holes still open:**
  - two-operand reductions are never exercised;
  - the HIDE branch of the environment scan is never tested;
  - nothing checks that the low-byte randomisation still happens, so N7 and N8 pass again if it stops.
- **Defects still open:**
  - fix 8 does not reach variables a Python program sets for itself on Windows;
  - two `vrun_ix` argument rules still diverge between the routes;
  - `ias15_engine_route()` exists, but nothing reads it.

### The coordinator's two questions

**The environment scan in the library half, inside Python on Windows: a hole, and confirmed.** I ran `v0r/pyenv.py` through `build/libcft_ias15.dll`, which imports `_environ` and `getenv` from `msvcrt.dll`.

| how the variable was set | `CFT_REBOUND_ROUTE_SCALER=on` | `CFT_REBOUND_ROUTE_SCALAR=bogus` |
|---|---|---|
| by the parent, before Python started | `RuntimeError` naming the variable | `RuntimeError`, "expected on, off or auto" |
| through `os.environ`, before `cft_rebound.load()` | not refused | not refused |
| through `os.environ`, after `load()` | not refused | not refused |

`CFT_REBOUND_ARTIFACT` set through `os.environ` is not seen either; that part is pre-existing.

The scan and `getenv` do agree with each other: both read msvcrt's copy of the environment, taken before the script ran. Neither sees UCRT's `os.environ`. So the scan creates no new inconsistency. But in Python on Windows, the door's whole policy is unreachable from inside the program: forcing a route, hiding a bit, and refusing a typo. README's "and so is a misspelled variable" does not hold there.

Believed, not run: reading the live process environment through the Win32 API (`GetEnvironmentStringsW`/`GetEnvironmentVariableW`) would see `os.environ`, because UCRT updates the process block.

Also believed: on Darwin, a dylib that references `environ` does not link (Apple's environ(7) says to use `_NSGetEnviron()`). The Darwin library path has never been run, and it already leaves REBOUND's symbols undefined without `-undefined dynamic_lookup`. Not determined.

**Reading a scalar once, when the scalar aliases another operand rather than d: correct, no hole.** I ran an instrumented copy (`v0r/probe_chunk2.c`) on five shapes:
1. `mul`, d separate, a dense = X, b scalar = X;
2. `mul` with d = X as well;
3. `fma`, d = Y, a scalar = Y, b dense = Y;
4. `fma` with two scalars from one buffer, and d = c;
5. a scalar sitting inside d (b = d + 5).

On both routes at all three formats, every case gave 0 of 2,048 lanes different from an "array of copies" reference built before any write. I found no aliasing pattern where read-once departs from today's broadcast route.

### Per fix

1. **The reference outside the wrappers: confirmed.**
   - `check_door --build build`: PASS at fp64, fp128 and fp256, with 125 of 125 cases equal to the reference on both routes, 0 accounting errors and 3 of 3 controls.
   - My new sabotages that are wrong on both routes at once are now caught: F9 (c's table ignored on both routes) and F10 (the reduction's op ignored on both). Without the reference neither would be.
   - N1 fails too, though through the flag abort rather than the comparison: the dense read of the 32-byte scalar copy runs past it.

2. **Accounting: confirmed.**
   - N2, the swapped counters: 200 COUNT lines.
   - N3, a fallback counting every segment: `calls=` moved 8 to 8,194 per call.

3. **N4: confirmed.** "0 of 125 … FAIL", and "the software backend publishes every bit … by=absent" FAILs too.
   - Believed: the f128 image recorded `seq_features 0xf1f` (docs/BITSTREAM.md:283), which publishes the scalar bit. If so, the new "nothing compared is a FAIL" rule will not trip on the card day.

4. **N7 and N8: fixed, but nothing checks the fix still works.**
   - Measured by widening known patterns:
     - the layout is little-endian, with the sign in the top bit of the last byte;
     - after widening, the low 7 bytes (fp128) and 23 bytes (fp256) are zero, so `door_low_bytes()` = 0, 7 and 23 is right;
     - `door_zero(-0)` equals a widened -0.0;
     - `door_fill` puts a nonzero low byte in 93,908 of 93,908 nonzero values and leaves every zero intact.
   - N7 and N8 now fail at fp128 and fp256.
   - Gap: F4 (`door_low_bytes()` returning 0) passes the gate. So does F4 together with N8, at all three formats. Nothing asserts that the data has any bits below binary64's reach, so a regression in `door_fill` silently re-opens N7 and N8.

5. **Aliasing: confirmed for what was fixed, and two divergences remain.**
   - Fixed:
     - F1 (the scalar copy removed) fails: 4,095 and 3,947 of 4,096 lanes differ;
     - F2 (the overlap rule removed) and F3 (the rule restricted to indexed operands again) fail;
     - an overlap of one element is refused on both routes, and an adjacent, non-overlapping d is accepted on both;
     - every `--door-refuse` case is refused with the route forced on and forced off.
   - **Still route-dependent (a latent defect).** `vrun_ix` with:
     - a table on a NULL operand: the new route dies on libcft's "idx_c indexes operand c, which is NULL", while today's route computes;
     - a table on an operand the opcode does not read (`mul` with `idx_c`): the new route dies on "idx_c gathers operand c and opcode 3 (mul) does not read it", while today's route gathers c and computes.

     The scenario: a parcel reuses fma's tables for a mul. The call dies on the software backend and computes on a card without CAPS2[9].

6. **Shapes: confirmed.** The self-test runs n=49,153 lanes, 524,273 pairs and a 131,072-element source, and the code no longer claims a largest shape.

7. **Signed zero: confirmed.** 12 cases with a +0 scalar and 12 with a -0 scalar, all within the 125.

8. **Misspelled variables: refused in the program, with three gaps.**
   - `v0r/parse2.py`: misspellings after the prefix are refused (`_SCALER`, `_INDEX`, `_REDUCESEG`, `_HIDE_FEATURE`, `_HIDEFEATURES`, a bare `CFT_REBOUND_ROUTE_`). So are lower-case and mixed-case names.
   - Gaps:
     - a typo inside the prefix runs rc 0 unrefused: `CFT_REBOUND_ROTUE_INDEXED=on` (with indexed hidden), `CFT_REBUOND_ROUTE_SCALAR=bogus`, `CFT_REBOUND_HDIE_FEATURES=scalar`;
     - Python on Windows, as above;
     - F6 (the HIDE half of the scan removed) passes the gate, because `check_door` tests only a `ROUTE_` typo.
   - Two wording points:
     - the message calls a lower-case name "not one of the door's variables", though Windows' `getenv` would read it as one;
     - the message's list reads "...and CFT_REBOUND_ROUTE_REDUCE_SEG, and CFT_REBOUND_HIDE_FEATURES", with "and" twice.

9. **Item 10's fixes: confirmed, except that the accessor has no consumer.**
   - **The gate cache.** In a scratch cache, a pass with every route hidden no longer satisfies the default run (it ran, by=device), and a second default run does still skip.
   - **The normalisers and the routes() helper.** All four normalisers now drop `staged_bytes` as well. I read the three shell normalisers and their `routes()` helper out of the scripts, and imported `bench-workload.py`'s `normalise()`. A copy of a record with `staged_bytes` and one route line changed normalises to the same text in all four, and `routes()` in each shell script shows the changed route.
   - **The accessor.** Through a drop-in, `ias15_engine_route()` reports "unopened" before the engine opens, device/forced/hidden afterwards, and -1 past the last route. But nothing in the tree calls it: no gate and no Python wrapper. So "the library half passes unseen on a card that falls back" stays true until a gate reads it.
   - **Counters in `check_door`.** Every counter is now required (read in the code).

10. **The comments: confirmed by reading.**

11. **The Linux warnings: not determined.** `gate_real.c` and `gate_subprocess.c` build clean with `-Wall -Wextra` on Windows. I did not touch cft2204.

12. **The docs: confirmed.** Every line citation in ROUND3.md's P0 and parcel sections holds at `90e6f3f`, including the moved Makefile lines (587/612/640) and `trailer()` at :169. BITSTREAM.md and the shim's comment are right. README's "a misspelled variable" is refused is true outside Python, apart from typos inside the prefix.

### What I re-ran

- **The A/B.** `v0r/ab2.py` against the pre-P0 records saved on the first pass: 51 of 51 identical on the whole comparator, with both controls caught.
- **Python.** `example_equivalence.py` on the new DLL: "IDENTICAL: 13 values"; the fp128 control: "DIFFERS: 9 of 13".
- **The sabotages.** `v0r/sabotage2.py`, 21 copies:
  - all eleven of the lead's (S1 to S5, N1 to N4, N7, N8) FAIL;
  - of my ten new ones, six FAIL: F1, F2, F3, F5, F9, F10;
  - four PASS: F4, F4+N8, F6, and F11 (the fallback ignoring the second operand's segment). F11 passes because no case uses a two-operand reduction.
- **`make check-light` at `90e6f3f`.** Exit 0, all 15 legs run on a fresh cache, 217 `ok` lines, 0 `FAIL`, and only the deliberate `body_count` skip. The six `gate_real` wide-state digests are identical to the pre-P0 build's and to entry 38's: `e08541bc0af9b3ec`/`56bacf3bf63f19a7`, `5d7cf4588fad050e`/`cd16e6dc29aa0589`, `a1052750e206bebe`/`ba4d447c8e58bd20`.

### For

Lead, before `round3-p0-v1` merges. Also P1, who may use `vrun_ix`, and P2, if a two-operand reduction is ever planned.
