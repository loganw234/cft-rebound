# V2's report on P2 (0b5e17e), placed verbatim by the lead (2026-11-02, about 11:00)

SENT BACK, 2. My ledger entries went to the drop at `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\V2.md`. The write was not refused. The lead has placed the entry; two corrections were appended to it afterwards.

I verified `round3-p2` at `0b5e17e` (`git log --oneline -1` matched), against base `af2f400`, on the software backend only. P2's code gives the base's records on every integration I ran. Both blocking findings are in the gate, not the engine: each is a defect the gate cannot see.

## (a) Findings that block the merge

**1. The mixed-pass ensemble cannot see a replay that ignores each system's own exit, at any format.**
- **Defect.** The sabotage is M2: in `sched_pass()`, a system that reaches its count stays in the corrector (`if (iters[s] >= sched_want[s]) continue;`). It is frozen only when the attempt's last system finishes. Each system's own counts are still reported exactly.
  - Every pass past a system's exit lands on its fixed point, so no record bit moves.
  - The masking is a host memcpy, so `calls=` cannot see it either.
  - The counters come from the schedule, so the lead's argument that the counters prove the replay drives the run does not hold system by system.
- **Evidence.** `python tools/check_corrector.py --build …\V2\sab\M2` at each format:
  - `--quick`: rc 0, 159 ok, 0 FAIL, `RESULT: PASS`, with `ok   the replay: 35 record lines and every counter of the run, … mean_pc_iterations=3.263`.
  - `--formats fp128`: 47 ok, 0 FAIL, PASS.
  - `--formats fp256`: 51 ok, 0 FAIL, PASS. In that run all 13 of 13 attempts had systems leave at different passes.
  - `v2_mask.py`: across 18 ensemble runs (E = 2 to 16, modes 0 and 2, all three formats), both M2 and the real replay reproduce the recording exactly, for example `0 of 35 record lines differ` for each.
- **A control that sees it.** In a mixed attempt, cut one system that is not the longest to 1 pass.
  - Real replay, for example: `system 1 cut from 36 to 1 -> clean: system 1's lines differ 2, the others' 0`.
  - M2: `system 1's lines differ 0, the others' 0`.
  - Over 30 cuts, the real replay changed only that system's lines in 28, was refused by name in 1, and was inert in 1. M2 changed nothing in 30 of 30.
- **Property it breaks.** The brief's named trap ("the mixed-pass-count ensemble is the case for that… a control that cannot fail"). Also "`--replay-iters` runs exactly those counts", and the `sched_pass` comment's claim that "an ensemble's masking is the recording's as well".
- **What is only believed.** M2 would give a wrong record wherever extra passes miss a fixed point, as one extra pass does for fp128 Kepler at attempts 25 and 28. I found no ensemble where it shows.

**2. The library-path case holds the route to nothing.**
- **Defect.** The sabotage is M4: `route_on[ROUTE_REDUCE_SEG] = 0;` after `engine_routes()` in `ias15_engine_open()`. The library half then silently takes today's route.
- **Evidence.** `…\sab\M4\check_dropin.exe --light` gives rc 0 and `check_dropin: every case passed`, with `ok   corrector kepler GLOBAL: reduce_seg=off by=device carried this case's 118 maxima on today's route, and no device call`.
- **Property it breaks.** brief-common corrections 1 and 3: the library-path gate must read `ias15_engine_route()` the way the program's gates read the `# route` lines, and those assert `by=`. `tools/cases_corrector.c` only checks that the counts agree with whichever route opened. On software with no door variable, `off by=device` is a state a correct door cannot reach. P2's stated limit concedes "whichever route opened", but not this. The lead has already sent P1 the same check (`urgent/lead-p1-route-case.md`).

## (b) Should be fixed, need not block

- **The run key's refusal is tested on only one field.** The gate only tries a schedule from another format.
  - M3 (key without epsilon) and M3s (key without the state hash) both pass the gate: 159 ok, 0 FAIL.
  - With M3, kepler's 1e-9 schedule replayed at epsilon 1e-8 was accepted with rc 0, and 1 of 3 record lines differed from a true run.
  - The real key refuses both, so the code is right today; the gate would not catch a regression.

## Notes

- **Ownership.** Every hunk is on P2's list or is a declared crossing.
  - `src/cft_embedded_image.h` is byte-identical to the lead's block (sha256 `4f8dfa60…`, checked with `cmp`).
  - Small undeclared edits: the usage comment at the top of the file, and `sched_begin()`/`sched_end()` either side of the corrector loop.
  - Nothing touches another parcel's functions, `dtnew_*`, `choose_timestep()` or `trailer_keys[]`.
- **M5, a stall-rule change shared by both routes, passes P2's leg.** That is by design, since the leg compares routes. `check_equivalence` (7 FAIL) and the full `check_records` (10 FAIL, all three formats) catch it.
- **Wide-format route comparisons in the gate are a subset**, as P2's report says: at fp128 and fp256, modes 1 and 3 are covered by the self-test only. My A/B covers every problem in every mode there.
- **S5 gave 39 FAIL against P2's 47.** My copy records a line when any system accepts; P2's when system 0 does. Both are caught.
- **The image-refusal path P2 called unexercised works in the program.** With a truncated image it is refused by name, rc 3, and runs with the route forced off. The library half's -4 path was not run.
- **The `normalabs` image needs no sequencer feature** (`cft-asm -i` prints `features -`).
- **Seven refusals the gate doesn't test all work by name**, rc 3, no trailer.
- **All of P2's cited line numbers hold** at `0b5e17e`.
- **Sabotaged binaries are left, labelled**, in `…\scratchpad\V2\sab\`. I did not delete them.

## What I ran

**Builds**
- P2, clean and serial: 105 s.
- The base, from `git archive af2f400`: about 65 s.
- Only REBOUND's five warnings in either.

**The gate**
- `make check-light`: rc 0 in 1,212 s, 16 legs, 394 ok, 0 FAIL. The only skip is `body_count`, and the six `gate_real` digests are P0's.
- `check_corrector` at all three formats: 243 ok, 0 FAIL in 146 s.
- `check_door` at all three formats: 56 ok in 78 s. The forced-off comparison passes and no longer says vacuous.
- `check_dropin` full: every case passed in 956 s, with the corrector cases carrying 261, 550, 696, 608 and 614 maxima.
- `check-python`: IDENTICAL, 13 values. Its control: DIFFERS, 9 of 13.

**Records held to the base: 258 pairs, every one identical.**
- 129 pairs on the default route (368 s) and 129 with the route forced off (323 s).
- They cover every problem in all four modes and fixed steps, rejections, `--max-iter 3` and `60`, `--pc-tol-shift`, `--cs augmented`, `--arith fma`, the program engine, `--softening` and `--min-dt`, E = 5 and E = 16 ensembles, and `--member`, at all three formats.
- Compared: every non-comment line, every non-timing counter, each system line, the header, and the other route lines.
- The comparator's controls: M5 moved 38 of 43 fp64 pairs, and M7 moved 7 of 43.

**P2's controls, all caught at the check meant for each**

| control | FAIL lines |
|---|---|
| S0 (replay runs the test instead) | 59 (38 + 10 + 11, one count per format) |
| S1a, S1b, S2 (the image's three properties) | 6 each |
| S3, S3b (the 1/1 of a system out of the corrector) | 3 each |
| S4 (a recorded cap not counted) | 14 |
| S5 (schedule keyed on accepted steps) | 39 |
| S6 (the `normalabs` run counted as a program call) | 50 |

Each full run took 132-172 s. A clean copy built the same way passes.

**My sabotages**
- Caught: M1 (35 FAIL), M6 (1), M7 (24), M8 (37), M9 (2).
- Passed: M2 (all three formats), M3, M3s, M4 (drop-in gate), and M5 (P2's leg only; the suite catches it).

**P2's numbers, reproduced**
- 4 of 60 one-count moves change the fp128 Kepler record, at attempts 25 and 28, each at +1 and -1.
- Lowering every uncapped count by one changes it too.
- The prototype has 7 anchors, 3 of them absent at `af2f400`.

## Not checked, and why

- **The card and amd-arc-box:** forbidden; that is session B's.
- **Linux and Darwin:** not run on this host.
- **The full `make check`:** I read P2's log instead (16 legs, 531 ok, 0 FAIL). It agrees with my own runs, so I had no reason to doubt it.
- **Some of P2's figures not reproduced:** the 0-of-122 survey, the 27-44% fp64 share, and P2's own A/B control.
- **The library half's -4 refusal path:** not exercised.
- **The merge seam with P1's generator:** the lead's.
- **Speed:** no speed claims were made.

My scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\V2\`.
