# P5: `scalar_mask` at the broadcast sites (the second wave)

*The lead, at dispatch, 2026-11-06.*

You are parcel **P5** in cft-rebound. You work in a git worktree of
`C:\Users\logan\source\repos\cft-rebound`, branched from main at
**`e47b04e`**. **Check that you are on that commit** with `git log
--oneline -1`. If you are not, say so in the drop and reset to it. Your
branch is `round3-p5`.

Read `brief-common.md` (beside this file) first, then ROUND3.md's P5
section, which is your plan. Then read `lead.md` from its "2026-11-02
16:55" entry to the end. Where those differ from this brief, this brief
wins.

## What changed since brief-common.md was written

It was written at `af2f400`, for the first wave. All of the first wave
is merged, so:
- **Its line numbers are stale.** At `e47b04e`, `route_def[]` is at :195,
  `engine_routes()` at :232, `vrun_k()` at :536.
- **Paths.** Your drop is
  `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P5.md`,
  and an escalation goes beside it as `urgent-P5-<slug>.md`. Your scratch
  directory is the same scratchpad's `P5\`. The older path in
  brief-common.md and in the ledger's README is out of date.
- **Launching.** Jobs the Bash tool launches run at BelowNormal priority
  and starve on this host. Launch long suites from PowerShell:
  `Start-Process -FilePath "C:\Program Files\Git\bin\bash.exe" -ArgumentList "<path to a .sh file>" -WindowStyle Hidden -PassThru`.
  - The script's path is the only argument, never `-c "..."`.
  - Inside the script, spell TMP and TEMP out as
    `C:\Users\logan\AppData\Local\Temp`. Git bash started this way has
    `TEMP=/tmp`, and msys64's make hands that to native children as
    `C:\msys64\tmp`.
- **Correction 1 has an exception.** `auto` no longer always takes the
  new route. `indexed` and `pair_gather` are **opt-in**: `route_def[]`
  has an `opt_in` flag, and under auto they stay off, `by=opt_in`, even
  where the bit is published.
- **Full suite:** about 80 minutes alone now, 18 legs. You are the only
  parcel running, but the lead may run card preparation beside you.

## Your job

ROADMAP item 2. Constant operands are staged as N3 copies of one value.
Pass them as one scalar instead, through P0's `vrun_k()`. Recount the
sites, take `vrun_k()`'s `DOOR_UNUSED` off when the first call lands,
and leave every record line unmoved.

**The `scalar` route is opt-in from the start.** On 2026-11-02 the card
measured gravity's new routes 22-74% slower with identical bits, so a
route that no card has measured does not go on by default. Set the
`opt_in` flag on `scalar`'s `route_def[]` row, and add it to
`tools/check_door.py`'s `OPT_IN`. The lead measures it on the card and
can flip the default later; that is one flag. Make no speed claims.

## What reading has turned up: verify it, do not trust it

Measured at `e47b04e`:
- **`vrun_k(op, d, a, b, c, n, smask, what)`.** Each bit of `smask` (0 a,
  1 b, 2 c) marks an operand that is one element. On the new route it
  stages one element; off, it broadcasts into scratch and runs today's
  call. It counts one call either way. A `vmul(d, a, K, N3)` site's
  `staged_bytes` falls by `ESZ * (N3 - 1)`, and only when the route is
  on.
- **The constants.** `kderived()` and `kint()` build the K vectors by
  broadcast: `KRINV`, `KHF`, `KC`, `KY4`, `KY5`, `KNUM`, `KVNUM`,
  `KPOSR`, and others.
- **Not every path runs elementwise.** Under `--engine program`, the
  corrector and predictor are programs, and their constants ride in the
  bank (`prog_bank`). So some sites run only under `--engine loop`.
  `vdiv` goes through `cft_div`, not `cft_run`, and may not be reachable
  through `vrun_k()` at all. Report the sites per engine, and per
  `--arith` where that decides. The card runs `--engine program --arith
  fma`, so the lead needs the count that applies there.

**The trap that would be a silent wrong answer: not every broadcast
vector is a constant.** `DTB`, `DTDB`, `RB`, and `D1B[]` and `D2B[]`,
which are built from `DTB`, are filled by `bcast_sys()` (:1326), one
value **per system**. For one system that looks exactly like a scalar.
In an ensemble whose systems have different steps it is not, and element
0 would be system 0's step applied to every system. No case with E = 1
can see that, and neither can an ensemble whose systems happen to share
a step. A site may take `scalar_mask` only if its operand is the same
for every lane of every system. So your gate needs an adaptive ensemble
whose systems' steps differ, and it must assert that they differ.

Two more to verify:
- **The door's rule:** a scalar operand is read once, before any element
  is written. `vrun_k()` copies it first, but check any site where `d`
  aliases another operand.
- **The library half.** `route_on[]` applies there too. With an opt-in
  route the suite's own `check_dropin` leg runs today's route, so a
  build whose library half silently ignores the forced route passes it
  (P1's M4, `lead.md` 16:55 onward). Something in `make check` must run
  the drop-in with `scalar` forced on, and read `ias15_engine_route()`.

## Files you own

- the call sites you convert, in `src/ias15_cft.c`;
- `route_def[]`'s `scalar` row, its flag only, and `vrun_k()`'s
  `DOOR_UNUSED`;
- `tools/check_door.py`: `OPT_IN`, and whatever the first real scalar
  calls make stale;
- a new gate, `tools/check_scalar.py`, in the shape of
  `tools/check_gravity.py`, with one line in each tier of the Makefile,
  and any library case it needs (`tools/cases_scalar.c` and the expected
  small edits).

## Files you must NOT touch

- **The archive files, and `tools/check_seams.py`.** The seam test is
  the lead's; the lead adds `scalar` to it at the merge.
- **`gen_programs.py` and the program bank's contents.** Programs carry
  their constants already.
- **`dtnew_*()` and `choose_timestep()`.** Nobody's this round.
- **Integrator-only files**, as brief-common.md lists them.

## Gate

- **Records are unchanged.** With `scalar` forced on, every problem's
  records and every counter but `staged_bytes` equal the forced-off run
  at every format, on both engines, in an ensemble whose systems' steps
  differ, and through a rejection.
- **Negative control.** `staged_bytes` falls by an amount **derived**
  from the recounted sites, their widths and the run's call counts. The
  gate computes it and asserts it; it is not transcribed.
- **A second control, for the trap.** A sabotage that passes one
  per-system vector as a scalar must fail your ensemble case, and must
  pass every E = 1 case. Show both.
- **The physics counter.** The `# route scalar=` line: calls above zero
  and no fallback when on, the reverse when off.

Your final report is brief-common.md's, plus the site count per engine.
Run the full `make check` before you report, launched as above, and read
its log. Do not touch the card or amd-arc-box.
