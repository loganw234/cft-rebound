# P2: the corrector's exit test

*The lead, at dispatch, 2026-11-02.*

You are parcel **P2** in cft-rebound. You work in a git worktree of
`C:\Users\logan\source\repos\cft-rebound`, branched from main at
**`af2f400`**. **Check that you are on that commit** with `git log
--oneline -1`. If you are not, say so in the drop and reset to it. Your
branch is `round3-p2`.

Read `brief-common.md` (beside this file) first. Then read ROUND3.md's
P2 section, which is your plan.

## Your job

cft-fp256 measured the corrector's exit test at 4-9% of a card step.
You build two mechanisms aimed at it.
- **(a) A recorded schedule.** `--record-iters FILE` writes the
  corrector's pass count for each step attempt. `--replay-iters FILE`
  runs exactly those counts, and skips `pc_error()` and the exit test.
- **(b) The test on the device.** `cft_reduce_seg` runs over the output
  of `normalabs-<fmt>`, through P0's `vreduce_seg()`, with today's host
  loop as the fallback.

Both must give the host route's records and counters, bit for bit.

## What reading has turned up: verify it, do not trust it

Measured at `af2f400`:
- `pc_error()` is defined at :1311. Line :1268 is a forward declaration.
- It has two call sites, and those two lines are yours:
  - `if (n == 7) pc_error(tmp);` at :1297, at the end of the
    elementwise corrector;
  - `if (n == 7) pc_error(prog_dep);` at :1457, at the end of the
    program route's corrector.

  `predict_next_step_vec()`, ten lines below the second, is P4's.
- `step_attempt()` is at :2007. `main()` is at :2725, and its parser is
  around :2767.
- `vreduce_seg()` is at :641, marked `DOOR_UNUSED`. Take that mark off
  when your call lands.
- `cft_reduce_seg` is at `cft.h`:1321 in the pinned tree.
- `normalabs-fp32`, `-fp64`, `-fp128` and `-fp256` (`.cfta`) are in
  `third_party/cft-fp256/programs/` at the pin. Your Makefile rule
  assembles them from there, so the pin governs them. See how the
  Makefile's `programs` target assembles the port's own programs, and
  do the same.
- The prototype is
  `C:\Users\logan\source\repos\cft-rebound\.ledger\prototype-patch_fixed_schedule.py`.
  - It is 7,928 bytes, copied on 2026-11-02 from amd-arc-box's
    `~/patch_fixed_schedule.py`.
  - It is dated 2026-09-10 and is 123 commits behind.
  - It is a patch script that rewrites `src/ias15_cft.c` at four
    anchors. It was applied to a box clone only.
  - Read it for its design; do not run it against your tree.
  - ROADMAP says its four anchors still exist. Check.

**Believed, from cft-fp256's ROADMAP (ask 7):** `normalabs-<fmt>`
followed by `cft_reduce_seg` is `pc_error` exactly, in both modes, the
+0 identity included. **Confirm it by reading `pc_error()` before you
rely on it:**
- INDIVIDUAL mode is the maximum of `|tmp/at|`, a divide per coordinate
  before the maximum;
- the other modes take `max|tmp| / max|at|`;
- a system that has left the corrector is given 1/1.

If the pair cannot express INDIVIDUAL's per-coordinate divide, that mode
keeps the host route, and your report says so.

**The trap that would be a silent wrong answer: a replay that
reproduces the state but not the counters, or that keys on the wrong
unit.**
- **The counters.** `iterations_max_exceeded` (round 2's P4),
  `steps_rejected` and the pass counts are trailer lines. Nothing
  compares the trailer for you, so your own case asserts each one.
- **The unit.** The schedule is per step *attempt*. A schedule keyed on
  accepted steps desyncs after the first rejection, and a case with no
  rejected step cannot see that. At least one case must assert
  `steps_rejected` above zero.
- **The ensemble.** An ensemble's systems leave the corrector at
  different passes, and the mixed-pass-count ensemble is the case for
  that. Assert that its systems' pass counts actually differ. If they
  do not, it is a control that cannot fail.

## Files you own

This is ROUND3.md's P2 list:
- `pc_error()` and its two call sites;
- the corrector's exit test inside `step_attempt()`, and only that;
- the two new flags in `main()`'s parser;
- one Makefile rule for `normalabs-<fmt>`;
- a new `tools/cases_corrector.c`, or a check script.

## Files you must NOT touch

- **P1's, which P1 is editing now:** `gravity_body()`,
  `build_scatter()`, `alloc_state()` and the indexed wrapper.
- **P4's, which P4 is editing now:** `predict_next_step_vec()`.
- **Nobody's this round:** `dtnew_*()` and `choose_timestep()`.
- **P3's, which P3 is editing now:** the archive files.
- **P0's** probe, wrappers and gate, beyond taking `DOOR_UNUSED` off
  `vreduce_seg()`. If one of them is wrong, report it.

Your new flags are program-only, in `main()`'s parser. The library half
takes the device route through the door like everything else, so the
drop-in's gates cover your route at `auto`. Say how a library-path gate
checks it, through `ias15_engine_route()`.

## Gate

ROUND3.md's P2 gate, all of it:
- **the replay** is byte-identical to the recording at every format and
  in the mixed-pass-count ensemble, and its case asserts the trailer's
  counters;
- **the device test** gives the host route's pass counts and records on
  every problem, in every mode it claims. Both routes are run
  explicitly, with their `# route` lines asserted.
- **`check_door.py`'s forced-off comparison** stops saying vacuous, and
  passes. P1's call may also make it live; whichever lands first does.

**Negative controls.** Each must fail, and you report all four with
their numbers.
- *Replay:* one count changed by one must change the record, or be
  refused by name.
- *The device route:* three cases, each with one property removed from
  the route:
  - a system with no normal coordinate (the +0 identity);
  - a subnormal coordinate (normal-only);
  - a system that has left the corrector (1/1).

## Stop line

If the device route needs per-coordinate host work of the kind the
reduction was meant to remove, stop and report.
