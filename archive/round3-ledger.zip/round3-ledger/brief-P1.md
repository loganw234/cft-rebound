# P1: gravity as indexed program runs (the long pole)

*The lead, at dispatch, 2026-11-02.*

You are parcel **P1** in cft-rebound. You work in a git worktree of
`C:\Users\logan\source\repos\cft-rebound`, branched from main at
**`af2f400`** ("Ledger entry 39: round 3's P0, ..."). **Check that you
are on that commit** with `git log --oneline -1`. If you are not, say so
in the drop and reset to it. Your branch is `round3-p1`.

Read `brief-common.md` (beside this file) first. Then read ROUND3.md's
P1 section, which is your plan. This brief adds what changed since, and
what the lead decided at dispatch.

## Your job

Make a force evaluation a handful of program runs instead of hundreds of
calls:
- build the indexed program-run wrapper beside `run_program()`;
- route gravity's accumulate half through one indexed run per force
  evaluation;
- route the pair arithmetic through one program over P lanes, with its
  six inputs gathered either by the host's loops or by index tables.

Every new route sits behind the door, with the dense route as its
fallback, and every route gives the same records.

## Decided at dispatch

- **Two switches, not one.** The card day must compare two things
  separately, without a rebuild (ROUND3.md, "The card day", item 3):
  - the accumulate fold, indexed against dense;
  - the pair gather, host against device.

  One `indexed` route cannot express both choices. So **add one row to
  `route_def[]`** (:182) for the second choice, sharing
  `CFT_SEQ_FEAT_INDEXED`.
  - That row is an expected small edit. Apart from the next item, it is
    the only change to P0's code you may make.
  - The names are yours. Post them in the drop as soon as they are
    fixed, because the card scripts read them.
  - Check what `CFT_REBOUND_HIDE_FEATURES` does when two routes share
    one bit, and say.
  - If one switch turns out to be enough, say why.
- **Your wrapper's cases go in `--door-selftest`, beside P0's**, in the
  same output format.
  - `check_door.py` then counts them with no edit, because it reads the
    totals from the program's summary line (:144-156).
  - Hold them against a reference computed outside the wrapper, as P0's
    cases are, and check each call's accounting.
  - If you add a `--door-refuse` case, its one `REFUSALS` row in
    `check_door.py` (:63) is an expected small edit.
- **Decide, and say, whether your routes depend on `--engine program`
  or run in every mode.** The library half sets `engine_program = 0`
  (:3113). Under the door, `auto` means on wherever the bit is
  published, the drop-in included. So unless you gate your route on
  `--engine`, the REBOUND gate at `--arith rebound` covers it. Either
  choice is defensible; give your reason.

## What reading has turned up: verify it, do not trust it

Measured at `af2f400`:
- `gravity_body()` is defined at :1150. Line :1148 is a forward
  declaration, and mistaking it for the definition has cost an hour
  before.
- `build_scatter()` (:1053) is called from three places:
  - :1125, in `alloc_state()`;
  - :3225, commented "the rows depend on N too";
  - :3260, in `ias15_engine_set_active()`.

  Your tables are rebuilt at exactly those points, or they are wrong.
- The host's pair gathers are at :1153-1157 (`t_g_copy`).
- `energy_all()` (:2208) has its own copy of the gather, at
  :2222-2226. It is not gravity, it is not on the hot path, and it is
  part of every record. Leave it.
- `run_program()` is at :1393, `load_programs()` at :1385 and
  `alloc_state()` at :1083.
- In the pinned `cft.h`:
  - `cft_run_args`' `idx_a`, `idx_b`, `idx_c` and `idx_*_src` are at
    :3033-3034;
  - `idx_scratch_in` and `idx_scratch_src` are at :3035-3036;
  - they are documented from :2959;
  - `CFT_IDX_NONE` reads as +0;
  - `CFT_SEQ_FEAT_INDEXED` is at :974.

**Believed, from cft-fp256's docs: the indexed run folds in table order
from +0.** Your design rests on that claim. Read the software backend's
indexed run in the pinned `third_party/cft-fp256/host/src/` and confirm
it.

**A finding to confirm before relying on it.** The port's fold is
believed to start from +0 and to run in one static order for every
body. It is believed to do so under `N_active` and
`gravity_ignore_terms` too, where round 2's P2 reproduced REBOUND's
`(i, j<i)` loop under the skip. If any of that does not hold, the
indexed fold is a different sum. Design from what is actually there,
and say so.

**There are two traps that would each give a silent wrong answer.**
1. **The fold's order and its zero** (ROUND3.md):
   - +0 + -0 is +0. So a fold that starts from its first addend differs
     from REBOUND's `ax = 0; ax += ...` exactly when that addend is -0.
   - A tree fold, or `CFT_IDX_NONE` padding inside a sum that REBOUND
     never forms, changes bits only where the reordering shows.
2. **A table built for the old N.** A merge can remove a particle, and
   `set_active` can change the active count. A table that is not
   rebuilt then reads the wrong partners, or reads past its source.
   - The suite's two merge cases show this. They opt out of `--light`
     scaling by name (CLAUDE.md).
   - So do the `N_active` and test-particle cases.
   - Assert a physics counter there, such as "3 particles became 2",
     beside the route-equivalence comparison.

## Files you own

This is ROUND3.md's P1 list:
- `gravity_body()` and `build_scatter()`;
- the pair-table part of `alloc_state()`, plus the rebuild in
  `ias15_engine_set_active()` if the tables change shape;
- the new indexed program-run wrapper;
- a gravity section in `tools/gen_programs.py`, with one entry in its
  `main()`;
- one `load_one()` line in `load_programs()`;
- a new `tools/cases_gravity.c`.

## Files you must NOT touch

- **P2's, which P2 is editing now:** `pc_error()`, its two call sites
  (:1297 and :1457), `correct*()` and `step_attempt()`.
- **P4's, which P4 is editing now:** `predict_next_step_vec()` (:1467).
- **Nobody's this round:** `dtnew_*()` and `choose_timestep()`.
- **P3's, which P3 is editing now:**
  - `src/cft_archive.c`;
  - `src/cft_ias15*.{c,h}`;
  - `src/reb_integrator_cft.c`;
  - `tests/gate_*.c`;
  - `tools/check_checkpoint.py` and `tools/check_archive.py`.
- **P0's** probe, wrappers and gate, except for the two edits above. If
  one of them is wrong, report it.
- **The shared one-liners.** `gen_programs.py`'s `main()` and
  `load_programs()` each get one line from you and one from P4. That is
  expected, and the lead resolves it at merge. Keep yours to one line
  each.

## Gate

ROUND3.md's P1 gate and controls, all of them, plus:
- **every route combination your two switches allow**, at every format,
  on the route-equivalence case, with each run's `# route` lines
  asserted: on or off, `by=`, and `calls=` above zero where the route
  ran;
- **the library path's gate** reads `ias15_engine_route()` the same way;
- **`check_door.py`'s forced-off comparison** stops saying vacuous, and
  passes.

**Negative controls** (ROUND3.md). Run both, watch both fail, and
report the numbers.
- *Order:* on a problem first shown to be order-sensitive, which you
  name.
- *Route:* one index pointed at the wrong partner.

**Also priced, not built: the whole-program divide and square root.**
Report its instruction count and what adopting it would take. Do not
adopt it.

## Stop line

If libcft's indexed run cannot express the fold in the port's order,
stop and report. Do not invent a different summation.
