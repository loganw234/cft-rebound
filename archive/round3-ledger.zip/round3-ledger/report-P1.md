# P1's final report, placed verbatim by the lead (2026-11-02, about 10:50)

The work is done and the gates hold. P1's routes give records identical to `af2f400` on all 170 A/B runs at all three formats, and the full `make check` at the tip passes with 0 FAIL.

**Branch `round3-p1`, tip `d4e710b94654455e3db0f034978dc97ea85b4c62`.** My ledger entries went to `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop\P1.md`: four entries, timed 07:02, 07:14, 08:35 and 09:05. The lead has placed the first two.

## Decisions the brief asked for
- **What a force evaluation is now.** Three programs over the pairs, with the library's square root and divide between them:
  - `gravity-pair`, its six coordinates gathered through a table;
  - `cft_sqrt`;
  - `gravity-cube`;
  - `cft_div`;
  - `gravity-force`.

  Then one fold run per 256 partners. Before, it was 22 elementwise calls plus one add per partner.
- **Two switches.** `indexed` (the existing row) is the accumulate fold, and `pair_gather` (the new row, `CFT_REBOUND_ROUTE_PAIR_GATHER`) is the pair program's inputs. Both read `CFT_SEQ_FEAT_INDEXED`.
  - One switch can't give on/off and off/on, so both are needed.
  - The off route of each is the host's gather into the same program, run dense. So `calls=` and `program_calls=` are equal on all four combinations.
- **The hide hook with a shared bit** (measured): `CFT_REBOUND_HIDE_FEATURES` set to either name turns both routes `off by=hidden`. Forcing one on while the other is hidden is refused by name, rc 3. All four combinations are reachable through the two route variables.
- **Every mode, both halves.** The routes don't depend on `--engine program`.
  - Gravity's programs carry REBOUND's own roundings (no FMA, no divide), so they don't need `--arith fma`.
  - `check_door`'s forced-off comparison runs at the default engine, so it only goes live this way.
  - The drop-in's REBOUND cases (merges, `N_active`, `set_active`) then cover the routes.
  - The lead's option A couldn't be honest for the shared `indexed` row in the library half, so I took option B: images compiled in through the lead's fixed interface.
- **The brief's two confirmations, by reading:**
  - The fold can be expressed in the port's order, so the stop line was not reached. The pinned backend (`program.c` 2701-2742) zeroes every register and slot, loads stream a into r0, and fills the scratch block through the table, with `CFT_IDX_NONE` as +0. The order and the +0 start are therefore my program's: its slot order, starting from a zero stream.
  - `build_scatter()` matches REBOUND's loop (`gravity.c` 184-257), under `N_active`, the test-particle type and the ignored terms.

## What changed, file by file
- **`src/ias15_cft.c`**:
  - the new route row and its enum constant;
  - `vprog_ix()`, the indexed program-run wrapper beside `run_program()`;
  - `build_gravity_tables()`, called at the end of `build_scatter()`, so the tables are rebuilt at all three call points;
  - `alloc_pairs()`, split out of `alloc_state()`;
  - the new `gravity_body()`;
  - `gravity_reference()`, today's elementwise gravity kept verbatim, program-only, as the self-test's reference;
  - in `--door-selftest`: lines naming the compiled-in images, the wrapper's cases with 2 new controls, and 12 gravity configurations;
  - one `--door-refuse` case, `px-alias-pool`.
- **`tools/gen_programs.py`**: a gravity section and one line in `main()`. It writes 36 new files, `programs/gravity-*.cfta`.
- **New, to the lead's interface**: `src/cft_embedded_image.h` (byte-identical to the lead's block, SHA-256 `4f8dfa60…`) and `tools/embed_programs.py`. The generator writes `build/gravity_images.h` only when its bytes change: relinking unchanged source alters the executable (byte 137, the PE timestamp), which would otherwise spoil every gate-cache key on each run.
- **New gates**: `tools/cases_gravity.c` (drop-in topic) and `tools/check_gravity.py`.
- **Expected one-liners**: one declaration in `tools/dropin_cases.h`, one call in `tools/check_dropin.c`, one `REFUSALS` row in `tools/check_door.py`, and `CASES_SRC`.
- **Crossed boundaries, disclosed**:
  - Makefile: the header rule, `$(ASM): $(CFTLIB)` (which keeps P3's measured `-j` race from reaching `make -j all`), `-I$(B)` and the header on the three compile rules, and one `check_gravity` leg in each tier.
  - One comment line in `src/ias15_engine.h`.
- **Not used**: no `load_one()` line, because the images are compiled in. `energy_all()` is untouched.

## Gate output (actual lines, from the `make check` log)
`check_door`, at all three formats:
```
  ok   164 of 164 cases identical to the reference on both routes, 0 differ (rc 0)
  ok   indexed: both routes ran (47 calls through CFT_SEQ_FEAT_INDEXED, 44 through today's route), nothing left uncompared
  ok   pair_gather: both routes ran (28 calls through CFT_SEQ_FEAT_INDEXED, 26 through today's route), nothing left uncompared
  ok   CFT_REBOUND_ROUTE_PAIR_GATHER=on against a hidden CFT_SEQ_FEAT_INDEXED is refused by name (rc 3)
  ok   px-alias-pool is refused by name with CFT_REBOUND_ROUTE_INDEXED=on (rc 3)
  ok   outer fixed: 3 sample lines and all 8 counters identical; forced-off run reports every route off by=forced
```
The forced-off line no longer says "vacuous".

`check_gravity`:
```
  ok   fp256: 12 images carried, 12 in programs/out, all equal by SHA-256
  ok   kepler e=0.99, a rejected step: 7 sample lines, all 5 runs identical, counters and route lines as they must be; 60 steps, 1 rejected, 5185 force evaluations, 1 fold runs each
  ok   258 bodies, rows one past the widest fold: 2 sample lines, all 5 runs identical, counters and route lines as they must be; 1 steps, 0 rejected, 15 force evaluations, 2 fold runs each
  ok   1025 bodies, one past CFT_MAX_BODIES = 1024, is refused by name (rc 3): ...
  ok   check_dropin --light, gravity on today's routes: rc 0, every case passed; indexed=off by=forced calls=0 fallbacks=234027, pair_gather=off by=forced calls=0 fallbacks=234078
```
`cases_gravity`, the library half's gate through `ias15_engine_route()`:
```
  ok   route indexed=on by=device calls=234027 fallbacks=0 (the software backend, unforced: on by=device is required)
  (a merge removed one: 4 particles became 3, on both sides: 3 and 3)
  ok   N_active changed mid-run: the change reached the arithmetic, 36 of 36 values differ from the unchanged run
```
The body-cap force evaluation, from `--door-selftest`: `door gravity the body cap: N=1024 ... 523776 pairs, rows of at most 1023, 4 fold runs of at most 256; 3072 of 3072 accelerations nonzero, 0 are -0`.

## Full `make check`
Log: `C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P1\make_check_1.log`, at `d4e710b`.
- 16 legs, all full mode: the 15 existing plus `check_gravity`.
- 320 `ok` lines and 0 FAIL lines.
- One skip, the deliberate `body_count` one.
- Exit 0, 08:45:45 to 10:42:26, on a heavily shared host.
- The six `gate_real` digests equal entry 38's.

Also run:
- `check-python`: "IDENTICAL: 13 values"; its control: "DIFFERS: 9 of 13".
- The A/B against the base: 34 integrations at all three formats, each on the default route and the four forced combinations, 170 of 170 identical. All 510 counter pairs match (steps done, steps rejected, capped correctors). At binary64, every counter but `calls`/`program_calls` matches on 12 of 12 runs.

## Controls (each sabotaged build deleted after its numbers were kept)
| control | property | sabotage | with it | without it |
|---|---|---|---|---|
| Order (brief's) | the fold adds a row's addends in REBOUND's order | body 0's 2nd and 3rd addends swapped in the fold table | outer's binary64 record differs: fixed 3 of 230 fields, adaptive 126 of 230, program engine 85 of 184; `check_equivalence` FAIL on 3 outer cases, first at step 25 | 170/170 identical; `check_equivalence` passes |
| Route, `indexed` (brief's) | the indexed fold actually ran | one index of the table given to libcft pointed at the wrong partner, new route only | outer fixed: 148 of 230 fields differ whenever `indexed` is on, 0 when off; `check_door` and `check_gravity` FAIL | identical; both pass |
| Route, `pair_gather` (brief's) | the device gather actually ran | the same, on the pair table | 148 of 230 when on, 0 when off; both gates FAIL | identical |
| Trap 1 (mine) | the fold starts from +0 | fold started from −0 | caught by the self-test's signed-zero case (2 of 15 lanes) | passes |
| Trap 2, loud (mine) | tables follow the body count | tables never rebuilt | refused by name at the first body-count change: "idx_scratch_in[1] = 9 ... is at or past the 6 elements" | passes |
| Trap 2, silent (mine) | tables follow `N_active` | `set_active` skips the rebuild | `cases_pairs`: 155 of 198 configurations disagree with REBOUND; my `N_active` case differs in 57 values | passes |

For the order control, the problem shown to be order-sensitive is the outer solar system (rows of 5). Swapping the first two addends is inert by construction, 12 of 12 identical, because `(+0 + a) + b` equals `(+0 + b) + a`. Kepler and the Pythagorean problem are inert because their rows are too short to swap.

## Not done, and stated limits
- No card and no speed claims. The divide and square root are priced, not built.
- **Self-test power.** A single force evaluation in the self-test did not catch the order swap; `check_door` passed on that sabotage. The fold's order is held at binary64 by the REBOUND gates over whole integrations. At binary128 and binary256 it is held only by my manual A/B against the base; no automated wide-format gate catches a swapped pair.
- **"One run per force evaluation" holds up to 257 bodies.** On a 256-deep device (the software backend, the f128 image), 1,024 bodies takes 4 runs. A row of R addends can cost up to 2R−1 adds of +0, which are exact.
- **Device requirement.** Gravity's images need SCRATCH and SCRATCH_IO. A device without them is refused by name at the first force evaluation, and the process exits in both halves, as every libcft error already does in the library half. Not measured on a real device.
- **Table size.** A pool of 2³²−1 elements or more (715,827,883 pairs) is refused by name. Checked by reading; too large to exercise here.
- **Library-half coverage.** The library half takes one route combination per process. The suite runs both-on, and in full mode both-off; the mixed combinations run only in the program half.
- **Test particles.** The standalone program has no `N_active`; true test particles are covered in the drop-in and the self-test.
- **Arity.** P0's stated limit carries over: a table on an input the program doesn't read is not refused.
- **Gate cost.** The binary64 self-test takes 35 s against the base's 7 s.

## Priced, not built: the whole-program divide and square root
Measured by assembling the pinned sources; all six digests match the pinned MANIFEST.
- `divfull` is 212, 214 and 216 instructions at binary64/128/256, with 42 external constants and 2 deposits.
- `sqrtfull` is 189, 192 and 195 instructions, with 49 external constants and 2 deposits.
- Both need wide constant indices, 32 registers and an external bank, all present on the f128 image.

Adopting it would make the pair chain one program of about 440 instructions at binary128. That means:
- re-allocating both programs' registers into one frame;
- merging over 91 constants plus the 5 rounding-mode words;
- reading the result from deposit 0 and the contract's flags from deposit 1, rather than from the run's flags. The run's own flags come from the Newton steps. libcft mutes them with an internal call, and a caller would need revision 8's flag-control regions, which the f128 image lacks.

cft-fp256 measured it slower per element: 2.33 against 1.70 µs, and 1.185 against 1.01 µs after sequencer revision 5. Your card table puts the divide and square root at 45–61% of a step at 256–512 bodies, so this is the item to weigh next.

## What the brief or ROUND3.md got wrong
- **"One `load_one()` line":** it's program-only; routes in the library half need compiled-in images.
- **"One indexed run per force evaluation":** it's one run per 256 partners.
- **"The pair arithmetic as one program":** it's three, because the square root and divide sit between them as library calls.
- **"The indexed run folds in table order from +0":** libcft only gathers. The order and the zero belong to my program. The substance holds, by construction.
- **The card day's image:** entry 37's f128 image publishes neither `CFT_SEQ_FEAT_INDEXED` nor `CFT_FEAT_REDUCE_SEG` (read from the docs). You now run the routes on rev8a.
- **`calls=`:** it is equal across routes, but moves against `af2f400` (for example 321,432 becomes 269,956 on Kepler fixed).
- **P0's comment** that "P1 the gather" uses `vrun_ix()` is now wrong: `vrun_ix()` stays unused. I reported it rather than changing P0's code.
- **Integrator-only files that should change:**
  - README.md:466–468: add the new variable.
  - README.md:481: say the hook hides a bit, so both routes hide together.
  - README.md:488–491: say `--engine` now governs only the predictor and corrector.
  - docs/HARDWARE.md:130–135: the accumulate program is built.
  - ROADMAP.md:679–681: what the gravity split's keys now hold.
  - docs/VALIDATION.md entry 40.
