# V1's report on P1 (d4e710b), placed by the lead (2026-11-02, about 13:40)

V1's final message, condensed where it repeats V1.md, its ledger entry with two corrections and an addendum. V1's figures throughout. V1's scripts, logs and sabotaged trees are in ...\scratchpad\V1\r3\.

**SENT BACK, 1.** P1's engine gave the base's records in every integration V1 ran. The blocking finding is in a test case, not in the engine.

## (a) tools/cases_gravity.c holds M4 only on software with no door variable set

- **Where.** The by= check runs only when `software && unforced` (cases_gravity.c:90-93, 104). `unforced` is false once CFT_REBOUND_ROUTE_INDEXED, _PAIR_GATHER or HIDE_FEATURES is set to anything. `software` is false once CFT_REBOUND_ARTIFACT is set. In every other case the test accepts whichever route opened, including the impossible `off by=device`.
- **The sabotage.** Set `route_on[ROUTE_INDEXED] = route_on[ROUTE_PAIR_GATHER] = 0;` after engine_routes() in ias15_engine_open(). Measured, with `check_dropin --light`:
  - With no door variable: rc 1, "2 FAILURES", including `FAIL route indexed=off by=device calls=0 fallbacks=234027 (the software backend, unforced: on by=device is required)`. Caught.
  - With CFT_REBOUND_HIDE_FEATURES=scalar: rc 0, "every case passed", `ok   route indexed=off by=device calls=0 fallbacks=234027`. Not caught.
  - The clean copy with the same variable: `on by=device calls=234027 fallbacks=0`.
- **The property it breaks.** urgent/lead-p1-route-case.md's second clause, brief-common corrections 1 and 3, and brief-P1's library-path gate. P2's 53ffd5f shows the shape of the fix.

## (b) Should be fixed, need not block

1. **vprog_ix()'s claimed refusals are untested, apart from the overlap rule (px-alias-pool).** Its comment claims refusals of:
   - a NULL stream a;
   - a table on a NULL input;
   - a table beside a zero-element source;
   - a table on an undeclared block;
   - an index past its source on today's route.

   Two sabotages pass check_door --formats fp64 and check_gravity --quick, rc 0:
   - no_src_check: today's route's bound check removed;
   - no_null_zero: the NULL-source and zero-source refusals removed.

   P0's vrun_ix has cases for the same rules, ix-table-on-null and ix-zero-source.
2. **P1's self-test limit is false at binary128.**
   - Full-mode check_records fails "outer_fixed_dt40_fp128: sample 1 (step 365) column 3", for both swap variants V1 built: order12, three lanes swapped, and order12x, the x lane only.
   - check_door at fp128 fails order12: "160 of 164 … 4 differ".
   - order12x passes check_door at every format, as P1 says.
   - At binary256 nothing automated catches either variant. gate_real's six digests move, but it exits 0.
3. **m4_lie passes everything.** A route that counts itself as taken while today's route runs passes check_door, check_gravity and check_dropin. On software both routes compute the same thing, so state it as a limit rather than gate it.

## Minor notes (V1)

- check_gravity's "a rejected step" case prints the rejection but does not assert it.
- find_fold_widths() filters on max_scratch but not max_insns. gravity-fold256 is 514 instructions, and the documented images have at least 16,384.
- The "twice its own length" cost comment holds only for the longest row.
- Under load, the fp64 self-test took 69-86 s, against the base's 7-10 s.

## Held

- **Records, all identical:**
  - program half, default routes: 108 of 108 pairs over 39 configurations;
  - program half, four forced combinations plus the default: 120 of 120;
  - library half: 56 pairs, including the forced combinations at binary128 and binary256.
- **P1's six controls** reproduce with P1's numbers.
- **Gates:**
  - check-light: 16 legs, 250 ok, 0 FAIL;
  - check_door at all three formats: 164 of 164 each, with the forced-off comparison live;
  - check_gravity --library: pass;
  - check_records: pass;
  - check-python: pass, with its control.
