# urgent-P3-launch-quotes — the PowerShell-to-Git-bash launch (lead.md 13:40, "measured by P3") cuts the -c string at the first quoted space; a make target after it is dropped

2026-11-02 15:10, P3.

Measured (Windows PowerShell 5.1 running `& "C:\Program Files\Git\bin\bash.exe" -c '...'`, software backend, nothing on the card):
- `-c 'echo make CFT_REBOUND_ARTIFACT="C:\some dir\image.bin" check-light; echo second command ran'`
  prints `make CFT_REBOUND_ARTIFACT=C:some` and nothing else. PowerShell
  5.1 passes the string's embedded double quotes unescaped, so the
  command line is re-split at the first space inside them. The target
  and every later command are gone. As `make`, that line would build the
  default goal and could exit 0 without running a suite.
- A quoted value WITHOUT a space survives, but loses its quotes, so bash
  eats the backslashes. My check-light launches for d8ae085 (13:35) and
  for this follow-up (14:48) used that form. make received
  `TMP=C:UsersloganAppDataLocalTemp TEMP=C:UsersloganAppDataLocalTemp`
  (measured by echoing the same line). The suite's Python temp
  directories went to C:\WINDOWS\Temp. My closing `echo "MAKE EXIT $?"`
  printed only `MAKE`, so neither run printed make's exit status. Their
  legs passed: no FAIL line, and every leg that ran recorded a pass
  stamp. But they ran under a TMP other than the one written. The 08:30
  run, started another way, used the user temp.
- A script file avoids all of it. Put the make line in a .sh file and
  start it with `& "C:\Program Files\Git\bin\bash.exe" C:/path/to/x.sh`.
  Started that way, make receives `TMP=C:\Users\logan\AppData\Local\Temp`
  and the exit status prints. Mine is
  C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-cft-rebound\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\P3\check-light.sh.
  It prints each argument make receives.

Believed: any `-c` string that holds a double-quoted Windows path or a
quoted value with a space is affected, whatever the target. That
includes CFT_REBOUND_ARTIFACT for a card run. PowerShell 7.3 and later
pass embedded quotes differently. Not tried: this host runs 5.1.

For: the lead (the merge suite's launch), V3.
