You are parcel **P3** of round 5 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `5b1cac6`, main where round 5's P0 landed. **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 5b1cac6` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. tools/compare_run.py (round 4's P4) holds a run's records against this tree. It reruns each sampled member and compares every column. It samples particles by replaying them out of their wave through round 4's P3 tool, against the attempts record and corrector schedule **its own rerun** wrote. A GPU run of 10^6 particles cannot afford a rerun of every member whose particles are sampled. docs/RING.md: "To sample its particles without a rerun, a GPU run must write each wave's attempts record and corrector schedule, and the driver must take them: not built." **Your parcel builds the driver's half: compare_run takes a producer's own files.** CPU only; no GPU.

## Start here

1. `ROUND5.md`, all of it, then its **P3** section, which defines your job.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`, §1 and §5.
3. docs/RING.md, and docs/VALIDATION.md entries 49 (the replay, rejected attempts included), 50 (compare_run) and 51 (the P3 x P4 wiring, controls p and p2).
4. The code, at your base:
   - tools/compare_run.py: `rerun_cmd()`, `p3_replay()`, `sample_particles()` and `particle_compare()`;
   - tools/check_compare_run.py: its cases and every control;
   - tools/extract_particle.py and tools/check_replay.py;
   - src/ias15_cft.c: `--attempts-out`'s writer, `--record-iters` and `--replay-iters`, and the schedule's run key, `sched_key()`;
   - a record's header lines, which name the member and its run.
5. `CLAUDE.md`, all of it, especially "A rejection leaves state only before the first accepted step" and "A planted control holds only the column, line and format it sits in".

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there at three moments: before you start, before you design anything ROUND5.md calls shared, and before you report. The file names and formats a producer must write are shared with P2, whose kernel will write them. Append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P3.md`. Anything that must not wait goes in the same drop as `urgent-P3-<slug>.md`. **Arm a watcher on `.ledger\urgent\` first.**

## Your job

1. **The files.** compare_run takes, beside a producer's record, each sampled member's attempts record and corrector schedule, in the formats `ias15_cft --attempts-out` and `--record-iters` write.
   - Design how they are named and found: an argument naming a directory, with a file name per member, for one. Write it down in the ledger for P2.
   - An absent file falls back to today's rerun, and says so by name in the output.
2. **The replay.** When the files are given, particles are sampled by replaying them against the producer's own schedule, with no rerun of the member.
   - The member's own lines are still held as today: a rerun where the driver chooses one, or the record alone where it does not. Say which, and why.
3. **The run key.** A schedule recorded for another wave, another format, or another problem line (`active`, `zonal`) is refused by its key, by name, as `--replay-iters` refuses today.

## The gates (in tools/check_compare_run.py, its leg in all three tiers, every executed artifact an `--input`)

1. **The same particles.** With `ias15_cft` as the producer, each sampled particle replayed from the producer's own files is IDENTICAL to the same particle replayed from a rerun's, at every format the case runs. Include a wave with a first-attempt rejection, the one rejection that leaves state.
2. **The physics beside it.** Each particle's counters, steps and passes, and its closest approach at the samples, are printed and asserted, as case 1 does today.

## Negative controls (each from a copy, shown failing by name, then deleted)

- One change planted in the attempts record: one attempt's dt, on more than one line, including the first attempt.
- One change planted in the schedule: one pass count.
- A schedule from another wave of the same ring: refused by its key.
- A schedule whose run key's `zonal` field differs: refused.
- **A mutant of compare_run** that reads the files but replays against a rerun's schedule anyway. The gate must catch it: the "same particles" gate must not pass against itself.

## Files you own

- tools/compare_run.py.
- tools/check_compare_run.py.
- `Makefile`: check_compare_run's `--input` lists, if it gains inputs. The lead merges the Makefile's conflicts.

## Files you must NOT touch

- src/: the files' formats are `ias15_cft`'s as they are. A change to them is reported first.
- tools/extract_particle.py and tools/check_replay.py, which you run. A change you need is reported first.
- P1's tools/check_gpu.py, and P2's src/wave/ and tools/check_wave.py.
- The integrator's files: README.md, ROADMAP.md, CLAUDE.md, docs/, ROUND5.md and third_party/MANIFEST.
- ../cft-fp256, which you read and never write.

## Building and testing on this host

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional; no `make -j` in a fresh tree.
- Run your gate and `make check-light` while you work.
- Before you report, run a full `make check`, booked in the TimeSheet as `desktop` shared and started from PowerShell (CLAUDE.md, "Launching a long suite from an agent"):

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book desktop --mode shared --from now --until +3h --who cft-REBOUND/P3 --why "<what>" --pid <pid>
  ```

  **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **Every committed record stays byte for byte where it is.**
- **Bit-identity is not validity.** Print the physics beside every comparison.
- **A gate that cannot fail is not a gate.** A mutation script must refuse to run unless its edit lands exactly once.
- **Derive; never transcribe.**
- **Label every claim** MEASURED or BELIEVED.
- **Never bare `git stash`.** No GPU, no WSL, no card. **No speed claims.**

## Do not

- push, merge or rebase, or commit to main. Commit inside your worktree only.
- change what an existing record, schedule or attempts file means.
- "fix" anything outside your scope. Report it instead.

## Report

- what changed, file by file;
- the gate output, as **actual lines**;
- each control, with its numbers;
- the file naming and the format a producer must write, as P2 will read them;
- what you did not do;
- **anything you found that this brief or ROUND5.md got wrong.**

If something makes the approach unworkable, stop and report it.
