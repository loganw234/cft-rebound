(R5-VL's report on the lead's p1p2_seam.py fix, c9e39a38545d5599, its final message on 2026-11-20 at ~01:40, copied verbatim by the lead.)

**Your p1p2_seam.py change (sha c9e39a38545d5599): READY.** Both changes are right, and every check you listed fails by name through the script's own `main()`. The only gaps are cases today's kernel cannot produce; three one-line fixes below close them.

I left your files untouched (the sha is unchanged) and wrote no bytecode next to them. My scratch is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\seamtest\`; the ledger entry is "2026-11-20 01:40" in VL.md.

**1. Scope — confirmed (READ).** `diff -u` against .orig-7444157 shows only these changes:
- the docstring;
- `DEVICE_PREFIX`;
- `parse()` putting `# device ` lines into their own list and setting them aside;
- on a GPU, the kernel's wanted backend becomes `hip:0:<arch>`, the arch taken from its one device line;
- the record verdict says "want" instead of "asked for", and gains a detail line naming a wrong backend;
- one new verdict for the device line.

`compare()`, `plant()`, the controls, and sections 3 and 4 are unchanged.

**2. Nothing new hidden — confirmed.**
- Only lines that start with `# device ` (with the space) are set aside (READ).
- An unknown header still FAILs (MEASURED): `# devices hip:0` in the kernel's record, `# devicehip:0 =` with the space missing, and `# note x` in the hip record each FAIL 7 to 9 verdicts.
- On the saved records the value comparisons and the 11 controls give exactly 0125's results: 24 ok, and each control fails with its one planted difference (MEASURED).

**3. The new checks bite through your own code — confirmed (MEASURED, vl/vl_seamtest.py).** I loaded your file by path and replaced its `run()` with a stub. The stub answers from the 0100 run's saved records, the hip run's probe line, and the saved compare_run logs. Then I called `main()` on edited copies of the records.

| change to the saved records | verdicts that FAIL |
|---|---|
| no device line | the wave record (backend) and the device verdict |
| two device lines | the wave record and the device verdict |
| another GPU named | the device verdict |
| a device line in the cpu record | the device verdict ("cpu 1") |
| a device line in the hip record | the device verdict ("hip 1") |
| `backend=gpu` | the wave record ("want hip:0:sm_120") |
| another arch in the backend | the wave record |
| another arch in the device line only | the wave record ("want hip:0:sm_89") |
| another device index in the backend | the wave record |

Three cases still pass with no FAIL:
- the device line's own index changed (`# device hip:1 = …`): 24 ok;
- the arch changed in both the device line and the backend together: 24 ok;
- with `--dry-host`, a device line in any record is set aside with no verdict at all: 22 ok.

None of these can come from today's kernel (READ). `gpu_open()` builds the device line and the backend from the same device index and arch, after `hipSetDevice(0)`, and a host run writes no device line.

**4. The two logs — confirmed (MEASURED).** 0100 has 23 verdicts and 0125 has 24:
- 15 have the same outcome in both;
- 8 flip from FAIL to ok: the wave record, wave against cpu, and the six wave controls;
- 1 is new: the kernel record's device line.

**5. The right change — yes (READ).**
- The device line is P2's deliberate design: wave_main.cpp:28-29 and :531. The 46ddfed commit says "the proof the GPU ran is its own description, not a backend= the program writes".
- check_wave holds it: exactly one per GPU record, equal to the probe's line, with `--expect` in it (check_wave.py:1099-1110 and 1208-1209 at 7444157).
- compare_run never needed to know the line. It holds header lines one way only, so a line only the producer writes is allowed to stand (compare_run.py:873-877).
- The kernel writes `backend=hip:<index>:<arch>`, cut at the first ':' (wave_gpu.inc:118-119). So the old wish for `backend=gpu` never matched P2's code.

**Optional, not blocking** (BELIEVED to cost one line each):
- Hold the kernel record's device line equal to the `--device-info` line from section 0, as check_wave does. That also catches the index and both-arch cases.
- With `--dry-host`, require no device line in any record.
- Let the arch regex accept ':' as well as ',' after the arch, the way the kernel cuts the backend. A gcnArchName with feature flags (`gfx90a:sramecc+:xnack-`) fails today, which is the safe direction, and neither of today's two GPUs has such a name.

**READY**
