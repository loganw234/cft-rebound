(R5-VD's report on its second look at the records' phase 1, a2c84fb, its final message on 2026-11-19 at ~10:40, copied verbatim by the lead.)

D fixed all nine defects and the four minor items, and each fix matches its source when reread. D was right about the three-wave ring and I was wrong. **READY for phase 1**, with one optional one-word change.

I worked read only at a2c84fb; the worktree is clean, and I ran no build and no suite.

**1. The thirteen items: all fixed**
- **D1:** README.md:815 now says "on the RX 7600", which is the only column entry 55's leg table has.
- **D2:** entry 55 now names "P2's check_wave runs and mutants… under B0171 until 17:35", which matches P2.md 17:37 and lead.md 19:52.
- **D3:** "P2's suite" is gone from entry 57. That suite ended at 09:27:33 and B0131 was released at 09:28 (P2.md 09:28; lead.md 12:49).
- **D4:** ROUND5.md, RING.md and entry 57 now say the member is held, NOT RERUN, both its particles IDENTICAL, in a GATE 1b run that ends rc 1. That matches check_compare_run.py:836 (`rc1 == 1`) and the log's "(rc 1)". RESULT: PASS is now credited to V3, which item4.log:44 confirms. The "(rc 1)" added to GATE 1b's bullet matches the log.
- **D5:** "the arithmetic that reaches its samples and trailer", with the entry-49 caveat. It is word for word what compare_run.py:157–159 says.
- **D6:** each of V3's looks is now described as it happened:
  - first look: P1's and part 3's patterns (V3's first report, items 3 and 8);
  - second look: those and P2's, on three cases at both commits (second report, item 2);
  - third look: by reading, with check_wave.py:361–364 unchanged (third report, item 7).
- **D7:** RING.md now gives the exception and cites check_gpu.py:565–570 and :562; I reread both at fda3b40. Its new "does not hold" bullet matches V1's first report, item 3. The README clause is right.
- **D8:** ROUND5.md:189–192 is corrected in place from P1's report, item 3, so entry 55's "had" is now true.
- **D9:** "two fewer on an accepted first attempt" matches P3.md 11:34, where member 4's first attempt was accepted (q1). The 8 tokens at binary256 since 0bee543 match the suite log.
- **Minor 1:** "ten in their quick form and check_dropin in its `--light` form" matches GPU_LEGS (ten from check-quick, one from check-light).
- **Minor 2:** "[the same variables as the build]" is now in RING.md's usage line.
- **Minor 3:** the README now cites Makefile:837, the recipe line that passes `--hip '$(HIP)'` on every OS.
- **Minor 4:** entry 50 now carries a bracketed correction. The one word to change is in it: "every `hip:0` record holds the pair at the software backend's bits (entries 54 and 55)" is broader than those entries, which hold every record they measured. Suggested: "every `hip:0` record measured". Not blocking.

**2. D4's deviation: D is right, and my "two-wave ring" was wrong.**
- item4.py:21–24 uses `ring3_z.txt` with `E, N = 3, 64`.
- item4.log:43–44 reads "first attempt's passes 4 -> 2 … 2 of 3 sample lines not this tree's", then "RESULT: PASS: 1 sampled member(s) of 3 … 2 member(s) not rerun".
- item4.py's docstring says the ring is make_ring.py's, which entry 57 now states.

**3. The fix beyond the list: right.** Entry 55's legs bullet at :7269–7274 contradicted itself: it said "each in its quick form" and then "check_dropin_light as check-light runs it". It now matches GPU_LEGS and check_gpu.py's header.

**4. Nothing else moved: confirmed.**
- `git diff 4980440 a2c84fb` has 16 hunks: README 3, ROUND5.md 2, RING.md 4, VALIDATION.md 7. Each is one of the fixes above.
- Every new number or reference has a source: Makefile:837, check_gpu.py:565–570 and :562, check_compare_run.py:836, check_wave.py:361–364, entry 49, the 8 tokens, the three-wave ring, B0171 and 17:35.
- The added lines hold no placeholder, no empty cell and no gendered pronoun.
- The cft-fp256 provenance row is byte-identical, still at line 182 (`cmp`). Both check_pins README tests pass by hand: one row, and its commit cell begins with eae74e3.

**5. LEAD-FILL lines: exactly five**, at ROUND5.md:9 and :411, RING.md:327, and VALIDATION.md:7661 and :7936.

**READY** for phase 1.
