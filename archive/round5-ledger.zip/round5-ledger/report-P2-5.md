(R5-P2's report on send-back 3, 1e13456, its final message on 2026-11-19 at ~17:27, copied verbatim by the lead.)

Send-back 3 is done: commit **1e13456** on f3ef701, tools/check_wave.py only (+221/−29), not pushed or merged. The tree passes both forms, and all eight mutants fail by name. Everything below is MEASURED on the desktop unless marked READ.

**What changed** (READ, from the diff)
- **Each copy is checked against the clean record, value by value.** A new function, `measured_plants()`, does the comparison. A copy is refused by name unless it holds exactly its planned values: member, column, body, and the sample number of the first or last sampled line its plan names. That sample number is read from the record itself, not from the line the planting code chose. So an empty copy, a value on the wrong line, or an extra value fails.
- **`coverage()` is now its own function and works from the measured values only.**
  - It reads the classes itself, with `own_columns()` (the `# columns:` words, `# active`, each member's sample numbers and trailer keys) and with `COUNTERS`.
  - `record_classes()` must agree with that reading: the classes, the counters (compared as a set of keys), the member count and the active count.
  - It finds each member's first and last sampled lines itself, and requires them to differ.
  - A member counts as left out only in a copy that planted another member and in which compare_run held it IDENTICAL with both its particles.
- **One addition beyond V2's three points.** The particle class now counts only on a body that the clean compare_run replays for that member, and each replayed particle must be planted on its own body. Without this, a plant on a particle no replay carries passes the per-plant verdicts ("0 of 2 carry it ... ok") and would pass coverage too.

**The tree:** quick RESULT: PASS, 92 ok, 0 FAIL; full RESULT: PASS, 101 ok, 0 FAIL. That is 81 and 90 as at f3ef701, plus one new verdict for each of the 11 copies.

**Mutants.** Each edit lands exactly once or the script refuses; I showed the refusal at 3 landings and at 0. Every run below ended RESULT: FAIL.

| mutant | quick ok/FAIL | full ok/FAIL | what FAILs |
|---|---|---|---|
| step class dropped (V2) | 83/1 | 92/1 | coverage: `record_classes()` disagrees; step missing on both lines in all 3 members |
| max_pc_iterations dropped (V2) | 91/1 | 100/1 | coverage: counters disagree; the column was never planted |
| `[1:]` → `[1:2]` (V2) | 87/5 | 96/5 | copies 2, 4, 6, 8 refused (sample 3 planned, sample 1 found); coverage names the last-line gaps |
| left-out copies past the end (V2) | 90/2 | 99/2 | copy 11 holds NOTHING; coverage: no member ever left out |
| (iii) member 2 never planted | 81/1 | 90/1 | coverage, member 2's gaps |
| (iv) no counter planted | 83/1 | 92/1 | coverage, all counters |
| particle plants on body 7 (mine) | 91/1 | — | coverage: particle class not planted |
| last particle plant on the seeded particle (mine) | 91/1 | — | coverage: bodies 27, 48, 52 never planted |

I ran my two only in the quick form, because V2 measured that the plants are the same in both forms.

**The 27 compare_run mutants: not rerun.** `plants()` and the per-plant verdicts are unchanged (READ), and a new verdict can only add FAILs. In send-back 2's logs, none of the 27 failed on the coverage verdict alone; each had 1 to 31 other FAILs.

**Two false starts.** Neither is counted above.
- 15:29: the first quick run failed 91/1 on my own new check, because the trailer lists the counters in a different order from `COUNTERS`. They are now compared as sets.
- 15:46: I stopped the runs after 3 minutes to make the planned line come from the plan rather than from the planting.

**One gap left as is:** the massive class is planted on bodies 0–5 and never on body 6, the seventh. No send-back asks for it, and fixing it would change `plants()`, which would mean rerunning the 27.

**Housekeeping**
- All 16 runs were on the desktop, booked shared as B0203 (15:29–17:25, now released), with at most three of mine at a time.
- The ledger entry is in P2.md under 17:25.
- Nothing of mine is running.

Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\sb3:
- run3.log
- tree_quick.log
- tree_full.log
- mut\<name>\quick.log and full.log
- mutants3.py
