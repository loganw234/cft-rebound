(R5-VL's report on PL's send-back 3, 4fcd775, its final message on 2026-11-19 at ~13:50, copied verbatim by the lead.)

**PL's send-back 3 (4fcd775): READY for the merge.** It does exactly what it says, and closes the constants gap from my item 4b.

Worktree detached at 4fcd775, whose parent is e8a7d89. Every run took under 10 minutes, so I booked nothing, and none of my processes are running. The ledger entry is "2026-11-19 13:40" in VL.md.

**1. Scope — confirmed (MEASURED).**
- `git diff e8a7d89 4fcd775` changes the Makefile only, 3 lines. Each is the constants line in check, check-quick and check-light gaining `--input third_party/rebound/src/integrator_ias15.c`.
- My extractor ran `make -n` of all three tiers under both Makefiles, in a built tree and a fresh one. For the fresh tree I moved build/ and programs/out into scratch and back; all 105 hashes matched afterwards.
- In all six cases only the constants leg changes, and only by that file. The other 24 legs have identical inputs and commands.
- 4fcd775 gives the same sets fresh and built, no input is listed twice, and e8a7d89's sets equal this morning's.

**2. My constants control — confirmed (MEASURED; vl/sb3.sh, logs/sb3.log).**
- The edit refuses unless it lands exactly once. The bare h[1] literal was refused ("lands 2 times"), and so was a second application ("lands 0 times"). Anchored on the `h[8]` line, it lands once.
- e8a7d89's constants line SKIPPED (4210bd53eb4f), both before the edit and after it.
- 4fcd775's line:
  - first run: PASS, stamp 0e3b9434b62f (the same key PL got);
  - second run: SKIPPED, so the stamp held;
  - after the edit: ran and FAILed, rc 1, "FAIL h[1]: derived 0.05626256053692215, REBOUND literal 0.056262570536922143 … DERIVATION CHECK FAILED".
- Through make: `make -o third_party/rebound/src/integrator_ias15.c check-quick` stopped at the constants leg with rc 2 and "Error 1". The `-o` kept REBOUND from being rebuilt off the edited file, and the log has no compile line.
- Restored from a `cp -p` copy: sha256 085a0bcb, the baseline, and the clone's `git status` is empty. The line then PASSed with the same key, 0e3b9434b62f, and a warm run SKIPPED.
- The worktree's `git status` is empty, and all 189 non-build baseline hashes match.
- Every step except the one make run used the line exactly as `make -n` printed it. I did not show the final PASS and warm SKIP through a full `make check-quick`: it would rerun 11 legs whose stamps my item 8 run left keyed on other image bytes, about 35 minutes.

**3. PL's third_party sweep — agrees (MEASURED, from item 8's trace of e8a7d89's check-quick; no new run).**
- constants reads only `third_party/rebound/src/integrator_ias15.c`.
- check_corrector reads only cft-fp256's programs/MANIFEST, which is in its key.
- check_zonal reads exactly nine cft_golden modules (__init__, augmented, chars, formatof, formats, reduce, softfloat, transcend, vectors), all in its key. Its listings of python/ and cft_golden/ come from Python's import machinery.
- The other 22 legs read nothing under third_party/.
- The trace covers the quick tier only. In the full tier these legs differ only in formats and step counts (READ), so I expect the same files (BELIEVED).
- PL's lazy path, vectors.py:520-538, imports host/tools/pi_worstcase.py only when called. The trace never imported it (MEASURED), and check_zonal calls nothing in vectors (READ).

**4. Anything else that moved.**
- No other file, leg or command changed (MEASURED).
- After the merge, every tree's constants stamp is invalidated once, and the leg reruns in about 10 s (BELIEVED).
- In a tree without the rebound clone, gate_cache would now stop with "no such input" instead of skipping. But check-pins runs first and already fails on a missing clone (READ, tools/check_pins.sh).
- check-gpu reads only the command after `--`, and constants is not one of its legs, so it is unaffected (READ).
- I agree with PL that MANIFEST is not needed in this key: the file's bytes are now keyed, and it is the leg's only read under third_party/.

**READY**
