(R5-PL's report on send-back 1, its final message on 2026-11-19 at ~08:28, copied verbatim by the lead.)

Send-back 1 is done: the `check_ensemble` fix is the third commit on `round5-pl`, both checks you asked for came out as expected, and nothing was pushed or merged.

**Tip:** `cc3d87a73134c8d4787bffc6807060e4c76bc485`, after 3012353 (Fix 1) and 5fa7534 (Fix 2).
```
$ git diff --stat fda3b40..cc3d87a
 Makefile                   |  20 ++++++--
 tools/check_compare_run.py | 123 ++++++++++++++++++++++++++++++++++-----------
 2 files changed, 111 insertions(+), 32 deletions(-)
```
`git diff --stat 5fa7534..cc3d87a` is the Makefile only, 3 lines in and 3 out: `$(IN_PROGS)` added to the three `check_ensemble` lines and nothing else. `git status --short` is empty after the commit.

**1. The keys (measured).** I ran `mkn.sh` and `legs_inputs.py compare`, 5fa7534's Makefile against the fix, in all three tiers. The fresh tree is my worktree with `build/` and `programs/out` moved aside, then put back.
- In both the fresh and the built tree, only `check_ensemble` changes: its inputs go from 8 to 74, the 66 images added.
- Every other leg's input set is unchanged.
- The fresh sets equal the built sets under both Makefiles.
- 11 legs now list `programs/out`, and all 11 list the same 66 files.

**2. The cache control (measured).** This ran in my worktree's own `build/` and `build/.gate-cache`. Each run was the check-quick `check_ensemble` line exactly as `make -n check-quick` printed it under each Makefile.

The image is `programs/out/predict-ens-fp64.cftp`. Two reasons I know the leg loads it:
- **Read:** `load_programs()` (`src/ias15_cft.c:1966`) loads `predict-ens` only for program-engine ensembles with adaptive steps (`:4676`). `check_ensemble --quick` runs at fp64 and has two such cases.
- **Measured:** I ran its "kepler vscale E=5 adaptive eps=1e-9, program engine" case on a copy of `programs/out` without that file. It exits with rc 3, "cannot open program image …/predict-ens-fp64.cftp". Member 0 run alone on the same copy is rc 0.

The change is one byte, offset 0x24, 0x06 to 0x05. On a scratch copy it changes 5 of the ensemble's 10 data lines; the member run alone changes only its timing fields.

| step | 5fa7534's line | the fix's line |
|---|---|---|
| first run | PASS, stamp `fd5db2bb532a`, 8 inputs | runs (its inputs differ), PASS, stamp `d5dbf84d504a`, 74 inputs |
| run again | `check_ensemble: SKIPPED - inputs unchanged since it passed (fd5db2bb532a, quick run)` | SKIPPED (`d5dbf84d504a`) |
| byte changed | **SKIPPED**, the same line | **ran**, rc 1, RESULT: FAIL; the 2 FAILs are the two adaptive program-engine cases ("member 0: first difference at sample 1"); stamp retired |

After restoring the image, all 66 hashes match the baseline, and the fix's line runs again and PASSes with the same key. I then ran `make programs`: its 66 sha256 equal the baseline taken before the control. So `programs/out` is exactly what `make programs` writes, and the tracked `.cfta` files are unchanged. Each `check_ensemble --quick` run took about 51 s and the whole control about 5 minutes, so nothing needed a booking.

**Found, not fixed** (read from the scripts; you said nothing else):
- `check_ensemble`'s key still lacks `tools/check_equivalence.py` (imported, line 24) and `tools/make_ensemble.py` (run, lines 118-125). `check_program_engine`'s key lists both.
- `check_records` imports `check_equivalence` (line 23), which is not in its key.
- `check_bodycount` imports `check_equivalence` (line 41) and runs `make_nbody.py` (line 66); neither is in its key.

None of my processes are running. The ledger entry is "2026-11-19 08:27" in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\PL.md`.

The step log and probe logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\pl\cc\`; `steps.txt` has the step log, and `load_probe.log` and the `probe_*` files have the probe output.
