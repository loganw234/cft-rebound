(R5-P3's third report, its final message on 2026-11-18 at ~08:49, copied verbatim by the lead.)

P3's send-back 2 is committed as `e3f6a39` on `worktree-agent-a35562c26dc613fed`, one commit on 0bee543. All seven items are done. The gate passes in all four forms, and every mutant fails it by name.

- **Commit:** tools/check_compare_run.py (127 lines changed) and tools/compare_run.py (18), +100/−45. Nothing is pushed, merged or rebased, and the worktree is clean.
- **Ledger:** the entry is in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P3.md`, headed 08:45.
- **Housekeeping:** booking B0141 was released at 08:44 and the urgent watcher is stopped. I ran no full make check, and I make no timing claims because the host was shared.

**Items**

1. **Whole lines.** `limit_once()` passes only if exactly one line equals PRODUCER_LIMIT, it comes after the plan line, and no other line opens with the limit's words. I unit-checked it on nine shapes; two adjacent copies now fail.
2. **Absent without files.** `limit_absent()` (no line opening with the limit's words, in any wording) is asserted in four places:
   - **Case 1 at each format:** the default path. A stray print beside SAMPLE_LIMIT would land here, and the Ldefault mutant shows it is caught.
   - **Case 5's `--member` record:** a single system, which prints no SAMPLE_LIMIT line.
   - **Case 5's kepler run:** no test particles.
   - **Case 7's kepler run with `--producer-files`:** the files are given but never read.
3. **Settings clause.** It now ends "…not to those the producer ran with, so its epsilon, pc_tol_shift and max_iter, and the settings no record carries, are held only in a member that is rerun, and there only through what they move in its lines". The gate's copy matches word for word. My own runs:
   - Member 4 produced at pc_tol_shift 2, with its header rewritten to the defaults, is IDENTICAL on its rerun (RESULT PASS).
   - At epsilon 1e-8 it FAILs at record line 13 (sample 1, step 20), column t.
4. **The line in every producer-path run.** It is asserted in 12 runs at fp64; before this fix, only 4 of V3's 9 asserted it. The 12 are:
   - A and B;
   - GATE 1b's two runs;
   - half pair;
   - `--member` and single problem;
   - other producer, program engine and zonal;
   - q1 and q2.

   In the full tier, A, B, q1 and q2 also assert it at fp128 and fp256, 20 runs in all.
5. **A missing replay.** `moves()` now FAILs by name when a kept replay is missing: "what the plant moves cannot be read: no replay of member 4 body 3 kept by gate 1, in …". The Grm mutant shows it.
6. **Printed, not asserted.** q2 prints "which moves, as measured here, N tokens of its replays and <counters>". The gate asserts only that each plant FAILs its particles and moves something. The full run printed the tokens each of the four plants moved:

   | format | tokens moved |
   |---|---|
   | fp64 | 26 / 0 / 0 / 9 |
   | fp128 | 0 / 0 / 0 / 0 |
   | fp256 | 0 / 0 / 0 / 8 |

   Every plant moved the mean passes. So "only the counters" held at fp128 in this run, but one plant moved 8 tokens at fp256. That is why it stays a description. It appears in the full tier only, the only tier that runs fp128.
7. **Corrections, in the ledger and here:**
   - Send-back 1 said the line was held "once". That was false for two adjacent copies until e3f6a39: the old substring count let them share a newline and saw one.
   - Send-back 1's settings clause said a rerun member holds those settings. A rerun holds them only through what they move in its lines. V3's pc_tol_shift 8 and max_iter 12, and my pc_tol_shift 2, are all IDENTICAL on a rerun.

**Mutants** (run against the new --quick gate)

Each edit must land exactly once or `mutate.py` refuses. I re-ran the refusal test: `=== NOT MUTATED: edit x lands 0 times in compare_run.py, not once`, rc 3, nothing created.

| mutant | gate | caught by |
|---|---|---|
| M0 (control) | PASS, 70 ok | nothing |
| Ltwice (adjacent copies) | FAIL, 58 ok / 12 FAIL | all 12 producer-path runs |
| Ldefault | FAIL, 59 / 11 | case 1's absence check, and the 10 ensemble producer runs |
| Lgone | FAIL, 58 / 12 | all 12 |
| Lword | FAIL, 58 / 12 | all 12 |
| Lbefore | FAIL, 58 / 12 | all 12 |
| M1 | FAIL, 66 / 4 | the from-files run, GATE 1b, the program-engine case, q2 |
| M2 | FAIL, 65 / 5 | the same, plus half pair |
| Mf2 | FAIL, 68 / 2 | the program-engine case, q2 |
| Mj | FAIL, 69 / 1 | the program-engine case, refused by its run key's `engine` |
| Grm (gate copy with one kept replay deleted) | FAIL, 69 / 1 | q2, naming member 4 body 3 |

**Gate counts** (at e3f6a39; each log read line by line, no FAIL verdicts)

| run | result |
|---|---|
| `check_compare_run.py --quick` | PASS, 70 ok |
| `check_compare_run.py`, full | PASS, 108 ok |
| check-light's own command through `tools/gate_cache.py` (executed, not cached) | PASS, 70 ok |
| `check_ring_seams --quick` | PASS, 21 ok |

**Readers:** not re-checked. The driver's changes since 0bee543 are the limit's text and its header comment only, and the new text contains neither IDENTICAL nor FAIL.

The scripts (`mutate.py`, `unit_limit.py`, `drycheck.py`) and the run logs (`run-*.log`) are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p3-r5\`.
