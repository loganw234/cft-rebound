(R5-PL's report, its final message on 2026-11-19 at ~08:15, copied verbatim by the lead.)

Both fixes are committed on `round5-pl`, and the tip is `5fa75340a7a470cf6977982badb7ed179c7ca2ce`. The clean tree passes the compare_run gate in `--quick` and in full. Every mutant fails it in both tiers, by name, and the fda3b40 gate passes each one where it is the gap. Nothing was pushed or merged.

```
3012353 Makefile: the program images the legs key on are named from their sources ...
5fa7534 check_compare_run: the limit of a producer's files held absent on every run ...

$ git diff --stat fda3b40..5fa7534
 Makefile                   |  14 +++++-
 tools/check_compare_run.py | 123 ++++++++++++++++++++++++++++++++++-----------
 2 files changed, 108 insertions(+), 29 deletions(-)
```

## Fix 1: the PROGRAMS key (3012353)
`PROGRAMS := $(sort $(patsubst programs/%.cfta,programs/out/%.cftp,$(wildcard programs/*.cfta)) $(wildcard programs/out/*.cftp))`, with a comment saying what it does.

I added the union with `programs/out`, which the brief did not ask for. It keeps an image that is already in `programs/out` but has no source, as the old line did. `check_gravity` lists that directory and fails on any image the binary does not carry (READ, `tools/check_gravity.py` lines 175-187).

**Evidence (MEASURED).** `bash <scratch>\pl\mkn.sh LABEL MAKEFILE` runs `make -n -f MAKEFILE OS=Windows_NT TMP=… TEMP=… PYTHON=… <target>` for check, check-quick and check-light. `python <scratch>\pl\legs_inputs.py compare A B` then compares each leg's `--input` set.
- **Fresh tree** (no `build/`, no `programs/out`): fda3b40's Makefile lists no `programs/out` file on any leg. The fix lists the same 66 on the 10 named legs, in all three tiers. The other 15 legs are unchanged.
- **Built tree:** the fix's sets equal the fresh tree's and fda3b40's on all 25 legs, in each tier. So no leg's inputs change.
- **Built tree with `programs/out` moved aside:** same result as the fresh tree.
- **A stray image planted in `programs/out`:** fda3b40's Makefile and the fix both list it. The derivation alone, without the union, drops it.

## Fix 2: limit_absent (5fa7534)
- **(a) Indentation.** `limit_lines()` finds the limit's opening words anywhere in a line. Both `limit_absent()` and `limit_once()`'s "no other line" check use it. The `limit_once()` change is beyond the brief: it had the same gap.
- **(b) Every run.** `drive()` is the only place the gate starts the driver. It now records every run without `--producer-files`, from the whole of stdout and stderr. One closing verdict holds that none printed the line, and says how many runs there were and how many of each kind V3 named. It fails if there is no `--plan`, `--rerun-engine`, binary128/256 or FMA run.
- **Case 6 now runs in every tier,** 4 steps in `--quick`. Before, `--quick` had no `--rerun-engine` run without files, so no gate change could make M2 fail `--quick`.

**Clean tree (MEASURED):**
- `--quick`: PASS, 73 ok. fda3b40's gate: 70.
- Full: PASS, 109 ok. fda3b40's gate: 108, measured while it held M2 and passed.
- M0, an unedited copy, gives 73 ok in `--quick` with the same 73 verdict lines.

**Mutant copies.** `<scratch>\pl\mutate.py` copies `compare_run.py` and its 7 sibling files, and inserts the edit after one anchor. It refuses unless the anchor lands exactly once (measured: "lands 0 times", "lands 2 times", "lands 3 times"). Each gate run was `python <tree>\tools\check_compare_run.py --build <own dir> [--quick] --driver <copy>`. fda3b40's gate ran from a `git archive` copy. The fix's runs held exactly the committed file (blob `b77e7944`).

| copy | fix, `--quick` | fix, full | fda3b40's gate |
|---|---|---|---|
| M1: indented, default path | FAIL, 69 ok / 4 FAIL: case 1, case 5 ×2, closing ("printed by 35") | FAIL, 103 ok / 6 FAIL: case 1 ×3, case 5 ×2, closing ("printed by 37") | `--quick` PASS, 70 ok |
| M2: only `--rerun-engine` without files | FAIL, 72 ok / 1 FAIL: closing, "printed by 1: waves_fma_program.rec --rerun-engine loop" | FAIL, 108 ok / 1 FAIL: the same | full PASS, 108 ok; `--quick` PASS, 70 ok (no case 6 there) |
| M3: only under `--plan` | FAIL, 72 ok / 1 FAIL: closing, "printed by 10: … --plan --seed 1 …" | FAIL, 108 ok / 1 FAIL: the same | `--quick` PASS, 70 ok |
| M4: only case 4's two records | FAIL, 72 ok / 1 FAIL: closing, names `waves_fp128_short.rec` and `waves_fma_short.rec` | FAIL, 108 ok / 1 FAIL: the same | `--quick` PASS, 70 ok |
| M5: indented 2nd copy on the producer path (extra) | FAIL, 61 ok / 12 FAIL: each producer run's `limit_once` | FAIL, 89 ok / 20 FAIL | `--quick` PASS, 70 ok |

Before the gate runs, a smoke test (`smoke.py`) confirmed each copy prints the line only where intended, and every one of those 30 runs otherwise passed.

`verify_gaps.py` then drove each copy again on the files the fda3b40 runs left and applied both gates' checks. Results:
- **M1:** the line is indented. fda3b40's `limit_absent` says absent (True); the fix's says False.
- **M2, M3, M4:** the line starts at column 0, so either version of the check catches it. fda3b40's gate simply never checked those runs.
- **M5:** fda3b40's `limit_once` says True; the fix's says False.

## Booking
B0187 (desktop, shared, 05:39 to 09:30), with the queue's pids 18164 and 42908 attached. Released at 08:13 with both pids gone. The build (1.5 min) and the `make -n` runs were under 10 minutes and not booked.

## Found, not fixed
- **The `check_ensemble` leg lists no program images,** in any tree. `tools/check_ensemble.py` runs three program-engine cases with `--programs programs/out` (lines 101 and 137-150). Left alone because the brief keeps other legs' inputs fixed (READ).
- **A program new in `gen_programs.py`** is only keyed from the next make on. The Makefile comment says so.
- **Control i ignores `--driver`.** It copies the tree's own `compare_run.py`, so its 3 runs never hold the copy under test (READ; consistent with M1's 37-of-48 count).
- **Runs refused after reading a producer's files** (q3 to q7, and the other-engine record without `--rerun-engine`) are never checked for the limit line.
- **Per-run checks see only stderr's last 600 characters.** The closing verdict reads all of it.
- **Two variables share the name `unread`:** a local in `hold_clean` and the new list in `main`. They are in different scopes and never meet. I left them so the committed file is the one that was tested.
- **check-gpu's `check_compare_run` leg now also runs case 6 on the device.** Not run on a GPU.

## State
- The worktree is clean (`git status --short` is empty). Only ignored files are present: `build/`, `programs/out/` and the local pin clones.
- None of my processes are running.
- The mutant copies are deleted. Logs and scripts remain in `<scratch>\pl\`.
- The ledger has four entries in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\PL.md`.
- No timings are claimed: the runs went 5 at a time beside V2.

`<scratch>` is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad`.
