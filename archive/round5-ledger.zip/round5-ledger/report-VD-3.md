(R5-VD's report on records phase 2, round5-docs at 87fb2b8, its final message on 2026-11-20 at ~06:00, copied verbatim by the lead.)

**NOT READY** for phase 2. Every number I checked matches its source, all the mechanics pass, and nothing needs recounting. Three sentences need fixing; they are listed at the end.

I worked read only at 87fb2b8 and the worktree stayed clean. My ledger entry is in the drop as `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\VD.md`.

**1. Numbers: recounted, all match**
- **int-check-620c98b.log:** 13:38:35 to 16:55:59 (3:17:24).
  - clean, build and check each rc 0; 25 legs; 1,505 lines beginning `  ok `; 17 RESULT lines, all PASS; no line beginning FAIL; 5 warnings.
  - Every leg has fda3b40's count except check_compare_run, which goes from 108 to 109.
- **int-check-61e45bc.log:** 02:11:37 to 05:03:15 (2:51:38).
  - 26 legs; 1,649 `  ok ` lines; 18 RESULT lines, all PASS.
  - The 25 shared legs have 620c98b's counts. check_wave has 144, and its count rule holds on A at 5 lines of 390 and of 54.
  - Gate 4 has 152,735 augmentedAddition cases, 7,259 of them ties (log line 2474).
- **int-check-7444157.log:** it stops in its sixth leg, check_door.
- **The lead's normalizer, rerun on the logs:** the "differs only in" lists for both suites hold. Lines with long hex tokens are identical both ways. My regex counts 117 such lines where the lead counted 122; the entry attributes the 122 to the lead.
- **The GPU folders:**
  - plgpu-620c98b: 152m46s; the leg 73 ok; 1606 of 1606 processes; 665 records, 22,347 steps, 435 rejected, 3.61 passes.
  - p2seam-7444157: rc 2 after 15m19s; the traceback at check_wave.py:1088; the seam script 15 ok and 8 FAIL, all eight the script's own.
  - p2seam-61e45bc: 02:13:13 to 02:42:23; check_records 4 ok in 15m21s; check_wave 147 ok, 0 FAIL; 228,352 cases, digest ca7246a62d9533f6; the seam script 24 ok, with lines of 394 values, 12 steps, 1 rejected, 3.769 passes and 11 controls.
- **Entry 56 against the reports:**
  - P2.md: the rate table, the GPU-E2 conversions (245 and 756) and the kernel frames.
  - V2's reports 1 to 6: the contraction table, gate 4's plant counts, 0 of 278,535 lines differing across GPUs, 18,013 of 199,714 fma triples, and every look's mutant counts.
  - P2's reports 4, 5 and 9: the counts of the mutants and send-backs P2 ran.
- **git:**
  - P2: nine commits to 82b75b8, then seven send-backs. PL: five commits.
  - The merges: fda3b40..620c98b is +120/−41, and 620c98b's tree is 4fcd775's. 7444157 differs from 61e45bc in check_wave.py alone (+6/−2), and both Makefiles are f82c107b.
  - The send-back counts hold: P1's seam three, and check_wave six of the planted-control shape plus one for the work directory.

**2. Labels:** two defects (2 and 3 below) and some nits.

**3. CLAUDE.md**
- The make check row matches my recount.
- "26 since check_wave" holds: each tier on main has 26 `--leg` lines.
- "Nine: three and six" matches entries 55 and 56.
- The new bullet is accurate to the ledger, but one clause is missing from entry 58 (defect 1).

**4. Citations: all correct.**
- Makefile:988 on main is check-gpu's `--hip` line.
- check_compare_run.py:836 at 4a8fe99 and :863 at 620c98b and 61e45bc are both GATE 1b's `rc1 == 1` test.
- check_wave.py:1088 is 9fa5956's `os.makedirs`, and costs.py lines 18–19 say what entry 55 says they say.

**5. Mechanics: all pass.**
- The branch changes the six documents and nothing else.
- No LEAD-FILL line is left.
- The pin row is a single row, its commit cell begins with eae74e3, and it is byte-identical to fda3b40's.
- `git merge-tree --write-tree main round5-docs` gives rc 0, and the merged tree differs from main only in the six documents.
- ROADMAP invents no plan and leaves the pin move on Logan's word.

**Defects, each with its fix**
1. **CLAUDE.md's new bullet** says the seam script was "dry-run only on the host twin" and cites entry 58, which never says so. The fact itself is true: lead.md 2026-11-19 05:12 records a desktop dry run, 22 ok (gpu/p1p2/dry2.log). Fix: add one sentence with that source to entry 58's seam-script bullet, or drop the clause from CLAUDE.md.
2. **Entry 56, part 4,** says each particle's distance stays "within 1e-2 of what the field's absence would move it". check_wave's bound is a ratio. Fix: "its distance from Saturn moves by under 1e-2 of what the field's absence would move it, its angle swept is n t to 1e-4, relative, and its energy holds to 1e-13" (check_wave.py's head; CIRC_BOUND).
3. **Entry 56, wave_gpu.inc,** says "none meets the display driver's watchdog (`7dec985`)". 7dec985's own message marks the two-second reset as BELIEVED, not met. Fix: add "the reset at about two seconds BELIEVED, never met".

**Nits (optional)**
- ROUND5.md's findings say "62 and 66 min alone". V1 never said its 66 min run was alone; entry 55 rightly says "66 min there".
- ROADMAP item 2 should say "at the pin" and "every record the legs made on hip:0 was the software backend's", narrowed as entry 50 was.
- ROADMAP's "keys on every file a leg runs, imports or reads" should add "PL's open notes aside". By one of those notes, cached build/ problems still steer two legs.
- Entry 58 says "my count, and the lead's" twice. Name D instead.
- In entry 58, "every other path is 620c98b's" should add "but the Makefile".
- The check_wave usage line in README and RING.md omits `--expect`, which check-gpu passes; the tool's own header omits it too.

**NOT READY** until the three fixes land.
