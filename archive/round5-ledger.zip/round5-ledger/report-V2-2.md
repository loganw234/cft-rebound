(R5-V2's report on its second look at P2's 8f559c8, its final message on 2026-11-19 at ~08:58, copied verbatim by the lead.)

**NOT READY on 8f559c8.** Two gaps remain in check_wave's plants. Everything else in scope holds, and every mutant on your list fails check_wave in both forms. I released the 5060 Ti (B0188) and WSL cft-gpu (B0189) at 06:35, and the desktop (B0190) at 08:56; nothing of mine is running.

**Where.** On the desktop I used my worktree, detached at 8f559c8, with `make clean` then `all programs wave-host` (rc 0, 63 s), booked shared (B0183, then B0186, then B0190, each with its pids). On the 5060 Ti I made a fresh clone of my own 8f559c8 bundle (sha256 82ab3700, the same at both ends) in /root/cft-rebound-r5-v2/tree8, from 05:55 to 06:35. Every command there set `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1`, and nvidia-smi showed no other compute process. I did not use the RX 7600 or the 4070.

**1. Plants — DEFECT.**
- MEASURED: the tree passes: --quick 74 ok, full 83 ok, 0 FAIL.
- MEASURED: both forms plant the same 24 values on the same lines. Full's P record is quick's A apart from its trailer's timings, and compare_run's output on one plant copy is the same in both forms apart from the problem path.
- MEASURED, where each class sits:
  - the schedule's six columns, the massive bodies' x to vz, and a sampled particle's own body each span members 0, 1 and 2, on first and last lines;
  - the counters are spread one each: max in member 0, steps_rejected and caps in member 1, mean and steps_done in member 2;
  - **the step field is planted once, in member 0's last line.**
- MEASURED: each plant fails its own member naming line and column. Its particles fail where their replay carries the column (2 of 2, or 1 of 2 for a particle's own body), and unplanted members stay IDENTICAL with their particles.
- READ: which particles carry a column comes from compare_run's own particle lines, not from a hard-coded list.
- **Gap A, the step field (MEASURED).** I planted a wrong step in member 1's first sampled line.
  - The tree's compare_run catches it ("incomplete in the record: line 207 is sample 1 at step 5").
  - A compare_run copy that checks the step only in member 0, and one that never checks it on sample 1, both call it IDENTICAL.
  - Both copies pass check_wave --quick, 74 ok.
- **Gap B, the verdict passes with a member or a class unplanted (MEASURED).**
  - A check_wave copy that never plants member 2 passes, 66 ok. That also drops the step field and all five counters.
  - A copy that skips the counters passes, 69 ok.
  - READ: omissions driven by the data do fail: a particle compare_run doesn't name, or no three-member record.
  - The plan is 24 hand-written tuples. Nothing derives it from the record's `# columns:` line, as check_compare_run's a5 does.

**2. Mutants.** I wrote my own edits, on other anchor lines than P2's script wherever one exists. Each lands exactly once; the script refuses at 0 and at 2 landings, and I showed both refusals.

Every mutant on your list fails check_wave in both forms (MEASURED; ok/FAIL):

| mutant | --quick | full |
|---|---|---|
| member 0 never compared | 67/7 | 76/7 |
| member 1 never compared | 66/8 | 75/8 |
| member 2 never compared | 67/7 | 76/7 |
| lines past the third, members alone or with particles | 65/9 | 74/9 |
| no particles replayed | 44/30 | 52/31 |
| no-op particle_compare | 52/22 | 61/22 |
| the 12 columns | 72–73 ok, 1–2 FAIL | 80–82 ok, 1–3 FAIL |
| the four member trailer counters | 73/1 | 82/1 |
| the step field | 73/1 | 82/1 |
| steps_done | 73/1 | 82/1 |
| physics decision skipped | 73/1 | 82/1 |
| attempts comparison skipped | 73/1 | 82/1 |
| particle parse skipped | 44/30 | 52/31 |

- P2's script had no E or t_lo column mutant; both fail here.
- Member values alone, never compared, also fail: 68/6 each in --quick.

**The step field and steps_done are still held, but only by compare_run's completeness check** (MEASURED):
- Removing only the completeness test fails check_wave, 73/1 for each.
- Removing only the comparisons in compare() and particle_compare() passes, 74/0 for each. No record plant ever reaches those comparisons.
- BELIEVED: the rerun always lays out its lines as the completeness check expects, which is why the comparisons are unreachable.

Replacing part 4's attempts call with `same += 1` passes (74/0). That is scope, not a defect: the control holds attempts_same() itself, not each call site, as with any verdict line.

**3. Particle count — confirmed.** MEASURED: the plans print 6 for each ring case, 2 for E, 1 for zonal_saturn, and 0 with "particles: none to sample" for the rest. A copy that replays none fails with "0 of 0 … (the plan: 6)".

**4. Physics — confirmed.** MEASURED: the control fails when physics_verdict() refuses nothing ("by nothing"), when it lacks the distance criterion ("by mm"), and when it lacks the angle criterion ("by circ"). It needs both.

**5. Identity — confirmed.**
- MEASURED on the desktop: the three builds print off/checked, off/unchecked and on/unchecked. Their FMA instruction counts agree: 10, 3 and 44.
- MEASURED on the 5060 Ti: the same three lines. The build log shows the contract object compiled with `--fmad=true -ffp-contract=fast -DWAVE_CONTRACT_ON -DWAVE_UNCHECKED`.
- check_wave asserts all three (lines 835 and 857–867), on both hosts.
- READ: no compiler macro reports contraction, so the line depends on the Makefile pairing the define with the flag, which all three of its lines do.

**6. Makefile — confirmed.** MEASURED with `make -n -B`:
- all and programs are identical under 5b1cac6's, 82b75b8's and 8f559c8's Makefiles.
- Each tier differs from 82b75b8 only by `-DWAVE_CONTRACT_ON` on the contract build, and from 5b1cac6 only by the wave-host builds and the check_wave leg.
- `HIP=1 wave` (amd and nvidia): only the contract object's line moves.

**7. Probe — confirmed.**
- READ: `--device-info` returns after gpu_open(), before any problem is read or any kernel set up, and check_wave runs it first.
- MEASURED on the desktop, against stand-in binaries: check_wave refuses in 0.46 s and its work directory stays empty.

**8. 5060 Ti — confirmed.**
- MEASURED: the build passed (rc 0, 228 s).
- MEASURED: `--device-info` prints one device line in 10.9 s, most of it CUDA starting up in WSL. There is no ncu in the distro, so "launches nothing" is READ from the code, not traced.
- MEASURED: `check_wave --device gpu --quick --expect "RTX 5060 Ti"` gives `RESULT: PASS`, 91 ok, 0 FAIL, in 2,099 s.
- MEASURED: with `--expect "RX 7600"` it is refused on the probe's device line in 12.1 s, and its work directory holds 0 entries.

**Send-back, tools/check_wave.py only:**
- Plant the step field in members 1 and 2, and on a first sampled line.
- Derive the plan's kinds from the record's columns and counters, and assert that every kind is planted in every member on first and last lines, so dropping one fails by name.
- After that, the four passing mutants (step checked in member 0 only, step never checked on sample 1, member 2 unplanted, counters unplanted) must all fail.

I deleted the mutant trees and kept the logs in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\sb1\logs. My ledger entries are in V2.md at 05:07, 05:50, 06:36, 07:30, 07:48 and 08:57.

**NOT READY**
