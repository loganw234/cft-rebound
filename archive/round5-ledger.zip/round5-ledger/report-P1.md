P1 is done except for one leg on one GPU: check_corrector did not run on the RX 7600 because its window ran out. Every other record-making leg passed on both GPUs, and every record each one made is the software backend's, process by process. Both GPUs and all bookings are released, and nothing is pushed or merged.

Branch `worktree-agent-ab5e6c159761d1e5e`, 16 commits on 5b1cac6, final commit `ab75fbe`.

## What changed
- **`Makefile`**: a `check-gpu` target, with the variables `GPU_ARTIFACT`, `GPU_LEGS`, `GPU_SKIP` and `GPU_EXPECT`, plus a usage line in the header. It doesn't use the gate cache, because a cached pass would carry no device line. `make -n -B` of `all`, `programs`, `check`, `check-quick` and `check-light` matches the base Makefile with HIP unset and with HIP=1, on the desktop and on nvidia-box.
- **`tools/check_gpu.py`** (new): the driver.
  - **Probe:** it opens `hip:0` with `CFT_HIP_INFO=1`; on a host with no `hip:0` (the desktop) it refuses by name.
  - **Witness:** each leg runs against a shadow build directory. There, `ias15_cft` and `check_dropin` are wrappers: each keeps every process's device line and re-runs the same arguments on the software backend, comparing stdout and output files byte for byte.
  - **strace:** where it is installed, every exec is checked against what the wrapper accounts for.
  - **Contents:** controls a to g, the routes, the seam, and the legs (commands read from the Makefile, not retyped).
  - **Options:** `--reach` (a survey of legs it doesn't gate) and `--analyse` (re-reads a kept run without touching a GPU).
- **`hw/gpu/where.py`**, **`hw/gpu/program_caps.c`**, **`hw/gpu/costs.py`** (new): the what-runs-where and cost measurements.

## check-gpu on each GPU (actual lines)
**RX 7600**, commit 8ea24bd, every leg but `check_dropin_light`, which ran beside it as its own process:
```
ok   check_records (quick form): rc 0, RESULT: PASS, 4 ok, 0 FAIL, 30m54s; witness: 4 of 4 process(es) on the device (ias15_cft 4), a device line each and every line the probe's; 4 of 4 record(s) identical to the software backend's from the same arguments, 8 route line(s) by=absent against opt_in; strace: 4 run(s) of the witnesses and 8 of the real programs, as the witness accounts
ok   check_compare_run (quick form): rc 0, RESULT: PASS, 45 ok, 0 FAIL, 161m48s; witness: 774 of 774 process(es) on the device ... strace: 774 run(s) of the witnesses and 1548 of the real programs, as the witness accounts
ok   check_dropin_light (--light form): rc 0, check_dropin: every case passed, 169 ok, 0 FAIL, 147m53s; witness: 1 of 1 ... 1 of 1 record(s) identical to the software backend's
```
The "169 ok" is an artefact: the leg's stdout has 170. Merging stdout and stderr into one log split a line; that is fixed in `ec66a15`.

Also PASS on the RX 7600, every process on the device:

| Leg | Processes | Time |
|---|---|---|
| check_equivalence | 6 | 6m12s |
| check_program_engine | 14 | 11m42s |
| check_ensemble | 49 | 15m38s |
| check_ring | 15 | 4m06s |
| check_replay | 141 | 20m30s |
| check_zonal | 31 | 31m29s |
| check_reversal | 15 | 15m06s |

**RTX 5060 Ti**, commit 20dad58. All legs PASS with every process on the device: check_records 4, check_equivalence 6, check_program_engine 14, check_ensemble 49, check_ring 15, check_replay 141, check_compare_run 774 (102m), check_zonal 31, check_reversal 15. `check_dropin_light` also passed: "every case passed", 170 ok, its whole output identical to software's.

check_corrector on the 5060 Ti printed:
```
FAIL check_corrector (quick form): rc 0, RESULT: PASS, 212 ok, 0 FAIL, 100m25s; witness: 163 of 165 process(es) on the device ... 165 of 165 record(s) identical to the software backend's
```
The two processes without a device line are check_corrector's own refusal cases: `--trace-pc` or `--record-iters` beside `--replay-iters`. `ias15_cft` refuses those with rc 3 before it opens any device, exactly as it does in software. The bug was in my driver's rule, not the GPU. It is fixed in `ab75fbe`, and re-reading the kept witness data gives:
```
ok   check_corrector, re-read: RESULT: PASS, 212 ok, 0 FAIL; witness: 163 of 165 process(es) on the device ..., and 2 refused by their own arguments before opening it ...; check_dropin: 170 ok, 0 FAIL, every case passed
```

## Seam test and controls (both GPUs)
- **Seam:** the ring generator's two-wave ring with its zonal line, recorded on `hip:0` from a first step of 1e5 s (one rejection per wave). `compare_run.py` holds it against software reruns: both members IDENTICAL, and 4 particles IDENTICAL.
  - **Plants:** one hex digit each in x of body 1, dt_next, the exact-time pair's t_lo, vz of body 63 and t, on record lines 140 and 142. Each fails wave 0, naming the line and column, while wave 1 stays IDENTICAL.
  - **FMA form**, the form P2's kernel is held in: clean, plus one plant, caught.
- **Controls:**
  - a: one digit in a record → caught.
  - a2: the trailer's `calls=` one higher → caught.
  - b: an attempt's outcome flipped → caught.
  - c: the device line altered → caught.
  - d: a process run with no artifact → caught as a stand-in.
  - e: a device process with no device line → caught.
  - f: check_records run entirely in software passes on its own, but fails here with 4 of 4 stand-ins.
  - g: a process that runs `ias15_cft` past the witness → caught by strace (RX 7600 only; the WSL host has no strace).
- **Routes**, at all three formats:
  - `scalar` and `reduce_seg` forced on give software's bits, with the fallbacks moved to calls one for one (4341, 60, …).
  - `indexed` and `pair_gather` forced on are refused by name, while software runs the same command.
  - `--door-selftest` on `hip:0`: "116 identical, 0 differ, 48 not compared, 0 accounting errors; controls 2 of 2". That is exactly what software gives with those two routes hidden.

## Which legs reach the GPU
- **All eleven GPU legs reach it.** Every process carried the probe's device line.
- **gate_subprocess** reaches it: 8 child runs on the device, records identical to software's.
- **gate_real** reaches it and gives software's wide-state digests (`e08541bc0af9b3ec`, `56bacf3bf63f19a7`). It fails only its identity check: `tests/gate_real.c:324-350` treats any artifact that isn't `cft://` as a card image, and a GPU loads no image. So gate_real, check_checkpoint and check_seams can't be pointed at a GPU without a fix in `tests/`, which I didn't touch.
- **The archive gates** open no device (0 of 4 device lines): they open the software backend by design, and gate_stock links no libcft.

## What runs where (RX 7600 with gdb, all three formats; the 5060 Ti has no gdb)
- **Exact-time clock:** `cft_augmented_add` was entered once per step attempt, rejected attempts included (5/5, 4/4, 3/3). None of the run's 19,351 / 25,105 / 20,941 GPU backend calls came from inside it, so it runs on the host.
- **Divide and square root:** entered exactly `divsqrt_calls` times. Each ran one program on the device and no elementwise run, with the rounding done on the host.
  - Forcing `CFT_DIVSQRT_SEQ=1` gives identical counts.
  - Forcing `CFT_DIVSQRT_SEQ=0` gives no programs and 72,917–105,256 elementwise runs.
  - All three records are identical.

  | Divide or root (µs) | Default | Forced program route | Forced chunk route |
  |---|---|---|---|
  | RX 7600, fp64 / fp128 / fp256 | 661 / 868 / 1341 | 651 / 866 / 1344 | 4603 / 5882 / 6367 |
  | 5060 Ti, fp64 / fp128 / fp256 | 242 / 299 / 386 | 261 / 296 / 389 | 1818 / 2091 / 2456 |

  On the 5060 Ti this is shown by the forcing variable and the timings alone, since there is no gdb.
- **Index-table routes:** `indexed` and `pair_gather` read `by=absent` with no calls.
- **Program capacities:** all 69 images load on both GPUs. The widest, `gravity-fold256-fp128`, uses all 256 scratch slots, so there is no margin. The most constants any program uses is 13. A block of 256 slots and a bank of 512 constants load; 257 slots and 513 constants are refused by name.

## Costs (MEASURED, one run a row, `wall_seconds`, unranked within the noise; every row's record identical to software's)
| | µs per call (kepler, fp64 / fp128 / fp256, loop then program) | µs per call (64-body ring) | GPU time ÷ software time |
|---|---|---|---|
| RX 7600 | 288, 333 / 346, 476 / 449, 690 | 274–457 | kepler 5.6–18.0×; ring 0.3–0.6× |
| 5060 Ti | 119, 140 / 130, 176 / 150, 229 | 141–230 | kepler 2.9–11.6×; ring 0.3–0.5× |

The RX 7600's kepler rows reproduce P0's within 1.5%. The 5060 Ti rows were measured while other suites shared the desktop.

The desktop's full `make check` at a29f602 (the final Makefile apart from one comment) passed: rc 0, 25 legs, 1463 ok, every leg's count matching P0's suite, the six digests present.

## Not done
- **check_corrector on the RX 7600:** stopped as it started at 16:16. Its `--library` step is another `check_dropin --light`, which could not finish before P2's window at 18:00.
- **check_dropin_light on both GPUs** ran beside the main run, two processes on one GPU, so those leg times are not costs.
- **Final commit not run in full on a GPU:** `ab75fbe`'s changes were exercised only through `--analyse` and the seam path. The 5060 Ti's main run used 20dad58; its controls, routes and seam were re-run at 8ea24bd (34 ok, PASS).
- **P2's GPU leg:** agreed with P2 in the ledger as a second line of `check-gpu`'s recipe, to be added at the merge. It is not in this branch.

## What the brief or ROUND5.md got wrong
1. "CPU time 1.5 to 2.0 times the wall time on hip:0" holds only on ROCm (RX 7600: 1.54–1.92). On the 5060 Ti it is 1.02–1.03.
2. Estimates for `check_dropin --light`:
   - 62 minutes when it ran alone on the 5060 Ti.
   - 104 and 148 minutes beside the main runs, on the 5060 Ti and the RX 7600.
3. check_corrector mostly runs the standalone program; only its `--library` step goes through the registered integrator.
4. ROUND5.md lists `cft_reduce` as GPU work, but this port's default path never calls it.
5. "Within 256 scratch slots" is true with zero margin.
6. A whole-output comparison must also set aside the door and corrector self-tests' first lines, which name the backend.
7. The clock's augmented add runs at every step *attempt*, rejected ones included.
8. The WSL GPU host's own mpmath is 1.2.1, so I copied the desktop's 1.3.0 into my directory there.
9. Even the "quick" legs take hours on a GPU: about 5 hours of legs on the RX 7600, not counting check_corrector.

I fixed three bugs in my own driver along the way: a stray control character in a regex that crashed the first seam run, the merged-log line cut, and the over-strict refusal rule.

All run logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p1\` (subfolders `rx-logs` and `wsl-logs`; the desktop suite is `make-check-a29f602-1116-1034.log`). The witness data are kept on the GPU hosts in `~/cft-rebound-r5-p1` and `/root/cft-rebound-r5-p1` for V1. My ledger entries are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P1.md`.

Files are in `C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-ab5e6c159761d1e5e\`:
- Makefile
- tools\check_gpu.py
- hw\gpu\where.py
- hw\gpu\costs.py
- hw\gpu\program_caps.c