You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, the multi-precision arithmetic library of the sibling repository cft-fp256. Its central invariant is that every backend gives the same bits and **no committed record line moves** unless a change means it to. Round 5 (ROUND5.md) brings in libcft's GPU device, `hip:N`.

Round 5's parcel P1 built `make HIP=1 check-gpu`. It runs the suite's record-making legs on `hip:0`, and holds every process they start to the software backend's output through a "witness". **The question: does check-gpu prove what it says, that each leg ran on the GPU and gave the software backend's bits, and could a leg that quietly ran the software backend, or a difference, get past it?**

Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for the failure shapes to hunt: a gate driving a stand-in, a comparison that cannot fail, bit-identity taken for validity.

## What to verify

P1's branch `worktree-agent-ab5e6c159761d1e5e`: 16 commits on main `5b1cac6`, tip `ab75fbe`. It adds the Makefile's `check-gpu`, tools/check_gpu.py and hw/gpu/{where.py, costs.py, program_caps.c}.

The claims:
- P1's report: `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\R5-P1-report.md`. Read all of it.
- Its ledger entries: `C:\Users\logan\source\repos\cft-rebound\.ledger\P1.md`. Read every file in that directory.
- The context: ROUND5.md's P1 section, docs/VALIDATION.md entry 54, and CLAUDE.md.

P1's logs are in `scratchpad\p1\`. It kept its witness data on the GPU hosts for you: `~/cft-rebound-r5-p1` on nvidia-box and `/root/cft-rebound-r5-p1` in WSL cft-gpu. Read them there; never write them.

**Already checked by the lead; do not repeat:**
- P1's desktop `make check` at `a29f602` matches P0's suite on d7b5047 leg by leg (25 legs, 1,463 ok), all 10 program legs keyed with the programs.
- Between `a29f602` and `ab75fbe` only check_gpu.py, hw/gpu/where.py and Makefile comments change, and no desktop tier runs those.

**Do not run a full `make check`.**

## Where things are, and when you may use them

- **The desktop: your isolated worktree.**
  - `git checkout --detach ab75fbe`, then confirm it.
  - Clone the pins locally, never from the web, each in separate commands (a one-line loop is refused by the worktree guard). REBOUND comes from `/c/Users/logan/source/repos/cft-rebound/third_party/rebound` at bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93; cft-fp256 from `/c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256` at eae74e3eddc67836d4b7c8922badd40e6e1bdb2f.
  - Build with `export PATH="/c/msys64/mingw64/bin:$PATH"` (not optional), then `make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs`.
- **The RX 7600:** nvidia-box (`ssh -o BatchMode=yes logan@192.168.0.2`, ROCm at /opt/rocm, gfx1102).
  - Work only in **~/cft-rebound-r5-v1**, which you create.
  - mpmath 1.3.0 is at ~/cft-rebound-r5-py (`PYTHONPATH`).
- **The RTX 5060 Ti:** WSL `cft-gpu`, reached with `wsl.exe -d cft-gpu -- bash -lc '...'`. In MSYS bash, set `MSYS_NO_PATHCONV=1`.
  - Work only in **/root/cft-rebound-r5-v1**.
  - Build with `HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120`.
  - **Set `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1` before anything opens `hip:0`, and `GPU_EXPECT="RTX 5060 Ti"`. Never the RTX 4070.**
  - Its own mpmath is 1.2.1: copy the desktop's 1.3.0 into your directory, as P1 did.
- **Code on both hosts:** carry it as git bundles made on the desktop from local clones (`git bundle create`, then scp or the WSL path). Nothing comes from the web.
  - Run `make clean` before the first `make HIP=1` in a tree first built without HIP. Otherwise libcft.a stays software-only, and `hip:0` is refused by name.
- **The windows (TimeSheet at 16:55).** P2 holds the 5060 Ti and cft-gpu to 20:30 (B0071, B0072), and the RX 7600 exclusive with nvidia-box shared from 18:00 to 22:00 (B0073, B0074).
  - **Touch neither GPU host inside P2's windows,** not even to read files, since P2 is timing there.
  - Before 18:00 the RX 7600 is free for short work.
  - cft-fp256's GPU round 2 books both GPUs from Tuesday morning, so `check` before every run.
  - **Book every GPU run of 10 minutes or more** from the desktop, as `--who cft-REBOUND/V1`, with the ssh or wsl session's Windows pid attached, and release it at the end:

    ```
    python C:\Users\logan\source\repos\TimeSheet\timesheet.py book <rx7600|rtx5060ti> --mode exclusive --from <WHEN> --until <WHEN> --who cft-REBOUND/V1 --why "<what>" --pid <pid>
    ```

    Book nvidia-box (shared) or wsl-cft-gpu (exclusive) beside it. Before a short run, `check <resource> --short`.
  - Start with everything that needs no GPU.

## Specific things to attack

1. **Stand-ins.**
   - **The bypass:** P1's witness replaces `ias15_cft` and `check_dropin` in a shadow build directory. Does any leg, Python gate or helper reach a real binary by a path that bypasses that directory? Look for a hardcoded `build/`, an absolute path, or a program not wrapped.
   - **Without strace:** strace catches a bypass on the RX 7600 (control g). How would one be caught on the 5060 Ti, which has no strace?
   - **The device line as evidence:** could a process print the probe's device line and still compute in software?
2. **What the witness sets aside.** It compares stdout and output files byte for byte, apart from:
   - the header's `backend=`;
   - timings;
   - the absent routes' `by=`;
   - the door and corrector self-tests' first lines.

   Read the code that sets those aside. Could a set-aside rule eat a real difference: a line too broad, a token beside the timing on the same line, a counter? Plant a difference next to each rule, in a copy, and show whether it is caught.
3. **The refusal rule of ab75fbe.** A process that exits non-zero with no record, and is refused alike in software, is counted apart. Could a real GPU failure pass as that: a crash, a refused `hip:0`, a device lost? Build the case that distinguishes them.
4. **The seam.** Re-run the GPU seam and its plants yourself on one GPU, at ab75fbe.
   - Is each plant one hex digit, on two lines, caught by name, with the other wave IDENTICAL?
   - Is the FMA-form seam really run?
   - P3's branch (`worktree-agent-a35562c26dc613fed`, 2922fa1) changes compare_run.py's default particle sample. Do not merge it. Read its verdict-line wording with `git show` and say whether check_gpu.py's regexes still read it.
5. **The final commit on a GPU.** ab75fbe was run on no GPU in full, only through `--analyse` and the seam path.
   - **The 5060 Ti, after 20:30:** run `make HIP=1 check-gpu` at ab75fbe in a named subset that includes the controls, the routes and the seam, plus at least check_records and check_corrector.
   - **The RX 7600, after 22:00 if the window is free:** run **check_corrector**, the leg P1 could not run there. Book it long: P1 measured its --library step alone at 62 minutes on the 5060 Ti, and believes about twice that on the RX 7600.
   - **Report:** actual lines, every process's device line, and the records' identity.
6. **`HIP=0` changes nothing, and the desktop refuses.**
   - Compare `make -n -B` of `all`, `programs`, `check`, `check-quick` and `check-light` between 5b1cac6 and ab75fbe, on the desktop (HIP unset).
   - Does `make check-gpu` on the desktop refuse by name, rc non-zero?
7. **What runs where.** Re-run hw/gpu/where.py on the RX 7600 at one format, inside a window of your own. Check its counts: augmented sums one per step attempt, divides and roots each one device program, and `CFT_DIVSQRT_SEQ` 0 against 1.
   - Is any claim stronger than its measurement? For instance, the 5060 Ti's "what runs where" without gdb.
8. **gate_real.** P1 says tests/gate_real.c:324-350 treats any artifact that is not `cft://` as a card image, so gate_real, check_checkpoint and check_seams cannot be pointed at a GPU without a fix in tests/.
   - Read the code: is that right?
   - Is anything else in the desktop's tiers similarly unpointable?
9. **The costs and the corrections.**
   - Are P1's cost rows labelled as what they are: one run, wall_seconds, and the 5060 Ti's taken on a shared desktop?
   - Check two of P1's "what the brief got wrong" against the code: `cft_reduce` never called by the default path, and the clock's augmented sum at every step attempt.
10. **Anything else.** Tell the lead what it did not think to ask.

## Ground rules

- Re-run things; do not trust pasted output.
- Report only. Edit no tracked file. Build controls from copies in scratch, and delete them after.
- No card, never the RTX 4070. No network except the SSH to nvidia-box and WSL. Never bare `git stash`; never push, merge or rebase.
- "Found nothing" is a fine answer. State precisely what you ran, where, and in which booking.

## Report

- **For each numbered item:** the commands you ran, what you observed, and a verdict: **confirmed**, **defect** or **not determined**. A defect needs a concrete failure scenario.
- **End with** **READY** or **NOT READY**.
- **Length:** under 1,500 words. Your report is your final message.
