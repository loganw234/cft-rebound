#!/bin/bash
# Round 5's third merge: the full make check on round5-int after P2's merge
# (620c98b + P2's final tip, check_wave added to check-gpu by hand) in
# cft-rebound-r5, launched by the lead from PowerShell. A clean build first,
# then `all programs` in its own make so PROGRAMS is filled when check's
# Makefile is read, then `check`. The log is named by the merged commit.
cd /c/Users/logan/source/repos/cft-rebound-r5 || exit 1
export PATH="/c/msys64/mingw64/bin:$PATH"
export TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp"
C=$(git rev-parse --short HEAD)
L=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/int-check-$C.log
PY=/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe
mk() { make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" PYTHON="$PY" "$@"; }
{
  echo "start $(date '+%Y-%m-%d %H:%M:%S') commit $(git log --oneline -1 | cut -c1-140)"
  echo "branch $(git rev-parse --abbrev-ref HEAD); changed paths: $(git status --short | wc -l)"
  echo "cc: $(cc -dumpmachine)"
  echo "rebound pin $(git -C third_party/rebound rev-parse HEAD)"
  echo "cft-fp256 pin $(git -C third_party/cft-fp256 rev-parse HEAD)"
  mk clean; echo "clean rc=$?"
  mk all programs; echo "build rc=$?"
  mk check; echo "rc=$?"
  echo "end $(date '+%Y-%m-%d %H:%M:%S')"
} > "$L" 2>&1
