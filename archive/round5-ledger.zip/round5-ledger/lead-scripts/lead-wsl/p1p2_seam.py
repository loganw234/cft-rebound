#!/usr/bin/env python3
"""The lead's seam tests for P2's merge (round 5; ROUND5.md, "What the integrator keeps"), on the merged tree.

P1 x P2: one ring wave (tools/make_ring.py, 57 particles, seed 1, its zonal line) at binary64 in the FMA form,
three ways: this tree's port on the CPU (ias15_cft on the software backend), the same port on the GPU through
libcft (CFT_REBOUND_ARTIFACT=hip:0, CFT_HIP_INFO=1), and P2's kernel (wave --device gpu). From a first step of
1e5 s, so the first attempt is rejected before any step is accepted (the one rejection that leaves state). The
three records must be the same bits: every sample line value for value, every body line, the problem's header
lines text for text, and the trailer's five counters, which are printed beside the verdict and must show the
rejection. Set aside BY NAME, nothing else: the program line's program=, impl=, backend= and engine=; the
identity line; the port's route lines; the kernel's `# device` line, which a GPU run's record must carry
exactly once, naming --expect, and the port's records never; every trailer key but the five. A header line of
any other kind FAILs.
Each record's backend must be the one its run asked for, and the hip:0 run must print a device line naming
--expect. Then the hip:0 record and the kernel's are each held by tools/compare_run.py against this tree's CPU
rerun. Controls: one value planted in a copy of the hip:0 record or of the kernel's, eleven copies (the schedule,
a massive body, a test particle, the step field and the trailer's counters; on the first, second and last sample
lines), each of which must FAIL the comparison with exactly one difference, naming its line and its column.

P2 x P3: the kernel's own attempts records and schedules (wave --attempts-dir) on a three-wave ring, through
compare_run --producer-files: particles replayed from P2's files, in members not rerun, all IDENTICAL. Control:
one dt moved one ulp in a not-rerun member's attempts record (an edit that must land exactly once) must FAIL
that member's sampled particles by name and leave the other members' IDENTICAL.

usage, in WSL cft-gpu with CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1:
    python3 p1p2_seam.py --tree TREE --work DIR --expect "RTX 5060 Ti"
a desktop dry run of the logic, nothing on a GPU (the port twice on software, the kernel as its host twin):
    python p1p2_seam.py --dry-host --tree TREE --port PORT.exe --wave WAVE_HOST.exe --work DIR
"""
import argparse
import math
import os
import re
import shutil
import subprocess
import sys

OKS, FAILS = [0], []
COUNTERS = ("steps_done", "steps_rejected", "iterations_max_exceeded", "mean_pc_iterations", "max_pc_iterations")
PROGRAM_ASIDE = ("program", "impl", "backend", "engine")
SAME_PREFIX = ("# cft-rebound ias15 record v1", "# dt0=", "# active ", "# zonal ", "# body ", "# columns:")
ASIDE_PREFIX = ("# identity ", "# route ")
DEVICE_PREFIX = "# device "   # P2's kernel, on a GPU (46ddfed): set aside by name, and held by its own verdict


def verdict(ok, msg, detail=None):
    if ok:
        OKS[0] += 1
    else:
        FAILS.append(msg)
    print("  %s %s" % ("ok  " if ok else "FAIL", msg), flush=True)
    for d in ([] if ok else (detail or []))[:10]:
        print("         " + d, flush=True)


def run(cmd, env=None, out=None):
    p = subprocess.run(cmd, env=env, capture_output=True, text=True)
    if out:
        with open(out, "w", newline="\n") as f:
            f.write(p.stdout)
        with open(out + ".err", "w", newline="\n") as f:
            f.write(p.stderr)
    return p.returncode, p.stdout, p.stderr


# ---- the comparison ------------------------------------------------------------------------------------------

def colname(i, nbodies):
    """A sample line's field i (0-based): the word `sample`, the sample's index, step, t, dt_next, dt_last, E,
    then x y z vx vy vz a body, then `|` and the exact-time pair (src/ias15_cft.c's main(), as P2's kernel)."""
    head = ("the word sample", "sample", "step", "t", "dt_next", "dt_last", "E")
    if i < 7:
        return head[i]
    j = i - 7
    if j < 6 * nbodies:
        return "body %d %s" % (j // 6, ("x", "y", "z", "vx", "vy", "vz")[j % 6])
    j -= 6 * nbodies
    return ("the bar", "t_hi", "t_lo")[j] if j < 3 else "field %d" % (i + 1)


def body_xyz(row, b):
    return row[7 + 6 * b:10 + 6 * b]


def parse(text):
    """A record's compared lines, in order, as (line number, kind, value); and its set-aside and unknown lines."""
    items, aside, unknown, device, N = [], [], [], [], None
    for n, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        if not line.startswith("#"):
            items.append((n, "sample", line.split()))
        elif line.startswith("# program="):
            kv = dict(t.split("=", 1) for t in line[2:].split() if "=" in t)
            N = int(kv.get("N", "0"))
            items.append((n, "prog", {k: v for k, v in kv.items() if k not in PROGRAM_ASIDE}))
            aside.append("line %d: %s" % (n, " ".join("%s=%s" % (k, kv.get(k)) for k in PROGRAM_ASIDE)))
        elif line.startswith("# steps_done="):
            kv = dict(t.split("=", 1) for t in line[2:].split() if "=" in t)
            items.append((n, "trailer", {k: kv.get(k) for k in COUNTERS}))
        elif line.startswith(ASIDE_PREFIX):
            aside.append("line %d: %s" % (n, line[:90]))
        elif line.startswith(DEVICE_PREFIX):
            device.append((n, line))
            aside.append("line %d: %s" % (n, line[:90]))
        elif line.startswith(SAME_PREFIX):
            items.append((n, "line", line))
        else:
            unknown.append((n, line))
    return {"items": items, "aside": aside, "unknown": unknown, "device": device, "N": N}


def compare(ref, oth):
    """Every difference of `oth` from `ref`, each naming its line (in oth) and its column."""
    d = []
    ri, oi = ref["items"], oth["items"]
    if len(ri) != len(oi):
        d.append("%d compared lines against the reference's %d" % (len(oi), len(ri)))
    N = ref["N"] or 0
    for (rn, rk, rv), (on, ok_, ov) in zip(ri, oi):
        if rk != ok_:
            d.append("line %d: a %s line where the reference's line %d is a %s line" % (on, ok_, rn, rk))
        elif rk == "sample":
            if len(rv) != len(ov):
                d.append("line %d: %d fields against the reference's %d" % (on, len(ov), len(rv)))
            for i, (a, b) in enumerate(zip(rv, ov)):
                if a != b:
                    d.append("line %d (sample %s), column %d (%s): %s, the reference %s" % (
                        on, rv[1] if len(rv) > 1 else "?", i + 1, colname(i, N), b, a))
        elif rk in ("prog", "trailer"):
            for k in sorted(set(rv) | set(ov)):
                if rv.get(k) != ov.get(k) or rv.get(k) is None:
                    d.append("line %d (%s): %s=%s, the reference %s" % (on, "the program line" if rk == "prog"
                                                                        else "the trailer", k, ov.get(k), rv.get(k)))
        elif rv != ov:
            d.append("line %d: %r, the reference %r" % (on, ov[:100], rv[:100]))
    for n, line in oth["unknown"]:
        d.append("line %d: a header line of no known kind: %r" % (n, line[:90]))
    return d


def counters(p):
    t = [v for _, k, v in p["items"] if k == "trailer"]
    return t[0] if len(t) == 1 else None


def say_counters(c):
    return "steps %s, rejected %s, cap hits %s, mean passes %s, max passes %s" % tuple(
        c.get(k) for k in ("steps_done", "steps_rejected", "iterations_max_exceeded", "mean_pc_iterations",
                           "max_pc_iterations"))


# ---- plants ----------------------------------------------------------------------------------------------------

def c_hex(x):
    m, e = float.hex(x).split("p")
    if "." in m:
        m = m.rstrip("0").rstrip(".")
    return m + "p" + e


def bump(tok):
    if tok.lstrip("-").startswith("0x"):
        x = float.fromhex(tok)
        y = math.nextafter(x, math.inf)
        return c_hex(y)
    if re.fullmatch(r"-?\d+", tok):
        return str(int(tok) + 1)
    if re.fullmatch(r"-?\d+\.\d+", tok):
        return tok[:-1] + str((int(tok[-1]) + 1) % 10)
    raise SystemExit("p1p2_seam: no way to plant in %r" % tok)


def plant(text, where, col, N):
    """A copy of the record with one value changed: the trailer's key `col`, or column `col` of sample line
    `where` (0 the first, 1 the second, -1 the last). Returns (text, the line number, its old and new value)."""
    lines = text.split("\n")
    if where == "trailer":
        hits = [i for i, l in enumerate(lines) if l.startswith("# steps_done=")]
        if len(hits) != 1:
            raise SystemExit("p1p2_seam: plant: %d trailer lines" % len(hits))
        i = hits[0]
        toks = lines[i].split(" ")
        js = [j for j, t in enumerate(toks) if t.startswith(col + "=")]
        if len(js) != 1:
            raise SystemExit("p1p2_seam: plant: the trailer key %s lands %d times, not once" % (col, len(js)))
        k, v = toks[js[0]].split("=", 1)
        toks[js[0]] = k + "=" + bump(v)
        lines[i] = " ".join(toks)
        return "\n".join(lines), i + 1, v, toks[js[0]].split("=", 1)[1]
    samp = [i for i, l in enumerate(lines) if l.strip() and not l.startswith("#")]
    i = samp[where]
    f = lines[i].split()
    names = [colname(c, N) for c in range(len(f))]
    if names.count(col) != 1:
        raise SystemExit("p1p2_seam: plant: column %s lands %d times, not once" % (col, names.count(col)))
    c = names.index(col)
    old = f[c]
    f[c] = bump(old)
    if f[c] == old:
        raise SystemExit("p1p2_seam: plant: %s unchanged" % col)
    lines[i] = " ".join(f)
    return "\n".join(lines), i + 1, old, f[c]


# ---- compare_run -----------------------------------------------------------------------------------------------

def drive(args, rec, prob, env, log, extra=()):
    cmd = [sys.executable, "-B", os.path.join(args.tree, "tools", "compare_run.py"), rec, "--problem", prob,
           "--format", "fp64", "--arith", "fma", "--exe", args.port, "--rerun-engine", "loop", "--strata", "1",
           "--seed", "1"] + list(extra)
    rc, out, err = run(cmd, env)
    with open(log, "w", newline="\n") as f:
        f.write(" ".join(cmd) + "\n" + out + err)
    members = {int(m.group(1)): m.group(2) for m in re.finditer(r"^member (\d+) \(\S+\): (IDENTICAL|FAIL|NOT RERUN)",
                                                               out, re.M)}
    parts = [(int(m.group(1)), m.group(2), int(m.group(3)), "producer's own attempts record" in m.group(0),
              m.group(4) or "FAIL")
             for m in re.finditer(r"^  member (\d+): particle (\S+) \(body (\d+), [^)]*\): .*?"
                                  r"(?:held to the record: (IDENTICAL|FAIL)|$)", out, re.M)]
    notrerun = [int(m.group(1)) for m in re.finditer(r"^  member (\d+): its lines held by its particles' replays "
                                                      r"alone, NOT RERUN", out, re.M)]
    result = re.search(r"^RESULT: (PASS|FAIL)", out, re.M)
    return rc, members, parts, notrerun, result.group(1) if result else None, out + err


# ---- main ------------------------------------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tree", required=True)
    ap.add_argument("--work", required=True)
    ap.add_argument("--expect", default="")
    ap.add_argument("--port", default=None)
    ap.add_argument("--wave", default=None)
    ap.add_argument("--dry-host", action="store_true")
    args = ap.parse_args()
    args.tree = os.path.abspath(args.tree)
    exe = ".exe" if os.name == "nt" else ""
    B = os.path.join(args.tree, "build")
    args.port = os.path.abspath(args.port or os.path.join(B, "ias15_cft" + exe))
    args.wave = os.path.abspath(args.wave or os.path.join(B, "wave" + exe))
    dev = [] if args.dry_host else ["--device", "gpu"]
    W = os.path.abspath(args.work)
    os.makedirs(W, exist_ok=True)
    env_sw = {k: v for k, v in os.environ.items() if k not in ("CFT_REBOUND_ARTIFACT", "CFT_HIP_INFO")}
    env_dev = dict(env_sw) if args.dry_host else dict(env_sw, CFT_REBOUND_ARTIFACT="hip:0", CFT_HIP_INFO="1")
    git = subprocess.run(["git", "-C", args.tree, "log", "--oneline", "-1"], capture_output=True, text=True).stdout
    print("p1p2_seam: the P1 x P2 and P2 x P3 seams on %s%s" % (git.strip()[:110],
                                                                 " (DRY RUN on the host: nothing on a GPU)"
                                                                 if args.dry_host else ""), flush=True)
    print("  port %s; kernel %s %s; CUDA_VISIBLE_DEVICES=%s" % (args.port, args.wave, " ".join(dev),
                                                               os.environ.get("CUDA_VISIBLE_DEVICES")), flush=True)

    # 0. the devices, before anything runs on them
    kdev = None
    if not args.dry_host:
        if not args.expect:
            raise SystemExit("p1p2_seam: REFUSED: --expect is required on a GPU")
        rc, out, err = run([args.wave, "--device", "gpu", "--device-info"], env_sw)
        line = (out + err).strip().splitlines()
        # the probe's own `# device` line, which the kernel's record must repeat exactly (as check_wave holds it)
        kdev = next((l for l in out.splitlines() if l.startswith(DEVICE_PREFIX)), "")
        if rc or not line or not kdev or args.expect not in kdev:
            raise SystemExit("p1p2_seam: REFUSED: the kernel's device is not %r (rc %d): %r" % (args.expect, rc,
                                                                                               (out + err)[:300]))
        print("  kernel's device: %s" % line[0][:200], flush=True)
        rc, out, err = run([args.port, "--probe"], env_dev)
        dl = [l for l in (out + err).splitlines() if l.startswith("cft hip: ")]
        if rc or len(dl) != 1 or args.expect not in dl[0]:
            raise SystemExit("p1p2_seam: REFUSED: the port's hip:0 is not %r (rc %d): %r" % (args.expect, rc, dl))
        print("  port's device:   %s" % dl[0][:200], flush=True)

    mk = os.path.join(args.tree, "tools", "make_ring.py")
    ring1 = os.path.join(W, "ring1w.txt")
    ring3 = os.path.join(W, "ring3w.txt")
    for path, n in ((ring1, 57), (ring3, 171)):
        rc, out, err = run([sys.executable, "-B", mk, path, "--particles", str(n), "--seed", "1"], env_sw)
        if rc:
            raise SystemExit("p1p2_seam: make_ring failed: %s" % (err or out))

    # 1. P1 x P2: one wave, three ways
    print("1. P1 x P2: one ring wave at fp64, the FMA form, three ways, from a first step of 1e5 s", flush=True)
    a = ["--problem", ring1, "--dt", "1e5", "--steps", "12", "--sample", "4", "--quiet"]
    paths = {k: os.path.join(W, "ring1w.%s.rec" % k) for k in ("cpu", "hip", "wave")}
    rcs = {}
    rcs["cpu"], _, _ = run([args.port, "--format", "fp64", "--arith", "fma"] + a, env_sw, paths["cpu"])
    rcs["hip"], _, herr = run([args.port, "--format", "fp64", "--arith", "fma"] + a, env_dev, paths["hip"])
    rcs["wave"], _, _ = run([args.wave] + dev + a, env_sw, paths["wave"])
    text = {k: open(p).read() for k, p in paths.items()}
    P = {k: parse(t) for k, t in text.items()}
    want_backend = {"cpu": "software", "hip": "software" if args.dry_host else "hip:0",
                    "wave": "host" if args.dry_host else "gpu"}
    if not args.dry_host:
        # asked for --device gpu, the kernel names the device it ran on: hip:0 and the arch its one `# device`
        # line names (sm_120 on the RTX 5060 Ti, gfx1102 on the RX 7600)
        dv = P["wave"]["device"]
        am = re.search(r"\((sm_\d+|gfx[0-9a-f]+)[,:]", dv[0][1]) if len(dv) == 1 else None
        want_backend["wave"] = "hip:0:" + (am.group(1) if am else "<the arch of its one # device line>")
    for k in ("cpu", "hip", "wave"):
        m = re.search(r"^# program=(\S+) .*?backend=(\S+)", text[k], re.M)
        c = counters(P[k])
        verdict(rcs[k] == 0 and m is not None and m.group(2) == want_backend[k] and c is not None
                and not P[k]["unknown"],
                "%-4s record: rc %d, program=%s backend=%s (want %s), %d sample lines; %s" % (
                    k, rcs[k], m.group(1) if m else "?", m.group(2) if m else "?", want_backend[k],
                    sum(1 for _, kk, _ in P[k]["items"] if kk == "sample"), say_counters(c) if c else "NO TRAILER"),
                ["unknown: line %d %r" % u for u in P[k]["unknown"]]
                + ([] if m is not None and m.group(2) == want_backend[k] else
                   ["backend %s, where %s is wanted" % (m.group(2) if m else "NONE", want_backend[k])]))
    if not args.dry_host:
        dl = [l for l in herr.splitlines() if l.startswith("cft hip: ")]
        verdict(len(dl) >= 1 and all(args.expect in l for l in dl),
                "the hip:0 run's device line(s), %d, each naming %r: %s" % (len(dl), args.expect,
                                                                            dl[0][:150] if dl else "NONE"))
        dv = P["wave"]["device"]
        verdict(len(dv) == 1 and args.expect in dv[0][1] and dv[0][1] == kdev
                and not P["cpu"]["device"] and not P["hip"]["device"],
                "the kernel record's device line(s), %d, naming %r and the same as its --device-info line (%s), and "
                "the port's records' none (cpu %d, hip %d): %s" % (
                    len(dv), args.expect, bool(dv) and dv[0][1] == kdev, len(P["cpu"]["device"]),
                    len(P["hip"]["device"]), dv[0][1][:150] if dv else "NONE"))
    else:
        nd = {k: len(P[k]["device"]) for k in P}
        verdict(not any(nd.values()), "dry run: no record carries a `# device` line on the host: %s" % nd)
    for k in ("hip", "wave"):
        d = compare(P["cpu"], P[k])
        rows = [v for _, kk, v in P[k]["items"] if kk == "sample"]
        nbody = sum(1 for _, kk, v in P[k]["items"] if kk == "line" and v.startswith("# body "))
        verdict(not d and len(rows) >= 3, "%s against cpu: %s" % (
            k, "IDENTICAL: %d sample lines of %d values, %d body lines, the header lines and the trailer's five "
               "counters" % (len(rows), len(rows[0]) if rows else 0, nbody) if not d else "%d difference(s)" % len(d)), d)
        print("         set aside by name: " + "; ".join(P[k]["aside"])[:400], flush=True)
    c = counters(P["cpu"])
    samp = [v for _, kk, v in P["cpu"]["items"] if kk == "sample"]
    N = P["cpu"]["N"]
    moved = sum(1 for b in range(N) if samp and body_xyz(samp[0], b) != body_xyz(samp[-1], b))
    shape = all(r[0] == "sample" and r[7 + 6 * N] == "|" and len(r) == 10 + 6 * N for r in samp)
    verdict(c is not None and c["steps_done"] == "12" and int(c["steps_rejected"] or 0) >= 1 and moved == N and shape,
            "the physics beside the bits: %s; %d of %d bodies moved between the first and the last sample; every "
            "sample line is `sample`, 6 head fields, %d bodies' 6, `|` and the exact-time pair: %s" % (
                say_counters(c) if c else "NO TRAILER", moved, N, N, shape))

    # 2. controls: one value planted a copy, each FAILing with exactly that difference
    print("2. controls: one value planted in a copy of the hip:0 record or the kernel's", flush=True)
    plants = [("wave", 0, "t"), ("wave", -1, "dt_next"), ("wave", 0, "body 1 x"), ("wave", -1, "body 22 vy"),
              ("wave", 1, "t_lo"), ("wave", "trailer", "steps_rejected"),
              ("hip", -1, "E"), ("hip", 0, "body 63 vz"), ("hip", -1, "body 6 z"), ("hip", -1, "step"),
              ("hip", "trailer", "mean_pc_iterations")]
    for k, where, col in plants:
        t2, ln, old, new = plant(text[k], where, col, N)
        d = compare(P["cpu"], parse(t2))
        tag = ("(the trailer): %s=" % col) if where == "trailer" else ("(%s):" % col)
        named = len(d) == 1 and d[0].startswith("line %d " % ln) and tag in d[0]
        verdict(named, "%s, %s on line %d (%s to %s): %s" % (k, col, ln, old, new,
                                                             "FAIL, by name: " + d[0] if named else
                                                             "%d difference(s), not the one planted" % len(d)), d)

    # 3. compare_run, this tree's driver, on the hip:0 record and the kernel's
    print("3. tools/compare_run.py: the hip:0 record and the kernel's, each against this tree's CPU rerun", flush=True)
    for k in ("hip", "wave"):
        rc, mem, parts, _, res, out = drive(args, paths[k], ring1, env_sw, os.path.join(W, "cr1.%s.log" % k))
        ok = rc == 0 and mem.get(0) == "IDENTICAL" and len(parts) >= 2 and all(p[4] == "IDENTICAL" for p in parts) \
            and res == "PASS"
        verdict(ok, "%s: compare_run rc %d, member 0 %s, %d particle(s) replayed, %s; RESULT: %s" % (
            k, rc, mem.get(0), len(parts), ", ".join("body %d %s" % (p[2], p[4]) for p in parts), res))

    # 4. P2 x P3: the kernel's own files, through compare_run --producer-files
    print("4. P2 x P3: the kernel's attempts records and schedules on three waves, through compare_run "
          "--producer-files", flush=True)
    D = os.path.join(W, "att3")
    shutil.rmtree(D, ignore_errors=True)
    os.makedirs(D)
    rec3 = os.path.join(W, "ring3w.wave.rec")
    rc, _, _ = run([args.wave] + dev + ["--problem", ring3, "--dt", "600", "--steps", "12", "--sample", "4", "--quiet",
                                        "--attempts-dir", D], env_sw, rec3)
    files = sorted(os.listdir(D))
    verdict(rc == 0 and all("member%d.%s" % (k, s) in files for k in range(3) for s in ("att", "sched")),
            "the kernel's three-wave run: rc %d, its files %s" % (rc, " ".join(files)))
    rc, mem, parts, notrerun, res, out = drive(args, rec3, ring3, env_sw, os.path.join(W, "cr3.log"),
                                               ["--producer-files", D, "--particle-strata", "3"])
    fromfiles = [p for p in parts if p[3]]
    ok = (rc == 0 and res == "PASS" and notrerun and parts and all(p[4] == "IDENTICAL" for p in parts)
          and all(any(p[0] == k for p in fromfiles) for k in notrerun)
          and all(v in ("IDENTICAL", "NOT RERUN") for v in mem.values()))
    verdict(ok, "compare_run --producer-files: rc %d, members %s, not rerun %s; %d particle(s), %d from P2's own "
                "files: %s; RESULT: %s" % (rc, mem, notrerun, len(parts), len(fromfiles),
                                           ", ".join("%d:%d %s" % (p[0], p[2], p[4]) for p in parts), res))
    if notrerun:
        k = notrerun[0]
        Dp = D + ".plant"
        shutil.rmtree(Dp, ignore_errors=True)
        shutil.copytree(D, Dp)
        att = os.path.join(Dp, "member%d.att" % k)
        lines = open(att).read().split("\n")
        idx = [i for i, l in enumerate(lines) if re.fullmatch(r"-?0x\S+ [ar]", l)]
        i = idx[2]
        dt, outcome = lines[i].split()
        lines[i] = "%s %s" % (bump(dt), outcome)
        open(att, "w", newline="\n").write("\n".join(lines))
        changed = sum(1 for x, y in zip(open(os.path.join(D, "member%d.att" % k)).read().split("\n"), lines) if x != y)
        if changed != 1:
            raise SystemExit("p1p2_seam: the attempts plant changed %d lines, not one" % changed)
        rc, mem, parts2, _, res, out = drive(args, rec3, ring3, env_sw, os.path.join(W, "cr3.plant.log"),
                                             ["--producer-files", Dp, "--particle-strata", "3"])
        mine = [p for p in parts2 if p[0] == k]
        others = [p for p in parts2 if p[0] != k]
        ok = (rc != 0 and res == "FAIL" and mine and all(p[4] == "FAIL" for p in mine)
              and others and all(p[4] == "IDENTICAL" for p in others))
        verdict(ok, "control: member %d's attempts record, line %d, dt %s moved one ulp: compare_run rc %d, its "
                    "particles %s, the others' %s; RESULT: %s" % (k, i + 1, dt, rc,
                                                                  ", ".join("body %d %s" % (p[2], p[4]) for p in mine),
                                                                  ", ".join("%d:%d %s" % (p[0], p[2], p[4])
                                                                            for p in others), res))
    print("p1p2_seam: %d ok, %d FAIL" % (OKS[0], len(FAILS)), flush=True)
    print("RESULT: %s" % ("PASS" if not FAILS else "FAIL"), flush=True)
    return 0 if not FAILS else 1


if __name__ == "__main__":
    sys.exit(main())
