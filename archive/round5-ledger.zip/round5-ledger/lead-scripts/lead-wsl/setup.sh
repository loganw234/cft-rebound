#!/bin/bash
# round 5 lead: the merged tree (round5-int with P1 merged) in WSL cft-gpu, from desktop bundles,
# built with HIP=1 for the RTX 5060 Ti. Usage: setup.sh <merged commit>. Own directory only.
set -e
C=${1:?merged commit}
S=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad
G=$S/gpu/lead-wsl
W=/root/cft-rebound-r5-lead
mkdir -p $W/bundles $W/py
cp $G/cft-rebound-lead.bundle $W/bundles/
cp $S/r5v1/bundles/cft-fp256.bundle $S/r5v1/bundles/rebound.bundle $W/bundles/
(cd $W/bundles && sha256sum *.bundle)
cd $W
rm -rf tree
git clone -q bundles/cft-rebound-lead.bundle tree
git -C tree checkout -q --detach $C
git clone -q --no-checkout bundles/cft-fp256.bundle tree/third_party/cft-fp256
git -C tree/third_party/cft-fp256 checkout -q eae74e3eddc67836d4b7c8922badd40e6e1bdb2f
git clone -q --no-checkout bundles/rebound.bundle tree/third_party/rebound
git -C tree/third_party/rebound checkout -q bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93
git -C tree log --oneline -1
(cd tree && bash tools/check_pins.sh)
rm -rf $W/py/mpmath
tar -C $W/py -xzf $S/r5v1/mpmath-1.3.0-desktop.tgz
PYTHONPATH=$W/py python3 -c "import mpmath; print('mpmath', mpmath.__version__)"
set +e
cd $W/tree
export HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120
make clean > /dev/null 2>&1
s=$(date +%s)
make HIP=1 HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120 PYTHON=python3 all programs > $W/build-hip.log 2>&1
rc=$?
echo "build rc=$rc in $(( $(date +%s) - s )) s; $(grep -c 'warning:' $W/build-hip.log) warnings"
tail -2 $W/build-hip.log
ldd build/ias15_cft | grep -i -E 'cuda|hip'
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
CFT_REBOUND_ARTIFACT=hip:0 CFT_HIP_INFO=1 ./build/ias15_cft --probe 2>&1 | grep -E '^cft hip|^backend|^seq_features'
exit $rc
