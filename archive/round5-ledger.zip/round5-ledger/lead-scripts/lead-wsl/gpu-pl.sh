#!/bin/bash
# round 5 lead: PL's merge on the RTX 5060 Ti (hip:0 must be the 5060 Ti, never the 4070): check-gpu's first
# recipe line with the one leg PL changed, check_compare_run (its case 6 now runs in every tier), held process
# by process to the software backend by check_gpu.py's witness. Run directly rather than through make, so that
# check-gpu's second line (check_wave, once P2 has merged) is not rerun here.
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
S=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad
W=/root/cft-rebound-r5-lead
export PYTHONPATH=$W/py
cd $W/tree || exit 1
L=$W/plgpu-$(git rev-parse --short HEAD)-$(date +%m%d-%H%M)
mkdir -p $L
echo "commit $(git log --oneline -1 | cut -c1-120); status $(git status --short | wc -l) changed; started $(date); CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" > $L/README
python3 tools/check_gpu.py --build build --artifact hip:0 --hip 1 --list > $L/list.txt 2>&1
s=$(date +%s)
python3 tools/check_gpu.py --build build --artifact hip:0 --hip 1 --expect "RTX 5060 Ti" --legs check_compare_run > $L/check-gpu.log 2>&1
rc=$?
echo "check_gpu --legs check_compare_run rc $rc in $(( $(date +%s) - s )) s; $(grep -E '^check_gpu: [0-9]|^RESULT' $L/check-gpu.log | tr '\n' ' '); ended $(date)" >> $L/README
cp -r $L $S/gpu/lead-wsl/
cat $L/README
[ $rc -eq 0 ]
