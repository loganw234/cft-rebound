#!/bin/bash
# round 5 lead: the GPU seam and the witness's controls on the merged tree, on the RTX 5060 Ti
# (hip:0 must be the 5060 Ti, never the 4070), as P1 ran them: --parts controls,seam, no legs.
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
S=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad
W=/root/cft-rebound-r5-lead
export PYTHONPATH=$W/py
cd $W/tree || exit 1
L=$W/seam-$(git rev-parse --short HEAD)-$(date +%m%d-%H%M)
mkdir -p $L
echo "commit $(git log --oneline -1 | cut -c1-120); status $(git status --short | wc -l) changed; started $(date); CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" > $L/README
python3 tools/check_gpu.py --build $W/tree/build --artifact hip:0 --hip 1 --expect "RTX 5060 Ti" --no-legs --keep --parts controls,seam > $L/seam.log 2>&1
rc=$?
echo "rc $rc; $(grep -E '^check_gpu: [0-9]' $L/seam.log); ended $(date)" >> $L/README
cp -r $L $S/gpu/lead-wsl/
cat $L/README
exit $rc
