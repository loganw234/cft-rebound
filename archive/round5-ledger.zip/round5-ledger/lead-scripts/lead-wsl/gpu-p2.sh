#!/bin/bash
# round 5 lead: the P1 x P2 and P2 x P3 seams on the P2-merged tree, on the RTX 5060 Ti (hip:0 must be the
# 5060 Ti, never the 4070): (a) the merged check-gpu recipe with one leg (check_records), then its second line,
# check_wave --device gpu --quick; (b) p1p2_seam.py, one ring wave three ways and the kernel's own files.
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
S=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad
G=$S/gpu/lead-wsl
W=/root/cft-rebound-r5-lead
export PYTHONPATH=$W/py
cd $W/tree || exit 1
L=$W/p2seam-$(git rev-parse --short HEAD)-$(date +%m%d-%H%M)
mkdir -p $L
echo "commit $(git log --oneline -1 | cut -c1-120); status $(git status --short | wc -l) changed; started $(date); CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" > $L/README
s=$(date +%s)
make HIP=1 HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120 PYTHON=python3 GPU_EXPECT="RTX 5060 Ti" GPU_LEGS=check_records check-gpu > $L/check-gpu.log 2>&1
rca=$?
echo "a: make check-gpu (GPU_LEGS=check_records) rc $rca in $(( $(date +%s) - s )) s; $(grep -E '^check_gpu: [0-9]' $L/check-gpu.log); $(grep -E '^check_wave: [0-9]|^RESULT' $L/check-gpu.log | tr '\n' ' ')" >> $L/README
s=$(date +%s)
python3 $G/p1p2_seam.py --tree $W/tree --work $L/seam --expect "RTX 5060 Ti" > $L/p1p2.log 2>&1
rcb=$?
echo "b: p1p2_seam rc $rcb in $(( $(date +%s) - s )) s; $(grep -E '^p1p2_seam: [0-9]' $L/p1p2.log); ended $(date)" >> $L/README
rm -rf $L/seam/att3.plant
cp -r $L $S/gpu/lead-wsl/
cat $L/README
[ $rca -eq 0 ] && [ $rcb -eq 0 ]
