#!/bin/bash
G=/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/lead-wsl
L=$G/run-fda3b40.log
echo "start $(date '+%F %T')" > $L
MSYS_NO_PATHCONV=1 wsl.exe -d cft-gpu --exec bash /mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/lead-wsl/run.sh fda3b40 >> $L 2>&1 &
p=$!
cat /proc/$p/winpid > $G/wsl.winpid 2>/dev/null
echo "wsl.exe msys pid $p, windows pid $(cat $G/wsl.winpid)" >> $L
wait $p; rc=$?
echo "wsl rc=$rc; end $(date '+%F %T')" >> $L
exit $rc
