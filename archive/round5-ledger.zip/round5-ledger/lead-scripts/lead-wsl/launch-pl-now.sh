#!/bin/bash
# round 5 lead: PowerShell's Start-Process passes only a script path, so this
# wrapper names the merged commit (cft-rebound-r5's HEAD, which must already be
# in cft-rebound-lead.bundle) and hands it to launch-pl.sh.
C=$(git -C /c/Users/logan/source/repos/cft-rebound-r5 rev-parse --short HEAD) || exit 1
exec bash /c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/lead-wsl/launch-pl.sh "$C"
