#!/bin/bash
# round 5 lead: setup, then the P2 seams, in WSL cft-gpu (one wsl.exe process for the booking's pid)
G=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad/gpu/lead-wsl
echo "=== setup $(date '+%F %T')"
bash $G/setup-p2.sh "$1"; rc=$?
echo "setup rc=$rc"
[ $rc -eq 0 ] || exit $rc
echo "=== p2 seams $(date '+%F %T')"
bash $G/gpu-p2.sh; rc=$?
echo "seam rc=$rc $(date '+%F %T')"
exit $rc
