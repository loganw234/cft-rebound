#!/bin/bash
# round 5 lead: p1p2_seam.py alone (after its device-line fix) on the already-built tree in WSL cft-gpu, RTX 5060 Ti
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1
S=/mnt/c/Users/logan/AppData/Local/Temp/claude/443d8e8619fd4f31/fa64df2f-560a-4117-8348-b3ce1b89172a/scratchpad
G=$S/gpu/lead-wsl
W=/root/cft-rebound-r5-lead
export PYTHONPATH=$W/py
cd $W/tree || exit 1
L=$W/seamtest-$(git rev-parse --short HEAD)-$(date +%m%d-%H%M)
mkdir -p $L
echo "commit $(git log --oneline -1 | cut -c1-80); status $(git status --short | wc -l) changed; seam script sha $(sha256sum $G/p1p2_seam.py | cut -c1-16)" > $L/README
python3 $G/p1p2_seam.py --tree $W/tree --work $L/seam --expect "RTX 5060 Ti" > $L/p1p2.log 2>&1
rc=$?
echo "p1p2_seam rc $rc; $(grep -E '^p1p2_seam: [0-9]' $L/p1p2.log)" >> $L/README
rm -rf $L/seam/att3.plant
cp -r $L $G/
cat $L/README
exit $rc
