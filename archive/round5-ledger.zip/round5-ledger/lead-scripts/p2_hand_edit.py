"""The lead's hand edit at P2's merge (round 5): check_wave on the GPU as check-gpu's second recipe line.

usage: python p2_hand_edit.py MAKEFILE
Each anchor must land exactly once, or nothing is written and it refuses.
"""
import sys

p = sys.argv[1]
with open(p, newline="") as f:
    s = f.read()
if "\r\n" in s:
    sys.exit("REFUSED: %s has CRLF line endings" % p)
edits = [
    ("#   make HIP=1 check-gpu  on a GPU host only: the record-making legs on\n"
     "#                         hip:0, held to the software backend process by\n"
     "#                         process (tools/check_gpu.py). Refuses by name\n"
     "#                         where there is no hip:0, and is in no tier\n",
     "#   make HIP=1 check-gpu  on a GPU host only: the record-making legs on\n"
     "#                         hip:0, held to the software backend process by\n"
     "#                         process (tools/check_gpu.py), then the wave\n"
     "#                         kernel on the GPU (tools/check_wave.py --device\n"
     "#                         gpu --quick). Refuses by name where there is no\n"
     "#                         hip:0, and is in no tier\n"),
    ("# WSL cft-gpu, \"RTX 5060 Ti\": hip:0 must never be the 4070 there).\n"
     "GPU_ARTIFACT ?= hip:0\n",
     "# WSL cft-gpu, \"RTX 5060 Ti\": hip:0 must never be the 4070 there).\n"
     "# The second line is P2's kernel (ROUND5.md, P2): tools/check_wave.py on\n"
     "# the GPU in its quick form, each record held to this tree's port and to\n"
     "# the GPU build's own host twin. It runs once the first line passes, and\n"
     "# GPU_LEGS and GPU_SKIP do not reach it. The kernel opens the first\n"
     "# device the GPU runtime shows it (src/wave/wave_gpu.inc, hipSetDevice(0)),\n"
     "# and its probe holds that device's line to GPU_EXPECT before anything runs.\n"
     "GPU_ARTIFACT ?= hip:0\n"),
    ("check-gpu: check-pins all programs\n",
     "check-gpu: check-pins all programs $(if $(filter 1,$(HIP)),wave)\n"),
    ("\t    $(if $(GPU_LEGS),--legs $(GPU_LEGS)) $(if $(GPU_SKIP),--skip $(GPU_SKIP))\n",
     "\t    $(if $(GPU_LEGS),--legs $(GPU_LEGS)) $(if $(GPU_SKIP),--skip $(GPU_SKIP))\n"
     "\t$(PYTHON) tools/check_wave.py --build $(B) --device gpu --quick --expect '$(GPU_EXPECT)'\n"),
]
for old, new in edits:
    n = s.count(old)
    if n != 1:
        sys.exit("REFUSED: an anchor lands %d times, not once: %r" % (n, old[:70]))
for old, new in edits:
    s = s.replace(old, new)
with open(p, "w", newline="") as f:
    f.write(s)
print("applied %d edits to %s" % (len(edits), p))
