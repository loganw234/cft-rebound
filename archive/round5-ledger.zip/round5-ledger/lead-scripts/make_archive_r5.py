"""Round 5's ledger, archived as round 4's was: one zip, each file under
round5-ledger/ with its original timestamp, deflated, in sorted order, and
every entry checked byte for byte against its source.
Usage: python -I make_archive_r5.py OUT.zip"""
import os
import sys
import time
import zipfile

SCR = r"C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad"
LEDGER = r"C:\Users\logan\source\repos\cft-rebound\.ledger"
G = os.path.join(SCR, "gpu")
W = os.path.join(G, "lead-wsl")

entries = {}                      # archive name -> source path


def add(name, path):
    if not os.path.isfile(path):
        sys.exit("make_archive_r5: missing %s" % path)
    key = "round5-ledger/" + name
    if key in entries:
        sys.exit("make_archive_r5: %s twice" % name)
    entries[key] = path


# the ledger: README, the lead's file, every author's placed entries, urgent/
for f in sorted(os.listdir(LEDGER)):
    p = os.path.join(LEDGER, f)
    if os.path.isfile(p) and f.endswith(".md"):
        add(f, p)
for f in sorted(os.listdir(os.path.join(LEDGER, "urgent"))):
    add("urgent/" + f, os.path.join(LEDGER, "urgent", f))

# every dispatched brief, and the verifier templates they were filled from
for f in sorted(os.listdir(os.path.join(G, "briefs", "filled"))):
    if f.startswith("R5-"):
        add("brief-" + f[len("R5-"):], os.path.join(G, "briefs", "filled", f))
add("brief-V-common.md", os.path.join(G, "briefs", "V-common.md"))
add("brief-V-attacks.md", os.path.join(G, "briefs", "V-attacks.md"))
add("brief-fill_v.py", os.path.join(G, "briefs", "fill_v.py"))

# every report, verbatim: R5-<who>-report[-<n>].md -> report-<who>[-<n>].md
for f in sorted(os.listdir(os.path.join(G, "reports"))):
    if not f.startswith("R5-"):
        continue
    who, _, n = f[len("R5-"):-len(".md")].partition("-report")
    add("report-%s%s.md" % (who, n), os.path.join(G, "reports", f))

# the full make check logs this round read
for src, name in (("r5-check-d7b5047.log", "logs/make-check-d7b5047.log"),
                  ("int-check-4a8fe99.log", "logs/make-check-4a8fe99.log"),
                  ("int-check-fda3b40.log", "logs/make-check-fda3b40.log"),
                  ("int-check-620c98b.log", "logs/make-check-620c98b.log"),
                  ("int-check-7444157.log", "logs/make-check-7444157-stopped.log"),
                  ("int-check-61e45bc.log", "logs/make-check-61e45bc.log")):
    add(name, os.path.join(G, src))

# the lead's GPU checks and seams in WSL cft-gpu, with their launchers' logs
for d, files in (("seam-fda3b40-1118-1547", ("README", "seam.log")),
                 ("plgpu-620c98b-1119-1339", ("README", "check-gpu.log", "list.txt")),
                 ("p2seam-7444157-1120-0100", ("README", "check-gpu.log", "p1p2.log")),
                 ("seamtest-7444157-1120-0123", ("README", "p1p2.log")),
                 ("seamtest-7444157-1120-0125", ("README", "p1p2.log")),
                 ("p2seam-61e45bc-1120-0213", ("README", "check-gpu.log", "p1p2.log"))):
    for f in files:
        add("logs/gpu/%s/%s" % (d, f), os.path.join(W, d, f))
for f in ("run-fda3b40.log", "run-pl-620c98b.log", "run-pl-620c98b.wsl.log", "run-p2-7444157.log",
          "run-p2-7444157.wsl.log", "run-p2-61e45bc.log", "run-p2-61e45bc.wsl.log"):
    add("logs/gpu/" + f, os.path.join(W, f))
for f in ("dry1.log", "dry2.log"):
    add("logs/seam-dry-runs/" + f, os.path.join(G, "p1p2", f))

# the lead's scripts
for f in ("resolve_tiers.py", "p2_hand_edit.py", "int-check-r5-p1.sh", "int-check-r5-p2.sh", "int-check-r5-p3.sh",
          "int-check-r5-pl.sh", "drop-watch-r5.sh", "make_archive_r5.py"):
    add("lead-scripts/" + f, os.path.join(G, f))
for f in ("legcmp.py", "legkeys.py", "normlog.py", "durable_copy.py"):
    add("lead-scripts/" + f, os.path.join(G, "tools", f))
for f in ("setup.sh", "seam.sh", "run.sh", "launch.sh", "setup-pl.sh", "gpu-pl.sh", "run-pl.sh", "launch-pl.sh",
          "launch-pl-now.sh", "setup-p2.sh", "gpu-p2.sh", "run-p2.sh", "launch-p2.sh", "launch-p2-now.sh",
          "seamtest.sh", "p1p2_seam.py", "p1p2_seam.py.orig-7444157"):
    add("lead-scripts/lead-wsl/" + f, os.path.join(W, f))
for f in ("harness.py", "harness2.py"):
    add("lead-scripts/seamfix-test/" + f, os.path.join(G, "seamfix-test", f))

out = sys.argv[1]
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(entries):
        path = entries[name]
        zi = zipfile.ZipInfo(name, date_time=time.localtime(os.path.getmtime(path))[:6])
        zi.compress_type = zipfile.ZIP_DEFLATED
        with open(path, "rb") as f:
            z.writestr(zi, f.read(), compresslevel=9)
# verify: every entry's bytes are its source's, and nothing else is in the zip
with zipfile.ZipFile(out) as z:
    bad = [n for n in entries if z.read(n) != open(entries[n], "rb").read()]
    if bad or sorted(z.namelist()) != sorted(entries):
        sys.exit("make_archive_r5: %d entries differ from their sources: %s" % (len(bad), bad[:5]))
print("%s: %d entries, %d bytes, every entry byte-identical to its source"
      % (out, len(entries), os.path.getsize(out)))
