"""For each --leg line in two logs: the tokens in one and not the other, outside programs/out/."""
import re, sys
def keys(path):
    d = {}
    for line in open(path, encoding="utf-8", errors="replace"):
        m = re.search(r"--leg (\S+)", line)
        if m and "gate_cache.py" in line:
            d[m.group(1)] = line.split()
    return d
a, b = keys(sys.argv[1]), keys(sys.argv[2])
for leg in a:
    ta, tb = a[leg], b.get(leg, [])
    onlya = [t for t in ta if t not in tb and t != "--input"]
    onlyb = [t for t in tb if t not in ta and t != "--input"]
    po = [t for t in onlyb if t.startswith("programs/out/")]
    rest_b = [t for t in onlyb if not t.startswith("programs/out/")]
    print("%-22s A-only %d  B-only %d (programs/out %d, other %d)%s" % (leg, len(onlya), len(onlyb), len(po), len(rest_b),
          ("  A-only: " + " ".join(onlya[:6]) if onlya else "") + ("  B-other: " + " ".join(rest_b[:6]) if rest_b else "")))
