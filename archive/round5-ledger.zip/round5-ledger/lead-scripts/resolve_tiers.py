"""The lead's resolver for round 5's second merge (P2 x PL): the three tier conflicts in the Makefile.

P2 changed each tier's target line (`check: ... wave-host ...`) and PL's 4fcd775 the constants line right
under it, so a merge of either onto the other leaves three conflict blocks. Run the merge with
`-c merge.conflictstyle=diff3`, then:

    python resolve_tiers.py MAKEFILE [EXPECTED]

Each block is resolved line by line: where one side kept the base's line, the other side's line is taken.
It refuses (and writes nothing) unless there are exactly three diff3 blocks, each with the same number of
lines in ours, base and theirs, each line changed by at most one side, and every resolved line a tier's
target line or a constants line. With EXPECTED, the result must equal that file byte for byte.
"""
import re
import sys

p = sys.argv[1]
with open(p, newline="") as f:
    text = f.read()
if "\r\n" in text:
    sys.exit("REFUSED: CRLF in %s" % p)
lines = text.split("\n")
out, i, blocks = [], 0, []
TIER = re.compile(r"^(check|check-quick|check-light): check-pins all programs ")
while i < len(lines):
    l = lines[i]
    if not l.startswith("<<<<<<< "):
        if l.startswith(("||||||| ", ">>>>>>> ")) or l == "=======":
            sys.exit("REFUSED: a stray conflict marker at line %d" % (i + 1))
        out.append(l)
        i += 1
        continue
    j, ours = i + 1, []
    while not lines[j].startswith("||||||| "):
        if lines[j].startswith(("<<<<<<< ", ">>>>>>> ")) or lines[j] == "=======":
            sys.exit("REFUSED: block at line %d is not diff3 style" % (i + 1))
        ours.append(lines[j])
        j += 1
    j, base = j + 1, []
    while lines[j] != "=======":
        base.append(lines[j])
        j += 1
    j, theirs = j + 1, []
    while not lines[j].startswith(">>>>>>> "):
        theirs.append(lines[j])
        j += 1
    if not len(ours) == len(base) == len(theirs):
        sys.exit("REFUSED: block at line %d has %d/%d/%d lines (ours/base/theirs)"
                 % (i + 1, len(ours), len(base), len(theirs)))
    res = []
    for o, b, t in zip(ours, base, theirs):
        if o == t:
            res.append(o)
        elif o == b:
            res.append(t)
        elif t == b:
            res.append(o)
        else:
            sys.exit("REFUSED: block at line %d: both sides changed %r" % (i + 1, b[:70]))
    for r in res:
        if not (TIER.match(r) or "--leg constants " in r):
            sys.exit("REFUSED: block at line %d resolves to a line that is neither a tier's target nor a "
                     "constants line: %r" % (i + 1, r[:70]))
    blocks.append((i + 1, res))
    out.extend(res)
    i = j + 1
if len(blocks) != 3:
    sys.exit("REFUSED: %d conflict blocks, not 3" % len(blocks))
result = "\n".join(out)
if len(sys.argv) > 2:
    with open(sys.argv[2], newline="") as f:
        want = f.read()
    if result != want:
        sys.exit("REFUSED: the resolution is not the expected Makefile")
with open(p, "w", newline="") as f:
    f.write(result)
for at, res in blocks:
    print("resolved the block at line %d:" % at)
    for r in res:
        print("    " + r[:150])
print("3 blocks resolved%s" % (", equal to the expected Makefile" if len(sys.argv) > 2 else ""))
