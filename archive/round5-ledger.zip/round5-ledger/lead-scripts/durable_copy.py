"""Copy round 5's scratch into .ledger/scratch-r5/ (the durable copy), leaving out what can be
rebuilt: git bundles, build and third_party trees, mutant and dry-run copies, binaries, caches,
and any file over 20 MB. Existing files are overwritten; nothing is deleted. Prints a summary."""
import os, shutil, sys
SRC = r"C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad"
DST = r"C:\Users\logan\source\repos\cft-rebound\.ledger\scratch-r5"
DIRS = ["gpu", "p1", "p2r5", "p3-r5", "r5v1", "v2", "v3-r5", "v3-r5b", "v3-r5c", "ledger-drop-r5", "mkn", "genhdr"]
SKIP_DIRS = {"build", "third_party", "__pycache__", "bundles", ".git", "tree", "xgpu"}
SKIP_PREFIX = ("mut-", "mut_", "dry-mut", "p3cr", "mut-tree", "mut-p3")
SKIP_EXT = {".bundle", ".exe", ".o", ".a", ".so", ".dll", ".pack", ".tgz", ".bin"}
LIMIT = 20 * 1024 * 1024
copied = skipped = 0
size = 0
for d in DIRS:
    top = os.path.join(SRC, d)
    if not os.path.isdir(top):
        print("absent:", d); continue
    for root, dirs, files in os.walk(top):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(SKIP_PREFIX)]
        rel = os.path.relpath(root, SRC)
        for f in files:
            p = os.path.join(root, f)
            if os.path.splitext(f)[1].lower() in SKIP_EXT or os.path.getsize(p) > LIMIT:
                skipped += 1; continue
            q = os.path.join(DST, rel, f)
            os.makedirs(os.path.dirname(q), exist_ok=True)
            shutil.copy2(p, q); copied += 1; size += os.path.getsize(p)
print("copied %d files, %.1f MB; skipped %d (bundles, binaries, archives, files over 20 MB)" % (copied, size / 1e6, skipped))
