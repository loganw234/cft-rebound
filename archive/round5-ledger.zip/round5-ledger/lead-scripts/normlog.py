"""Print a make-check log with volatile tokens masked, leg by leg, leaving out one named leg."""
import re, sys
path, skip = sys.argv[1], sys.argv[2]
cur = None
for line in open(path, encoding="utf-8", errors="replace"):
    m = re.search(r"--leg (\S+)", line)
    if m and "gate_cache.py" in line:
        cur = m.group(1)
    if cur == skip:
        continue
    s = line.rstrip("\n")
    s = re.sub(r"\b\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?\b", "<DATE>", s)
    s = re.sub(r"\b\d+h\d+m\d+s\b|\b\d+m\d+(\.\d+)?s\b|\b\d+(\.\d+)?\s?(s|ms|sec|seconds|min)\b", "<T>", s)
    s = re.sub(r"(seconds|wall_seconds|steps_per_s|system_steps_per_s|t_[a-z_]+)=\S+", r"\1=<T>", s)
    s = re.sub(r"\b[0-9a-f]{7,40}\b", "<SHA>", s)
    s = re.sub(r"[A-Za-z]:[\/][^\s'\"]*|/c/[^\s'\"]*|/tmp/[^\s'\"]*", "<PATH>", s)
    s = re.sub(r"\bB\d{4}\b", "<BOOK>", s)
    s = re.sub(r"\bpid \d+|\bpids? \d+", "pid <N>", s)
    print(s)
