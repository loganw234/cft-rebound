"""Compare two make-check logs leg by leg: per leg, ok / FAIL / RESULT / Error! counts and the
summary lines that carry counts. Prints one row per leg and every difference."""
import re, sys

def legs(path):
    rows, cur, order = {}, None, []
    pre = {"ok": 0, "FAIL": 0, "RESULT": [], "Error": 0, "warn": 0, "summ": []}
    for line in open(path, encoding="utf-8", errors="replace"):
        m = re.search(r"--leg (\S+)", line)
        if m and "gate_cache.py" in line:
            cur = m.group(1)
            if cur in rows:
                cur = cur + "#2"
            order.append(cur)
            rows[cur] = {"ok": 0, "FAIL": 0, "RESULT": [], "Error": 0, "warn": 0, "summ": []}
            continue
        r = rows[cur] if cur else pre
        s = line.rstrip("\n")
        if re.match(r"^\s*ok\s", s): r["ok"] += 1
        if re.match(r"^\s*FAIL\b", s): r["FAIL"] += 1
        if re.match(r"^\s*RESULT", s): r["RESULT"].append(s.strip()[:60])
        if s.startswith("Error!"): r["Error"] += 1
        if "warning:" in s: r["warn"] += 1
        if re.search(r"\b\d+ ok, \d+ FAIL\b", s): r["summ"].append(re.sub(r"\s+", " ", s.strip())[:140])
    return pre, rows, order

a_pre, a, ao = legs(sys.argv[1])
b_pre, b, bo = legs(sys.argv[2])
print("pre-leg (build):  A warn %d Error %d | B warn %d Error %d" % (a_pre["warn"], a_pre["Error"], b_pre["warn"], b_pre["Error"]))
print("legs: A %d, B %d; same order: %s" % (len(ao), len(bo), ao == bo))
names = ao + [n for n in bo if n not in a]
for n in names:
    x, y = a.get(n), b.get(n)
    if x is None or y is None:
        print("%-22s only in %s" % (n, "B" if x is None else "A")); continue
    same = (x["ok"], x["FAIL"], x["RESULT"], x["Error"], x["warn"]) == (y["ok"], y["FAIL"], y["RESULT"], y["Error"], y["warn"])
    print("%-22s ok %4d -> %4d  FAIL %d -> %d  RESULT %s -> %s  Error! %d -> %d  warn %d -> %d  %s" % (
        n, x["ok"], y["ok"], x["FAIL"], y["FAIL"], len(x["RESULT"]), len(y["RESULT"]), x["Error"], y["Error"],
        x["warn"], y["warn"], "same" if same else "DIFFERS"))
    if x["summ"] != y["summ"]:
        for s in x["summ"]:
            if s not in y["summ"]: print("      A only: " + s)
        for s in y["summ"]:
            if s not in x["summ"]: print("      B only: " + s)
