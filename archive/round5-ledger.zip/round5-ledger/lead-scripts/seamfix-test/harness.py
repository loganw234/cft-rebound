"""Offline controls for the lead's p1p2_seam.py device-line fix, on the saved records of the failed 7444157 run."""
import importlib.util, sys
spec = importlib.util.spec_from_file_location("seam", sys.argv[1]); seam = importlib.util.module_from_spec(spec); spec.loader.exec_module(seam)
d = sys.argv[2]
text = {k: open("%s/ring1w.%s.rec" % (d, k)).read() for k in ("cpu", "hip", "wave")}
P = {k: seam.parse(t) for k, t in text.items()}
EXP = "RTX 5060 Ti"
def dev_ok(P):
    dv = P["wave"]["device"]
    return len(dv) == 1 and EXP in dv[0][1] and not P["cpu"]["device"] and not P["hip"]["device"]
res = []
def check(name, cond):
    res.append(cond); print("%-4s %s" % ("ok" if cond else "FAIL", name))
N = P["cpu"]["N"]
check("wave against cpu: 0 differences now (was 1)", seam.compare(P["cpu"], P["wave"]) == [])
check("hip against cpu: still 0 differences", seam.compare(P["cpu"], P["hip"]) == [])
check("no unknown lines in any record", all(not P[k]["unknown"] for k in P))
check("device verdict holds on the real records: wave has 1 naming %r, cpu 0, hip 0" % EXP, dev_ok(P))
def with_wave(t):
    Q = dict(P); Q["wave"] = seam.parse(t); return Q
lines = text["wave"].split("\n")
di = [i for i, l in enumerate(lines) if l.startswith("# device ")]
check("exactly one device line in the wave record, at line %d" % (di[0] + 1 if di else -1), len(di) == 1)
# controls: each must make the check FAIL
t = "\n".join(lines[:di[0] + 1] + ["# foo an unknown header"] + lines[di[0] + 1:])
dd = seam.compare(P["cpu"], seam.parse(t))
check("control: an extra unknown header in the wave record still FAILs (1 difference: %s)" % (dd[:1],), len(dd) == 1 and "no known kind" in dd[0])
t = "\n".join(lines[:di[0]] + lines[di[0] + 1:])
check("control: the device line removed FAILs the device verdict", not dev_ok(with_wave(t)))
t = "\n".join(lines[:di[0]] + [lines[di[0]].replace("RTX 5060 Ti", "RTX 4070")] + lines[di[0] + 1:])
check("control: the device line naming another GPU FAILs the device verdict", not dev_ok(with_wave(t)))
t = "\n".join(lines[:di[0] + 1] + [lines[di[0]]] + lines[di[0] + 1:])
check("control: two device lines FAIL the device verdict", not dev_ok(with_wave(t)))
cl = text["cpu"].split("\n"); Q = dict(P); Q["cpu"] = seam.parse("\n".join(cl[:3] + [lines[di[0]]] + cl[3:]))
check("control: a device line in the port's cpu record FAILs the device verdict", not dev_ok(Q))
# a value change inside the device line is set aside, by design: the line is metadata, held only by the verdict above
for k, where, col in [("wave", 0, "t"), ("wave", -1, "dt_next"), ("wave", 0, "body 1 x"), ("wave", -1, "body 22 vy"),
                      ("wave", 1, "t_lo"), ("wave", "trailer", "steps_rejected")]:
    t2, ln, old, new = seam.plant(text[k], where, col, N)
    dd = seam.compare(P["cpu"], seam.parse(t2))
    tag = ("(the trailer): %s=" % col) if where == "trailer" else ("(%s):" % col)
    check("wave control %s on line %d: exactly the one planted difference" % (col, ln), len(dd) == 1 and dd[0].startswith("line %d " % ln) and tag in dd[0])
print("%d ok, %d FAIL" % (sum(res), len(res) - sum(res)))
sys.exit(0 if all(res) else 1)
