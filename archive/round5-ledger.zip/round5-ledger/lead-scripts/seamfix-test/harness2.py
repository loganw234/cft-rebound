"""Offline checks of the backend expectation in the lead's p1p2_seam.py, on the saved records."""
import importlib.util, re, sys
spec = importlib.util.spec_from_file_location("seam", sys.argv[1]); seam = importlib.util.module_from_spec(spec); spec.loader.exec_module(seam)
d = sys.argv[2]
wave = open("%s/ring1w.wave.rec" % d).read()
def want(text):
    P = seam.parse(text); dv = P["device"]
    am = re.search(r"\((sm_\d+|gfx[0-9a-f]+), ", dv[0][1]) if len(dv) == 1 else None
    return "hip:0:" + (am.group(1) if am else "<the arch of its one # device line>")
def got(text):
    m = re.search(r"^# program=(\S+) .*?backend=(\S+)", text, re.M); return m.group(2) if m else None
res = []
def check(name, cond):
    res.append(cond); print("%-4s %s" % ("ok" if cond else "FAIL", name))
check("real record: backend %s, want %s" % (got(wave), want(wave)), got(wave) == want(wave))
check("control: backend=gpu FAILs", got(wave.replace("backend=hip:0:sm_120", "backend=gpu", 1)) != want(wave))
check("control: backend=hip:0:sm_89 FAILs", got(wave.replace("backend=hip:0:sm_120", "backend=hip:0:sm_89", 1)) != want(wave))
check("control: backend=hip:1:sm_120 FAILs", got(wave.replace("backend=hip:0:sm_120", "backend=hip:1:sm_120", 1)) != want(wave))
t = wave.replace("(sm_120, ", "(sm_89, ", 1)
check("control: the device line naming another arch FAILs", got(t) != want(t))
t = "\n".join(l for l in wave.split("\n") if not l.startswith("# device "))
check("control: no device line FAILs", got(t) != want(t))
print("%d ok, %d FAIL" % (sum(res), len(res) - sum(res))); sys.exit(0 if all(res) else 1)
