You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, the multi-precision arithmetic library of the sibling repository cft-fp256. Its central invariant is that every backend gives the same bits and **no committed record line moves** unless a change means it to. This round (ROUND5.md) brings in a new backend: libcft's GPU device, `hip:N`. The question is exactly that: **does this tree build with it, and does `hip:0` give the software backend's bits, with the records saying only what was measured?**

Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for the failure shapes to hunt: a gate driving a stand-in (here, a "GPU" run that quietly ran the software backend), a comparison that cannot fail, bit-identity taken for validity.

## What to verify

Round 5's P0, the lead's, three commits on branch `round5-p0` from main at `1354a05`:
- `d95ac0d`: the Makefile's `HIP=1`.
- `5389ff7`: ROUND5.md, the round's plan.
- `d7b5047`: docs/VALIDATION.md entry 54, P0's measurements.

Read each with `git show`. ROUND5.md's "Where it starts" and entry 54 are the claims.

## Where things are

- **The desktop.** Your isolated worktree. `git checkout --detach d7b5047` and confirm it. Clone the pins locally, never from the web: REBOUND from `/c/Users/logan/source/repos/cft-rebound/third_party/rebound` at bdfda4bd, and cft-fp256 from `/c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256` at eae74e3e. The lead's full `make check` on d7b5047 is running in `C:\Users\logan\source\repos\cft-rebound-r5` until about 09:00. Leave that tree alone and do not run a full `make check` yourself.
- **The GPU.** An AMD RX 7600 (gfx1102) on the Linux machine nvidia-box: `ssh -o BatchMode=yes logan@192.168.0.2` (key login). ROCm is at /opt/rocm.
  - Work only in **~/cft-rebound-r5-v0**, which you create.
  - Read the lead's ~/cft-rebound-r5 and /tmp/r5smoke if you need to, but never write them.
  - Never touch another session's directories there (g1a, g1b, g1b2 and the rest of ~).
  - mpmath 1.3.0 is at ~/cft-rebound-r5-py; use it with `PYTHONPATH=~/cft-rebound-r5-py`.
  - Carry code there as git bundles made on the desktop from local clones, `git bundle create` and then `scp`, as P0 did. Nothing comes from the web.
- **Booking.** The RX 7600 is the lead's from 09:00 to 17:00 (B0043, exclusive), and short work under 10 minutes may run in it. Before 09:00 it is free. For any GPU run of 10 minutes or more, book first, from the desktop, as `--who cft-REBOUND/V0`, with the ssh session's Windows pid attached, and release it at the end:

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book rx7600 --mode exclusive --from now --until 08:55 --who cft-REBOUND/V0 --why "<what>" --pid <pid>
  ```

  Before a short run, `check rx7600 --short`.

## Specific things to attack

1. **`HIP=0` changes nothing.** On the desktop, and on nvidia-box with `HIP=0`, compare `make -n` of `all` and `programs` between main (1354a05) and d7b5047. Are every compile and link line the same?
2. **`HIP=1` does what it says.**
   - The variables reach libcft's Makefile.
   - The link carries libcft's HIPLIBS for `amd`, and for `nvidia` by `make -n` (there is no CUDA on nvidia-box).
   - `HIP=1 XRT=1` is refused.
   - Read cft-fp256's host/Makefile at eae74e3e (in the pin clone) and compare.
3. **The build on the RX 7600.** In ~/cft-rebound-r5-v0, from your own bundles of d7b5047 and the pins, run `make HIP=1 PYTHON=python3 all programs`.
   - Check pins, warnings and `ldd`.
   - Is entry 54's account of the 15 warnings right?
   - Is the GCC 13 null-source warning at src/ias15_cft.c:2155 a false positive? Read the code that allocates `prog_dep`, and say what would have to be true for it not to be.
4. **The same bits, independently.** Write your own comparison, not the lead's smoke_hip.sh: one binary, the software backend against `CFT_REBOUND_ARTIFACT=hip:0 CFT_HIP_INFO=1`.
   - Cover more than kepler: outer; pythagorean; zonal_saturn with its `active` and `zonal` lines; an ensemble (tools/make_ensemble.py); a short ring wave from tools/make_ring.py.
   - Cover all three formats; both engines; `--cs augmented`, whose augmented sums run on the host; and an adaptive run with rejections.
   - Prove the GPU ran in each: the device line or the record's `backend=hip:0`.
   - Print physics counters beside the bits.
   - Run a control through your comparator: one planted digit must be caught.
   - Report which lines differ and why. The lead found only the route lines `indexed` and `pair_gather`, reading `by=absent`.
5. **The routes on `hip:0`.** Force each of the four routes on, as tools/check_door.py and the forced check_dropin legs do. What does each do on `hip:0`: refused by name, falling back, or running? Is that what ROUND5.md says?
6. **ROUND5.md's READ claims** against cft-fp256 at eae74e3e (read only, in the pin clone):
   - docs/HOSTAPI.md, "The GPU backend";
   - host/src/divsqrt.c, the program route;
   - host/src/augmented.c, on the host;
   - `seq_features` 0x75f1f, and scratch 256 and banks 512;
   - G1C's 87 and 234 µs a call (its docs/VALIDATION.md).

   Is any claim stronger than its source?
7. **Entry 54's figures** against what you re-measure: the device line, the route lines, the counters. Timings are expected to differ, so say by how much.
8. **Anything else.** Tell the lead what it did not think to ask.

## Ground rules

- Re-run things; do not trust pasted output. Report only: edit no tracked file; build controls from copies in scratch and delete them.
- No WSL, no card, never the RTX 4070. No network except the SSH to nvidia-box. Never bare `git stash`; never push, merge or rebase.
- "Found nothing" is a fine answer. State precisely what you ran.

## Report

For each numbered item, give the commands you ran, what you observed, and a verdict: **confirmed**, **defect**, or **not determined**. A defect needs a concrete failure scenario. End with **READY** or **NOT READY**. Keep it under 1,500 words; your report is your final message.
