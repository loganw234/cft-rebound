You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, the multi-precision arithmetic library of the sibling repository cft-fp256. Its central invariant is that every backend gives the same bits and **no committed record line moves** unless a change means it to. Round 5 (ROUND5.md) brings in GPUs.

A GPU run of a Saturn ring with 10^6 particles cannot afford to rerun every system whose particles it samples. So round 5's parcel P3 taught tools/compare_run.py to take a producer's own files: each system's attempts record and corrector schedule. With them, it replays sampled particles with no rerun of their system. **The question is whether that driver holds what it says it holds, and says plainly what it does not.**

Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for the failure shapes to hunt: a gate driving a stand-in, a comparison that cannot fail, bit-identity taken for validity.

## What to verify

P3's commit `2922fa1` on branch `worktree-agent-a35562c26dc613fed`, from main at `5b1cac6`. It changes tools/compare_run.py and tools/check_compare_run.py.

The claims:
- **P3's report:** `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\R5-P3-report.md`. Read all of it.
- **Its ledger entries:** `C:\Users\logan\source\repos\cft-rebound\.ledger\P3.md`. Read every file in that directory: P1's and P2's entries say how they read P3's output and files.
- **The context:** ROUND5.md's P3 section, docs/RING.md, docs/VALIDATION.md entries 49 to 51, and CLAUDE.md, especially "A rejection leaves state only before the first accepted step" and "A planted control holds only the column, line and format it sits in".

P3's own work is in `scratchpad\p3-r5\` (its mutation script, gate logs and suite logs). You may read it. Build your own mutants; do not reuse its script.

**Already checked by the lead; do not repeat:** P3's full `make check` on 2922fa1 (12:39 to 16:40). Leg by leg it matches P0's suite on d7b5047 in every leg but check_compare_run (67 ok to 105), and the identity lines match. **Do not run a full `make check`.**

## Where things are

- **Your isolated worktree.** Run `git checkout --detach 2922fa1` and confirm it. Clone the pins locally, never from the web, **each in separate commands** (a one-line loop is refused by the worktree guard):

  ```bash
  git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/rebound third_party/rebound
  git -C third_party/rebound checkout --quiet bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93
  git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256 third_party/cft-fp256
  git -C third_party/cft-fp256 checkout --quiet eae74e3eddc67836d4b7c8922badd40e6e1bdb2f
  export PATH="/c/msys64/mingw64/bin:$PATH"
  make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
       PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
  ```

  The PATH line is not optional. No `make -j` in a fresh tree.
- **The other parcels:** P1 (`worktree-agent-ab5e6c159761d1e5e`) and P2 (`worktree-agent-aecde4474af33b9f7`) are still working. You may read their branches with `git show <branch>:<path>`. Never touch their worktrees.
- **Booking.** CPU only. Any run of 10 minutes or more on the desktop is booked first as `desktop` shared, and released when it ends:

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book desktop --mode shared --from now --until <WHEN> --who cft-REBOUND/V3 --why "<what>" --pid <pid>
  ```

  The desktop is shared today, so no timing claims.

## Specific things to attack

1. **Scope.** Does `git diff --stat 5b1cac6 2922fa1` touch only the two tools, with no record, problem or schedule changed?
   - P3 says the Makefile needs no change. Check that claim: does every artifact case 7 executes appear in `IN_COMPARE` (Makefile:691)? A missing one shortens the gate cache's key.
2. **The gate, re-run on your build.** Run `tools/check_compare_run.py --build build` and the same with `--quick`. Read the lines, not the exit code: the ok counts, which cases ran, and each RESULT.
3. **The default path.** Without `--producer-files`, does compare_run at 2922fa1 sample the same members and particles, and print the same verdict lines, as at 5b1cac6, for the same record and arguments? `--particle-strata` defaults to `--strata`, so the default particle sample may have changed.
   - If it changed, say what moved.
   - Say whether check_ring_seams and P1's GPU seam still hold what they held. P1's tools/check_gpu.py is on its branch.
4. **What a NOT RERUN member is held to.** P3 says such a member is "held by the record alone, and by its particles' replays, which hold every massive body and the exact-time pair."
   - **Plants:** in a ring record from tools/make_ring.py, with its zonal line, given with `--producer-files` so that some member is NOT RERUN, plant one change at a time in that member, each on two lines: t, dt_next, E, x of a moon, t_hi, t_lo, a column of a sampled particle, and a column of an unsampled particle.
   - **What to report:** which are caught, and by what name. Is E held? Does the output say that an unsampled particle of a NOT RERUN member is held by nothing?
5. **Mutants of the driver, against the final gate.** P3 ran its M1 (it reads the files, but replays rerun members against the rerun's schedule) and M2 against the gate as it stood that morning, not against 2922fa1's. Rerun both against 2922fa1's gate. Then build your own:
   - (a) the key check skipped;
   - (b) one key field dropped from the comparison: `zonal`, then `active`;
   - (c) the fallback for an absent file made silent;
   - (d) a NOT RERUN member's verdict printed without replaying its particles;
   - (e) the producer's schedule used with the rerun's attempts record.

   Each mutation script must refuse to run unless its edit lands exactly once. For each mutant, which check catches it, and by what?
6. **The controls' placement.**
   - **q1 and q2:** do they sit at all three formats, on more than one line, with a first-attempt rejection among them?
   - **The pass-count claim:** is it right that 8 of 9 planted pass counts are caught only by the trailer's three-decimal `mean_pc_iterations`?
   - **The ~1,000-attempt limit:** check P3's COMPUTED figure, the attempt count beyond which a single pass may not show in that counter.
   - **The 10^6 ring:** for one of its waves over 10 orbits, is that limit a defect or a stated limit? Derive the attempt count from GPU-E2's figures in cft-fp256's docs/studies/GPU-E-mi300x-ring.md, at the pin, read-only, or from a short run of your own.
7. **The key.** Is it `ias15_cft --run-key`'s own, with nothing hashed in Python?
   - Is a file refused when it was keyed at another epsilon, another dt0, another engine, or for a one-system problem (`member=-1`) used as a ring member?
   - Is every refusal by name, with the fields that differ?
8. **The readers.** P1's seam and check_ring_seams read compare_run's output by its words; P1's regexes are in .ledger/P1.md, 10:25.
   - Do P3's changed lines still match them, for rerun members and for NOT RERUN members alike?
   - Would a NOT RERUN member's line be counted by `^member K (NAME): IDENTICAL|FAIL` as if it had been rerun?
9. **The findings.** Reproduce GATE 1b's "producer whose lines are not this tree's".
   - **The limit:** is "a producer's files hold its arithmetic, not its decisions" stated where a reader of compare_run's output would see it?
   - **Overreach:** is any claim in the report stronger than its evidence?
10. **Anything else.** Tell the lead what it did not think to ask.

## Ground rules

- Re-run things; do not trust pasted output.
- Report only. Edit no tracked file. Build controls from copies in scratch, and delete them after.
- No GPU, no WSL, no card, no network. Never bare `git stash`. Never push, merge or rebase.
- "Found nothing" is a fine answer. State precisely what you ran.

## Report

- **For each numbered item:** the commands you ran, what you observed, and a verdict: **confirmed**, **defect** or **not determined**. A defect needs a concrete failure scenario.
- **End with** **READY** or **NOT READY**.
- **Length:** under 1,500 words. Your report is your final message.
