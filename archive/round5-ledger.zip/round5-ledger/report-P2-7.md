(R5-P2's report on send-back 5, 2d062cd, its final message on 2026-11-19 at ~20:10, copied verbatim by the lead.)

Send-back 5 is done: commit **2d062cd** on ff7221a, tools/check_wave.py only (+68/−19), not pushed or merged. Sample 0 is now planted in every member, both a schedule column and its step. The sweep found no other loop end that one copy or one rule can close; the other unheld ends are listed below, not fixed. Everything is MEASURED on the desktop unless marked READ.

**1. The sweep** (READ, compare_run.py at ff7221a, done before any change). Each loop's ends and what holds them:

| loop | first / last | held by |
|---|---|---|
| members (plan and reruns :634, :1049–1057; particles :882) | 0 / 2 | rule "every class in every member" |
| sample lines, compare() :752, particle_compare() :840 | last line | rule "last sampled line" |
| | sample 0's bodies | hold_initial() :520–529 (the rerun and each replay also start from the problem file, extract_particle.py:206) |
| | sample 0's t, dt_next, dt_last, E, t_hi, t_lo | **nothing** |
| | sample 0's step | scan() :573, but no plant exercised it on a first line: **unheld** |
| a line's values, compare() :760 | t / t_lo | rule "every column at least once" |
| a replay's pairs, :833–837, :849 | t..E, x..vz, t_hi..t_lo | every column |
| | massive body 0 / body 6 / the particle | every massive body / the last in every member / each particle on its own body |
| counters, :766, :856 | max_pc_iterations | every column |
| | steps_done | nothing, and nothing can (see below) |
| particles, :891–906 | nearest / seeded | each replayed particle on its own body |

The two unheld sample-0 ends are the same shape as body 6 (one copy plus one rule), so I closed both in this commit.

**2. Two copies after the twelve.**
- **Copy 13:** sample 0's t in member 0, E in member 1 and t_lo in member 2. Both loops compare these, and hold_initial() compares none of them.
- **Copy 14:** sample 0's step in every member.
- Sample 0 can be planted without the run being refused. Each of plants 13.0–13.2 FAILs its own member and both its particles, naming the value. Each of plants 14.0–14.2 marks its member incomplete in the record.

**3. Coverage.** By its own parse of the sample lines, the verdict now requires sample 0 in every member, with a schedule column and the step. A gap reads like "sample 0 of member 1: no schedule column planted on it".

**4. Runs** (B0205, 19:00–20:10, released; at most four at a time)

| run | at ff7221a | now, `--quick` | now, full |
|---|---|---|---|
| tree | — | PASS 104/0 | PASS 113/0 |
| cr_sample0_skipped (both loops late) | PASS 96/0 | FAIL 101/3 | FAIL 110/3 |
| member loop late alone | PASS 96/0 | FAIL 101/3 | — |
| particle loop late alone | PASS 96/0 | FAIL 101/3 | — |

- cr_sample0_skipped fails on plants 13.0–13.2, each saying the member did not FAIL naming it and 0 of 2 particles did.
- With the member loop late, the member doesn't FAIL naming the plant, while the particles still FAIL as they must.
- With the particle loop late, the member FAILs naming it, but 0 of 2 particles do.
- All three single-loop runs passed at ff7221a because no copy touched sample 0. Copy 14's step plants pass under all three mutants, since scan() holds that step, not the loops.

Every other mutant fails `--quick`:

| mutant | ok/FAIL |
|---|---|
| cr_last_massive_short | 101/3 |
| step class dropped | 91/1 (now also names sample 0's step in every member) |
| max_pc_iterations dropped | 103/1 |
| `[1:2]` | 98/6 |
| left-out past end | 102/2 |
| (iii) member 2 never planted | 93/1 |
| (iv) no counter | 95/1 |
| my two particle mutants | 103/1 each |

Each edit lands exactly once or the script refuses; I showed refusals at 2 landings and at 0.

**Twelve copies unchanged:** with timings masked, all twelve have ff7221a's sha256 in both forms. Raw, they differ only on line 218's timings. So the 27 compare_run mutants still need no rerun. The new copies are 13 = ecb99a1ac3cfa32c and 14 = 37ff2d6838b1ff43.

**Other shapes, reported and not fixed** (READ):
- **Counters' first item, steps_done, and the (k, step) checks at :756/:844:** no record plant can reach them. hold_structure() (:610) and scan() (:573) catch those values first, and the member is never rerun.
- **Selection loops:** closest() :784–791, least() :888 and `parts` :883 choose the particles but compare nothing. An off-by-one there replays a different particle, which check_wave plants just as faithfully.
- **Trailer-key presence check (:607):** no plant deletes a key, and a trailer missing one still FAILs at :766–768.
- **The totals sum (:621):** copy 9 moves member 1's steps_rejected and the total together. Member 2's term is never planted, and the per-plant verdict doesn't look for a "record: FAIL" line, so a sum that stops one short passes.
- **hold_initial(), hold_problem(), hold_rerun():** a plant there refuses the whole run, and check_wave has no verdict that expects a refusal.
- **compare_run's value count:** it prints how many values it compared. Under cr_sample0_skipped that is "4 samples, 1170 values", i.e. three lines of 390, where all four would make 1560. check_wave never reads this count. One rule holding it would cover every loop end at once.

The ledger entry is in P2.md under 20:10. Nothing of mine is running.

Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\sb5:
- run5.log
- copies_sha5.log
- mutants5.py
- tree\, mutA\, mutB\ (one log per run)
