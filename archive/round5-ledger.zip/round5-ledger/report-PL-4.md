(R5-PL's report on send-back 3, 4fcd775, its final message on 2026-11-19 at ~13:35, copied verbatim by the lead.)

Send-back 3 is committed as `4fcd775` on top of `e8a7d89`, and the control behaved as you asked: e8a7d89's constants line skips the changed file, and the new one runs and fails.

**Commit:** `4fcd775d705ee4914a181056ff27a60c54de2835` on `round5-pl`. `git status --short` is empty after the commit, and nothing was pushed or merged.

**Diff:** `Makefile | 6 +++---`. `--input third_party/rebound/src/integrator_ias15.c` is added to the constants line in all three tiers (`check`, `check-quick` and `check-light`, lines 729, 764 and 802), and nothing else changes.

**Key check:** I compared each leg's `--input` set under e8a7d89's Makefile and the new one (`make -n`, all three tiers, built tree and fresh tree). Only the constants leg changes, and only by this file.

**The control.** Each step runs the constants line exactly as `make -n -f <Makefile> check-quick` printed it at that moment, against my worktree's own `build/.gate-cache`:
```
1-old-first        [e8a7d89 line, 1 input]  rc=0 | ran: 78 constants compared, all match | stamp 4210bd53eb4f
2-old-held         [e8a7d89 line]           rc=0 | constants: SKIPPED - inputs unchanged since it passed (4210bd53eb4f, quick run)
  change: h[1] ...369221... -> ...369321... (line 185, byte 10691, '2' -> '3'); clone status: [ M src/integrator_ias15.c]
3-old-after-change [e8a7d89 line]           rc=0 | constants: SKIPPED - inputs unchanged since it passed (4210bd53eb4f, quick run)
4-new-after-change [new line, 2 inputs]     rc=1 | ran: 78 constants compared, MISMATCHES; DERIVATION CHECK FAILED | no stamp
  gen_constants.py run directly: rc=1 | FAIL h[1]: derived 0.05626256053692215, REBOUND literal 0.05626256053693215
  restored: byte for byte the copy; sha256 085a0bcb.. (the baseline); clone status: [] (HEAD bdfda4b)
5-new-restored     [new line]               rc=0 | ran: 78 constants compared, all match | stamp 0e3b9434b62f
6-new-warm         [new line]               rc=0 | constants: SKIPPED - inputs unchanged since it passed (0e3b9434b62f, quick run)
```
The h[1] literal appears twice in the file: in the `h[8]` array that `gen_constants.py` reads, and in an `mpf_set_str` call at line 1002. So the edit is anchored on the array's own text and refuses unless it lands exactly once. On copies, I showed it refusing the bare literal ("lands 2 times") and refusing a second application ("lands 0 times"). The clone was touched only by that edit and its restore.

**What else is under third_party/:** nothing else is missing from any key. I checked three ways:
- **Text search** of every `tools/*.py`, `src/` and `tests/` for "third_party", then read each hit. There are six sites:
  - `gen_constants.py` reads this file; that is the finding.
  - `check_corrector.py:189` reads cft-fp256's `programs/MANIFEST`, which is already an input.
  - `check_zonal.py:120` adds the golden-model directory to Python's import path.
  - `check_gpu.py` has two, but check-gpu is not a cached leg.
  - `make_problems.py` has one, but no leg runs it.
  - `src/` and `tests/` name nothing under third_party.
- **My audit, rerun with third_party treated as a root** in all three tiers. Only this file comes out missing. Only the constants, check_corrector and check_zonal legs reach any tool that names third_party; the other 22 legs reach none of them.
- **A runtime trace.** A Python audit hook in every Python process each leg starts logged every open, import, directory listing and process start under third_party/. I ran it on those three legs' check-quick commands (13:23 to 13:29):
  - constants opens only `integrator_ias15.c`.
  - check_corrector opens only `programs/MANIFEST`.
  - check_zonal opens only nine `cft_golden` modules, all already in its key. The one lazy path that reaches into third_party (`vectors.py:531`) sits in a function check_zonal never calls.

**MANIFEST:** I agree it is not needed in the constants key. `integrator_ias15.c` is the leg's only read under third_party and is now keyed by its bytes. A pin move that leaves those bytes alone cannot change the leg, and one that changes them changes the key.

No booking was needed: the trace took 6 minutes and the control 9 seconds. None of my processes are running. The ledger entry is "2026-11-19 13:31" in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\PL.md`. The control's log is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\pl\cc3\steps.txt`, and the trace logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\pl\trace\`.
