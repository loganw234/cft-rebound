(R5-VD's report on the records' phase 1 at 4980440, its final message on 2026-11-19 at ~10:05, copied verbatim by the lead.)

I counted the suites myself, and every number I checked in the four documents matches its source. The verdict is still **NOT READY**: nine pieces of new text claim more than their sources show, or describe a condition wrongly. All nine are text fixes.

How I worked: the worktree was detached at 4980440 and stayed clean. I ran no build and no suite and edited nothing tracked. My counting script is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vd\count_suite.py`. I read cft-fp256's HOSTAPI.md from the main checkout's `third_party/cft-fp256`, whose HEAD is eae74e3e, and did not enter the cft-fp256 repository.

## 1. Numbers against sources
**Suites, recounted from the logs: confirmed.**
- **int-check-fda3b40.log:** 16:22:07 to 19:48:06 (3:25:59). clean, build and check each rc 0. 25 legs, 1,504 lines beginning `  ok `, 17 RESULT lines all PASS, no line beginning FAIL, 5 compiler warnings, all six of entry 45's digests. Every leg matches 4a8fe99.
- **int-check-4a8fe99.log:** 09:41:33 to 12:16:29 (2:34:56), the same counts. Every leg matches d7b5047 except check_compare_run, 67 to 108. check_ring_seams is 34.
- **P3's suites at 2922fa1:** 1,501 ok and 937 ok, 25 legs each.
- **P1's suite at a29f602:** 1,463 ok, 10:34:46 to 14:23:22.

**RING.md, ROUND5.md and README.md:** every number matches. One false pointer is defect D1 below.

**Sample from entries 55 and 57, more than 40 groups, all matching:**
- **Merges:** 16 commits to ab75fbe; +2131 for P1; +1247/−58 for P3; e3f6a39's tree is 4a8fe99's (git).
- **The seam on fda3b40:** 38 ok, 32m16s, 15:47:31 to 16:19:49, and the device line (run-fda3b40.log and seam.log). Control a3 at line 11, field 13, beside 12 timings; control a at line 10. Bodies 22/30 and 57/31; 14 + 8 plants.
- **P1's mutant tables:** 28/0, 17/11, 8/20, 24/4 three times (P1.md 14:56, V1's fifth report). 26 ok in 7m24s, 11/6, 17/0 (P1.md 13:03). 16, 10/6, 6/10 (P1.md 14:03). 144 against 162 values (V1's fourth report).
- **V1's runs:** 36 ok in 123m04s; 212 ok in 192m16s; 165/330 under strace. 32 plants, six refusal cases, 191/206 lines, rc 2 on the desktop. 7m56s and 18 processes; 12 ok and 24 FAIL.
- **What runs where:** every where.py count and every divide time; 4,341/60 and 116/48; 69 images, 256/512 load, 257/513 refused, 13 constants. 15,089 launches and 84 of 19,434 calls on the host.
- **Costs:** all 48 cells of the cost table. +0.23% to +1.86% (my recomputation: 19.15/18.8 = +1.86%, 8.00/7.98 = +0.25%, 35.18/35.1 = +0.23%). 7.9% = 261/242.
- **Legs:** the leg table (P1.md 16:37, V1's second report); 31 ok and 8 children; both digests.
- **Code references:** gate_real.c:326 and :646; check_gpu.py:562; ias15_cft.c:1680, :1835, :3049, :4773, :3281–3295, :4782; the 13 timing keys.
- **Entry 57's gates (merged suite log):** GATE 1's 18 particles, 1,512 tokens, 18 of 18. GATE 2's 40 steps, 3.293–3.875, 7–9, 36 approaches, 3.29e-7 and 3.14e-7. GATE 1b's 5 against 7, 3.275/3.300, 7/8. q2's tokens 26/0/0/9 and 0/0/0/8, and the q3–q7 key fields.
- **Entry 57's tables and looks:** the mutant table (P3's third report). V3's 105/68, 69, 58/12, 67/3, 12 and 20 runs. 359–374 steps, 0.0027, 28 orbits; 7 of 7 tries; record line 13.
- **The limit's quote:** word for word with compare_run.py:262.

## 2. Claims against labels (defects)
- **D4, "PASS" credited to GATE 1b.** It appears in ROUND5.md:306–309 ("gets RESULT: PASS where that member is not rerun… (P3's GATE 1b…)"), RING.md:212–214 ("…says PASS while the member is not rerun… (P3's GATE 1b, MEASURED)") and entry 57 at :7721 ("…says PASS").
  - GATE 1b requires that run to end rc 1, because member 2 fails on its rerun (check_compare_run.py:836 `rc1 == 1`; the log prints "(rc 1)").
  - RESULT: PASS was V3's measurement on a two-wave ring, wave 0 at 2 passes where this tree takes 4 (V3's first report, item 9).
  - Correction: "holds that member, NOT RERUN, both its particles IDENTICAL (P3's GATE 1b); a run with no other difference says RESULT: PASS (V3, a two-wave ring); the same member FAILs once rerun."
- **D5, "each attempt's arithmetic".** Entry 57 at :7716 says "holds each attempt's arithmetic"; RING.md:197 says "Each sampled particle's arithmetic, attempt by attempt".
  - Only sample lines and the trailer are compared. A rejected attempt after an accepted step moves no state bit (entry 49; compare_run.py:157 says so beside this same claim).
  - Correction: "holds the arithmetic that reaches its samples and trailer"; add the entry-49 caveat.
- **D6, readers.** Entry 57 at :7696–7698 says "V3 measured at each look that P1's, check_ring_seams' and P2's readers capture what they did."
  - V3's first look ran P1's and part 3's patterns only. P2's readers came in at the second look. The third look confirmed by reading only: the driver's text was unchanged and check_wave.py:361–364 was identical.
- **D7, RING.md:263–266.** It says: "Every process prints the probe's device line, or it is a stand-in and its leg FAILs."
  - Since ab75fbe, a process refused by its own arguments is counted apart (check_gpu.py:566–569), and is counted among the identical records.
  - "What it does not hold" leaves out the merge message's second open note, that a refused process counts as a device process.
  - README's "Every process those legs start must print…" needs the same clause.
- **D9, entry 57 at :7726.** "two fewer moved none at binary128 or binary256" holds for 2922fa1's plants (P3.md 11:34). The same entry's q2 row has member 0's rejected first attempt, two passes fewer, moving 8 tokens at binary256.
  - Correction: "two fewer on an accepted first attempt…".

## 3. The corrections
Each queued correction is made in the file that carried the claim, and each says what its source says: TwoSum (P2.md 11:00); the CPU-to-wall ratio in ROUND5.md and entry 54; the 62 min; cft_reduce; the 256 slots; every attempt; the self-tests' banners; gate_real and check_checkpoint (entry 55 only, and I confirmed no document at fda3b40 carried that claim); and V1's plant-per-line and 1.9%.
- **Contraction:** ROUND5.md at fda3b40 never worded a contraction control, so this is an addition. It is accurate to P2.md 11:00 and 16:13.
- **Arithmetic, not decisions:** made in the right files, but D4 applies.
- **Still standing elsewhere:** only hw/gpu/costs.py, which ruling 7 covers.

## 4. README
- **compare_run's options:** the 14 arguments and their defaults match argparse (compare_run.py:1423–1441) and the usage header.
- **check-gpu:** its variables match Makefile:831–838, and the HIP pass-through and XRT refusal match :209–234.
- **Provenance row:** byte-identical at line 182 (`cmp`), and both check_pins README tests pass by hand.
- **D1:** "Entry 55 has each leg's measured time on each GPU" is wrong. Entry 55's table has the RX 7600 only. Correction: "on the RX 7600", or add the 5060 Ti's times from P1.md 12:00, 12:42 and 15:54.

## 5. LEAD-FILL lines: confirmed
Exactly five: ROUND5.md:9 and :405, RING.md:310, VALIDATION.md:7657 and :7920. The added lines have no other placeholder and no empty table cell.

## 6. Consistency (defects)
Commits, counts, the merge order (P3 then P1) and the send-backs (the lead's one, V1's two, V3's two) agree across the files, apart from these:
- **D2, entry 55's suite.** "P2's suite beside it until 17:35": B0171 held P2's check_wave runs and 27 mutants, not a make check (P2.md 17:37; lead.md 19:52 says "P2's B0171").
- **D3, entry 57's suite.** "with P2's suite… beside it": P2's suite ended at 09:27:33 and B0131 was released at 09:28 (P2.md 09:28, lead.md 12:49), before 09:41:33. Strike "P2's suite".
- **D8, entry 55 at :7466.** "ROUND5.md had check_corrector 'through the registered integrator'": ROUND5.md:189 still says it. Write "has", or correct ROUND5.md:189.

## 7. D's eleven items and the lead's rulings
- **1, the P0 log:** right. p0-check.log is 9a42b1d, 2026-11-11, 19 legs, pin 922c2ad.
- **2, the ok counts:** right. d7b5047 has 1,463 `  ok ` lines and 1,464 in all; the extra is check_dropin's " ok   kepler, post only".
- **3, V0's ratio:** right. d13aa45 says "1.5 to 2.0… not 1.7 to 1.9".
- **4 and 5:** both rulings are sound. V1.md 12:10 does have 66 min. The cost table carries MEASURED, one run a row, and its host and conditions.
- **6, RING.md's Bits bullet:** right. fda3b40's RING.md:139–141 still held the belief that :261–266 had struck.
- **7, 8 and 9:** right. costs.py:18–19 says 1.5–2.0; README lacked HIP=1; ROUND5.md:152–154 is still "To do".
- **10, who sent P1 back first:** right (lead.md 12:14), but see D8.
- **11, the line number:** right. check_gpu.py:562 is `res["device"] += 1`.

## 8. Anything else (minor, your call)
- RING.md:248 says "eleven legs, each in its quick form", but check_dropin_light runs in its --light form.
- RING.md's check-gpu usage line lacks README's "[the same variables]". On the 5060 Ti, a stale target would relink with ROCm's runtime (the amd branch), and V1 saw a relink in cft-gpu.
- README says "The Makefile reads `HIP` only where `OS` is not `Windows_NT`". That is true of the build, but check-gpu passes `--hip '$(HIP)'` on every OS (Makefile:837).
- Entry 50 (VALIDATION.md:6321–6322) still says the exact-time pair comes from "vaugadd, the path G1B is expected to refuse as AUGADD on hip:N". That is the belief D struck in RING.md under item 6.
- Pronouns: no he/his/him in new text; Logan is named twice.

**NOT READY** for phase 1. No number needs changing; D1–D9 above are all text edits.
