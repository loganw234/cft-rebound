(R5-P3's second report, its final message on 2026-11-18 at ~06:54, copied verbatim by the lead.)

D1 and all five of V3's items are fixed at `0bee543`, and every gate form passes. All four mutants (M1, M2, Mf2, Mj) now fail the `--quick` gate by name, which check-quick and check-light both run.

**New tip:** `0bee543` on `worktree-agent-a35562c26dc613fed`, parent `2922fa1`; nothing pushed or merged. Against `2922fa1`: `tools/check_compare_run.py` +255/−? and `tools/compare_run.py`, 2 files, 219 insertions and 111 deletions.

**D1, the limit never printed.** Under `--producer-files`, compare_run now prints this once beside the plan:

> particles: the limit of the producer's own files: each replay takes the producer's dts, outcomes and passes as given, so only a member that is rerun holds its decisions; a NOT RERUN member's particles that are not sampled are held by nothing; and the run key holds the files to the arguments the record names, so whether the producer ran with them - its epsilon, pc_tol_shift and max_iter, and the settings no record carries - is held only in a member that is rerun

- The gate holds its own copy of that text and asserts it word for word, exactly once, after the plan line. That covers GATE 1's runs at every format, GATE 1b, and the program-engine case.
- Three lines no longer claim the record holds a NOT RERUN member: the member line, its plan line and RESULT's suffix. The member line keeps its prefix `member K (NAME): NOT RERUN: `.
- **I re-checked the readers:**
  - P1's patterns from check_gpu.py at `ab75fbe` (lines 994, 995, 1000, 1027) and check_ring_seams' part-3 patterns capture exactly what they did. I applied them to the new default-path and producer-path output and to a planted FAIL.
  - check_ring_seams passes: 21 ok in `--quick`, 34 ok in full.

**V3's other items:**
1. **The pass-count claim.** The gate now works out what each plant moves and prints it, instead of asserting "only the mean"; the wrong wording at :97 and :698 is gone. At binary64, one fewer pass on member 2 moves the mean (3.275 against 3.300) and the max (7 against 8). Only the middle-attempt +1 plant rests on the mean alone. My 11-16 entries and report are corrected in the ledger.
2. **Mf2.** q2 now also takes two passes off member 0's rejected first attempt. That moves 9 tokens of its replays at binary64 and 8 at binary256, plus the mean and the max; at binary128 it moves only the counters. V3's 28 tokens were counted on the member's full lines, mine on the replays'.
3. **Mj.** The program-engine case with `--rerun-engine loop` now runs in `--quick` too, at 4 steps. No Makefile comment was needed.
4. **Paths containing " and ".** The gate reads the source from fixed phrases and matches each pair whole against the paths it wrote. GATE 1's producer directory is now named `producer <fmt> and its pairs` to prove it.
5. **Report overreach, corrected in the ledger:**
   - Only the driver's source header stated the limit, until `0bee543`.
   - It is five whole-file reads per particle member, not three: one for my key check, and two for each of the two particles inside extract_particle.

**Gate counts** (all RESULT: PASS, 0 FAIL, lines read):

| form | ok |
|---|---|
| full | 105 |
| `--quick` | 69 (the old 68 plus the program-engine case) |
| check-light's own command (from `make -n check-light`), through the gate cache | 69 |

**Mutants** (each edit lands exactly once, and a non-landing edit was shown to refuse):

| mutant | result | caught by |
|---|---|---|
| M0, unmutated | PASS, 69 ok | nothing, as it must be |
| M1 | FAIL, 4 | its lines naming the rerun's schedule; GATE 1b; the program-engine case; q2 (members 2 and 0) |
| M2 | FAIL, 5 | the same, plus half a pair |
| Mf2 | FAIL, 2 | q2's new plant on member 0; the program-engine case |
| Mj | FAIL, 1 | the program-engine case, refused by its run key's `engine` field |

There was no full `make check`, as briefed. Booking B0137 is released, no process of mine is left running, and the ledger entry is in my drop file (P3.md).
