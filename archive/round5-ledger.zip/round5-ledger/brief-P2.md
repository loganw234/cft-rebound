You are parcel **P2** of round 5 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `5b1cac6`, main where round 5's P0 landed. **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 5b1cac6` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. At binary64 its FMA form (`ias15_cft --arith fma --format fp64`) is a fixed sequence of correctly rounded operations. Round 4 built on the CPU what a GPU run of a Saturn ring will be held to: the ring generator, tools/compare_run.py and the particle replay (docs/RING.md). **Your parcel is P5, the wave kernel at the hardware's binary64** (ROUND5.md, P2; Logan's "Yes"). One ring system to a 64-thread GPU workgroup, in the hardware's own doubles, writing this repository's record format. It is held bit for bit to the CPU port by tools/compare_run.py. You are the round's long pole.

## Start here

1. `ROUND5.md`, all of it, then its **P2** section, which defines your job.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`, §1 and §5.
3. docs/RING.md and docs/VALIDATION.md entries 47 to 51: what round 4 built and how a run is held.
4. cft-fp256's study GPU-E, read in your pin clone at `eae74e3e`: docs/studies/GPU-E-mi300x-ring.md.
   - Its shape a2 is yours: one 64-lane wave a system, Saturn with J2 and J4 and six moons in seven lanes, 57 test particles, one step and one pass count a system.
   - Its §6 says why binary128 and binary256 wait for a device divide. They are not yours.
5. The code you reproduce, at your base:
   - src/ias15_cft.c's step under `--arith fma`: the predictor, the corrector's passes and their convergence test, and the default compensated sums (`--cs kahan`);
   - gravity with the `active` split, in ascending pair order;
   - `choose_timestep()`, and `sqrt7()` at :2251, which is REBOUND's Newton iteration of multiplies, divides, subtracts and adds, not `pow`;
   - the exact-time clock at :3049, which calls `cft_augmented_add`;
   - `energy_all()`, the record's E column;
   - the record writer: the header lines, the sample lines and the trailer.
6. src/ias15_zonal.inc: J2 and J4, their operation order, and the reaction.
7. tools/compare_run.py: what a record must carry for the driver to rerun and hold it. A record from another producer is held if it carries every rerun field (docs/RING.md).
8. `CLAUDE.md`, all of it.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there at three moments: before you start, before you design anything ROUND5.md calls shared (the record format is shared with P3), and before you report. Append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P2.md`. Anything that must not wait goes in the same drop as `urgent-P2-<slug>.md`. **Arm a watcher on `.ledger\urgent\` first.**

## Your job, in order

1. **The step's arithmetic as `__host__ __device__` functions over `double`,** in src/wave/. Without HIP, a header defines both attributes away, so the same source compiles as plain C++.
2. **The host twin.** A program built by `make wave-host` on the desktop (MinGW g++) and on Linux reads a ring file from tools/make_ring.py: waves of 57 particles, with its zonal line. It integrates each system on the CPU with those functions, and writes a record in this repository's format.
   - Its gate, tools/check_wave.py, is a leg in all three of the desktop's tiers.
   - It holds the twin's records to `ias15_cft --arith fma --format fp64`'s through tools/compare_run.py, every column, member by member, with particles sampled through the replay.
   - Show it on adaptive runs with rejections, a first-attempt rejection included (CLAUDE.md, "A rejection leaves state only before the first accepted step").
3. **The kernel.** The same functions in a HIP kernel, one system to a 64-thread workgroup, one thread a body. The system's maxima and minimum are reduced in shared memory, not by wave intrinsics, so the kernel is the same on NVIDIA's 32-wide warps and on RDNA3's wave32 and wave64.
   - Built by `make HIP=1 wave`: hipcc for gfx1102 on nvidia-box, and HIP 7.2.4's NVIDIA layer for sm_120 in WSL `cft-gpu`.
   - Its records must be the host twin's and the CPU port's, bit for bit.
4. **The hardware's arithmetic, gated first, on each GPU.** Before anything rests on the hardware's add, multiply, fma, divide and square root being libcft's correctly rounded binary64, measure it.
   - Use a corpus run on the GPU against libcft's software binary64: random operands, ties, subnormals, the extremes. Also `cft_div` and `cft_sqrt`, and the augmented addition the clock needs.
   - Report every mismatch by name.
5. **The GPU seam test** (ROUND5.md, "What the integrator keeps") on your first GPU record: one hex digit planted in the record, caught by name.
6. **Measure** system-steps a second on each GPU at a few wave counts. MEASURED, labelled, one run a row, set beside GPU-E2's estimates. Make no other speed claim.

## Traps that would be a silent wrong answer

- **Contraction.** GPU compilers fuse `a*b + c` into an fma by default, and GCC's C++ mode does too. Every unfused multiply-add would then change bits.
  - Compile with `-ffp-contract=off`, and under HIP's NVIDIA layer also `--fmad=false`.
  - Write `fma()` exactly where the port's FMA form has one.
  - A control: build one copy with contraction on, and show the gate catches it.
- **Division and square root.** These must be the correctly rounded ones: no fast-math, and on NVIDIA `-prec-div=true -prec-sqrt=true`. Gate 4 measures it.
- **Subnormals.** Keep them; flushing them is a different answer. Gate 4 measures it.
- **The clock's augmented sum.** libcft's `cft_augmented_add` is IEEE 754-2019's augmentedAddition (§9.5). BELIEVED: it rounds its high part with ties toward zero, which the textbook TwoSum, rounding ties to even, does not. Read host/src/augmented.c in your pin clone, reproduce exactly what it defines, and hold it on a corpus with ties.
- **Flags.** A GPU has no IEEE flags. Where the port aborts on OVERFLOW, DIVBYZERO or UNDERFLOW (its default; `--no-flag-abort` turns that off), the kernel checks its own results and stops by name. Whatever it cannot check is a stated limit.
- **Bit-identity is not validity.** A wave whose particles are massless leaves the moons' bits untouched whatever the particles do. Print each system's physics counters beside its verdict: steps, passes, rejections, and the precession or circularity counter round 4's seam tests use.

## Booking: every GPU run of 10 minutes or more

- Book it in the TimeSheet from the desktop first, as `--who cft-REBOUND/P2`, with the ssh or wsl session's Windows pid attached, and release it when the run ends:

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book <resource> --mode exclusive --from now --until <WHEN> --who cft-REBOUND/P2 --why "<what>" --pid <pid>
  ```

  - The resources: `rx7600` with `nvidia-box` (shared), and `rtx5060ti` with `wsl-cft-gpu`.
  - Before a short run, `check <resource> --short`.
- **The hosts:**
  - **nvidia-box:** `ssh -o BatchMode=yes logan@192.168.0.2`; work in **~/cft-rebound-r5-p2** only; mpmath at ~/cft-rebound-r5-py.
  - **WSL `cft-gpu`:** work in **/root/cft-rebound-r5-p2**, with `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1` before any device. Never the RTX 4070.
  - Code goes there as git bundles of your branch and the pins, made from local clones. Nothing comes from the web.
  - **The stale-library trap** (V0, entry 54). In a tree first built without HIP, `make HIP=1 all` leaves libcft.a software-only. Run `make clean` before the first `make HIP=1`.
  - For scale: through libcft, `hip:0` costs this port 286 µs a call on kepler's loop engine at binary64 on the RX 7600, and 218 to 769 µs over V0's runs (entry 54). A 64-body ring wave still ran faster there than in software. Your kernel is measured against both.
- **P1 shares both GPUs** with you, and cft-fp256's GPU round 2 shares them from Tuesday 2026-11-17. Book early, never over another's window, and keep the host-twin work (steps 1 and 2) off the GPUs entirely. One agent at a time on a GPU host.

## Files you own

- `src/wave/`, new.
- `tools/check_wave.py`, new.
- `Makefile`: the `wave-host` and `wave` targets, and check_wave's leg in the three tiers with every executed artifact an `--input`. The lead merges the Makefile's conflicts.

## Files you must NOT touch

- src/ias15_cft.c, src/ias15_zonal.inc and every other file the port builds from. You reproduce the port; you do not change it. Anything in it you need changed is reported first.
- tools/compare_run.py, tools/check_compare_run.py and tools/extract_particle.py, which are P3's or round 4's. You run them.
- P1's `tools/check_gpu.py`. Add your GPU leg to `check-gpu` only through the ledger, by agreement with P1.
- The integrator's files: README.md, ROADMAP.md, CLAUDE.md, docs/, ROUND5.md and third_party/MANIFEST.
- ../cft-fp256, which you read and never write. On nvidia-box and in cft-gpu, every directory but your own.

## Building and testing on the desktop

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional; no `make -j` in a fresh tree.
- Run your gate and `make check-light` while you work.
- Before you report, run a full `make check` on the desktop, booked as `desktop` shared and started from PowerShell (CLAUDE.md). **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **A gate that cannot fail is not a gate.** Plant one change a column, on more than one line, and run the mutant that skips each (CLAUDE.md, "A planted control holds only the column, line and format it sits in"). A mutation script must refuse to run unless its edit lands exactly once.
- **Derive; never transcribe.** Read record fields with the tools that already read them.
- **Label every claim** MEASURED or BELIEVED. No speed claims beyond labelled measurements.
- **Never bare `git stash`.** No card. Never push, merge or rebase.

## Report

- what changed, file by file;
- each gate's output, as **actual lines**, on the desktop and on each GPU;
- gate 4's corpus results on each GPU, every mismatch named;
- every control, with its numbers;
- the measured rates, labelled;
- what you did not do;
- **anything you found that this brief or ROUND5.md got wrong.**

If something makes the approach unworkable, stop and report it: a hardware operation that is not correctly rounded, for one.
