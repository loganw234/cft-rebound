**V1 interim report on P1 (`ab75fbe`), paused at 17:33 as the lead asked**

Nothing is running. Both of my bookings, B0096 (rx7600) and B0097 (nvidia-box), ran 17:02–17:25 and are released. I edited no tracked file, and the worktree is clean at `ab75fbe`.

**Where I ran:**
- **Desktop:** my worktree, detached at `ab75fbe`, with the pins cloned locally and `all programs` built (rc 0).
- **RX 7600:** only inside my own booking, before P2's window, in `~/cft-rebound-r5-v1/tree` built from my bundles (`make clean`, then `make HIP=1 all programs`, rc 0; `backend_hip.o` is in `libcft.a`).
- **WSL cft-gpu:** not touched.

**1. Stand-ins — confirmed, with two gaps.**
- **Bypass, by reading:** every GPU leg finds its programs through `--build $(B)` (the shadow) or an `--exe` built from it. `compare_run.py`'s default `build/ias15_cft` (line 1127) is reached by no leg. The seam passes the real program on purpose, for its CPU reruns. Control g caught a bypass again in my run.
- **Gap 1:** check_corrector has never run under strace. It ran only on the 5060 Ti.
- **Gap 2:** on the 5060 Ti nothing in check_gpu can catch a bypass. The only evidence is indirect: the same code, and the same process count per leg as the RX 7600's strace-checked run. A compare_run rerun that bypassed the witness would inherit `hip:0` and compare GPU against GPU.
- **The device line:** libcft prints it only after it has selected the device, read its kernels and allocated its stage (`backend_hip.cpp:1743-1800`). So it proves the process opened the GPU, not that every operation ran there.
- **Measured with gdb (RX 7600, kepler fp64):**
  - 15,089 `cft_run` calls became 15,089 `cfth_run` kernel launches.
  - `cft_class` (79 calls) and `cft_augmented_add` (5) reached no backend function. So 84 of the 19,434 counted calls run wholly on the host, by design.
  - A libcft that quietly ran everything on the host would still pass the witness bit for bit.

**2. Set-aside rules — confirmed, with two latent notes.**
- **What I did:** 32 plants in copies of my RX 7600 witness directories and of real `hip:0` and software self-test outputs, judged by check_gpu's own `analyse()`.
- **Caught by line and column:**
  - the tokens on either side of `backend=`, and the identity line;
  - eight counters next to the timings (`divsqrt_calls`, `program_calls`, `staged_bytes`, `nextstep_calls`, `flags_seen`, both pass counts, `steps_rejected`);
  - `calls=`, `fallbacks=` and on/off next to `by=absent`;
  - the corrector banner's tail and its format;
  - the zonal line, a member's trailer, `pc_lane_efficiency` and `t_lo`.
- **Not caught, by design:** the `backend=` value itself (the device line holds the device) and `wall_seconds`.
- **Latent note 1:** `TIMING` (`check_gpu.py:164`) drops any trailer key named `t_*`. A planted `t_new=1` passed. Every `t_` key is a timing today.
- **Latent note 2:** stderr never fails a leg; an added stderr line passed as a note. ias15_cft writes only its `done:` line there.

**3. The refusal rule — confirmed.** Six real processes through check_gpu's own witness on the RX 7600:

| Case | Result |
|---|---|
| check_corrector's `--trace-pc` beside `--replay-iters` (positive control) | refused, PASS |
| `hip:1`, a device this host lacks | FAIL |
| `HIP_VISIBLE_DEVICES=-1`, a device gone at open | FAIL |
| `CFT_HIP_INFO=2` | FAIL |
| SIGSEGV to the device run after its device line | FAIL (rc −11 against 0) |
| SIGKILL at once | FAIL (no device line) |

What tells them apart: the software replay never opens a device, so a failure the device caused cannot be refused the same way in software. One minor point: refused processes count toward `res["device"]` (line 527), so a leg whose processes were all refused passes the "no process ran on the device" check. Only the leg's own verdict would fail it.

**4. Seam — confirmed, with one wording correction.**
- **My run:** `check_gpu.py --no-legs --keep --expect 'RX 7600'` at `ab75fbe` gave 35 ok, 0 FAIL in 13m26s: controls a to g, the routes at three formats, and the seam in both forms.
- **The plants:** each is one hex digit on **one** line, not two. dt_next and t_lo are planted on line 140 only; x of body 1, vz of body 63 and t on line 142 only (lines 1011-1013). I measured one changed line and one changed token in each planted file. Each was caught by name, with wave 1 IDENTICAL.
- **Not covered:** every plant is in wave 0. A compare_run that never compared member 1 would pass the seam. That is from reading; I did not run the mutant.
- **The FMA form is really run:** the record says `arith=fma`, compare_run refuses a mismatch (`compare_run.py:997`), and the values differ from REBOUND's form.
- **P3's `compare_run.py` (`2922fa1`):** run on my `hip:0` records with reruns on the desktop's software backend, check_gpu's clean and all six plant checks still pass with its output. So check_gpu's regexes still read P3's wording. The Windows reruns also matched the Linux GPU record.

**5. The final commit on a GPU — not determined.** Nothing ran because of the pause.

**6. `HIP=0` changes nothing, and the desktop refuses — confirmed.**
- `make -n -B` of all, programs, check, check-quick and check-light is identical byte for byte between the `5b1cac6` and `ab75fbe` Makefiles with HIP unset. With `HIP=1`, all and check-quick are identical too.
- A copy of the Makefile with one word added to a recipe differs, so the comparison can fail.
- `make check-gpu` on the desktop refuses by name ("this host has no hip:0 … no GPU backend") with rc 2.

**7. What runs where — confirmed at fp64, with one overstatement.**
- **where.py on the RX 7600 matched P1's counts exactly:**
  - A: 5 of 5 attempts, with none of the 19,351 backend calls inside.
  - B: 3,346 divides and roots (= `divsqrt_calls`), 3,346 programs, 0 elementwise runs. `CFT_DIVSQRT_SEQ=0` gives 0 programs and 72,917 elementwise runs. The three records are identical.
  - D: 69 of 69 images; 256 and 512 load, 257 and 513 are refused by name.
- **The overstatement:** the 5060 Ti's part is timing only, and labelled so. Its default divide (242 µs) and forced program route (261 µs) differ by 7.9%, more than the 6% noise. They are still 7.5 times faster than the chunk route, so the conclusion holds.

**8. gate_real — right for gate_real, wrong for check_checkpoint and check_seams.**
- `gate_real.c:327-328` does treat any non-empty artifact that isn't `cft://` as a card image.
- But `identity_ok()` is called only at line 646, in the self-contained mode. `--straight`, `--save` and `--resume` (lines 1472-1474) never call it.
- check_checkpoint and check_seams use only those three modes and read no identity. So P1's reason, which the lead has queued for the records, does not apply to them.
- check_seams forces indexed and pair_gather on (`check_seams.py:87`), which `hip:0` refuses by name, so it would likely fail for that reason instead (believed, not run).
- check_checkpoint forces no route; whether it passes on `hip:0` is not determined.
- Nothing else in the tiers keys on `cft://`: `check_door.py:339` and `cases_*.c` accept a GPU.

**9. Costs and corrections — confirmed, with one overstatement.**
- **Labels:** the cost rows are labelled one run a row, unranked, from `wall_seconds`, and the report says the 5060 Ti rows were taken on a shared desktop.
- **Overstatement:** "within 1.5% of P0" is 1.9% for kepler fp128 on the program engine (19.15 against 18.8).
- **`cft_reduce` never called by default — confirmed:**
  - The corrector's device route is `route_on[REDUCE_SEG]` (`ias15_cft.c:1835`). With it off, the maxima are `cft_class` plus a host loop, which the route's `fallbacks=` counts.
  - gdb found 0 entries of `cft_reduce` and `cft_reduce_seg`.
- **Augmented sum every attempt — confirmed:** it is issued at `ias15_cft.c:3049` on every attempt (adding +0 for a rejected system), and gdb counted 5 of 5.

**10. Things you didn't ask about.**
- `GPU_LEGS` switches off the controls, routes and seam. A named subset that includes them must be spelled with `GPU_SKIP`.
- `--door-selftest` differs between `hip:0` and software when nothing is hidden (191 against 206 lines). That is harmless, since no GPU leg runs it through the witness.

**PAUSED.** Where to pick up:
- **Desktop:** the worktree is at `ab75fbe`, built. Logs, harnesses, bundles and my kept RX 7600 run are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\r5v1\` (the kept run is under `rx\263475`).
- **nvidia-box:** `~/cft-rebound-r5-v1` is built with `HIP=1`. Delete `refusal-work/` and `where-work/` when we resume; I couldn't touch the host after the pause.
- **Item 5, 5060 Ti:** after 20:30, set up `/root/cft-rebound-r5-v1` from the bundles in that scratch folder, copy in mpmath 1.3.0, run `make clean`, then `make HIP=1 … check-gpu GPU_EXPECT="RTX 5060 Ti" GPU_SKIP=check_equivalence,check_program_engine,check_ensemble,check_ring,check_replay,check_compare_run,check_zonal,check_reversal,check_dropin_light`.
- **Item 5, RX 7600:** check_corrector, booked long. Running it under strace also closes item 1's gap.
- **Optional:** run the wave-1 compare_run mutant, and check_checkpoint on `hip:0` through `--reach` after `make HIP=1 archive`.