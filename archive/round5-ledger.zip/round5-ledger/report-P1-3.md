(R5-P1's report on send-back 2, its final message on 2026-11-18 at ~14:02, copied verbatim by the lead.)

The gap V1 found is closed in **fc4ba21**, a new commit on 6a5e448 that changes `seam_form()` and section 3 of the header only. V1's particle mutant now fails the seam, the two member mutants still do, and the tree passes. Nothing is pushed or merged.

**The rule.** Each plant's verdict now also checks the planted wave's sampled particles. The sampled bodies and the massive-body count are read from compare_run.py's own particle lines, not written in. A particle's replay carries the schedule (t, dt_next, dt_last, E, t_hi, t_lo), the wave's massive bodies and its own body.
- A plant in a column the replay carries must FAIL that particle, naming the same line and column. This covers t, dt_next, t_lo, and x of body 1, one of the 7 massive bodies.
- A plant on a body no sampled replay carries must leave the particles IDENTICAL. Here that is vz of body 63; the sampled bodies are 22 and 30 in wave 0, 57 and 31 in wave 1.

**Verdict lines** (desktop harness, software record, no GPU; run on exactly the committed file):
```
ok   the plant, arith=rebound: one hex digit of x of body 1 on wave 1's record line 143 (...): wave 1 FAILs naming that line and column, and so do those of its 2 sampled particle(s) whose replay carries that column, 2 here (a replay carries the schedule, the wave's 7 massive bodies and the particle's own body), the rest IDENTICAL: 2 of 2 as they must be; ...
FAIL (particle mutant, same plant) ... the rest IDENTICAL: 0 of 2 as they must be; ...
       wave 1's particle, body 57: IDENTICAL: MUTANT: particle not compared
```

| Run | Tree's compare_run | P3's (round5-int) | Which verdicts FAIL |
|---|---|---|---|
| Clean | 16 ok, 0 FAIL | 16 ok, 0 FAIL | none |
| Never compares member 1 | 10 ok, 6 FAIL | 10 ok, 6 FAIL | wave 1's five REBOUND plants and its FMA plant |
| Never compares member 0 | 10 ok, 6 FAIL | 10 ok, 6 FAIL | the same in wave 0 |
| V1's particle mutant | 6 ok, 10 FAIL | 6 ok, 10 FAIL | x of body 1, dt_next, t_lo and t in each wave, plus both FMA plants |

- **Particle mutant's six ok:** the two records, the two clean runs, and the two vz-of-body-63 plants. No sampled replay carries body 63, so the mutant can't be told apart there.
- **The two versions:** each mutant's FAIL set is the same, plant for plant, on both compare_runs.
- **Display fix:** with P3's longer particle line, a failure's detail used to show only the closest approaches. It now prints the particle's own verdict.
- **Mutation script:** it now also makes V1's particle edit, verbatim, and lands every edit exactly once. Run on its own mutants (the particle one and member 1), it refuses: "REFUSED: the edit lands 0 time(s) … not once; nothing written", rc 2.

**Bookings:** desktop only, shared. B0167 ran 13:31 to 13:46:19 and B0168 13:46 to 14:01:46; each was released when its pass ended. I used no GPU. A 14:03 entry is in my drop file.

Files are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad:
- p1\sb2\ (dry-run logs; the first pass is in pass1\)
- p1\sb1\mutate_compare_run.py
- ledger-drop-r5\P1.md
