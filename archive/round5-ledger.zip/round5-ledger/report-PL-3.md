(R5-PL's report on send-back 2, its final message on 2026-11-19 at ~09:00, copied verbatim by the lead.)

Send-back 2 is committed as `e8a7d89` on `round5-pl`: the audit found 6 missing inputs in 3 legs, all now added, and every check you asked for passed. Nothing was pushed or merged.

**Tip:** `e8a7d89377d75b8f926dd596a0876dc25df6ec62`
```
$ git diff --stat cc3d87a..e8a7d89      Makefile | 18 +++++++++---------  (9 insertions, 9 deletions)
$ git diff --stat fda3b40..e8a7d89      Makefile | 32 ++++++---; tools/check_compare_run.py | 123 +++++---  (117 insertions, 38 deletions)
```
`git status --short` is empty after the commit.

## The audit (kept in scratch, not committed)
Tool: `<scratch>\pl\audit_keys.py`, run as `audit_keys.py TREE MAKE_N_OUTPUT`. Its docstring has the full rules:
1. **Start point.** Each `--leg` line's command after `--`. A Python leg starts from its script, run as `__main__`. A binary leg's executable is its own key input, and I read its C source by hand.
2. **What it follows (by `ast`).**
   - `import M`, `from M import f` and `importlib.import_module("M")`, where `tools/M.py` exists.
   - References to top-level defs, including `A.f` through a module alias.
   - Any `tools/X.py` the code builds a path to is treated as run as `__main__`; a copy source counts as data instead.
   - A def that nothing reachable names is never entered.
3. **Paths, by a small evaluator.**
   - It handles string constants, f-strings, `+` and `%`, the `os.path` join/dirname/abspath/normpath/basename calls, conditional expressions, assigned names (including `x += "s"`), and loop variables over literal lists and tuples.
   - Call-site arguments are bound to a def's parameters, repeated until nothing grows.
   - `args.<dest>` comes from the leg's own command line, or else the argparse default.
   - It skips docstrings, help strings, argparse defaults where they are declared, and paths that are only written, created or deleted.
   - A path counts only if it has no whitespace and sits under tools/, build/, data/, results/, src/, tests/ or programs/.
4. **What a path means.**
   - An existing file is needed; a directory means every file directly in it.
   - In `build/`, only a built product directly there counts; anything deeper is the leg's own scratch.
   - A path with a part the evaluator cannot know is reported as UNRESOLVED by file:line, globbed against the leg's inputs.
   - `third_party/` is reported as outside the roots, never needed.
5. **MISSING** means needed but not an `--input`. I read every MISSING and UNRESOLVED line before acting on it.

**Full output.** Output for all three tiers at cc3d87a is in `<scratch>\pl\audit_check.txt`, `audit_check-quick.txt` and `audit_check-light.txt`. Each covers 25 legs and gives the same findings. In the check tier, the lines that are not "MISSING 0" are:
```
constants         written, not read: data/ias15_constants.json, src/ias15_constants.h (gen_constants.py:497-503)
                  outside the roots: third_party/rebound/src/integrator_ias15.c (gen_constants.py:397,442), not an input
check_corrector   UNRESOLVED data/problems/* at 16 sites (194..592): all inputs; outside: third_party/cft-fp256/programs/MANIFEST (an input)
check_gravity     UNRESOLVED programs/out/* at :178: all inputs
check_zonal       written, not read: data/problems/zonal_saturn.txt at :633
check_scalar      UNRESOLVED src/* at :207: 16 of 18 not inputs; UNRESOLVED data/problems/* at :746: all inputs
check_records     MISSING tools/check_equivalence.py <- imports it (check_records.py:23)
check_ensemble    MISSING tools/check_equivalence.py <- imports it (:24); MISSING tools/make_ensemble.py <- runs it (:124-125)
check_ring        UNRESOLVED programs/out/* at :329: all inputs; absent programs/out/ring_{one30,one57,wave57}.txt at :329
check_compare_run UNRESOLVED tools/* at :1960: not all inputs
check_bodycount   MISSING src/ias15_limits.h <- reads it (:56); MISSING tools/check_equivalence.py <- imports it (:41);
                  MISSING tools/make_nbody.py <- runs it (:66)
check_ring_seams  MISSING tools/compare_formats.py <- runs it (check_ring_seams.py:418 -> compare_run.py:1142);
                  MISSING tools/oracle.py <- (same chain) imports it (compare_formats.py:28)
check_reversal    UNRESOLVED tools/* at :246: not all inputs; UNRESOLVED results/horizon/reversal/* at :334-335: all inputs
(the other 15 legs, 6 of them binaries: MISSING 0, nothing else reported)
```

**Legs by inputs added**, in all three tiers each (read and confirmed):

| leg | added | why |
|---|---|---|
| check_records | `tools/check_equivalence.py` | imported at line 23 |
| check_ensemble | `tools/check_equivalence.py`, `tools/make_ensemble.py` | imported at line 24; run on every pass at lines 118-125 |
| check_bodycount | `tools/check_equivalence.py`, `tools/make_nbody.py`, `src/ias15_limits.h` | imported at line 41; run at line 66; read by `cap_from_source()` (line 56), which `main` calls at line 88 |

Each was added on that leg's own lines. No shared `IN_*` variable is used by exactly these legs, so none was touched.

**Pruned after reading.** `check_ring_seams`'s `compare_formats.py` and `oracle.py` are not added. `compare_run.py` runs `compare_formats.py` only under `--format-diff` (lines 1375-1376), and `oracle.py` is imported only by `compare_formats.py`. `check_ring_seams`'s driver command (lines 418-419) never passes `--format-diff`.

**UNRESOLVED lines, read:**
- **`check_scalar.py:207`:** the only `.inc` that `src/ias15_cft.c` includes is `ias15_zonal.inc` (line 1555), already an input.
- **`check_compare_run.py:1960` and `check_reversal.py:246`:** both copy literal tuples, and every file in them is already an input. They show as unresolved only because the audit merges other loops over the same variable name.
- **The rest:** all inputs.

**Binary legs, read by hand:** `check_dropin`, `gate_real` and `gate_subprocess` open or spawn nothing outside their keys.

**Stop rule:** 6 missing, all per-leg additions, so I committed.

## Evidence (measured)
1. **The keys.** `mkn.sh`, then `grow_check.py`, comparing cc3d87a's Makefile with the fix in all three tiers, on the built tree and a fresh one (`build/` and `programs/out` moved aside).
   - All 6 tier-and-tree combinations print "PASS: 25 legs; every leg grew by exactly its audit list and none lost an input".
   - The fresh tree gives the same sets as the built tree.
   - Rerun on the fix's `make -n`, the audit reports only `check_ring_seams`'s two pruned files.
2. **The cache controls.** `control2.sh` ran 08:51 to 08:57 in my worktree's own `build/.gate-cache`. Each step ran the check-quick line exactly as `make -n` printed it. Each change was one byte in a comment line, made by `onebyte.py`, which refuses a line that is not a comment.

| kind | file, with leg | stamp held | cc3d87a's line after the change | fix's line after the change |
|---|---|---|---|---|
| import | `check_equivalence.py:5`, check_records | SKIPPED by name | **SKIPPED** (feeaf7a19588) | **ran**, PASS, 4 ok |
| run script | `make_nbody.py:5`, check_bodycount | SKIPPED by name | **SKIPPED** (b0e0f532fe6b) | **ran**, PASS |
| file read | `src/ias15_limits.h:4`, check_bodycount | SKIPPED by name | **SKIPPED** (b0e0f532fe6b) | **ran**, PASS |

   Every file was restored from a `cp -p` copy. Their sha256 match the baseline, and their `git hash-object` values match HEAD's blobs (f850fb8c, c6c70892, 25af6b68).

**Booking:** B0193 (desktop, shared) with pids 37840 and 39148, released at 08:57 with both gone. None of my processes are running.

**Found, not fixed:**
- **Cached problem files.** `check_bodycount` (lines 63-71) and `check_gravity` (lines 198-200) reuse the `nbody<N>.txt` files they generated earlier in `build/`. So a changed `make_nbody.py` now reruns the leg, but on the old problem until that file is deleted. The control's run after the `make_nbody.py` change passed on the problems the first run wrote.
- **Constants leg.** It reads `third_party/rebound/src/integrator_ias15.c`, which is outside the roots you named and not in its key.
- **Audit limits.**
  - It does not follow imports outside `tools/` (`check_zonal`'s golden model, which its key already lists).
  - Its name binding is flow-insensitive, which produces the false UNRESOLVED and absent lines above.
  - A script run by another script (`compare_run.py`) is evaluated with its own defaults, not the caller's arguments.

The ledger entry is "2026-11-19 09:00" in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\PL.md`.

`<scratch>` is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad`.
