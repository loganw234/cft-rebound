(R5-D's phase 1 report, its final message on 2026-11-19 at ~09:30, copied verbatim by the lead.)

Phase 1 is committed as `4980440` on `round5-docs` (parent `fda3b40`). It changes documents only, and nothing is pushed or merged.

```
 README.md          |  87 ++++++-
 ROUND5.md          |  63 ++++-
 docs/RING.md       | 184 +++++++++++---
 docs/VALIDATION.md | 714 ++++++++++++++++++++++++++++++++++++-
 4 files changed, 1009 insertions(+), 39 deletions(-)
```

**What was written**
- **docs/VALIDATION.md:** entry 55 (P1) and entry 57 (P3) are written in full. Entries 56 and 58 are one LEAD-FILL line each. Entry 54's CPU-to-wall sentence is corrected.
- **ROUND5.md:** every correction the ledger queued is made in place with its source, plus two LEAD-FILL lines.
- **docs/RING.md:**
  - what a producer's files let compare_run hold, and what they do not;
  - a new section on what check-gpu holds of a GPU run;
  - the GPU seam marked as built;
  - one LEAD-FILL line for the wave kernel.
- **README.md:**
  - a check-gpu subsection: its variables and the HIP=1 build it needs;
  - compare_run's usage and its two new options, from the tool's usage text;
  - new lines in the file list.
- The cft-fp256 provenance row is untouched, and it passes check_pins' two README tests, which I ran by hand.

**Numbers and their sources**
- **The two merge suites:** I counted these from the logs myself, leg by leg, with a script against r5-check-d7b5047.log.
  - int-check-fda3b40.log: 16:22:07–19:48:06, 3 h 26 min; 25 legs; 1,504 lines beginning `  ok `; 17 leg RESULT lines, all PASS; 5 compiler warnings; all six digests present.
  - int-check-4a8fe99.log: 09:41:33–12:16:29, 2 h 35 min, with the same counts. Only check_compare_run differs from `d7b5047`, going from 67 to 108; check_ring_seams is 34.
  - The "shared host" notes come from lead.md 09:42 and 19:52.
- **The GPU seam on fda3b40** (seam.log and run-fda3b40.log): 38 ok, 0 FAIL, in 32m16s, 15:47:31–16:19:49. Also from those logs: the device line, the 12 timings in control a3, sampled bodies 22, 30, 57 and 31, and 14 plus 8 plants.
- **P1's measurements** (P1.md 10:25, 10:35, 10:50, 10:55, 15:54, 16:37 and 16:53; R5-P1-report-1 to 4):
  - the cost table; CPU-to-wall ratios of 1.54–1.92 and 1.02–1.03;
  - the where.py counts and the divide and root µs;
  - 69 images; 256/512 load and 257/513 are refused; 13 constants;
  - the route counts 4,341 and 60; the door self-test's 116 and 48;
  - the leg table, the 62 min, gate_subprocess's 31 ok, and the a29f602 suite;
  - the desktop-harness ok/FAIL counts.
- **V1's measurements** (R5-V1-report-1 to 5; V1.md):
  - 36 ok in 123m04s; 212 ok in 192m16s; strace 165/330;
  - the 32 plants and the six refusal cases;
  - 15,089 launches; 84 of 19,434 calls on the host;
  - check_checkpoint 7m56s with 18 device lines; check_seams 12 ok and 24 FAIL;
  - 7.9%; 191 against 206 lines; 144 against 162 values.
  - +0.23% to +1.86% (P1.md 13:03 and V1's report 3). I recomputed them from 10:55's figures. "1.9%" is +1.86% rounded: kepler binary128 on the program engine, 19.15 s against 18.8 s.
- **P3's measurements** (R5-P3-report-1 to 3; P3.md):
  - the GATE 1, GATE 1b and GATE 2 figures and q1–q7, as printed in the fda3b40 log;
  - the q2 token counts; the mutant table; gate counts 70/108 and 105/68/69;
  - 937 ok and 1,501 ok; record line 13.
- **V3's measurements** (R5-V3-report-1 to 3): 359–374 steps, 0.0027, about 28 orbits; 69 ok; 58/12 and 67/3; 12 and 20 runs; 4 of 9; five whole-file reads.
- **P2's measurements** (P2.md 11:00 and 16:13): 7,259 ties in 152,735 cases; two of three cases tried.
- **Merge diffs and decisions** (lead.md 09:42, 12:14, 12:19, 15:46, 16:23 and 19:52): +2131 lines for P1; +1247/-58 for P3.

**LEAD-FILL lines**
- ROUND5.md:9, the status line.
- ROUND5.md:405, the closing section "What the round found against this plan".
- docs/RING.md:310, the wave kernel's section.
- docs/VALIDATION.md:7657, entry 56.
- docs/VALIDATION.md:7920, entry 58.

RING.md's "The record" list now has 54, 55 and 57. Entries 56 and 58 go in at phase 2; I added no extra marker, since the brief allows one LEAD-FILL line in RING.md.

**Findings against ROUND5.md's plan so far**
1. The clock is not TwoSum (P2.md 11:00). Corrected.
2. The contraction control as worded cannot fail (P2.md 11:00, 16:13). Corrected.
3. The 1.5–2.0 CPU-to-wall ratio is ROCm's (P1.md 15:54). Corrected.
4. A producer's files hold its arithmetic, not its decisions, and the first P3 test cannot fail by itself (R5-P3-report-1). Corrected.
5. The default path never calls `cft_reduce` (P1 report item 4; V1). Corrected.
6. The 256 scratch slots fit with no margin (P1.md 10:55). Corrected.
7. The clock's sum runs at every step attempt, rejected ones included (P1.md 16:37). Corrected.
8. The two self-tests' first lines name the backend (P1.md 10:50). Corrected.
9. `check_dropin --light` took 62 min alone on the 5060 Ti (P1.md 16:37). Added beside the plan's estimate.
10. Only check_corrector's `--library` step goes through the registered integrator (P1 report item 3). Recorded in entry 55; ROUND5.md not edited, since it was not queued.
11. Only gate_real's self-contained mode refuses a GPU; check_checkpoint passes on `hip:0`; check_seams fails there only on the routes the device does not publish (lead.md 17:40 and 12:14; V1 report 2). Entry 55 only, because no document carried the wrong claim.
12. cft-gpu has mpmath 1.2.1, no strace and no gdb (P1.md 10:35).
13. Even the quick legs take about 5 hours on the RX 7600 (P1 report item 9).
14. A rejecting wave is always rerun, so "with no rerun of the member" never applies to it (P3 report 1).
15. A seam plant needed both waves and every class a replay carries (V1 reports 2–4).
16. For phase 2: GPU-E2's estimates priced libcft's software binary64, and the flags list omits INVALID (P2 report 1). The MinGW fma/sqrt finding (P2.md 11:15) and the PROGRAMS cache key (lead.md 09:50) also wait.

**Contradictions, and choices for you to review**
1. **The P0 suite log the brief named is the wrong one.** p0-check.log is round 4's P0 suite (`9a42b1d`, 2026-11-11, 19 legs, pin 922c2ad). P0's `d7b5047` suite is r5-check-d7b5047.log, which the ledger uses, so I used it.
2. **Two ok counts for `d7b5047`.** The ledger and P1 give 1,463, which counts lines beginning `  ok `. P2 gives 1,464, which counts every ok line: one check_dropin line has a single leading space. I used the `  ok ` convention throughout.
3. **V0's CPU-to-wall ratio.** lead.md 07:10 gives 1.7–1.9; entry 54 and ROUND5.md say 1.5–2.0, from d13aa45, "after V0's second look". I kept 1.5–2.0.
4. **A second figure for check_dropin --light.** V1.md 12:10 has 66 min on the 5060 Ti and "about 141" on the RX 7600. I wrote only P1's 62 min.
5. **Speed numbers in entry 55.** Entry 55 records P1's MEASURED cost table, with µs a call and the hip:0-over-software ratio. They carry P1's labels, following entry 54's precedent. If your rule allows only suite durations, cut that table.
6. **One correction outside the queue.** RING.md's "Bits" bullet still said the exact-time pair would be refused as AUGADD on hip:N, though the same belief was struck elsewhere in RING.md. I corrected it, citing entries 54 and 55.
7. **A stale comment in code.** hw/gpu/costs.py:19-21 still states 1.5–2.0 as a GPU's ratio in general. It is code, so I left it.
8. **README never documented HIP=1.** I added the build lines check-gpu needs.
9. **ROUND5.md's P0 "To do" bullet is stale.** P0's suite on `d7b5047` passed and P0 landed at `5b1cac6`. I left it for phase 2's status pass.
10. **Who sent P1 back the first time.** The merge message says V1 sent the seam back three times. In fact the first send-back was your decision on V1's READY (lead.md 12:14), and entry 55 says so.
11. **Line numbers for the refused-process count.** It sits at check_gpu.py:562 at `fda3b40`; P1 and V1 cited :543 and :527 at earlier commits. I cited :562.

Waiting for your message for phase 2.
