(R5-V3's third look, its final message on 2026-11-18 at ~09:39, copied verbatim by the lead.)

**READY.** Both mutants that passed last time now fail the gate by name. I found one narrow shape that still passes; it is minor and doesn't block.

**Setup.** Worktree detached at e3f6a39. `git diff --stat 0bee543 e3f6a39` shows the two tools only (+100/−45). `make … all programs` rebuilt nothing (both binaries still dated 11-16 16:48). Booked as B0148 (shared) and released at 09:39. Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v3-r5c\logs\`; copies deleted.

**1. The two passing mutants — confirmed fixed; one narrow gap.**
- **"printed twice" (adjacent):** 58 ok, 12 FAIL, one in every producer-path verdict.
- **"printed on the default path":** 67 ok, 3 FAIL. They are case 1's "without --producer-files, no line of the limit…" and case 5's two runs.
- **Other ways in:**

| Shape | Result |
|---|---|
| two copies apart | 60 ok, 10 FAIL |
| the only copy with a trailing space | 58 ok, 12 FAIL |
| an indented copy on the default path | **70 ok, PASS** |
| a print only in runs with `--rerun-engine` and no producer files ("Lengine") | **PASS in `--quick` (70 ok) and in full (108 ok)** |

- A unit check of the two line tests agrees: a copy that is indented, sits inside another line, or goes to stderr escapes both `limit_once` and `limit_absent`.
- **Cases 3 and 4 are not covered.** The absence check runs in case 1, case 5's two runs and case 7's kepler run only. Case 6 (full only) runs with `--rerun-engine` and no files, and does not check either.
- **Does it matter?** Lengine's run is exactly P2's check_wave invocation (`--rerun-engine loop`, no producer files). A stray line there would be a false sentence, but no reader's pattern matches it and no bit is at stake. I rate it minor.
- **Fix in one place:** assert `limit_absent` inside `drive()` for every run without `--producer-files`.

**2. Settings clause — confirmed.**
- It is true against my measurements. pc_tol_shift 2 and 8 and max_iter 12 moved nothing and pass a rerun, as it now says. max_iter 6 (the cap hits in its trailer line) and epsilon 1e-8 (t) moved something and FAIL.
- The gate's copy matches the driver's as a string. Changing one word ("lines" to "trailer") gives 58 ok, 12 FAIL.

**3. Producer-path count — confirmed.** By the code it is 12 at fp64:
- A and B, the two GATE 1b runs;
- half pair, `--member`, single problem;
- other producer, program engine, zonal;
- q1 and q2.

The 12 FAILs of "printed twice" agree. Full adds A, B, q1 and q2 at fp128 and fp256, giving 20. The seven refused runs (q3–q7, and the other producer without `--rerun-engine`) also print the line but nothing checks it; that is harmless.

**4. `moves()` on a missing replay — confirmed.** My gate copy deletes gate 1's replay of member 4 body 3 before q2. Result: 69 ok, 1 FAIL, q2: "what the plant moves cannot be read: no replay of member 4 body 3 kept by gate 1, in …".

**5. The binary128 text — confirmed.** q2 prints "which moves, as measured here, N tokens of its replays and <counters>". The full run gave fp128 0/0/0/0 and fp256 0/0/0/8 tokens. No "only the counters" wording remains in either tool.

**6. The gate — confirmed.**
- `--quick`: 70 ok, PASS.
- Full: 108 ok, PASS. The +3 over 105 is case 1's absence verdict at three formats.
- M1 66/4, M2 65/5, Mf2 68/2, Mj 69/1 (ok/FAIL) against `--quick`, matching P3.

**7. Readers — confirmed.**
- The driver changes only in the limit's text and its header comment.
- The new text still opens with "particles: the limit of the producer's own files" and contains neither IDENTICAL nor FAIL.
- P2's check_wave.py lines 361–364 are identical at 82b75b8 and 81af26a.

**8. Anything else.** Nothing beyond the gap in item 1.

**READY.** The holes from the second look are closed. What still passes is narrow: an indented copy, or a print confined to runs the absence check skips (`--rerun-engine` without producer files, case 3's `--plan`, case 4's binary128 and FMA records). No reader misreads any of it. The `drive()` fix is still worth making.
