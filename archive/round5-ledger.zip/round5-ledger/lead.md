# lead (round 5)

## 2026-11-16 06:20 - Round 5 opens: P0 built and smoke-run on the RX 7600; the GPU hosts, the bookings and what hip:N does with our calls

Measured (P0, branch round5-p0 in C:/Users/logan/source/repos/cft-rebound-r5):
- d95ac0d: the Makefile's HIP=1. 5389ff7: ROUND5.md. d7b5047: VALIDATION entry 54.
- nvidia-box (ssh -o BatchMode=yes logan@192.168.0.2, key login): ~/cft-rebound-r5 was cloned from git bundles. `make HIP=1 PYTHON=python3 all programs` built in 31 s, linking libamdhip64.so.7.
- The smoke, one binary, software against CFT_REBOUND_ARTIFACT=hip:0: kepler at three formats on both engines. Every sample line and counter is the same in 6 of 6 cases. Only the route lines differ: indexed and pair_gather read by=absent on hip:0, since the device publishes no INDEXED. The default path is call-bound there, at 7 to 30 times the wall time.
- mpmath 1.3.0, copied from the desktop's Miniconda (pure Python, python backend there), is at ~/cft-rebound-r5-py on nvidia-box: use PYTHONPATH=~/cft-rebound-r5-py. Logan's decision 2(a).

Read (cft-fp256's lead, 2026-11-16, and its docs/HOSTAPI.md "The GPU backend"):
- hip:N runs elementwise cft_run, cft_reduce and cft_program_run_ex on the GPU.
- Its programs have 256 scratch slots and 512 bank slots. Index tables and AUGADD/AUGERR inside a program are refused by name; seq_features is 0x75f1f.
- cft_div and cft_sqrt take the program route: the floating core on the GPU, the integer steps on the host. CFT_DIVSQRT_SEQ forces either route; CFT_DIVSQRT_FULL=1 is opt-in and unchecked on hip:N.
- cft_augmented_add runs on the host for every device. Our exact-time clock calls it at every step (src/ias15_cft.c:3049).
- G1C held hip:N to software's bits on both GPUs. It measured 87 us a call on the 5060 Ti and 234 us on the RX 7600.

Hosts and rules (ROUND5.md, "Rules for every parcel"):
- RX 7600: nvidia-box, ROCm with HIP 7.16, hipcc, gfx1102. Work in ~/cft-rebound-r5-<parcel> only, never in another session's directories (g1a, g1b, g1b2 and the rest).
- RTX 5060 Ti: WSL cft-gpu, HIP 7.2.4's NVIDIA layer (HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120). Set CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1 before hip:0, so it is never the RTX 4070. Work in /root/cft-rebound-r5-<parcel>.
- Booking: any GPU run of 10 minutes or more is booked from the desktop in C:/Users/logan/source/repos/TimeSheet, as --who cft-REBOUND/<parcel>, with the ssh or wsl session's Windows pid attached, and released at the end.
- cft-gpu is cft-fp256's until 15:00 today (B0042). Its GPU round 2 is dispatched from Tuesday at the earliest and shares both GPUs; it books its windows as each parcel starts.
- The lead holds rx7600 B0043 (exclusive) and nvidia-box B0044 (shared), 09:00 to 17:00 today, for P0's verifier and P1.

Plan: P0's full make check is running (B0049, from 06:06). V0 verifies P0 now. P0 lands on V0's READY and its suite; Logan delegated round 5's merges and pushes on round 4's bar ("Yes, delegate", 2026-11-16). Then P1, P2 and P3 are dispatched from P0's landing commit, P2 first.
For: anyone

## 2026-11-16 07:10 - V0 on P0: the build and the bits hold; five records corrected (2311e96, docs only)

Measured (V0, its own build in ~/cft-rebound-r5-v0, its own comparator, B0050):
- `HIP=0` changes nothing: `make -n all programs` is the same at 1354a05 and d7b5047, on the desktop and on nvidia-box.
- On hip:0, 24 of 24 cases are identical to software in every sample line and counter. They cover kepler, outer, pythagorean, zonal_saturn, an ensemble, a 64-body ring wave on both engines, `--cs augmented`, kepler_e099 with first-attempt rejections and its `--attempts-out` and `--record-iters` files, and a rejecting ensemble. Eight kinds of planted change were all caught.
- **The device line is the proof the GPU ran.** The record's `backend=hip:0` echoes the artifact string (src/ias15_cft.c:4697-4699) and proves nothing.
- **The routes on hip:0, forced on:** scalar and reduce_seg run in software's bits; indexed and pair_gather are refused by name. `--door-selftest` on hip:0 holds 116 cases identical, with 48 not compared because their routes are absent.
- **A 64-body ring wave ran faster on hip:0 than in software:** 6.31 against 7.19 s on the loop engine, 4.85 against 7.26 s on the program engine. "7 to 30 times slower" holds for kepler only.
- **The trailer's `seconds` and `steps_per_s` are CPU time,** 1.7 to 1.9 times the wall time on hip:0. Use `wall_seconds`.
- **This port's own cost:** 286 us a call on the RX 7600 at binary64. The 87 and 234 us figures are G1B's first part's, staged, not G1C's.
- **The stale-library trap:** in a tree first built without HIP, `make HIP=1 all` returns 0 but leaves libcft.a software-only, and hip:0 is then refused by name. Run `make clean` first.
- **Not this round's path:** HIP_PLATFORM=cuda falls into the amd link branch, and `make HIP=1 example` fails because examples/Makefile has no HIP block.
- `check_dropin --light` took 449 s in software on nvidia-box, so roughly 1 to 3.5 hours on hip:0.

Read (V0): index tables are refused at the call (device.c:861, :2281); only AUGADD and AUGERR are refused by the loader. None of this port's 66 programs uses AUGADD (the lead, by grep).
Done: 2311e96 on branch round5-p0-docs, parent d7b5047, carries the corrections: entry 54, ROUND5.md, and RING.md, whose AUGADD belief is struck as measured false. V0's second look is running. P0 lands as main fast-forwarded to 2311e96, once V0 says READY and d7b5047's suite passes, docs aside.
For: P1, P2, anyone using a GPU host

## 2026-11-16 09:50 - P0 landed: main is 5b1cac6, pushed. Your base, the GPUs' windows, and a gate-cache key found short

Done (the lead, under Logan's delegation of round 5's merges and pushes):
- main fast-forwarded 1354a05..5b1cac6 and pushed at 09:41. **Your base is 5b1cac6.**
- d7b5047's full make check passed, 06:06-09:38: rc 0, 25 legs, 1463 ok, 0 FAIL, every leg at the pin suite's counts (58b085c), read leg by leg. The three commits after it (2311e96, d13aa45, 5b1cac6) change only ROUND5.md, docs/RING.md and docs/VALIDATION.md, which no gate reads.

Found, not fixed (the lead's to fix, after the round's Makefile merges; not any parcel's):
- `PROGRAMS := $(wildcard programs/out/*.cftp)` (Makefile:629 at 5b1cac6, the same line as at 1354a05) is expanded when make reads the Makefile. MEASURED in P0's suite: the tree had no programs/out until 06:10, four minutes in. The suite assembled all 66 programs (log line 100) before its first leg (line 108) and ran every leg with them, but the 10 legs that execute them (check_program_engine, check_corrector, check_replay, check_gravity, check_zonal, check_scalar, check_ring, check_compare_run, check_seams, check_ring_seams) listed no `programs/out` input to the gate cache. That run's verdicts stand, since `make check` always executes; the stamps it wrote are keyed short.
- So: build `all programs` before your first suite, as your brief's build line does. A check-quick or check-light skip in a tree whose first run started without programs/out is not evidence.

The GPUs (TimeSheet at 09:42):
- The lead released rx7600 B0043 and nvidia-box B0044 at 09:42. Book your own windows as cft-REBOUND/<parcel>.
- cft-fp256's GPU round 2 has started, earlier than the Tuesday it first named. Its P0 and that P0's verifier ran on the 5060 Ti in cft-gpu, 08:09 to about 09:05 (B0057, B0058, B0060, B0061, all released). Its 15:00 hold on cft-gpu (B0042) was cancelled. Its parcels book as they start, so `check <resource> --short` before every short GPU run, and book early for anything of 10 minutes or more. Never book over another's window. A conflict goes to the lead as an urgent drop, not to cft-fp256 directly.
- The desktop is shared today with six QRO-Crate runs and a cft-debris notice (B0045-B0062). A suite's wall time there measures the host's load as much as ours, and no parcel times anything on the desktop.

Dispatched next, from 5b1cac6: P2 (the wave kernel), then P3 (compare_run takes a producer's files), then P1 (this tree on hip:0).
For: P1, P2, P3

## 2026-11-16 10:05 - cft-fp256's plans for the GPUs and cft-gpu (its lead, by message)

Read (cft-fp256's lead, 2026-11-16 about 10:00):
- **Today, nothing of cft-fp256's runs on either GPU.** Its round 2 P0 and that P0's verifier are done, and their bookings are released.
- **One study, GPU-H, may start today if Logan approves it.** It is CPU only (clspv, Tint and PoCL in WSL cft-gpu), about 4 h. **cft-gpu is one user at a time,** so it would hold the cft-gpu window that P1's and P2's 5060 Ti legs also need. cft-fp256 books it through the TimeSheet (wsl-cft-gpu) the moment Logan says yes. So check `wsl-cft-gpu` as well as `rtx5060ti` before any 5060 Ti run.
- **Tuesday 2026-11-17 (likely):** its round 2 parcels G2A and G2B run on both GPUs: the 5060 Ti in cft-gpu and the RX 7600 on nvidia-box. They book early and are mostly short runs, the longest legs a few minutes each.
- The nightly card stays on amd-arc-box, 18:00 to 07:45, and touches neither GPU.
- It offered to place its cft-gpu time around a planned long hip:0 leg of ours. P1: if you plan check_dropin --light (1 to 3.5 h) on the 5060 Ti, drop a ledger note with its planned start as soon as you know it. The lead will pass it on.
For: P1, P2

## 2026-11-16 16:55 - P3 reported (2922fa1); V3 verifies it; the records' corrections the round has found so far

Done (the lead):
- P3's commit 2922fa1 changes tools/compare_run.py and tools/check_compare_run.py only. Its full make check (12:39 to 16:40) matches P0's suite on d7b5047 leg by leg: every leg's ok count is the same but check_compare_run's, 67 to 105. The identity lines are the same, and all 10 legs that run the programs list them in the cache key.
- V3, P3's verifier, was dispatched at 16:55 on 2922fa1. Nothing of P3's merges until V3 says READY.

Queued for the round's records (the lead's files; no parcel edits them):
- ROUND5.md, P2: "an augmented sum done as TwoSum in binary64" is wrong. libcft's augmentedAddition rounds an exact tie toward zero (P2, 11:00; 7,259 ties in 152,735 cases, and records that differ).
- ROUND5.md and entry 54: "CPU time 1.5 to 2.0 times the wall time on hip:0" is ROCm's. On the NVIDIA layer it is 1.02 to 1.03 (P1, 15:54).
- ROUND5.md, P2: the contraction control as worded cannot fail on the checked source. P2's bites only with the checks compiled out (P2, 11:00; on nvcc too, 16:13).
- ROUND5.md, P3 and docs/RING.md: a producer's files hold its arithmetic, not its decisions (P3's GATE 1b). ROUND5.md's first P3 test cannot fail by itself.
- VALIDATION: MinGW's library fma and sqrt are not correctly rounded, and g++ calls them at -O0 (P2, 11:15). Every shipped build is -O2.
- Found by the lead: the PROGRAMS key (09:50 entry).
For: P1, P2, V3

## 2026-11-16 17:05 - P1 reported (ab75fbe); V1 verifies it, on the GPUs only after P2's windows

Done (the lead):
- P1's tip ab75fbe is 16 commits on 5b1cac6: the Makefile's check-gpu, tools/check_gpu.py and hw/gpu/{where.py, costs.py, program_caps.c}.
- Its desktop make check at a29f602 matches P0's suite leg by leg: 25 legs, 1,463 ok, all 10 program legs keyed with the programs. After a29f602, only check_gpu.py, hw/gpu/where.py and Makefile comments change, and no desktop tier runs them.
- V1 was dispatched at 17:05. Its desktop work comes first. It may touch the GPU hosts only after P2's windows: the 5060 Ti after 20:30, the RX 7600 after 22:00. There it runs ab75fbe's check-gpu on a named subset, and check_corrector on the RX 7600, which P1's window could not hold.

Found, not fixed (P1's, the lead's to schedule):
- gate_real, check_checkpoint and check_seams cannot be pointed at a GPU. tests/gate_real.c:324-350 takes any artifact not `cft://` for a card image, and a GPU loads none. The fix is a tests/ change, not a P1 one.

Queued for the records (beyond 16:55's list):
- check_dropin --light took 62 min alone on the 5060 Ti.
- ROUND5.md's cft_reduce on the GPU: the default path never calls it.
- The 256 scratch slots fit with no margin (gravity-fold256-fp128).
- The clock's augmented sum runs at every step attempt, rejected ones included.
- The two self-tests' first lines name the backend.

For P2:
- At the merge, check_wave joins check-gpu as a second line of its recipe, as P1 and P2 agreed (P1, 12:00). The lead adds it at whichever merge comes second.
- V1 will not touch nvidia-box or cft-gpu inside your windows.

For: P2, V1, V3

## 2026-11-16 17:30 - The round pauses, at Logan's word

- Logan asked to pause the round at a decent point (about 17:25). At 17:28 the lead asked P2, V1 and V3 to wind down by about 18:00:
  - commit what is worth keeping, or record it;
  - stop nothing of another's, and leave nothing of yours running on either GPU host;
  - release every booking;
  - send interim reports that say where to pick up.
- P2's RX 7600 window tonight (B0073/B0074, 18:00-22:00) goes unused and is released.
- Nothing merges during the pause. main stays at 5b1cac6, origin/main the same. P3's 2922fa1 and P1's ab75fbe wait on their verifiers.
- On resuming, in order:
  1. V3 and V1 finish their items. V1's GPU items include check_corrector on the RX 7600.
  2. P2 resumes its remaining steps.
  3. The merges, one at a time, each on a verifier's READY, with its seam tests and a full make check on the merged tree.
- The resume plan also sits in the lead's memory.
For: P2, V1, V3

## 2026-11-16 17:40 - Correction to 17:05: gate_real's identity check blocks gate_real alone (V1, interim)

Read (V1, at ab75fbe):
- tests/gate_real.c:327-328 does take any artifact that is not `cft://` for a card image.
- But identity_ok() is called only at :646, in the self-contained mode. `--straight`, `--save` and `--resume` (:1472-1474) never call it.
- check_checkpoint and check_seams use only those three modes. So the 17:05 entry's "gate_real, check_checkpoint and check_seams cannot be pointed at a GPU" holds for gate_real only.
- check_seams forces indexed and pair_gather on (check_seams.py:87), which hip:0 refuses by name. It would fail on that instead (BELIEVED, not run).
- Whether check_checkpoint passes on hip:0 is not determined.

V1 paused at 17:33 with its GPU item 5 not determined. Its interim report is in the lead's scratch (reports/R5-V1-report-1.md).
For: anyone

## 2026-11-16 18:00 - V3 on P3: NOT READY, on D1 alone; the send-back waits for the resume

V3's verdict on 2922fa1 (its report is in the lead's scratch, reports/R5-V3-report-1.md):
- **NOT READY on D1, a printing fix.** compare_run's output never states the limit. The limit is stated only in compare_run.py's source header (:145-154).
  - **The overclaim:** the output says "NOT RERUN: its lines are held by the record alone, and by its particles' replays".
  - **Measured:** a producer whose wave stopped two passes early, in a member that is not rerun, gets RESULT: PASS.
  - **The fix:** a printed limit line, asserted verbatim by the gate. It says that a producer's dts, outcomes and passes are taken as given; that unsampled particles of a NOT RERUN member are held by nothing; and that the key cannot hold settings a record does not carry (epsilon, pc_tol_shift, max_iter) on a member that is not rerun.

Confirmed:
- the scope;
- the gate (105 ok full, 68 quick);
- the default path, unchanged but for the particle lines' new clauses (--particle-strata without --producer-files is refused);
- the key;
- P1's and check_ring_seams' readers;
- E and the exact-time pair held for NOT RERUN members through the replays;
- the ~1,000-attempt limit. A 10^6 ring wave takes 359 to 374 steps over 10 orbits, so one pass moves the mean by about 0.0027. The limit binds only beyond about 28 orbits.

For P3's send-back, beside D1:
- **The pass-count claim is wrong.** Five of the eight plants said to be caught by the mean also move max_pc_iterations. Only the three middle-attempt +1 plants rest on the mean alone. check_compare_run.py:97 and :698 say "only the mean passes"; correct them.
- **Mutant Mf2 survives.** It is a driver that uses the rerun's schedule for rejecting members while naming the producer's. q2 plants no rejected attempt. Two fewer passes on member 0's rejected first attempt moves 28 tokens at fp64 and 8 at fp256, so a q2 plant there would catch it.
- **Mutant Mj (the files keyed to --rerun-engine's engine) is caught only by the full-only program-engine case.** check-quick and check-light cannot see it.
- **The gate's PF_SOURCE regex** splits paths at " and ". A path containing " and " fails spuriously.
- **The report's overreach:** "the header states the limit" (the source header only), and "about three whole-file reads" (five, by the code).

Not yet run, and the integrator's at the merge: the P2 x P3 seam. No producer but ias15_cft has gone through --producer-files.
On resuming: send P3 back with D1 and the list above, then V3's second look.
For: P3, P2, anyone

## 2026-11-17 09:44 - cft-fp256's GPU round 2 landed G2A and G2B (fb264545): what changes on hip:N, and the pin question it puts to round 5

Read (cft-fp256's lead, by message, about 09:42; "no reply needed"):
- G2A and G2B are on cft-fp256's main at fb264545, pushed at 09:41 and gated. Its stage `hip` passed on both GPUs at the merge with nothing skipped (428 s on the 5060 Ti, 681 s on the RX 7600).
  - Checked in ../cft-fp256's log, read-only: main is fb264545 (09:39:57), 30 commits past our pin eae74e3e. The merges are 3fb282d9 (G2A) and 3d183716 (G2B).
- On a hip:N handle at fb264545:
  - cft_augmented_add, _sub and _mul compute on the GPU, with the host's bits and flags (augmented.c's own ties-toward-zero lanes). Resident buffers stay on the device. Sub flips b's sign on the integer encoding, never through a double; a planted double flip turned their checks red.
  - The GPU beats the host loop from n between 256 and 1,024 upward, in every case they measured (both GPUs, fp64 and fp256, staged and resident). At our 17,544 it is 10 to 42 times faster; at 3,368,448, 14 to 122 times. A call at n = 1 costs about 109 to 234 us, slower than the host.
  - The executor runs AUGADD and AUGERR. seq_features is 0x7ff1f, the software handle's own.
  - Index tables run on the device. cft_open_ex opens a GPU at up to 2,048 scratch slots.
  - A known cost: on the 5060 Ti, programs without AUGADD run 7% to 17% slower than at their round 1. The RX 7600 pays nothing. It is left for their later tuning.
- Both GPUs are free of their bookings (B0098 to B0102 released). G2C is drafted next: divfull and sqrtfull on the device, and a form callable from device code for our wave kernel. They will book around our windows when we resume.

What it means here (read from our code and from their HOSTAPI.md at fb264545; BELIEVED where marked; nothing run):
- **Round 5 is pinned at eae74e3e (G1C).** Everything P1, P2, P3, V1 and V3 measured is at that pin. None of the above reaches this tree without a pin move, and that move is Logan's call.
- **If the pin moves:**
  - **The clock's augmented sum moves to the device.** On the default path it is the only augmented call: ias15_cft.c:3049, n = E, at every step attempt. add_cs's call at :1680 runs only under --cs augmented. For a one-system problem that is one more n = 1 device call per attempt, among the many small calls a step already makes there. BELIEVED small; not measured. On the 10^6 ring, n = E is the regime they measured faster.
  - **The routes' by= stops differing.** At the pin, hip:0 reads indexed and pair_gather as by=absent (ias15_cft.c:329), and check_gpu.py sets that difference aside. With CFT_SEQ_FEAT_INDEXED published, both would read by=opt_in, as software does (BELIEVED). Entry 54's "index tables refused at the call" would go stale. check_seams, which forces both routes on (17:40 above), might then run on hip:0 (BELIEVED, not run).
  - **The scratch margin stays zero.** This tree opens with cft_open (ias15_cft.c:4578). At fb264545 a `scratch_depth` of 0 is cft_open exactly, 256 on a GPU (HOSTAPI.md:2335-2336 and :3587, read). The 2,048 depth reaches us only if the tree asks cft_open_ex for it.
  - **The 5060 Ti's costs do not carry over.** P1's cost rows and P2's 67k-69k system-steps/s were taken at eae74e3e. At fb264545, programs without AUGADD run 7-17% slower there (their figure).
  - **G2C bears on P2's wave kernel** (binary64 today) and on Decision 3, the device divide and root.
- **The lead's recommendation, for Logan at the resume:** finish round 5 at eae74e3e, then move the pin as its own step, after G2C if G2C lands soon. Moving it mid-round would reopen P1's witness rules, P2's rates and entry 54, all measured at eae74e3e.
For: anyone

## 2026-11-17 12:50 - cft-fp256's G2C landed (d4964c3c): the divide and root on hip:N keep today's route; a device-callable divide measured, not built; two decisions with Logan

Read (cft-fp256's lead, by message, about 12:49; "no reply needed"):
- G2C is on cft-fp256's main at d4964c3c, pushed at 12:48.
  - Checked in ../cft-fp256's log, read-only: main is d4964c3c (12:47:17), five commits past fb264545, with the merge 1ef407f3.
  - Its stage `hip` passed once on each GPU with nothing skipped, in 459 s and 702 s (their commit 28a34d95's subject).
- **cft_div and cft_sqrt on hip:N keep today's program route.**
  - The whole-operation images (divfull, sqrtfull) load and run bit for bit on both GPUs, and from n = 4,096 they are 1.7 to 2.6 times faster.
  - At small n they are slower. One call is one lane's latency through about 216 interpreted instructions, and at n = 1 they are 0.11 to 0.50 ms slower.
  - The rule fixed beforehand needed both, so the default did not flip. CFT_DIVSQRT_FULL=1 still selects the images.
- **A size-dependent route** (the whole operation from n = 2,048) is a decision now with Logan.
- **A divide callable from device code** was measured and costed, not built.
  - The recommended shape, S1, runs one lane of the committed image through seq_run_block, with a device header fixing the include recipe.
  - In a scratch kernel at fp64: 6.05e7 divides a second on the 5060 Ti and 2.67e7 on the RX 7600, with frames of 12.8 to 16.9 KB a thread.
  - S1 alone holds the 5060 Ti to 67 to 83% of its resident threads. Whether its frame binds an IAS15 kernel is open.
  - Which shape to build is with Logan.
- Both GPUs are free of their bookings (B0109 to B0113 released).

What it means here (read from our code; BELIEVED where marked; nothing run):
- **Our divide and root calls, by size** (vdiv and vsqrt, ias15_cft.c:502-505, call cft_div and cft_sqrt):
  - **gravity's root and divide, at n = P** (:1569-1571, :1624-1627): 1 to 2,016 in the suite's 2- to 64-body problems. On a 10^6 ring wave it is about 35 M (their figure: 17,544 systems of 64 bodies).
  - **the corrector's and the update's, at n = N3** (:1759-1762, :1854, :2350, and :3026-3033 off the FMA form): 6 to 192 in the suite, 3,368,448 on the ring.
  - **the step-size control's, at n = 1, E or NB** (:2259-2580): small everywhere.
- **A route by size would split our calls cleanly** (BELIEVED, from their figures). The ring's gravity and corrector calls are far past n = 4,096, where they report the gain. Every call in the suite's one-system problems is under 2,048 and would keep today's route.
  - A 64-body system's 2,016 pairs sit just under 2,048, and under the 4,096 from which they report a gain. Their "well into the large-n gain" holds for the ring's sizes, not for 2,016.
- **The bits:** they say the images give the program route's bits. If so, a route chosen by n moves no line of ours. check-gpu's witness is what would hold that here (not run).
- **None of it reaches this tree at eae74e3e.** Like G2A and G2B (09:44 above), it waits on a pin move, and that move is Logan's call.
  - The two switches P1's where.py drives are read at both pins: divsqrt.c:1356 reads CFT_DIVSQRT_SEQ and :1480 reads CFT_DIVSQRT_FULL (git grep, read-only).
- **The device-callable divide matters to the wave kernel only past binary64** (BELIEVED). P2's kernel divides with w_div and roots with hw_sqrt in the hardware's binary64 (wave_arith.h:85; wave_step.h:185), and round 5 targets binary64. At a wider format the kernel would need S1 or its like. S1's frame would sit beside the kernel's own, and neither P2's interim report nor its ledger entries record that frame or the kernel's occupancy.
For: anyone

## 2026-11-18 05:41 - Logan: round 5 finishes on eae74e3e; the pin moves after, as its own step

- **Logan, in chat (2026-11-18 about 05:40):** "Agreed, finish round 5 on eae74e3e first". This answers the 09:44 entry's question. Round 5's parcels, verifiers and merges all stay on G1C.
- **The pin move comes after round 5 closes, as its own step, on Logan's word.** Round 5's merge delegation does not cover it. By then cft-fp256's main will carry G2A to G2C and G2D, whose merge cft-fp256 runs today (B0123-B0128, 08:30-10:30).
- **Today's GPU windows:** cft-fp256 holds both GPUs 08:30-10:30 for G2D's merge (rtx5060ti, wsl-cft-gpu and rx7600 exclusive; nvidia-box and desktop shared). Round 5's GPU work goes around that window. Message cft-fp256 before booking.
For: anyone

## 2026-11-18 05:46 - Round 5 resumes at Logan's word: P3 sent back, V1 and P2 resumed; today's windows

- **Logan, in chat, 2026-11-18 about 05:44: "Resume now".** The pause of 11-16 and 11-17 ends.
  - main and origin/main are both 5b1cac6. The parcels' tips are unchanged: P1 ab75fbe, P2 81af26a, P3 2922fa1.
  - The drop watcher was re-armed at 05:45.
- **Sent at about 05:45:**
  - **P3:** sent back with D1 and V3's list (18:00 above). It runs its gate in three forms and check_ring_seams, but no full make check, since the merge runs one.
  - **V1:** item 5 on both GPUs, the nvidia-box cleanup, then its final report.
  - **P2:** the RX 7600 steps, and its full make check at 81af26a.
- **Today's GPU windows, as cft-fp256 agreed by message at about 05:46:**
  - **Both GPUs** are ours until 08:25. cft-fp256's G2D replay runs from 08:25: about 13 min on the 5060 Ti and 19 on the RX 7600, done by about 09:00 if all goes well. It releases B0124-B0128 when that ends and messages us. Either way it is off both GPUs by 10:30, and it needs neither GPU inside our windows.
  - **The 5060 Ti:** V1 from now to 08:25, and from 10:35 (or from cft-fp256's release) to about 13:00. V2 later.
  - **The RX 7600:** P2 from now to 08:25 (the correctness steps). V1 from 10:35 to 13:35 (check_corrector under strace). P2 again from 13:35 to 16:00 (ladder, rung, hold, phys).
  - **The desktop:** P2's full make check at 81af26a (about 3.5 h), P3's gate runs, and later V3's second look. No timing claims from the desktop.
- **The merge order is unchanged.** One at a time, each with a full make check on the merged tree:
  1. P3, on V3's READY.
  2. P1, on V1's READY, with its GPU seam re-run on the merged tree.
  3. P2, on V2's READY, with the P1×P2 and P2×P3 seams.
For: P1, P2, P3, V1, V3, anyone

## 2026-11-18 06:57 - P3's send-back is in at 0bee543; V3 is sent for its second look

- **READ:**
  - P3's final message, copied verbatim to scratchpad/gpu/reports/R5-P3-report-2.md, and its 06:54 entry in P3.md.
  - The tip is 0bee543, with parent 2922fa1.
- **MEASURED by the lead:**
  - `git diff --stat 2922fa1 0bee543`: tools/check_compare_run.py and tools/compare_run.py only, +219/-111.
  - Against main 5b1cac6: the same two files, +1186/-52.
  - P3 touches no Makefile, but P1 and P2 both do, so the Makefile is the merge-time overlap between P1 and P2.
- **No full make check from P3,** as briefed. The one that counts is the merge's, on the merged tree.
- **V3 resumed** (af3f738e415983e97) at 06:57, with a second-look brief:
  - D1's line: printed once, absent on the default path, its text true clause by clause, and mutants of the print;
  - the readers, now including P2's check_wave.py;
  - the default path byte-identical to 2922fa1's;
  - its list: the pass counts; Mf2, Mj, M1 and M2 re-run on --quick; both tiers' commands and the key; paths with " and "; the corrections;
  - the gate re-run, --quick and full. 105 in full did not move, though checks were added, so V3 is to say what the ok lines now cover.
  - Report under 1,000 words.
- **For the merges (READ, 81af26a:tools/check_wave.py:362-364, 593, 621):** P2's check_wave reads compare_run's member and particle lines by its own patterns. So the P2 x P3 seam must cover check_wave's patterns on 0bee543's lines, as well as --producer-files on wave_host's files.
- **TimeSheet (READ at 06:55):**
  - cft-fp256's G2D bookings (B0123-B0128) run 08:30-10:30, not from 08:25. Ours end at 08:25.
  - The desktop is shared: P2's B0131 to 10:00, V1's B0136 to 08:25, and cft-debris's B0138 (a notice) to 07:29.

## 2026-11-18 07:45 - V3's second look at 0bee543: NOT READY, on the gate's hold of the limit line; P3 sent back a second time

- **READ:** V3's report, copied verbatim to scratchpad/gpu/reports/R5-V3-report-2.md. Its desktop booking was B0139, shared, released 07:43.
- **What V3 confirmed:**
  - the line's placement;
  - the reworded member, plan and RESULT lines;
  - every reader: P1's, part 3's and P2's check_wave.py at 81af26a;
  - the default path, byte-identical to 2922fa1 on six setups;
  - P3's mutant table and its gate counts: --quick 69, full 105 (07:01-07:43);
  - the " and " path;
  - both of P3's corrections.
- **What V3 found:**
  - **The line printed twice passes the gate.** MEASURED by the lead in the code: check_compare_run.py:510-514 at 0bee543 counts `out.count("\n" + PRODUCER_LIMIT + "\n") == 1`, and adjacent copies share a newline.
  - **The line printed on the default path passes too.** Nothing asserts that it is absent.
  - **The settings clause overstates.** Rerun with other settings, pc_tol_shift 2 and 8 and max_iter 12 came back IDENTICAL (V3's measurement), so a rerun holds them only through what they move.
  - **Weak spots:**
    - only 4 of the 9 producer-path runs assert the line;
    - moves() reports -1 tokens on a missing replay instead of failing;
    - "at binary128, only the counters" is printed, not asserted, and in the full tier only.
- **P3 resumed** (a35562c26dc613fed) at about 07:46, with send-back 2:
  - required: count the line as lines, assert it absent on the default path, reword the settings clause (and re-measure two of V3's cases);
  - in the same commit: the four smaller items;
  - proof: mutants of the driver (twice, default path, removed, one word, before the plan, M1, M2, Mf2, Mj), the missing-replay case, the gate in three forms, and check_ring_seams --quick;
  - no full make check; report under 800 words.
- **Next:** V3's third look, narrow, on P3's next tip.

## 2026-11-18 08:52 - The GPUs were released early (08:49); P3's e3f6a39 goes to V3 for a third look; P2's tip is 82b75b8

- **cft-fp256 (its message at 08:49, READ; the TimeSheet confirms it):**
  - B0124-B0128 were released at 08:49:16, and G2D's replays ended at 08:47 (5060 Ti) and 08:48 (RX 7600), both passing.
  - Their locks are free and no compute process is on either GPU.
  - Their files stay in /root/lead-1118-replay and ~/lead-1118-replay; nothing of ours touches them.
  - Replied at about 08:52.
- **New GPU order:**
  - V1 now has both GPUs: the 5060 Ti and cft-gpu to about 13:00, and the RX 7600 and nvidia-box for check_corrector under strace.
  - V1 is to release the RX 7600 at once when that run ends and tell main. P2's timings (ladder, rung, hold, phys) follow from then, or from 13:35 at the latest, with nvidia-box quiet.
  - V1 and P2 were told at about 08:52.
- **P3's send-back 2:**
  - It is e3f6a39 on 0bee543. MEASURED by the lead: `git diff --stat 0bee543 e3f6a39` shows the two tools only, +100/-45.
  - The driver's code lines changed only in PRODUCER_LIMIT's text. The settings clause now ends "...are held only in a member that is rerun, and there only through what they move in its lines".
  - P3's report is copied verbatim to reports/R5-P3-report-3.md. It claims: --quick 70 ok, full 108 ok, check-light's command 70 ok, check_ring_seams --quick 21 ok, and eleven mutants each FAIL by name, including Ltwice, Ldefault and Grm.
  - Its booking B0141 was released at 08:44.
- **V3 resumed for a third look at about 08:52,** narrow and under 600 words. It will:
  - re-run its two passing mutants and try other shapes past limit_once and limit_absent;
  - check the settings clause against its own measurements;
  - count the line's runs (12 at fp64, 20 in full);
  - show the missing-replay FAIL;
  - check the binary128 text;
  - re-run the gate.
- **P2's branch tip is 82b75b8,** committed at 05:59 on 81af26a. It changes the Makefile, src/wave/wave_corpus.cpp and tools/check_wave.py.
  - MEASURED from full3.log's first line: P2's full make check started at 05:59:39 at 82b75b8, after that commit. No commit landed mid-run.
  - B0131's text still says 81af26a.
  - check_wave's compare_run patterns (lines 362-363) are unchanged at 82b75b8; only the corpus-digest patterns were added.

## 2026-11-18 09:28 - cft-fp256's GPU round 2 is closed: G2D merged, main 9e8ff270 (pushed 09:27); the candidate for the pin move after round 5

- **READ, cft-fp256's message at about 09:27:**
  - G2D is merged and pushed; main is 9e8ff270.
  - No API change. The `hip` stage holds round 2's three classes on both GPUs, with 16 plants, each red by its own check.
  - At the merge: the stage passed on the 5060 Ti (941 s) and the RX 7600 (1,105 s), every count equal to G2D's own; the box gate passed; their verifier sent nothing back.
- **MEASURED by the lead, in ../cft-fp256 (read-only):**
  - main is 9e8ff270;
  - d4964c3c and our pin eae74e3e are both its ancestors;
  - it is 41 commits past eae74e3e.
- **For the pin move after round 5 closes (on Logan's word, not under the delegation):**
  - They name 9e8ff270 as round 2's whole state. hip:N publishes seq_features 0x7ff1f.
  - Their VALIDATION note: an augmented call's chunk at fp256 is 524,277 pairs only where at least 512 MiB is free when the handle opens (the stage is the smaller of 64 MiB and an eighth of free memory); on a fuller card it is smaller.
  - Our ring's corrector call is n=N3, about 3.4 M pairs, so it would be chunked either way (COMPUTED from the figures above).
- **Logan's decisions on cft-fp256's side, nothing built:** G2C's size-chosen divide route, and S1.
- **Booking:** cft-fp256 has nothing booked on either GPU today.

## 2026-11-18 09:42 - V3: READY on P3 at e3f6a39; P3 merged on round5-int (4a8fe99) and its full make check launched; main has not moved

- **READ, V3's third look** (copied verbatim to reports/R5-V3-report-3.md; its booking B0148 was released at 09:39):
  - **READY.** Both mutants that passed at 0bee543 now FAIL by name.
  - The settings clause is true against V3's own runs.
  - The line is asserted in 12 runs at fp64 and in 20 in full, matching the code.
  - moves() FAILs by name on a missing replay.
  - The binary128 text is a description only.
  - The gate: --quick 70 ok, full 108 ok. The +3 is case 1's absence check at three formats.
  - M1, M2, Mf2 and Mj match P3's counts.
  - The readers, including check_wave.py at 82b75b8, are unchanged.
- **V3's one open point, minor, not blocking: QUEUED for the lead,** beside the PROGRAMS key and the records' corrections.
  - An indented copy of the line, or a print confined to runs without producer files that the absence check skips, still passes. Those runs are --rerun-engine without files (check_wave's own call), case 3's --plan, and case 4's records.
  - No reader matches it and no bit is at stake.
  - The fix is limit_absent asserted inside drive() for every run without --producer-files.
- **MEASURED by the lead, the merge:**
  - In cft-rebound-r5 (pins at bdfda4b and eae74e3e), I created branch round5-int at main 5b1cac6, then ran `git merge --no-ff e3f6a39`. The result is 4a8fe99, with no conflict.
  - `git diff --stat 5b1cac6 4a8fe99`: the two tools only, +1247/-58.
  - `git diff e3f6a39 4a8fe99` is empty: the merged tree is P3's tree.
  - The message is in scratchpad/gpu/merge-p3-msg.txt.
- **MEASURED, the suite:**
  - The full make check on 4a8fe99 was launched from PowerShell at 09:41:33 (pid 22504), by script gpu/int-check-r5-p3.sh: make clean, then `all programs`, then `check`.
  - It logs to scratchpad/gpu/int-check-4a8fe99.log. The log's head shows round5-int at 4a8fe99, no changed paths, cc x86_64-w64-mingw32, and the pins bdfda4b and eae74e3e.
  - Booked B0150, desktop shared, to 14:30. The desktop is shared with P2's suite (B0131), V1's host side and cft-debris (B0140, a notice), so no timing claims.
- **Next:**
  - When rc=0 is read and every leg is read against P0's suite on d7b5047 (25 legs; check_compare_run 67 ok to 108 is P3's change), main fast-forwards 5b1cac6..4a8fe99 and is pushed, then reported to Logan.
  - No suite runs in the main checkout, so the fast-forward lands while none runs on main.

## 2026-11-18 12:08 - V1 released the RX 7600 and nvidia-box at 12:07, and P2's timings start; the merged tree's suite is at 23 of 25 legs

- **READ, V1's message at about 12:07:**
  - check_corrector on the RX 7600 ended at 12:06, PASS under strace.
  - B0145 and B0146 were released at 12:07, and nvidia-box is quiet.
  - V1's verdict on P1 is still to come.
- **MEASURED by the lead, the TimeSheet at 12:08:**
  - No booking is held on the RX 7600, nvidia-box or the 5060 Ti.
  - P2's B0131 is gone as well. Its suite's result at 82b75b8 is P2's to report.
  - Live bookings: B0150 (ours, desktop, to 14:30) and B0140 (cft-debris, a notice), plus the standing S001 and S003 tonight.
- **P2 was told at about 12:08** to:
  - start ladder, rung, hold and phys on 82b75b8 now, booked first;
  - name each figure's clock and compare like with like;
  - report with its full make check's result.

  This is the order of 08:52, from V1's release rather than from 13:35.
- **MEASURED, the merged tree's make check** (4a8fe99) at 12:08:47:
  - 23 of 25 legs are printed;
  - 14 RESULT lines, all PASS;
  - no line opens with FAIL;
  - there is no end line yet.

  It is read whole only when it ends.

## 2026-11-18 12:14 - V1: READY on P1 at ab75fbe; P1 sent back, narrowly, for wave-1 plants and named timing keys before the merge

- **READ, V1's final report** (copied verbatim to reports/R5-V1-report-2.md; its drop V1.md is placed):
  - **READY.** `make HIP=1 check-gpu` at ab75fbe passes on both GPUs:
    - 5060 Ti: 36 ok, 0 FAIL, 123m04s;
    - RX 7600: check_corrector under strace, 212 ok, 192m16s, "strace: 165 run(s) of the witnesses and 330 of the real programs".
  - Every process printed the probe's device line, and every record is identical to software's.
  - Every booking was released; on nvidia-box, only V1's own work directories were deleted.
  - **The seam gap, MEASURED by V1:** every plant is in wave 0. A one-line compare_run mutant that never compares member 1 passes the seam in both forms. On a wave-1 plant, the tree's compare_run FAILs member 1 and the mutant says IDENTICAL.
  - **Latent:** TIMING (check_gpu.py:164) sets aside any `t_*` key, so a planted `t_new=1` passes. Stderr never fails a leg. Refused processes count as device processes (:527). On the 5060 Ti nothing can see a bypass.
  - **Corrections:**
    - each plant is one hex digit on one line;
    - "within 1.5% of P0" is 1.9% (kepler fp128, program engine);
    - check_checkpoint --quick runs on hip:0 as it is (7m56s, 18 of 18 with the device line);
    - check_seams --quick fails there only on the forced indexed and pair_gather cases, which the device refuses by name.
- **CORRECTION to 17:05 (2026-11-16) and 17:40:**
  - "gate_real, check_checkpoint and check_seams cannot be pointed at a GPU" holds for gate_real's self-contained mode only.
  - check_checkpoint runs on hip:0 and passes (V1, MEASURED).
  - check_seams fails there on the routes the device does not publish, not on identity, as 17:40 believed.
- **The lead's decision: P1 is sent back narrowly before the merge,** rather than merged on READY with the fixes queued.
  - **Why:**
    - check-gpu is in no tier (READ, P1's Makefile hunk), so no desktop make check runs check_gpu.py. A fix after the merge would cost its own verifier and its own full make check.
    - The seam gap is CLAUDE.md's planted-control shape: a copy comparing less passes the gate.
    - P2 is still the round's long pole (timings now, then V2), so this delay is not expected to move the round's close.
  - **P1's send-back 1, sent at about 12:13; P1 was resumed.** In tools/check_gpu.py only, on ab75fbe:
    - wave-1 plants: at least two columns on two lines in the rebound form, and one in the FMA form;
    - the skip-member-1 and skip-member-0 mutants, each landing exactly once, FAILing the seam by name in both forms;
    - TIMING naming today's keys, with a planted t_new=1 FAILing.
  - P1 runs the seam alone on the 5060 Ti in WSL cft-gpu, booked first. Its corrections go in P1.md.
  - V1 then takes a narrow look. The merge follows: round5-int at the new main, `--no-ff` of P1's new tip, the GPU seam live on the merged tree (5060 Ti), then the full make check.
- **cft-fp256 was told at about 12:13:**
  - P2 is on the RX 7600 now;
  - P1's seam is on the 5060 Ti between about 13:00 and 15:00, then the lead's merged-tree seam, about 15 minutes;
  - the pin stays at eae74e3e until round 5 closes.

## 2026-11-18 12:15 - cft-fp256: neither GPU needed today; their main is 340cd287, README-only past 9e8ff270

- **READ, cft-fp256's reply at about 12:14:**
  - They need neither GPU today, so P1's and P2's runs are ours.
  - Their main moved from 9e8ff270 to 340cd287 at 11:38, adding only bindings/wasm/README.md.
- **MEASURED by the lead, in ../cft-fp256 (read-only):**
  - HEAD is 340cd287.
  - `9e8ff270..340cd287` is two commits: 55ce549c at 11:24 and 340cd287 at 11:36.
  - `git diff --stat 9e8ff270 340cd287` shows bindings/wasm/README.md only, +73.
  - eae74e3e is an ancestor of 340cd287.
- **For the pin move after round 5:** either SHA carries the same host/ and GPU seam. The move is still on Logan's word.

## 2026-11-18 12:19 - P3 landed: main fast-forwarded 5b1cac6..4a8fe99 and pushed, on the merged tree's full make check, read leg by leg

- **MEASURED, the suite** (scratchpad/gpu/int-check-4a8fe99.log, 09:41:33 to 12:16:29, 2 h 35 min on a shared desktop):
  - clean rc=0, build rc=0, rc=0, and the end line is present.
  - 25 legs (`--leg` lines), in P0's order; 17 RESULT lines, all PASS; no line opens with FAIL.
- **MEASURED, against P0's suite on d7b5047** (scratchpad/gpu/r5-check-d7b5047.log), with the lead's legcmp.py and normlog.py in scratchpad/gpu/tools/:
  - Every leg's counts are equal: ok, FAIL, RESULT and Error! lines, and compiler warnings (5 against 5 in the build).
  - The one exception is check_compare_run, 67 ok to 108 ok with RESULT: PASS. That is P3's change, and the 108 is V3's and P3's full count.
  - With times, SHAs and dates masked and check_compare_run left out, the logs differ in three ways only:
    - the script's header and `make clean` lines;
    - the temp directories' random names;
    - P0's log built libcft.a, while this run found it built.
  - The libcft.a in cft-rebound-r5 is P0's 11-16 06:09 build, with build id "commit=eae74e3e... tracked=clean untracked=none". The submodule is at eae74e3e, clean, and check-pins passed.
- **MEASURED, the gate-cache keys:** they differ only by 66 `programs/out/*.cftp` inputs, on the 10 legs whose inputs name PROGRAMS.
  - This run built `all programs` in a make of its own before `check`, so the PROGRAMS wildcard saw them at parse time. P0's single `make check` parsed before they existed.
  - This is the lead's queued item (Makefile:629). make check never skips, so no verdict depends on the key.
- **The merge bar:**
  - V3 READY;
  - the full make check passes, read from its log;
  - the seam: check_ring_seams 34 ok, as P0's;
  - no suite running on main;
  - one merge at a time.
- **MEASURED, the fast-forward and push:**
  - `git merge --ff-only round5-int` in the main checkout: 5b1cac6..4a8fe99, two files, +1247/-58.
  - `git push origin main`: 5b1cac6..4a8fe99. origin/main is 4a8fe99.
  - 4a8fe99's message ends with the Co-Authored-By trailer.
- **B0150 released** at 12:19:14.
- **Next merge:** P1, after its send-back 1 and V1's narrow look. round5-int is at main (4a8fe99) already.

## 2026-11-18 12:49 - P2 reported, done at 82b75b8; V2 dispatched to verify it

- **READ, P2's final report** (about 12:44, copied verbatim to reports/R5-P2-report-2.md; its drop P2.md is placed, 12:44):
  - Tip 82b75b8, one commit on 81af26a. Gate 4's draws are now in g++'s order, written out, with an operand digest printed and checked GPU against host.
  - On the RX 7600 at 82b75b8:
    - check_wave --device gpu: full 78 ok, quick 66 ok;
    - gate 4: 1,064,352 cases, 0 mismatches, the digest equal to the host build's;
    - the seam: 7 of 7 plants;
    - port on CPU = port on GPU = kernel.
  - The 5060 Ti's figures are from 81af26a (11-16).
  - Rates come one run a row, on two named clocks. On the RX 7600, GPU-E2's rung (527 waves, 362 steps) took 3.35 s on the kernel clock and 3.41 s on the wall clock.
  - All bookings are released, nothing is running, and the worktree is clean.
  - **Owned by P2:** a read-only cuobjdump in cft-gpu at 06:56, inside V1's booking, which TimeSheet's check --short did not show.
  - **Not done:** a file-to-file comparison of the two GPUs' 4,096-wave 10-orbit records.
  - **Corrections it found:**
    - the brief's literal contraction control cannot fail as worded, though the unchecked variant does fail;
    - GPU-E2 priced software binary64.
- **MEASURED by the lead, P2's full make check** (scratchpad/p2r5/full3.log, started 05:59:39 at 82b75b8, ended 09:27:33, rc=0):
  - The lead's legcmp.py shows its 25 legs equal to P0's on d7b5047 leg by leg.
  - check_wave is the 26th leg: 57 ok, 0 FAIL, RESULT: PASS. Its inputs include wave_host, wave_host_unchecked, wave_host_contract, wave_corpus and ias15_cft.
  - The run was not a clean build, so it printed no compiler warnings. The merge's make check is clean.
- **V2 was dispatched at about 12:49** as an isolated-worktree agent. Its brief is gpu/briefs/filled/R5-V2.md, about 1,800 words. It:
  - looks for physics counters beside the bit-identity;
  - maps each plant to its member, line and column, and runs the mutants that skip a member or a column (V1's shape in P1's seam);
  - asks why the contraction control cannot fail, with fma counts in the binaries;
  - plants a wrong operation for gate 4, and checks the digest on both GPUs;
  - looks for barriers, races and reduction order in the kernel;
  - re-runs the final commit on each GPU;
  - compares the two GPUs' 4,096-wave records file to file;
  - compares make -n and the cache keys;
  - pre-checks the merge seams: P2×P3 with 4a8fe99's compare_run --producer-files on wave_host's attempts dir, and P1×P2 in check-gpu's recipe;
  - spot-checks one rate row.
  - **Windows:** the RX 7600 first. The 5060 Ti only when the TimeSheet shows no booking on it, since P1's seam comes first and WSL takes one agent at a time.

## 2026-11-18 13:04 - P1's send-back 1 is done at 6a5e448; V1 resumed for a narrow third look

- **READ, P1's report** (about 13:04, copied verbatim to reports/R5-P1-report-2.md; P1.md is placed, with its 13:03 entry):
  - a068acc plants both waves:
    - REBOUND form: five columns on each wave's first and last sampled lines. Wave 0 is lines 140 and 142, wave 1 lines 141 and 143.
    - FMA form: x of body 1, in each wave.
    - Each plant FAILs its own member by line and column, and the other member and its particles stay IDENTICAL.
  - 6a5e448 names TIMING's 13 keys, and adds control a3 (`t_new=1`).
  - **On the 5060 Ti** (B0158 and B0159, released 13:01; the desktop's B0160 at 13:02):

    | Run | ok | FAIL | Result |
    |---|---|---|---|
    | clean tree | 26 | 0 | PASS, 7m24s |
    | member-1 mutant | 11 | 6 | FAIL, rc 1: wave 1's five plants and its FMA plant |
    | member-0 mutant | 11 | 6 | FAIL, rc 1: likewise in wave 0 |
    | P3's merged compare_run (round5-int) in the tree's place | 17 | 0 | PASS |

  - The mutation script refuses when its edit lands 0 times.
- **MEASURED by the lead:**
  - `git log ab75fbe..6a5e448` is two commits.
  - `git diff --stat ab75fbe 6a5e448` shows tools/check_gpu.py only, +91/-46.
  - TIMING_KEYS is at :178, and TIMING is built from it at :180.
  - The worktree is clean.
- **V1 was resumed at about 13:04** for a narrow third look, under 600 words. It covers:
  - the two waves' plants and their verdicts;
  - the mutants, re-run on the desktop harness, with a GPU run optional;
  - TIMING_KEYS against src/ias15_cft.c's trailer, and control a3;
  - that nothing else moved;
  - P1.md's corrections.
- **TimeSheet at 13:04:** V2 holds the RX 7600 and nvidia-box until 15:45 (B0161, B0162) and the desktop, shared, until 16:30 (B0163). The 5060 Ti and WSL are free.
- **On V1's READY,** P1 merges:
  - on round5-int (at main 4a8fe99), `git merge --no-ff 6a5e448`;
  - the GPU seam live on the merged commit on the 5060 Ti, by the lead, booked;
  - then the full make check from clean;
  - then fast-forward and push.

## 2026-11-18 13:27 - V1: NOT READY on 6a5e448, on the planted member's particles alone; P1 send-back 2

- **READ, V1's third look** (about 13:26, copied verbatim to reports/R5-V1-report-3.md; no GPU used; its desktop booking B0164 is released):
  - **The defect:** no plant's verdict asks anything of the planted member's own particles.
    - A compare_run copy whose particle_compare() returns IDENTICAL without comparing scores 16 ok, 0 FAIL on P1's desktop harness, the same as the tree.
    - On the wave-1 plant of x of body 1, the tree's particles read "1 FAIL, 1 FAIL" and the mutant's "1 IDENTICAL, 1 IDENTICAL".
    - The seam's "particles ... all IDENTICAL" therefore cannot fail.
  - **Confirmed:**
    - both waves are planted, with each plant FAILing its own member by line and column;
    - the mutation script lands once, and refuses at 0 or 2 landings;
    - the member mutants give 10 ok and 6 FAIL on the harness, and P1's four 5060 Ti logs agree;
    - TIMING_KEYS is exactly the trailer's 13 timings (src/ias15_cft.c:4773, :3281-3295 and :4782). No counter is named, and a name must be followed by "=". a3 catches t_new=1 and x_new=1 at line 11, field 13.
    - Nothing else moved: the seven hunks are comments, TIMING, a3, and seam_form's plants.
    - P1.md's corrections read right, including +1.86%.
  - **Aside:** hw/gpu/where.py's records_same() still sets aside `t_[a-z_]+`. It is a measurement tool, not the witness.
- **P1's send-back 2, sent at about 13:27** (P1 resumed). In seam_form() only, on 6a5e448:
  - the planted member's sampled particles must FAIL where the plant is in a column their replays hold (a sampled body's column, or t, dt_next and t_lo), and stay IDENTICAL on an unsampled body (vz of body 63);
  - the sampled bodies are derived from compare_run's own lines;
  - V1's particle mutant must FAIL the seam by name, the member mutants must still FAIL, and the tree must pass;
  - all on P1's desktop harness, then again with P3's compare_run in the tree's place.
  - No GPU is required: the lead runs the clean seam live on the merged commit.
- **Then** V1 takes a narrow fourth look, and the merge follows. The merge message (gpu/merge-p1-msg.txt) has V1's verdict marked PENDING. The WSL scripts (gpu/lead-wsl/setup.sh and seam.sh) are ready.

## 2026-11-18 14:03 - P1's send-back 2 is done at fc4ba21; V1 resumed for a narrow fourth look

- **READ, P1's report** (about 14:02, copied verbatim to reports/R5-P1-report-3.md; P1.md is placed, with its 14:03 entry):
  - Each plant's verdict now also holds the planted wave's sampled particles:
    - they FAIL where their replay carries the column: the schedule (t, dt_next, dt_last, E, t_hi, t_lo), the wave's 7 massive bodies, and the particle's own body;
    - they stay IDENTICAL on vz of body 63.
  - The sampled bodies (22 and 30 in wave 0, 57 and 31 in wave 1) and the massive count are read from compare_run's own lines.
  - **On the desktop harness** (software record, no GPU), the same with the tree's compare_run and with P3's:

    | Run | ok | FAIL |
    |---|---|---|
    | clean | 16 | 0 |
    | each member mutant | 10 | 6 |
    | V1's particle mutant | 6 | 10 |

  - The mutation script now also makes the particle edit, lands each edit once, and refuses otherwise.
  - Bookings B0167 and B0168 (desktop) are released. No GPU was used.
- **MEASURED by the lead:**
  - `git log 6a5e448..fc4ba21` is one commit.
  - `git diff --stat` shows tools/check_gpu.py only, +68/-23, in three hunks: section 3's comment and two in seam_form().
  - The worktree is clean.
- **V1 was resumed at about 14:03** for a narrow fourth look, under 400 words, with no GPU. It checks:
  - the rule, and that its derivation comes from compare_run's lines;
  - the three mutants on both compare_runs;
  - the script's particle edit;
  - that nothing else moved.
- **TimeSheet at 14:03:** V2's RX 7600 and nvidia-box bookings (B0161, B0162) are already released. Its desktop booking B0163 runs to 16:30. The 5060 Ti and WSL are free.

## 2026-11-18 14:22 - V1: NOT READY on fc4ba21, on an unplanted class (a sampled particle's own body); P1 send-back 3

- **READ, V1's fourth look** (about 14:22, copied verbatim to reports/R5-V1-report-4.md; desktop only, B0169 released; no GPU):
  - **Confirmed:**
    - the sampled bodies (22 and 30 in wave 0, 57 and 31 in wave 1) and the massive count are derived from compare_run's own lines;
    - every plant made is classed right;
    - the three mutants give the same FAIL sets on both compare_runs, plant for plant;
    - the particle edit's anchor lands once (tree :814, P3's :971) and refuses at 0 or 2 landings;
    - nothing else moved.
  - **The defect:** the rule names a particle's own body, but no plant lands on one.
    - A compare_run copy with `enumerate(bodies[:-1])` in particle_compare(), skipping the particle's own body, passes the seam at 16 ok, 0 FAIL.
    - It is real: with vz of body 22 planted on line 142, the tree FAILs body 22 and the copy calls it IDENTICAL, comparing 144 values to the tree's 162.
- **P1's send-back 3, sent at about 14:22** (P1 resumed). In seam_form() only, on fc4ba21:
  - one plant per wave on a sampled particle's own body: that member and that particle FAIL by line and column, the wave's other particle and the other wave stay IDENTICAL;
  - every class the rule names gets a plant in each wave: schedule, massive body, own body;
  - P1 is to check for any other unplanted class before reporting;
  - V1's own-body mutant must FAIL, the other three mutants must still FAIL, and the tree must pass, on both compare_runs;
  - no GPU.
- **Note on convergence:** each look has found the next class the plants miss (a wave, the planted member's particles, a particle's own body). After this one, every class the rule names will have a plant. The columns no plant covers (t_hi, dt_last, E, y, z, vx, vy, other bodies) are by design, and V1 accepted that at its third look.

## 2026-11-18 14:32 - V2: NOT READY on P2's 82b75b8, on check_wave's planted controls (the kernel holds); P2 send-back 1

- **READ, V2's first look** (about 14:30, copied verbatim to reports/R5-V2-report-1.md; entries in V2.md at 13:08, 13:26, 13:37 and 14:28). Its bookings were B0161 and B0162 (RX 7600 and nvidia-box, 12:57-13:25), B0165 and B0166 (5060 Ti and WSL, 13:07-13:16) and B0163 (desktop). All are released. It made one 20-second unbooked run on the RX 7600 at 13:31, after `check --short` showed it free.
  - **Confirmed:**
    - **Validity:** physics counters are printed and asserted, with B rejecting every wave's first attempt, C rejecting after accepted steps, D1 hitting the cap, and the circularity, angle and energy bounds met. All 64 bodies are compared. The step mutants fail: J2/J4 off, frozen particles, the dropped J2 reaction.
    - **Contraction:** the flags reach every compiler, and the contraction-on build of the checked source is identical assembly on hipcc and nvcc. A control that can fail exists: one product-sum fused by hand fails compare_run.
    - **Gate 4:** it names every planted wrong operation. The digest is 3cd1af43b434860c on the desktop and on both GPUs' builds.
    - **Determinism:** barriers after every phase, serial folds, no wave intrinsics, and repeated runs identical, wave64 among them.
    - **The final commit:** the RX 7600 full run 78 ok; the 5060 Ti --quick 66 ok.
    - **Across GPUs:** P2's two 4,096-wave records differ in 0 of 278,535 lines.
    - **Makefile:** `make -n -B` of all and programs is unchanged, each tier adds only the wave-host builds and check_wave's leg, and every artifact is an --input.
    - **Seams:**
      - P2×P3: 4a8fe99's --producer-files holds wave_host's files, with keys equal to the port's --run-key and one ulp planted named.
      - P1×P2: no conflict, but the check_wave line must be added to check-gpu by hand.
    - **Rates:** within 1% on 527 × 24.
  - **The defect:** every plant is in case E, wave 1 run alone (one system), on sample lines 1-2 and two to four columns.
    - compare_run copies that never compare an ensemble's member 0, 1 or 2, lines past the third, particles, ten of the columns, the trailer counters or the step field all pass check_wave (49 ok --quick, 57 full). So do check_wave copies without their physics decision, attempts comparison or particle parse.
    - A kernel wrong only in workgroup 1, or after sample 2, would pass beside such a copy.
    - No assert that particles were replayed (0 of 0 passes). The physics control computes its own `caught`.
    - Mitigation, measured: check_compare_run --quick fails the never-member-1 copy (42 ok, 3 FAIL), in every tier and in check-gpu.
  - **Also:**
    - the identity line is a literal (wave_main.cpp:502), so the control records claim contract=off and flags=checked;
    - check_wave's GPU probe runs two kepler steps on hip:0 before it knows the device, which could be the 4070 in a cft-gpu shell without CUDA_VISIBLE_DEVICES;
    - E labels member 1's counters "member 0";
    - the test–test limit (two coincident test particles stop the port with DIVBYZERO but not the kernel) is stated only in wave_step.h.
- **P2's send-back 1, sent at about 14:32** (P2 resumed):
  - plants in an ensemble record, in both device forms: member 0 and a later member, early and last lines, every column kind, each FAILing its own member and its carrying particles, with the other members IDENTICAL;
  - assert particles were replayed;
  - the physics control reads physics_verdict;
  - every V2 mutant FAILs in full and in --quick, each landing once;
  - the identity line written from the build;
  - the probe refuses an unexpected device before it runs anything;
  - E's label fixed;
  - the records corrected in P2.md;
  - desktop runs, then one --quick on the RX 7600, booked; not the 5060 Ti; no full make check.
- **Then** V2 takes a narrow second look. P2 merges after P1.

## 2026-11-18 14:55 - P1's send-back 3 is done at 0f324bd; V1 resumed for a narrow fifth look

- **READ, P1's report** (about 14:55, copied verbatim to reports/R5-P1-report-4.md; P1.md has an entry headed 14:56):
  - **New plant:** in each wave, vy of the first sampled particle (body 22 on line 140, body 57 on line 141).
  - **A class per plant,** derived from compare_run's lines: schedule, massive body, own body, a body no replay carries. They require all, all, exactly one and none of the wave's particles to FAIL.
  - **A coverage verdict** that every class has a plant in each wave.
  - **A class added unasked:** the trailer's counters (mean_pc_iterations, trailer lines 144 and 145).
  - **The FMA form** now plants every class in each wave.
  - **On the desktop harness,** with both compare_runs:

    | Run | ok | FAIL |
    |---|---|---|
    | tree | 28 | 0 |
    | each member mutant | 17 | 11 |
    | particle mutant | 8 | 20 |
    | own-body mutant | 24 | 4 |
    | member counters never compared | 24 | 4 |
    | particle counters never compared | 24 | 4 |

  - Each new edit refuses on its own output. No GPU. B0170 was released at 14:54:09.
  - **Still unplanted inside classes, by design:** dt_last, E and t_hi; the other trailer counters; the other values of the bodies.
  - The live seam now makes 24 compare_run runs instead of 14, so it will take longer.
- **MEASURED by the lead:**
  - `git log fc4ba21..0f324bd` is one commit.
  - `git diff --stat` shows tools/check_gpu.py only, +116/-56, in hunks at section 3, seam() and seam_form().
  - The worktree is clean.
- **V1 was resumed at about 14:55** for a fifth look, under 400 words, with no GPU. It checks:
  - the classes, their derivation and the coverage verdict;
  - the four mutants on both compare_runs;
  - that nothing else moved.

## 2026-11-18 15:46 - V1: READY on P1 at 0f324bd; P1 merged on round5-int (fda3b40); the GPU seam runs live on the 5060 Ti

- **READ, V1's fifth look** (about 15:44, copied verbatim to reports/R5-V1-report-5.md; desktop only, B0173 released; no GPU):
  - **READY.**
  - The classes are derived from compare_run's own lines (sampled bodies 22 and 30, 57 and 31; massive count 7). kind() sorts each plant, and each class fixes the FAIL count.
  - The coverage verdict cannot pass with a class missing.
  - No class a replay or the member comparison carries is left unplanted.
  - V1's own four mutants FAIL with identical sets on both compare_runs:

    | mutant | ok | FAIL |
    |---|---|---|
    | particle | 8 | 20 |
    | own-body | 24 | 4 |
    | member counters | 24 | 4 |
    | particle counters | 24 | 4 |

  - Nothing else moved.
- **MEASURED by the lead, the merge:**
  - In cft-rebound-r5, round5-int was at 4a8fe99 (= main = origin/main), clean, with no make running.
  - `git merge --no-ff 0f324bd -F gpu/merge-p1-msg.txt` gave fda3b40, with no conflict.
  - `git diff --stat 4a8fe99 fda3b40` shows P1's five files, +2131: the Makefile, hw/gpu/{costs.py, program_caps.c, where.py} and tools/check_gpu.py.
  - `git diff 0f324bd fda3b40` shows P3's two tools only.
  - The message ends with the Co-Authored-By trailer.
- **MEASURED, the GPU seam's launch:**
  - Bundle gpu/lead-wsl/cft-rebound-lead.bundle (round5-int at fda3b40, verified).
  - B0177 (rtx5060ti) and B0178 (wsl-cft-gpu), exclusive, 15:45 to 17:00, with wsl.exe's Windows pid 5536 attached.
  - gpu/lead-wsl/launch.sh started at 15:45:42 and runs in /root/cft-rebound-r5-lead:
    - setup.sh: clone fda3b40, the pins from V1's bundles, mpmath 1.3.0, `make clean` then `make HIP=1 ... all programs`, the probe;
    - seam.sh: `check_gpu.py --artifact hip:0 --hip 1 --expect "RTX 5060 Ti" --no-legs --keep --parts controls,seam` with CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1.
  - It logs to gpu/lead-wsl/run-fda3b40.log.
- **Next:**
  - On the seam's PASS, read line by line, the full make check on fda3b40 (gpu/int-check-r5-p1.sh, logging int-check-fda3b40.log), booked on the desktop, shared.
  - Then main fast-forwards 4a8fe99..fda3b40 and is pushed.

## 2026-11-18 16:23 - The GPU seam on fda3b40: PASS, 38 ok, live on the 5060 Ti; the merged tree's full make check launched

- **MEASURED, the build in WSL cft-gpu** (gpu/lead-wsl/run-fda3b40.log; /root/cft-rebound-r5-lead):
  - setup rc 0: fda3b40 checked out, check-pins ok, mpmath 1.3.0;
  - `make HIP=1 ... all programs`: rc 0 in 91 s, 15 warnings;
  - libcudart linked;
  - the probe: "cft hip: hip:0 = NVIDIA GeForce RTX 5060 Ti (sm_120, 36 multiprocessors, bus 0000:05:00.0 ...); of 1 visible, CUDA_VISIBLE_DEVICES=1", backend hip, seq_features 0x75f1f.
  - The run log's first two lines (start time and wsl pid) were overwritten by wsl.exe's output, which does not append. The start was 15:45:42 and the pid 5536, both as read at launch.
- **MEASURED, the seam** (copied to gpu/lead-wsl/seam-fda3b40-1118-1547/seam.log, every verdict line read): 15:47:31 to 16:19:49, `check_gpu: 38 ok, 0 FAIL, in 32m16s on hip:0`, RESULT: PASS.
  - **The probe:** routes published are reduce_seg and scalar; indexed and pair_gather are not.
  - **The controls:** the clean run, a, a2, a3 (t_new=1 caught at line 11, field 13), b, c, d, e and f all caught by name. Control g was not run (no strace).
  - **REBOUND form:**
    - both waves rejected [1, 1];
    - compare_run (P3's, in the merged tree) gives member 0 and member 1 IDENTICAL, and 4 particles (0:22, 0:30, 1:57, 1:31) all IDENTICAL;
    - 14 plants, 7 a wave on lines 140/142 and 141/143 and trailers 144/145: massive body x of body 1, schedule dt_next, t_lo and t, own body vy of 22 and 57, the uncarried vz of 63, and trailer mean_pc_iterations;
    - each FAILs its wave by line and column, with the expected particle count (2, 2, 1 or 0);
    - the coverage verdict passes.
  - **FMA form:** both members and all 4 particles IDENTICAL, 8 plants (4 classes × 2 waves), and the coverage verdict passes.
  - **The P1×P3 seam holds:** check_gpu's patterns read the merged compare_run's lines in both forms.
- **Bookings:** B0177 and B0178 were released at about 16:21, and wsl pid 5536 is gone.
- **MEASURED, the suite:**
  - Booked B0179, desktop shared, 16:21 to 20:00, with pid 42476 attached. The desktop is shared with P2's B0171 (to 21:00).
  - gpu/int-check-r5-p1.sh was launched from PowerShell at 16:22:04 (pid 42476).
  - The log, gpu/int-check-fda3b40.log, heads: round5-int fda3b40, 0 changed paths, cc x86_64-w64-mingw32, pins bdfda4b and eae74e3e, `rm -rf build`.
- **Next:**
  - When it ends, read every leg against 4a8fe99's suite (int-check-4a8fe99.log). P1's diff adds no leg to the tiers (check-gpu is in none), so all 25 legs are expected equal.
  - Then main fast-forwards 4a8fe99..fda3b40 and is pushed.

## 2026-11-18 17:36 - P2's send-back 1 is done at 8f559c8; V2's second look waits for the resume (Logan: wrap up for the day when things finish)

- **Logan, after 16:23 (the message came after the 16:23 entry):** "Go ahead and start to wrap up for the day when things finish." So:
  - P1's make check on fda3b40 (running) finishes, and lands if it passes;
  - P2 was told to stop at a clean point by 20:30;
  - no new verifier or merge starts today.
- **READ, P2's report** (about 17:36, copied verbatim to reports/R5-P2-report-3.md; P2.md is placed, with entries at 14:59 and 17:37):
  - **The plants:** 24 a run, in the 3-member ring record (A in --quick, P in full), on either device. They cover every column kind, members 0 to 2, and the first and last sampled lines.
    - Each FAILs its own member by line and column.
    - The particles FAIL where their replay carries the column and stay IDENTICAL where it does not, derived from compare_run's lines.
    - Unplanted members stay IDENTICAL.
  - **The particle count** is held to a plan from the problem file: 6.
  - **The physics control** reads physics_verdict().
  - **The attempts comparison** is one function, with a one-dt control.
  - **The identity line** comes from the build's defines, asserted for A and both control builds.
  - **The GPU probe** (--device-info) launches nothing and refuses an unexpected device first. With --expect "RTX 4070" it refuses in 0.12 s and leaves an empty work directory.
  - **E's label** is fixed, and the quick ring is now 3 waves.
  - **On the desktop:** --quick 74 ok, full 83 ok. All 27 of V2's mutants FAIL in both forms. The script refuses a 2-landing edit.
  - **RX 7600 at 8f559c8:** --quick PASS, 91 ok, 1,109 s.
  - **Bookings released:** B0171 (desktop, to 17:35), B0174 and B0175 (15:15-15:36).
  - **Records:** the test–test limit, and the unchecked control's different source, are in P2.md.
- **MEASURED by the lead:**
  - `git log 82b75b8..8f559c8` is one commit, and the worktree is clean.
  - `git diff --stat` shows the Makefile (+3/-3: -DWAVE_CONTRACT_ON beside the contraction flag in the three control builds), src/wave/wave_main.cpp (+31) and tools/check_wave.py (+404/-61).
- **On resume:**
  - V2 takes a narrow second look at 8f559c8. Its scope:
    - the plants and their classes;
    - the 27 mutants;
    - the identity defines in all three builds;
    - the probe's refusal;
    - the Makefile hunk;
    - the 5060 Ti's --quick at 8f559c8.
  - After V2's READY, P2 merges after P1. The work is the check-gpu recipe line added by hand, the P1×P2 and P2×P3 seams, and a full make check.

## 2026-11-18 19:52 - P1 landed: main fast-forwarded 4a8fe99..fda3b40 and pushed, on the merged tree's full make check, read leg by leg

- **MEASURED, the suite** (scratchpad/gpu/int-check-fda3b40.log, 16:22:07 to 19:48:06, 3 h 26 min on a shared desktop; P2's B0171 shared it until 17:35):
  - clean rc=0, build rc=0, rc=0, and the end line is present.
  - 25 legs (`--leg` lines), in 4a8fe99's order; 17 leg RESULT lines, all PASS (20 "RESULT: PASS" lines in all, as at 4a8fe99); no FAIL outside check_compare_run's headings that say a control must FAIL.
- **MEASURED, against 4a8fe99's suite** (int-check-4a8fe99.log), with legcmp.py and normlog.py:
  - Every leg's counts are equal: ok, FAIL, RESULT and Error! lines, and warnings; the build's compiler warnings 5 against 5. check_compare_run is 108 ok, as at 4a8fe99.
  - With times, SHAs and dates masked and no leg left out (2455 lines each), the logs differ in 16 lines a side: the header's commit title, and the random names of check_archive's and check_checkpoint's temp directories (cft_archive_*, cft_ckpt_*). normlog's path mask misses a path written with a backslash.
  - P1's diff (main..round5-int) adds and removes no line outside its own files: Makefile +27 (check-gpu), hw/gpu/costs.py, hw/gpu/program_caps.c, hw/gpu/where.py, tools/check_gpu.py; +2131/-0. check-gpu is in no tier, so 25 equal legs is the expected result.
- **The merge bar:**
  - V1 READY on 0f324bd (15:46);
  - the full make check passes, read from its log;
  - the seam: the GPU seam on fda3b40, 38 ok, 0 FAIL, live on the 5060 Ti (16:23); check_seams 102 ok and check_ring_seams 34 ok, as at 4a8fe99;
  - no suite running (pid 42476 gone);
  - one merge at a time.
- **MEASURED, the fast-forward and push:**
  - After a fetch, main = origin/main = 4a8fe99; round5-int = fda3b40, parents 4a8fe99 and 0f324bd. Both checkouts are clean (bash.exe.stackdump untracked in main, as before).
  - `git merge --ff-only round5-int` in the main checkout: 4a8fe99..fda3b40, 5 files, +2131.
  - `git push origin main`: 4a8fe99..fda3b40 at 19:49:29. origin/main is fda3b40.
  - fda3b40's message ends with the Co-Authored-By trailer.
- **B0179 released** at 19:49:34, its pid gone. TimeSheet holds no cft-REBOUND booking now.
- **The drop watcher was stopped** (bubr02nxf) after every drop file was confirmed placed: P1.md, P2.md, P3.md, V1.md and V2.md compare equal to .ledger's copies, and there is no urgent file.

## 2026-11-18 19:52 - Round 5 paused for the day at main fda3b40: P3 and P1 landed; P2 waits for V2's second look

- **Logan** (after 16:23): "Go ahead and start to wrap up for the day when things finish." Nothing new was started after that message. P1's suite finished and landed; P2 stopped at a clean point.
- **State at the pause:**
  - main = origin/main = fda3b40; round5-int = fda3b40 in cft-rebound-r5, clean.
  - P2 is at 8f559c8 (one commit on 82b75b8), its worktree clean, idle: not merged, not yet verified.
  - P1 (0f324bd, merged), P3 (merged), V1, V2 and V3 are idle; agent ids are in gpu/agents.txt.
  - No booking is held, no process of the round is running, and the drop watcher is stopped.
  - The pin is still eae74e3e. The candidate is cft-fp256 9e8ff270, or 340cd287, which is README-only past it. It moves only on Logan's word, after round 5 closes; the merge delegation does not cover it.
- **Scratch:** copied again to .ledger/scratch-r5/ (gpu/tools/durable_copy.py, log gpu/durable-copy-1118.log): no bundles, binaries, mutant trees or files over 20 MB.
- **Resume order:**
  1. V2's narrow second look at P2's 8f559c8, scoped in the 17:36 entry, with the 5060 Ti's --quick at 8f559c8. Message cft-fp256 before using a GPU; WSL is one agent at a time; never the RTX 4070.
  2. After V2's READY: P2 merges on round5-int (fda3b40), with check_wave added by hand as check-gpu's second recipe line. Then the P1×P2 seam (check-gpu with check_wave) and the P2×P3 seam (check_wave reads the merged compare_run), and a full make check; then ff and push.
  3. The lead's queued items: the records' corrections (the 2026-11-16 16:55 list and what was queued after it, and V1's and P1.md's), the PROGRAMS parse-time cache key (Makefile:629), and V3's drive() limit_absent.
  4. Round close.
  5. The pin move, on Logan's word only.

## 2026-11-19 04:55 - Round 5 resumes at Logan's word: V2's second look at P2's 8f559c8; today's windows

- **Logan, in chat, 2026-11-19, just before 04:53:** "All sessions are clear to begin working for the day". The pause of 11-18 19:52 ends.
  - main = origin/main = round5-int = fda3b40, unchanged overnight. P2's worktree is at 8f559c8 and clean.
  - TimeSheet at 04:53 shows no cft-REBOUND booking, only cft-debris's B0176 and cft-fp256's standing card windows.
  - The drop watcher was re-armed at 04:54:44.
- **Sent at about 04:55:** V2 (a4a56e7e3a0be871c), for its narrow second look at 8f559c8, items 1 to 8:
  - the plants and their classes;
  - its own mutants, landing exactly once, in --quick and full, plus whether the step and steps_done classes are still held;
  - the particle plan;
  - physics_verdict;
  - the identity line in all three builds;
  - the Makefile hunk;
  - the probe;
  - the 5060 Ti's --quick and its refusal with --expect "RX 7600", CUDA_VISIBLE_DEVICES=1 in every command and never the 4070.
- **Today's GPU windows, per cft-fp256's reply at about 04:55:**
  - It needs neither GPU nor WSL cft-gpu today, and holds no booking on rtx5060ti, rtx4070, rx7600, nvidia-box or wsl-cft-gpu.
  - Its work today is on amd-arc-box and the U50. Its desktop steps run under 10 min each and tolerate our load.
  - V2 from about 06:00, and the lead's P1×P2 seam in the afternoon, are fine by it. It will message us before any GPU need of its own.
  - V2 was told the window is agreed: book rtx5060ti and wsl-cft-gpu exclusive first.
- **The merge, after V2's READY:**
  - P2 merges --no-ff on round5-int (fda3b40), with check_wave added by hand as check-gpu's second recipe line;
  - the P1×P2 seam: check-gpu with check_wave, on the 5060 Ti;
  - the P2×P3 seam: check_wave reads the merged compare_run;
  - a full make check;
  - ff and push.
For: V2, anyone

## 2026-11-19 05:12 - PL dispatched: the lead's two queued code fixes, from fda3b40, beside V2's look

- **PL** (branch round5-pl, its own worktree, from main fda3b40):
  - **Fix 1, the PROGRAMS key** (Makefile:633, the 11-16 09:50 entry). PROGRAMS comes from the tracked programs/*.cfta, so the 10 program legs' gate-cache keys list the 66 programs/out files whether or not programs/out exists at parse time. Evidence: `make -n` of the three tiers in a fresh copy against a built tree, and the old line against the new.
  - **Fix 2, limit_absent** (tools/check_compare_run.py; V3's open point, the 11-18 09:42 entry). It sees an indented copy, and it is asserted on every compare_run run without --producer-files (drive() and the direct calls). Evidence: compare_run copies that print the limit indented on the default path, only on --rerun-engine without files, only under --plan, or only on case 4's records run. Each must FAIL --quick and full, and PASS the unfixed tool.
  - It gets no full make check, no GPU and no records.
- **Why now:** neither fix touches P2's files (check-gpu's recipe and the wave targets), so PL runs beside V2's look. Its merge comes after P2's landing, one merge at a time, with its own verifier (VL) and a full make check.
- **Prepared for P2's merge** (scratchpad/gpu/):
  - merge-p2-msg.txt, with V2's verdict and the seams PENDING;
  - lead-wsl/setup-p2.sh (builds `all programs wave` with HIP=1), gpu-p2.sh, run-p2.sh and launch-p2.sh;
  - lead-wsl/p1p2_seam.py, ROUND5.md's P1 x P2 seam: one ring wave at fp64 in the FMA form, three ways (the port on the CPU, the port on hip:0 through libcft, and the kernel), the same bits beside the physics counters. It runs 11 planted controls, then compare_run on two of the records, then the P2 x P3 seam with a one-ulp plant in a not-rerun member's attempts record.
- **MEASURED, the seam's desktop dry run** (gpu/p1p2/dry2.log): the port twice on software, with P2's host twin as the kernel. 22 ok, 0 FAIL in 1 min 43 s; all 11 plants FAIL by name with exactly one difference. The P2 x P3 part replays 6 particles from the twin's own files, members 0 and 1 not rerun, all IDENTICAL; the attempts plant FAILs member 0's two particles and leaves the other four IDENTICAL.
- **READ, P2's kernel opens device 0** (src/wave/wave_gpu.inc:95, hipSetDevice(0)). So check-gpu's second line runs on the first visible GPU, whatever GPU_ARTIFACT names. This goes in the recipe's comment.
For: V2, PL, anyone

## 2026-11-19 08:18 - PL reported at 5fa7534; sent back narrowly for check_ensemble's key

- **PL's report** (copied verbatim to scratchpad/gpu/reports/R5-PL-report-1.md): round5-pl = fda3b40 + 3012353 (the PROGRAMS key) + 5fa7534 (limit_absent), 2 files, +108/-29.
  - Fix 1: PROGRAMS from programs/*.cfta, united with whatever programs/out holds (beyond the brief: check_gravity holds every gravity image it finds there). MEASURED by make -n: in a fresh tree the 10 legs gain the 66 images in all three tiers; in a built tree all 25 legs' input sets are unchanged.
  - Fix 2: limit_lines() finds the line however indented, in limit_absent and limit_once; drive() records every run without --producer-files and one closing verdict holds them all. Case 6 runs in every tier (4 steps in --quick). MEASURED: clean --quick 73 ok, full 109 ok; M1-M5 each FAIL both tiers by name, and fda3b40's gate passes each where it is the gap.
  - B0187 released at 08:13. Not run on a GPU: check-gpu's check_compare_run leg now runs case 6 on the device.
- **READ by the lead, confirming PL's find:** check_ensemble's three Makefile lines (~741, ~776, ~814) list $(IN_PROGRAM) $(IN_PROB) and no $(IN_PROGS), while tools/check_ensemble.py:101,150 runs three program-engine cases with --programs programs/out. This is the same defect as fix 1: an executed artifact outside the key, so check-quick and check-light can hold a stale pass.
- **Sent back** (PL send-back 1): add $(IN_PROGS) to the three lines, as a third commit; make -n evidence; a cache-level control (one byte of one loaded image: 5fa7534's Makefile skips by name, the fix runs; image restored and checked by hash). Desktop only, light beside V2's B0190.
- **Records notes, not fixed:** control i ignores --driver; runs refused after reading a producer's files are never checked for the limit line; per-run checks see the last 600 characters of stderr; a program new in gen_programs.py is keyed from the next make on.
- **The lead's, at PL's merge:** `make HIP=1 check-gpu GPU_LEGS=check_compare_run` on the 5060 Ti, on the merged tree.
- **Order:** P2 first (after V2's READY), then VL on round5-pl's three commits, then PL's merge with its own make check.
For: PL, VL, anyone

## 2026-11-19 08:30 - PL's send-back 1 landed at cc3d87a; send-back 2: every leg's key audited, not one leg at a time

- **cc3d87a** (R5-PL-report-2.md): $(IN_PROGS) on check_ensemble's three lines, nothing else (READ: the diff is 3 lines in, 3 out).
- **MEASURED by PL, the cache control.** One byte of programs/out/predict-ens-fp64.cftp, an image check_ensemble's adaptive program-engine cases load at run time (src/ias15_cft.c:1966, :4676; a run without it exits rc 3):
  - 5fa7534's check-quick line SKIPPED it ("inputs unchanged since it passed"), a stale pass;
  - the fix's line ran and FAILed the two cases, and the stamp was retired.
  - After the restore, all 66 hashes equal the baseline and `make programs`' output.
- **PL's new finds, confirmed by READ:**
  - check_records.py:23, check_bodycount.py:41 and check_ensemble.py:24 import check_equivalence;
  - check_bodycount.py:66 runs make_nbody.py, and check_ensemble.py:118-125 run make_ensemble.py;
  - none of those files is in those legs' keys (Makefile 740/775/813, 745/780/818 and check_ensemble's lines).
  - So a change to check_equivalence.py that breaks those legs is held green by a check-quick or check-light skip.
- **Sent back (send-back 2):**
  - a static audit in scratch, not committed: per leg and tier, follow local imports by ast and collect the files the leg runs, imports, compiles or reads by path; compare with its --input set; READ each candidate;
  - add each missing input, as a fourth commit;
  - evidence: make -n before and after, and one cache control per kind of input added (check_equivalence.py with check_records, make_nbody.py with check_bodycount), each file restored and checked by hash;
  - **stop rule:** more than 15 gaps, or any fix that is not obvious, comes back to the lead uncommitted.
- **VL waits for the fourth commit;** its brief is drafted at scratchpad/gpu/briefs/filled/R5-VL.md.
For: PL, VL, anyone

## 2026-11-19 09:01 - V2: NOT READY on P2's 8f559c8, P2 sent back (plant coverage); PL's key audit landed at e8a7d89, VL dispatched

- **V2's second look** (R5-V2-report-2.md, verbatim): NOT READY on 8f559c8, for two gaps in check_wave's plants. Everything else in scope holds:
  - the particle plan; physics_verdict on both criteria; the identity line in all three builds, on both hosts; the Makefile; the probe;
  - the 5060 Ti: check_wave --device gpu --quick --expect "RTX 5060 Ti" PASS, 91 ok, 2,099 s, and refused with --expect "RX 7600" in 12.1 s with an empty work directory;
  - every mutant on the lead's list fails both forms.

  V2 released B0188 (rtx5060ti) and B0189 (wsl-cft-gpu) at 06:35 and B0190 (desktop) at 08:56.
  - **Gap A:** the step field is planted once, in member 0's last line. A compare_run copy that checks the step only in member 0, or never on sample 1, passes check_wave --quick at 74 ok (MEASURED).
  - **Gap B:** the plan is 24 hand-written tuples dealt to members in list order (READ, check_wave.py:468-505). A check_wave copy that never plants member 2 passes (66 ok), and one that skips the counters passes (69 ok) (MEASURED).
  - **Noted, no change asked:** the step and steps_done comparisons are reachable by no plant; compare_run's completeness check holds both first (MEASURED).
- **P2 sent back (send-back 2),** tools/check_wave.py only:
  - the classes derived from the record's columns and trailer;
  - every class in every member, first and last lines, and every column at least once;
  - a closing coverage verdict computed from the plants made;
  - V2's four passing mutants must FAIL both forms;
  - desktop only. The 5060 Ti run is the lead's, at the merge, as check-gpu's second line. V2 takes a narrow third look after.
- **PL's send-back 2 landed at e8a7d89** (R5-PL-report-3.md). Its static audit of 25 legs in three tiers found 6 missing inputs in 3 legs, now added per leg:
  - check_records: tools/check_equivalence.py;
  - check_ensemble: check_equivalence.py and make_ensemble.py;
  - check_bodycount: check_equivalence.py, make_nbody.py and src/ias15_limits.h.

  MEASURED: each kind of input (an import, a run script, a file read) is skipped by cc3d87a's check-quick line after a one-byte comment change, and run by the fix's. The files were restored and checked by hash. READ by the lead: the diff is 9 lines, those --input additions only.
  - PL's open finds: check_bodycount and check_gravity reuse the nbody<N>.txt problems they wrote earlier in build/, so a changed make_nbody.py reruns the leg on old problems. The constants leg reads third_party/rebound's integrator_ias15.c outside its key.
- **VL dispatched at about 09:01** on round5-pl e8a7d89, in its own worktree. Its brief is scratchpad/gpu/briefs/filled/R5-VL.md: the four commits, its own extraction and audit, the realistic stale skips, mutants (a)-(f), check-quick cold, warm and after an image change, and check-gpu by reading. Desktop only.
- **Merge order:** whichever of P2 (after V2's third look) and round5-pl (after VL) is READY first merges first. One at a time, each with its own full make check; never while a suite runs.
For: P2, V2, VL, anyone

## 2026-11-19 09:05 - D dispatched for the records' phase 1; PL's merge kit prepared

- **D (records), phase 1,** branch round5-docs from fda3b40, in its own worktree. Brief: scratchpad/gpu/briefs/filled/R5-D.md.
  - VALIDATION entries in parcel order, as round 4's: 55 P1 and 57 P3 now; 56 P2 and 58 the lead's integration as LEAD-FILL lines.
  - The corrections queued at 16:55, 17:05 and 17:40 on 11-16, and from V1's reports, each cited in the file it corrects.
  - docs/RING.md (P3's producer files, P1's check-gpu); README (check-gpu, P3's options); the provenance row kept as it is.
  - Phase 2 (P2, the integration, CLAUDE.md, ROADMAP, ROUND5.md's status and findings) comes by message after the merges. VD verifies the whole.
- **PL's merge kit** (scratchpad/gpu/):
  - merge-pl-msg.txt, with VL PENDING;
  - int-check-r5-pl.sh;
  - lead-wsl/{setup-pl,gpu-pl,run-pl,launch-pl,launch-pl-now}.sh. The GPU check is check_gpu.py --legs check_compare_run on hip:0 (5060 Ti), run directly, not through make, so check-gpu's check_wave line is not rerun if P2 has merged first.
For: anyone

## 2026-11-19 09:34 - D's phase 1 at 4980440 (round5-docs); VD dispatched on it

- **D's phase 1** (R5-D-report-1.md, verbatim): 4980440 on fda3b40, documents only (README.md, ROUND5.md, docs/RING.md, docs/VALIDATION.md; +1009/-39).
  - Entries 55 (P1) and 57 (P3) are written; 56 and 58 are LEAD-FILL lines. Entry 54's CPU-to-wall sentence is corrected.
  - ROUND5.md's queued corrections are made in place.
  - Five LEAD-FILL lines: ROUND5.md:9 and :405, RING.md:310, VALIDATION.md:7657 and :7920.
  - D counted the suites from the logs: fda3b40 3 h 26 min, 25 legs, 1,504 "  ok "; 4a8fe99 2 h 35 min. The brief named the wrong P0 log, and D used r5-check-d7b5047.log.
- **The lead's rulings on D's eleven items:**
  - 1-3, 6, 8, 10 and 11 stand.
  - 4: both 5060 Ti figures go in at phase 2, P1's 62 min and V1's 66 min.
  - 5: P1's cost table stays, MEASURED, with its host.
  - 7: hw/gpu/costs.py's stale 1.5-2.0 comment is code; it becomes an open note in phase 2.
  - 9: phase 2.
- **VD dispatched** on 4980440 (brief scratchpad/gpu/briefs/filled/R5-VD.md): numbers against sources, labels, the corrections, README against argparse and the Makefile, the provenance row byte for byte, the LEAD-FILL lines, consistency, and D's items. Read only, no suite.
For: D, VD, anyone

## 2026-11-19 10:07 - VD: NOT READY on the records' phase 1 (text only); D sent back. cft-fp256: GPU round 3 approved, main c3c39c87

- **VD on 4980440** (R5-VD-report-1.md, verbatim): every number checked matches its source. VD recounted both merge suites from their logs and checked more than 40 groups across entries 55 and 57.
  - NOT READY on nine text defects:
    - D1: README's "each GPU";
    - D2, D3: what ran beside the two suites;
    - D4: GATE 1b's "PASS" (it requires rc 1; the PASS was V3's, on a two-wave ring);
    - D5: "each attempt's arithmetic";
    - D6: which look checked which reader;
    - D7: refused processes in check-gpu;
    - D8: ROUND5.md:189's "registered integrator";
    - D9: "two fewer on an accepted first attempt".
  - Minor: RING.md:248's quick/--light; the usage line's variables; README's HIP sentence; entry 50's struck AUGADD belief.
- **D sent back** for all thirteen as a second phase-1 commit. Round 4's entry 50 gets a bracketed correction, not a rewrite. VD rechecks after.
- **cft-fp256, by message** (information, not approval of anything of ours):
  - Logan approved its GPU backend round 3 today: the fixed fp256 FMA path as a second implementation on hip:N, opt-in.
  - Nothing of theirs runs on a GPU today. G3A starts Friday 11-20 at the earliest, booked clear of ours, under flock locks /root/lead-gpu5060.lock (cft-gpu) and ~/lead-lock/rx7600.lock.
  - Its main is c3c39c87. READ by the lead, in its repository, read only: 9e8ff270..c3c39c87 is 9 files, all docs and site (CAPABILITIES.md, README.md, bindings/wasm/README.md, docs/ x5, site/nightly.json), nothing under host/.
  - **Pin candidates after round 5:** 9e8ff270, 340cd287 or c3c39c87, the same code. The move is only on Logan's word.
- **Told cft-fp256** our GPU plan: today only the 5060 Ti, booked exclusive before each run (P2's merge seams, PL's check_compare_run leg); if the round spills into Friday, those at most, clear of G3A.
For: anyone

## 2026-11-19 10:13 - D's phase 1 fixes at a2c84fb; VD's narrow second look

- **D's fixes** (R5-D-report-2.md, verbatim): a2c84fb on 4980440, documents only (+102/-59). D1-D9 and the four minor items, each at its new file:line. The five LEAD-FILL lines are now at ROUND5.md:9 and :411, RING.md:327, and VALIDATION.md:7661 and :7936.
  - **D4, deviation from VD's wording:** "a three-wave ring", from V3's item4.py:21-24 (ring3_z.txt, E, N = 3, 64) and item4.log:44.
  - One fix beyond the list: entry 55's legs bullet, "each in its quick form".
- **VD resumed** for a narrow second look at a2c84fb: each item against its source, D4's deviation, the extra fix, nothing else moved, and the LEAD-FILL lines.
For: VD, anyone

## 2026-11-19 10:18 - VD: READY on the records' phase 1 at a2c84fb

- **VD's second look** (R5-VD-report-2.md, verbatim): all thirteen fixed, each matching its source when reread.
  - D's "three-wave ring" is right and VD's "two-wave" was wrong (item4.py:21-24, item4.log:43-44).
  - The extra fix is right. Nothing else moved: 16 hunks, each a listed fix.
  - The provenance row is byte-identical, and there are five LEAD-FILL lines.
- **Optional, folded into phase 2:** in entry 50's bracketed correction, "every hip:0 record" becomes "every hip:0 record measured".
- round5-docs = a2c84fb waits for phase 2 (P2, the integration, CLAUDE.md, ROADMAP, ROUND5.md's status). It lands at round close, after VD's look at phase 2. It changes only documents no gate reads.
For: D, VD, anyone

## 2026-11-19 12:58 - A network outage cut P2 and VL; both resumed, nothing lost

- **The outage:** the API was unreachable from about 12:35 (P2's last tool result) until Logan's "back online" at about 12:56. P2's session ended at 12:38 and VL's after its 12:12 entry. D, VD and V2 were idle.
- **P2:** f3ef701 (send-back 2) is committed and its worktree is clean (MEASURED, git). The mutant runners finished without it:
  - mut_full_f1.log ended at 12:02:27 and mut_full_f2.log at 12:40:44, so all 31 full-form mutants are logged. The last is cw_particles full: rc 1, RESULT FAIL, 58 ok, 32 FAIL.
  - B0194's pids are all gone.
  - Resumed by message to tabulate, write its entry, release B0194 and report. Nothing needs re-running.
- **VL:** its item8.sh (bash pid 17156, running since 10:11, under B0195) carried on alone.
  - Its cold check-quick ran to 12:38, then warm and one byte, then the generator phase's check-quick from 12:39:00 (logs/cq-gen.log).
  - The worktree's modified gen_programs.py and three predict-ens .cfta are that phase's own edit, which the script restores.
  - Resumed by message: wait for item8.log's end line, then carry on.
- main = origin/main = fda3b40. Nothing is merged.
For: anyone

## 2026-11-19 13:00 - P2's send-back 2 at f3ef701; V2 resumed for its third look

- **P2's report** (R5-P2-report-4.md, verbatim): f3ef701 on 8f559c8, tools/check_wave.py only (+115/-55, MEASURED by the lead, git). Worktree clean; B0194 released.
  - record_classes() reads the classes from the record (`# columns:` and the trailer's keys). plants() puts each class into each member on its first and last sampled lines: 30 plants in 11 copies, each member left out of one copy. A closing coverage verdict names any gap.
  - The tree: --quick 81/0, full 90/0. All 31 mutants FAIL in both forms, V2's four included; (iii)'s FAIL is the coverage verdict, naming member 2's gaps.
  - P2 agrees with V2's note by reading compare_run.py: a planted step or steps_done is caught by hold_structure() (:573, :610), so compare()'s and particle_compare()'s step comparisons never see it.
- **V2 resumed** for a narrow third look, desktop only:
  - the diff's scope, and a rebuild at f3ef701;
  - the tree in both forms;
  - its four mutants;
  - what holds the coverage verdict itself: a record_classes() that drops a class, and a plants() that skips the last line, each measured;
  - members left out in turn.
- The merge order is unchanged: whichever of P2 (after V2) and round5-pl (after VL) is READY first merges first.
For: V2, anyone

## 2026-11-19 13:19 - VL: READY on round5-pl e8a7d89 with one defect (constants key); PL sent back narrowly (send-back 3)

- **VL's report** (R5-VL-report-1.md, verbatim): READY. The four commits do what they claim, each MEASURED: the scope, the PROGRAMS key, the old key's miss, check_ensemble, limit_absent, mutants (a)-(f), and the cache end to end (warm: 25 SKIPPED; the generator change: exactly the 11 legs with $(IN_PROGS) ran).
- **The defect (item 4b, MEASURED):** the constants leg's key lacks third_party/rebound/src/integrator_ias15.c, which gen_constants.py:414-416 reads. With one digit of h[1] changed, the constants line SKIPPED, while gen_constants.py run directly FAILed. It predates PL's commits, and PL had disclosed it.
- **Ruling:** the merge says every leg keys on every file it runs, imports or reads. That is false while this stands, and the fix is one line per tier. So PL goes back (send-back 3, Makefile only):
  - the input on the constants line in all three tiers;
  - a recheck of every leg for other reads under third_party/;
  - a make-level control: e8a7d89's line SKIPs and the new one runs and FAILs, then a restore, PASS, and a warm SKIP.
  - VL then takes a narrow look.
- **Open notes for the PL merge message**, from VL:
  - cached build/problems steer check_bodycount and check_gravity by their presence. check-quick and check-light hold a broken generator; make check after make clean does not.
  - The closing verdict's counts are printed, not asserted.
  - Mutant (g): a second limit copy on stderr, past drive()'s last 600 characters, passes.
  - --quick's 4-step case 6 holds no rejection after an accepted step.
  - A .cfta edit never reaches an image.
- **VL's checks for PL's GPU check at merge (item 9):**
  - check_compare_run's leg reads rc 0, RESULT: PASS, 73 ok, 0 FAIL;
  - the leg's log has case 6's "4 steps" header with its two ok lines;
  - the closing verdict reads "46 runs (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)";
  - the witness line reads N of N, with N above fda3b40's.
- **Lead's merge prep (MEASURED, git merge-tree, no refs or worktrees touched):**
  - P2 (f3ef701) onto fda3b40, and PL (e8a7d89) onto that and the reverse, auto-merge cleanly (Makefile), both orders giving tree 399adaf7.
  - P2 changes Makefile, src/wave/ and check_wave.py; PL changes Makefile and check_compare_run.py. No other file is shared, and P2 does not touch compare_run.py, so VL's item 9 holds in either order.
- **READ by the lead:** check_wave's key, IN_WAVE at f3ef701:823-829, lists every file check_wave.py runs, imports or reads:
  - check_wave.py; the four wave binaries and ias15_cft;
  - compare_run.py and its imports (check_equivalence, check_ensemble, check_records);
  - make_ring.py; check_replay.py and extract_particle.py; the five problems.
  - compare_formats.py is not needed: compare_run reaches it only under --format-diff (:1093), which check_wave never passes.
For: PL, VL, anyone

## 2026-11-19 13:24 - Merge prep while V2 and PL run

- **merge-p2-msg.txt:**
  - It now has V2's two NOT READYs (82b75b8, 8f559c8) and send-back 2 (f3ef701), and describes the plants as derived from the record, with the coverage verdict.
  - It describes the seams, not their results; those go in the ledger and the records.
  - New open note: a planted step or steps_done is caught by hold_structure() alone.
  - {V2-VERDICT} is still to fill.
- **merge-pl-msg.txt:**
  - Five commits, the fourth gap being send-back 3, with VL's through-make measurements. VL's findings are open notes, and the constants note is dropped since send-back 3 fixes it.
  - {SB3-SHA}, {SB3-MEASURED} and {VL-VERDICT} are still to fill.
- **p2_hand_edit.py** (scratchpad/gpu) does the hand edit at P2's merge:
  - the check-gpu header lines;
  - a comment on the second line;
  - `check-gpu: check-pins all programs $(if $(filter 1,$(HIP)),wave)`;
  - the recipe line `$(PYTHON) tools/check_wave.py --build $(B) --device gpu --quick --expect '$(GPU_EXPECT)'`.
  - MEASURED on both trial trees (P2 alone on fda3b40, and P2 with PL): each anchor lands once, a second run refuses, and `make -n -p HIP=1` resolves `check-gpu: check-pins all programs wave`.
  - READ: on a GPU, check_wave needs wave, wave_unchecked, wave_contract, wave_corpus_gpu, ias15_cft and the host build's wave_corpus, and `wave` builds every one but ias15_cft, which `all` builds.
For: anyone

## 2026-11-19 13:32 - PL's send-back 3 at 4fcd775; VL's narrow look; a known conflict for the second merge

- **PL's report** (R5-PL-report-4.md, verbatim): 4fcd775 on e8a7d89. MEASURED by the lead (git): Makefile only, +3/-3, the constants line in the three tiers gaining `--input third_party/rebound/src/integrator_ias15.c`.
  - The control, through the lines make prints: e8a7d89's line SKIPPED on the changed h[1], and the new line ran and FAILed (gen_constants: derived ...692215, literal ...693215). After the restore: PASS, then a warm SKIP.
  - Nothing else under third_party/ is missing from a key, checked three ways: a text search, a static audit and a runtime trace. Only constants, check_corrector and check_zonal read there, and each reads what its key lists. MANIFEST is not needed.
- **VL resumed** for a narrow look:
  - the scope by extractor;
  - its own constants control at 4fcd775;
  - PL's third_party sweep against its own item-8 trace, by reading;
  - anything else that moved.
- **The second merge has a conflict (MEASURED, git merge-tree, exit 1, both orders).** P2 changed each tier's target line (`check: ... wave-host ...`), and 4fcd775 changes the constants line right under it, so the three tiers make three adjacent-line conflicts.
  - The resolution is mechanical: P2's target line and PL's constants line.
  - With e8a7d89 there was none.
  - The lead is preparing a resolver that refuses anything but these three blocks, checked against an independent expected Makefile.
For: VL, anyone

## 2026-11-19 13:34 - The second merge's resolver, tested in both orders

- **resolve_tiers.py** (scratchpad/gpu) is the resolver. The merge runs with `-c merge.conflictstyle=diff3`, and each of the three blocks is resolved line by line: where one side kept the base's line, it takes the other side's.
  - It refuses and writes nothing unless:
    - there are exactly 3 diff3 blocks;
    - ours, base and theirs are the same length in each;
    - no line was changed by both sides;
    - every resolved line is a tier's target line or a constants line;
    - with an expected file, the result equals it byte for byte.
- **The expected Makefile, by another road:** P2 x e8a7d89, a clean merge to tree 399adaf7, plus 4fcd775's three lines by substitution.
  - The final file, with P2's hand edit, is scratchpad/gpu/expected-Makefile-final (sha256 f82c107b).
  - The second merge's Makefile must equal it.
- **MEASURED** (git merge-tree, diff3):
  - Order A (PL, then P2) and order B (P2, then PL) each give 3 blocks, resolved equal to the expected file.
  - Both final trees differ from 399adaf7 in the Makefile alone.
  - Refusals shown, each leaving the file unchanged: merge-style markers ("not diff3 style"), two blocks ("2 conflict blocks, not 3"), and a one-byte-wrong expected file.
- My own first expected file was wrong by a doubled space, and the resolver's equality check caught it. Fixed before any use.
For: anyone

## 2026-11-19 13:39 - VL: READY on 4fcd775; PL merged into round5-int as 620c98b; its GPU check and full make check started

- **VL's narrow look** (R5-VL-report-2.md, verbatim): READY.
  - Scope by extractor, fresh tree and built: only the constants leg's inputs change, by the one file.
  - Its own constants control: e8a7d89's line SKIPPED; 4fcd775's ran and FAILed (also through `make -o ... check-quick`, rc 2). After the restore: PASS on the same key 0e3b9434b62f, then a warm SKIP.
  - PL's third_party sweep agrees with VL's item-8 trace.
- **Merged** in cft-rebound-r5: `git merge --no-ff -F merge-pl-msg.txt round5-pl` gives **620c98b** on round5-int. MEASURED (git):
  - its tree equals 4fcd775's;
  - fda3b40..620c98b is Makefile +38 and check_compare_run.py +123, nothing else;
  - the worktree is clean.
  - The merge message has no placeholder left and ends with the Co-Authored-By line.
- **Bundle** re-created from round5-int (head 620c98b, verified, sha256 e242c2cb).
- **Told cft-fp256** by message before the GPU run: the 5060 Ti, WSL cft-gpu, one wsl.exe, until 15:30.
- **Started from PowerShell through Git's bash:**
  - 13:38:19, launch-pl-now.sh (pid 20712, wsl.exe Windows pid 12148): setup-pl.sh, a HIP=1 build of all and programs, then check_gpu.py --legs check_compare_run on hip:0. Log lead-wsl/run-pl-620c98b.log; results come back as plgpu-620c98b-<date>/.
  - 13:38:35, int-check-r5-pl.sh (pid 28572): make clean, all programs, then check. Log gpu/int-check-620c98b.log.
- **Booked:** B0199 rtx5060ti and B0200 wsl-cft-gpu, exclusive to 15:30 (pid 12148); B0201 desktop, shared to 18:30 (pid 28572).
- **What must hold before main moves** (VL's item 9 for the GPU check):
  - the leg reads rc 0, RESULT: PASS, 73 ok, 0 FAIL;
  - case 6's "4 steps" header with its two ok lines;
  - the closing verdict "46 runs (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)";
  - the witness line N of N, with N above fda3b40's;
  - make check rc 0, with 25 legs read leg by leg against int-check-fda3b40.log.
- **Ledger timing fix:** five of today's headings (13:05, 13:25, 13:30, 13:40, 13:50) had run ahead of the clock. They now carry their real write times from the session transcript (13:00, 13:19, 13:24, 13:32, 13:34), and agents.txt's three lines likewise.
For: anyone

## 2026-11-19 14:45 - PL's GPU check runs long; B0199/B0200 extended to 17:00. V2's third look: two gaps in the coverage verdict so far

- **PL's GPU check:** setup finished at 13:39:30 (HIP=1 build rc 0 in 61 s; hip:0 = RTX 5060 Ti, bus 0000:05:00.0, CUDA_VISIBLE_DEVICES=1). check_compare_run started at 13:39:31.
  - At 14:45: 33 of the expected 73 ok, 0 FAIL, GATE 1b among them (MEASURED, its log in WSL).
  - At this rate it ends around 16:00. The witness's software-backend half shares the desktop's CPUs with make check and V2.
  - B0199 and B0200 extended to 17:00, and cft-fp256 told by message.
- **make check on 620c98b:** at leg 9 (check_gravity) at 14:45.
- **V2's third look on f3ef701** (interim results, by notification; the report will follow):
  - **Held:**
    - (i)-(iv) FAIL in both forms; (iii) and (iv) by the coverage verdict, naming the gaps.
    - A plants() that skips the last line FAILs (80/1, 12 gaps named).
    - Each left-out member is held with its particles (vi_quiet_stray and vi_quiet_part, 75/6 each).
  - **Not held:**
    - **v_rc_no_max** (a record_classes() whose counter class drops max_pc_iterations) PASSes --quick, 81/0. The verdict reads the classes from the same function.
    - **v_hp_first_line** (a hold_plants that writes every last-line plant on sample 1) PASSes --quick, 81/0. The verdict takes the plan's line, not the line written.
  - Expected send-back 3 to P2, check_wave.py only, once V2's verdict is in:
    - each copy checked against the clean record: exactly the planned value changed, at the planned member, line and column, or it refuses;
    - the coverage verdict computed from those measured differences, against classes from a parse of the record separate from record_classes().
  - P2 cannot merge before PL's make check ends anyway, so this costs no wall time.
For: anyone

## 2026-11-19 15:26 - V2: NOT READY on P2's f3ef701 (the coverage verdict reads the plan); P2 sent back (send-back 3)

- **V2's third look** (R5-V2-report-3.md, verbatim): NOT READY.
  - **Holds (MEASURED):**
    - the scope is check_wave.py only, and nothing relinked;
    - the tree gives 81/0 and 90/0;
    - (i)-(iv) FAIL in both forms, (iii) and (iv) by the coverage verdict, naming the gaps;
    - a plants() that skips the last line FAILs;
    - left-out members are held with their particles (75/6 twice).
  - **Does not hold (MEASURED).** Four one-line edits to check_wave pass:
    - record_classes() without the step class: 75/0 and 84/0. With mutant (i) too it is still 75/0, so send-back 1's gap is open behind one line.
    - The counter class without max_pc_iterations: 81/0.
    - hold_plants() writing every last-line plant on sample 1: 81/0 and 90/0.
    - The left-out copies moved past the end: 81/0, with copy 11 empty.
  - **Cause:** the verdict reads record_classes() and hold_plants()' bookkeeping, not the copies.
- **V2's correction to its own 08:57 report:** "nothing of mine is running" was wrong. 19 idle `tail -f` processes from its monitors, running since 11-18, are now stopped. They read only V2's logs and used no CPU.
- **P2 sent back** (send-back 3, check_wave.py only):
  - expected classes from an independent parse of the record, with record_classes() required to agree;
  - each copy compared with the clean record value by value, refusing unless it differs in exactly its planned values (CLAUDE.md's exactly-once rule, applied to plants), and the verdict computed from those measured differences;
  - first and last lines found inside the verdict, and required to differ;
  - left out counted only where measured.
  - V2's four edits must FAIL by name in both forms; the tree must pass both; (iii) and (iv) rerun.
- No wall time is lost: P2 cannot merge before PL's make check on 620c98b ends, at about 17:00.
For: P2, V2, anyone

## 2026-11-19 16:15 - PL's GPU check on 620c98b: PASS on hip:0 (the RTX 5060 Ti); B0199/B0200 released

- **MEASURED** (lead-wsl/plgpu-620c98b-1119-1339/: README, check-gpu.log, list.txt; the leg log read in WSL):
  - setup rc 0 (HIP=1 build in 61 s); hip:0 = NVIDIA GeForce RTX 5060 Ti, bus 0000:05:00.0, CUDA_VISIBLE_DEVICES=1.
  - `check_gpu.py --legs check_compare_run`: rc 0, "check_gpu: 2 ok, 0 FAIL, in 152m46s on hip:0", RESULT: PASS, from 13:39:30 to 16:12:17.
- **VL's four checks (item 9):**
  - **Leg line:** "rc 0, RESULT: PASS, 73 ok, 0 FAIL". Matches.
  - **Case 6:** "case 6 - the FMA form on the program engine, as recorded and on the loop engine, 4 steps" (log line 30), with its two ok lines, 5 members IDENTICAL on each engine. Matches.
  - **Closing verdict:** "none of the 46 runs of the driver without --producer-files printed a line of it, in any wording, however indented, on stdout or stderr (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)" (line 83). Matches word for word.
  - **Witness:** "1606 of 1606 process(es) on the device (ias15_cft 1606) … 1606 of 1606 record(s) identical to the software backend's".
    - No hip:0 count of this leg exists at fda3b40: P1's merge seam did not run it.
    - The nearest is P1's report, its tree on 5b1cac6 before P3: 774 of 774 at 45 ok. 1606 is above it, as VL expected.
  - **Physics:** 665 records, 22347 steps, 435 rejected, 3.61 passes an attempt, 0 capped; 53144856 library calls in 7374.7 s on the device's clock.
- B0199 and B0200 released at 16:15.
- **Still to hold before main moves:** make check on 620c98b (B0201), now at leg 15 (check_compare_run), and read leg by leg.
For: anyone

## 2026-11-19 16:59 - PL's make check on 620c98b PASSES; main fast-forwarded to 620c98b and PUSHED (fda3b40..620c98b)

- **The suite** (gpu/int-check-620c98b.log, MEASURED): 13:38:35 to 16:55:59, 3:17:24 on a shared host (V2's check_wave runs, the GPU check's software half in WSL, and cft-fp256's M3S beside it; fda3b40's took 3:25:59).
  - clean, build and check each rc 0.
  - 25 legs in fda3b40's order.
  - 1505 lines beginning `  ok ` against 1504; 17 RESULT lines, all PASS.
  - No gate-cache skip. The one "SKIPPED" is check_dropin's "see SKIPPED" text, in both logs.
  - 5 compiler warnings, as before.
- **Leg by leg against int-check-fda3b40.log** (legcmp.py): every leg's ok, FAIL, RESULT and Error! counts are equal, except check_compare_run, 108 to 109 (VL's measured full-tier counts).
- **Normalized diff** (normlog.py none, temp directories masked) differs in exactly:
  - the commit line;
  - the gate_cache lines of constants, check_records, check_ensemble and check_bodycount (PL's added inputs);
  - check_compare_run's case 6 ("20 steps" in its header and two verdicts);
  - the new closing verdict, "none of the 48 runs of the driver without --producer-files printed a line of it ..." (10, 1, 4, 3, 3), as VL predicted for the full tier.
- **Every line carrying a 16+ hex digit token** (digests among them): all 122 identical, with timings and temp directories masked.
- **The bar for round 5's merges, every part met:**
  - VL READY on 4fcd775;
  - the GPU check PASS (16:15 entry);
  - this make check PASS, read from its log;
  - one merge at a time, with no suite running in cft-rebound-r5.
- **In the main checkout:** `git merge --ff-only round5-int` (fda3b40 to 620c98b), then `git push origin main`: "fda3b40..620c98b main -> main", rc 0. main = origin/main = 620c98b.
- B0201 released.
- **Next:** P2, after its send-back 3 and V2's fourth look.
  - P2's merge goes onto 620c98b, so it meets the three tier conflicts: resolve_tiers.py, checked against expected-Makefile-final (sha256 f82c107b), then p2_hand_edit.py.
  - Then a new bundle, the GPU seams, and a full make check.
For: anyone, Logan

## 2026-11-19 17:27 - P2's send-back 3 at 1e13456; send-back 4 (the last massive body) before V2's fourth look

- **P2's report** (R5-P2-report-5.md, verbatim). MEASURED by the lead (git): 1e13456 on f3ef701, tools/check_wave.py only (+221/-29); worktree clean; B0203 released.
  - measured_plants() holds each copy value by value to the clean record: exactly its planned member, column, body and sample, the sample number read from the record.
  - coverage() reads the classes with its own parse (own_columns(), COUNTERS), and record_classes() must agree. It finds the first and last lines itself. A member counts as left out only where measured.
  - Added beyond V2's three points: the particle class counts only on a replayed body.
  - The tree: 92/0 and 101/0. V2's four, (iii), (iv) and P2's two all FAIL by name. The 27 were not rerun, since plants() and the per-plant verdicts are unchanged (READ).
- **The gap P2 left open:** the massive class is planted on bodies 0-5, never on body 6, the last. A compare_run whose massive-body loop stops one short is the most common bug class, and it is unheld.
- **Ruling:** in scope now, before V2 looks, so that V2 looks once. Send-back 4, check_wave.py only:
  - show the off-by-one compare_run mutant PASSing at 1e13456;
  - plant the last massive body in every member in an added copy, leaving the 11 copies byte-identical (sha256), so the 27 need not rerun;
  - coverage, by its own parse, requires every massive body planted, and the last in every member;
  - check the other classes for an unplanted last item;
  - the mutant FAILs in both forms; the tree passes both; V2's four, (iii) and (iv) rerun in --quick.
For: P2, V2, anyone

## 2026-11-19 18:58 - P2's send-back 4 at ff7221a; send-back 5 (sample 0, and both ends of every loop) before V2's fourth look

- **P2's report** (R5-P2-report-6.md, verbatim). MEASURED by the lead (git):
  - ff7221a is on 1e13456 and touches tools/check_wave.py only (+90/-25);
  - the Makefile is unchanged since f3ef701, so resolve_tiers.py's expected file still holds;
  - the worktree is clean, and B0204 is released; the TimeSheet holds no booking of ours.
- **What ff7221a does:**
  - A twelfth copy plants body 6 (janus) in every member: vz on member 0's first sampled line, vy on member 1's last, vx on member 2's first.
  - The coverage verdict reads `# active` and each member's `# body` lines itself. It requires every massive body planted, and the last one in every member.
  - cr_last_massive_short, whose massive slice stops one short, PASSes 1e13456 at 92/0. It FAILs ff7221a at 93/3 and 102/3, on plants 12.0-12.2.
  - The tree passes at 96/0 and 105/0. V2's four, (iii), (iv) and P2's two all FAIL in --quick; `[1:2]` and (iii) also FAIL in full.
- **Masked identity in place of raw, accepted.** READ by the lead from copies_sha.log:
  - raw, every copy differs only on line 218, the totals line's system_steps_per_s and wall_seconds;
  - two runs of 1e13456 differ the same way;
  - masked, all eleven copies equal 1e13456's in both forms, so the 27 need no rerun.
- **The gap P2 disclosed: sample 0 is never planted.**
  - READ by the lead: hold_initial() (compare_run.py:515-529) holds only PROBLEM_FIELDS (m x y z vx vy vz, line 168) of sample 0's bodies.
  - Sample 0's step, t, dt_next, dt_last, E, t_hi and t_lo are compared only by the loops at compare_run.py:752 (member) and :840 (particle).
  - MEASURED by P2: cr_sample0_skipped, in which both loops start one late, passes ff7221a at 96/0 (mutB/cr_sample0_skipped/quick.log, read by the lead).
- **Ruling:** in scope, as body 6 was, since it is the same shape at the start of a loop. Send-back 5, check_wave.py only, closes the shape once:
  - before the change, a sweep (READ) of every loop compare_run compares over, naming its first and last item and what holds each;
  - a thirteenth copy that plants, on sample 0 in every member, a column hold_initial() does not compare; or a stop-and-report if sample 0 cannot be planted without the run being refused;
  - the coverage verdict requires sample 0 in every member, and any other end of the same shape that the sweep finds; anything of another shape is reported, not fixed;
  - the runs:
    - the tree in both forms;
    - cr_sample0_skipped FAILs in both forms;
    - each loop started late on its own, --quick, at ff7221a and at the new commit;
    - the eight earlier mutants and cr_last_massive_short, in --quick;
    - the twelve copies' masked sha256, unchanged.
- **Noticed, no action:** in the full form the plants sit on P.rec, 12 steps (samples 0-3), the same record as --quick's A.rec. The full form's A.rec runs 24 steps (samples 0-4) and carries no plants. MEASURED, by the lead's grep of tree/work-full and tree/work-quick.
For: P2, V2, anyone

## 2026-11-19 20:13 - P2's send-back 5 at 2d062cd; V2 resumed for its fourth look, on the final commit

- **P2's report** (R5-P2-report-7.md, verbatim). MEASURED by the lead (git):
  - 2d062cd is on ff7221a and touches tools/check_wave.py only (+68/-19);
  - the Makefile is unchanged since f3ef701, so resolve_tiers.py's expected file still holds;
  - the worktree is clean, and B0205 is released.
- **The sweep** (READ by P2) lists each loop's two ends in compare_run and what holds each. It found two unheld ends, both at sample 0:
  - the schedule columns, closed by copy 13 (t, E and t_lo);
  - the step, closed by copy 14, which scan() holds.
  The coverage verdict now requires a schedule column and the step on sample 0 in every member.
- **Measured, read by the lead from P2's logs:**
  - the tree passes, 104/0 and 113/0;
  - cr_sample0_skipped, and each loop late on its own, PASSed ff7221a (96/0) and FAIL 2d062cd (101/3; 110/3 full);
  - the other nine mutants all FAIL;
  - the twelve copies are unchanged masked in both forms (26 IDENTICAL lines).
- **Six unfixed shapes, reported by P2 as another shape:**
  - counters' first item, steps_done, and the (k, step) checks, which hold_structure() and scan() catch first;
  - the selection loops;
  - the trailer-key check;
  - the totals sum (:621) stopping one short, where member 2's term is never planted (READ by P2 that it passes);
  - refusals, which check_wave has no verdict for;
  - compare_run's printed value count, which check_wave never reads. MEASURED in P2's mutant log by the lead: "4 samples, 1170 values" three times and "4 samples, 162 values" six times under cr_sample0_skipped.
- **Ruling:** send-back 5 did what was asked. It closed the ends of the same shape and reported the rest. Whether any other shape blocks is the verifier's to measure, not the lead's to add, so V2 is resumed now, on 2d062cd.
- **What V2 checks:**
  - scope and build;
  - the tree;
  - its own four, plus (iii) and (iv);
  - its own loop-end edits;
  - the masked copies, with two runs of one commit;
  - its own mutants of the new code;
  - a ruling on each of the six shapes: it blocks READY, or it is an open note for the merge message. The totals sum one short, and a skipped middle sample line, are to be measured.
For: P2, V2, anyone

## 2026-11-19 22:53 - V2 NOT READY on 2d062cd, on the value count alone; P2 on send-back 6

- **V2's fourth look** (R5-V2-report-4.md, verbatim) is NOT READY on one point. Every item on the READY list held, MEASURED:
  - scope: check_wave.py only, through all three commits;
  - build: nothing relinked;
  - the tree: 104/0 and 113/0;
  - V2's six third-look mutants, now FAILing by name in both forms;
  - the four loop-end mutants, all FAILing;
  - the copies: unchanged across the four commits, with line 218's two timings the only field that moves between runs;
  - V2's own mutants of the new code: 12 of 13 FAIL.
- **The blocker** (MEASURED by V2; the lead read the RESULT lines in v2/sb3/logs):
  - A compare_run that skips the middle sample line PASSes 104/0 and 113/0.
  - One that stops after four lines PASSes full, 113/0.
  - compare_run prints its counts: 1170 and 162 for the middle-line mutant against the tree's 1560 and 216; 1560 on A for the four-line cap against 1950. check_wave reads neither.
  - The lead's 18:58 "no action" note mattered: no plant sits past sample 3 in either form, and full's longer records are only compared clean.
- **P2's READ on the totals sum was wrong:** a sum stopping one short FAILs 103/1 and 112/1, held by record B. It is no longer an open gap.
- **V2's open notes** for the merge message:
  - the sample-0 rule pinned to sample 1 passes; it weakens a rule, and every edit that drops or moves a plant FAILs;
  - steps_done and the (k, step) checks;
  - the selection loops;
  - the trailer-key check;
  - the refusals.
- **Send-back 6**, check_wave.py only, as V2 asked:
  - every IDENTICAL member and particle line, on every record, carries compare_run's sample and value counts;
  - check_wave's own parse gives the sample count and the width (390 per member line, 54 per particle line for the ring);
  - the rule must bite: the tree passes both forms; a width one short FAILs the clean tree; the middle-line mutant FAILs both forms; the four-line mutant FAILs full; P2 says whether --quick has a longer record;
  - no new copies, and no rerun of the earlier mutants.
- **Next:** V2's fifth look, on the count rule only. Then the merge, the GPU check and make check, likely through the night into Friday 11-20. Before any GPU or WSL use, message cft-fp256 and check the TimeSheet.
For: P2, V2, anyone

## 2026-11-19 23:32 - P2's send-back 6 at 9fa5956 (the count rule); V2 resumed for its fifth look, on that rule only

- **P2's report** (R5-P2-report-8.md, verbatim). MEASURED by the lead (git):
  - 9fa5956 is on 2d062cd and touches tools/check_wave.py only (+84/-1);
  - the Makefile is unchanged since f3ef701, so resolve_tiers.py's expected file still holds;
  - the worktree is clean, and B0207 is released.
- **The rule** (READ by P2): every IDENTICAL member and particle line on every compare_run run of the gate must say "N samples, M values".
  - N is the record's own count of that member's sample lines.
  - M is N times the width, which check_wave works out from `# columns:` and `# active`: 390 and 54 for the ring, 18 for kepler, 24 for zonal_saturn.
  - Nothing is taken from compare_run's output.
- **Runs, read by the lead from the RESULT lines in p2r5/sb6:**
  - the tree passes, 130/0 and 144/0, adding 26 and 31 count verdicts;
  - check_wave's member width one short FAILs the tree, 118/12;
  - the middle-line mutant FAILs both forms, 116/14 and 126/18;
  - the four-line cap FAILs both forms, 128/2 and 134/10; --quick holds it through C (13 lines) and D1 (5);
  - the 14 copies are unchanged masked (30 IDENTICAL lines).
- **P2 corrects its send-back 5 claim on the totals sum**, from V2's measurement.
- **V2 resumed for a fifth look, on the count rule only:**
  - scope and build;
  - the tree;
  - its two mutants, with its own edits;
  - rule mutants of its choosing, including a compare_run that stops printing its counts;
  - the copies.
  A READY on 9fa5956 is READY for P2's merge.
For: P2, V2, anyone

## 2026-11-20 01:00 - V2 READY on 9fa5956; P2 merged into round5-int as 7444157; the GPU seams and make check started 00:59

- **V2's fifth look** (R5-V2-report-5.md, verbatim): READY on 9fa5956. MEASURED by V2:
  - scope: check_wave.py only (+84/-1). hold_counts() runs after every compare_run run, and its expected counts come from record_counts(), which reads the record;
  - nothing relinked;
  - the tree passes, 130/0 and 144/0;
  - V2's own middle-line and four-line mutants FAIL in both forms, on count verdicts only (116/14, 126/18; 128/2, 134/10);
  - three single-part mutants FAIL: no counts printed, a particle-only skip, and a cut that also reports 4 samples;
  - the particle width one short FAILs the tree;
  - three weakenings of the rule (counts from the output, particle lines skipped, copies skipped) each still FAIL both mutants;
  - the copies are unchanged in both forms.
  The open notes are as in its fourth look.
- **The bar for P2's merge:** V2 READY on 9fa5956 is met. The GPU seams and the full make check run on the merge before main moves.
- **The merge**, in cft-rebound-r5 on round5-int, MEASURED:
  - `-c merge.conflictstyle=diff3 merge --no-ff --no-commit 9fa5956` returned rc 1, with a CONFLICT in the Makefile only: 12 markers, so 3 blocks. The 8 new P2 files merged cleanly;
  - resolve_tiers.py resolved the 3 blocks (lines 856, 900 and 947: P2's tier target line and PL's constants line) and matched handedit-dry/expected-prehand byte for byte;
  - p2_hand_edit.py applied its 4 edits, and the Makefile's sha256 f82c107b equals expected-Makefile-final;
  - P2's src/wave/* and tools/check_wave.py equal 9fa5956's, and every other path except the Makefile equals 620c98b's;
  - merge-p2-msg.txt was committed with -F, with no placeholders left: **7444157**, parents 620c98b and 9fa5956. The tree is clean, and HEAD:Makefile is f82c107b;
  - the bundle was re-created, and its head is 7444157 (round5-int).
- **cft-fp256** was told by message before any GPU or WSL use. Its reply: no clash. G3A dispatches later this morning, after night 1119 comes off the card (from about 07:45). It books after a TimeSheet check, and from our new end if we extend.
- **Booked:**
  - B0209 rtx5060ti and B0210 wsl-cft-gpu, exclusive to 05:30 (pid 29936);
  - B0211 desktop, shared to 05:30 (pid 33548).
- **Launched at 00:59:19 from PowerShell**, waiters bbtam4vyg and br3954p9c:
  - the GPU check, lead-wsl/launch-p2-now.sh on 7444157. Its setup cloned 7444157, the pins are ok, and mpmath is 1.3.0;
  - the make check, int-check-r5-p2.sh; its log is int-check-7444157.log, and cc reports x86_64-w64-mingw32.
- **Next:**
  - read README, check-gpu.log (check_records, then check_wave --device gpu --quick) and p1p2.log;
  - read the make check log against int-check-620c98b.log: 25 legs equal, plus check_wave as the 26th;
  - then fast-forward main, push, release the bookings, and report to Logan.
For: anyone, Logan

## 2026-11-20 01:28 - The GPU check on 7444157 FAILED on two things, neither in the kernel's numbers; make check stopped; P2 on send-back 7; the seam script fixed and sent to VL

- **The GPU check** (lead-wsl/p2seam-7444157-1120-0100, 00:59 to 01:17, MEASURED on the RTX 5060 Ti):
  - **setup** rc 0: the build took 84 s, hip:0 is the RTX 5060 Ti (sm_120), and the pins are ok;
  - **(a) make HIP=1 check-gpu** rc 2. Its first line, check_records, PASSed (check_gpu: 2 ok, 0 FAIL, 15m19s). Its second line, check_wave --device gpu --quick, crashed before running anything: "NotADirectoryError: [Errno 20] Not a directory: '/root/cft-rebound-r5-lead/tree/build/wave/1549'" (check_wave.py:1088). READ: `make HIP=1 wave` builds the kernel as build/wave (Makefile:678), and check_wave's default work directory is build/wave/<pid> (check_wave.py:1085). This has been so since P2's first commit, 3f7d67e, and P2's and V2's GPU runs never met it (how, P2 is to say). The tiers' check_wave leg would fail the same way on a HIP=1 tree with `wave` built;
  - **(b) p1p2_seam** 15 ok, 8 FAIL. All 8 are the lead's script not knowing the kernel record's `# device` line (P2's 46ddfed): "wave against cpu: 1 difference(s)", the device line alone. The six wave controls each found 2 differences. compare_run held the kernel's record IDENTICAL, and P2 x P3 passed.
- **make check on 7444157 stopped at 01:21** (taskkill of the lead's own tree, pid 33548; it was at check_door, past the build and four legs). Waiter br3954p9c was stopped, and B0211 released. Why: send-back 7 changes the merged tree, so this run could not be the bar, and it would have held cft-rebound-r5 ("never while a suite runs") until about 04:30.
- **Send-back 7 to P2**, check_wave.py only:
  - the default work directory moves to build/check_wave/<pid>, as check_gpu uses build/check_gpu/<pid>;
  - every other mention of the old path is checked, and nothing check_wave writes may collide with the `wave` target's outputs;
  - the clash is shown with a plain file at <build>/wave: it fails at 9fa5956 and passes at the new commit;
  - the tree passes both forms, and the copies are unchanged.
  V2 then looks at that commit only.
- **The lead's seam script, fixed** (sha 83f4c01e to c9e39a38; the original kept as p1p2_seam.py.orig-7444157):
  1. the kernel's `# device` line is set aside by name, and held by a new verdict: exactly one in the kernel's GPU record, naming --expect, and none in the port's records;
  2. the kernel's record backend is wanted as hip:0:<arch>, the arch read from that device line; the script had wanted "gpu", and the kernel writes hip:0:sm_120. This second cause hid behind the first: the record verdict's detail printed only the unknown lines, and now it prints a backend mismatch too.
  MEASURED:
  - offline on the failed run's saved records, harness.py gives 16/0 (the original script FAILs it) and harness2.py gives 6/0, with controls: an extra unknown header still FAILs; the device line removed, doubled, naming another GPU, or present in a port record each FAIL; backend=gpu, sm_89 or hip:1 each FAIL; each wave control finds exactly its one planted difference;
  - on the GPU, against the built 7444157 tree, seamtest 0123 gave 23/1 (the backend), then 0125 gave **24/0**. That checks the script, not the bar.
- **VL** (a6ab97e79a666f25b) has been resumed to verify the script change, desktop only, through the script's own code rather than the harnesses.
- **B0209 and B0210** were released at 01:28; they are re-booked for the re-run.
- **Next:**
  - P2's send-back 7, then V2's narrow look; VL's verdict on the seam script;
  - then round5-int reset (--keep) to 620c98b and the merge redone with P2's new tip, using the same kit and the message updated for send-back 7;
  - then a new bundle, the GPU check and make check;
  - main stays at 620c98b until both pass.
For: P2, V2, VL, anyone, Logan

## 2026-11-20 01:33 - VL READY on the lead's seam-script fix (c9e39a38); its three optional hardenings applied (f4e475dd), back to VL

- **VL's report** (R5-VL-report-3.md): READY. MEASURED through the script's own main(), with run() stubbed from the 0100 run's saved records:
  - all nine planted cases FAIL by name;
  - unknown headers such as `# devices`, `# devicehip:0` and `# note x` still FAIL;
  - 0100 to 0125: 15 verdicts unchanged, 8 flip FAIL to ok, 1 new.
  READ: the device line is P2's design (wave_main.cpp, 46ddfed), check_wave holds it equal to the probe's line, compare_run allows a producer-only header, and the kernel writes backend=hip:<index>:<arch>.
- **Three cases still passed,** none of which today's kernel can produce (READ by VL): the device line's own index changed, the arch changed in both places, and a device line under --dry-host.
- **The three hardenings VL suggested, applied by the lead** (sha f4e475dd, harness.py still 16/0):
  - the record's device line must equal the probe's --device-info line;
  - --dry-host requires no device line;
  - the arch regex accepts ':' as well as ','.
  VL is re-checking them through main().
For: VL, anyone

## 2026-11-20 01:35 - VL READY on the seam script's hardenings (f4e475dd)

- **VL's report** (R5-VL-report-4.md): READY on sha f4e475dd5282914a. MEASURED through main() with VL's stub (vl/vl_seamtest2.py):
  - the saved records still give 24/0 on the GPU path;
  - VL's three earlier passing cases now FAIL by name: the device line's index, the arch changed in both places, and a device line under --dry-host;
  - the nine earlier cases still FAIL;
  - a feature-flag arch (gfx90a:sramecc+:xnack-) passes;
  - a probe line one character off FAILs;
  - a probe line on stderr only, or naming another GPU, is refused before anything runs.
- **The seam script for P2's merge bar is p1p2_seam.py at f4e475dd.** It runs again in full on the redone merge.
For: anyone

## 2026-11-20 01:48 - P2's send-back 7 at 3d8ab5b (check_wave's work directory); V2 resumed for its sixth look, on that alone

- **P2's report** (R5-P2-report-9.md, verbatim). MEASURED by the lead (git):
  - 3d8ab5b is on 9fa5956 and touches tools/check_wave.py only (+6/-2): the header note, and the default, now os.path.join(B, "check_wave", pid);
  - the Makefile is unchanged since f3ef701, so the merge kit still holds;
  - the worktree is clean, and B0212 is released.
- **P2's runs, read by the lead in p2r5/sb7:**
  - with a plain file at <build>/wave, 9fa5956 dies at the makedirs (FileNotFoundError on Windows) and 3d8ab5b PASSes;
  - the tree PASSes in both forms, and without --keep;
  - the 14 copies are unchanged, masked.
  READ by P2: P2's own and V2's GPU runs passed --keep outside build/.
- **A note for the redo:** leftover build/wave/<pid> directories from old failed runs would block the kernel's link on a HIP=1 tree. The redo's GPU check clones fresh (setup-p2.sh: rm -rf tree), and its make check runs make clean first.
- **merge-p2-msg.txt** is updated for send-back 7, with a placeholder for V2's verdict on 3d8ab5b. int-check-r5-p2.sh's stale header comment is fixed (a comment only).
- **The redo plan, on V2's READY:**
  - git reset --keep 620c98b on round5-int (7444157 stays in the reflog; it was never pushed);
  - the same merge kit on 3d8ab5b;
  - a new bundle;
  - bookings checked and made;
  - the GPU check, with seam script f4e475dd, and make check launched from PowerShell.
For: P2, V2, anyone

## 2026-11-20 02:12 - V2 READY on 3d8ab5b; P2's merge redone as 61e45bc; the GPU check and make check started 02:11

- **V2's sixth look** (R5-V2-report-6.md): READY on 3d8ab5b. MEASURED by V2:
  - scope: check_wave.py only (+6/-2);
  - with a 73-byte plain file at <build>/wave, 9fa5956 dies at the makedirs and 3d8ab5b PASSes 130/0, leaving the file untouched;
  - the tree passes --quick at 130/0 and full without --keep at 144/0, with no <pid> directory left behind;
  - the copies are unchanged.
  V2's nuance: no check target depends on clean. The make clean before the redone merge's make check is the lead's procedure, and the GPU tree is a fresh clone.
- **Housekeeping found and fixed:** TaskStop of waiter br3954p9c at 01:21 left its timeout.exe (38748) and bash (18884) running. Both were the lead's own grep loop on int-check-7444157.log; taskkill /T at 02:10, and nothing references the old logs now. So stopping a waiter needs a check that its processes have gone.
- **The redo, in cft-rebound-r5, MEASURED:**
  - `git reset --keep 620c98b` on round5-int, rc 0; 7444157 is in the reflog (HEAD@{1}) and was never pushed;
  - `-c merge.conflictstyle=diff3 merge --no-ff --no-commit 3d8ab5b` returned rc 1, with a CONFLICT in the Makefile only (12 markers). The 8 new files merged cleanly;
  - the conflicted Makefile differs from the first merge's only on a marker line, which names the other commit;
  - resolve_tiers.py resolved 3 blocks, equal to expected-prehand; p2_hand_edit.py made 4 edits; the result equals expected-Makefile-final (f82c107b);
  - P2's files equal 3d8ab5b's, and everything else equals 620c98b's;
  - the merged tree differs from 7444157's by tools/check_wave.py alone (+6/-2);
  - merge-p2-msg.txt, with send-back 7 and V2's verdict on 3d8ab5b, was committed with -F: **61e45bc**, parents 620c98b and 3d8ab5b. The committed message has no braces and no CRs, and the tree is clean;
  - the bundle was re-created, and its head is 61e45bc.
- **Booked** after a TimeSheet check, within the window cft-fp256 was told (01:00 to 05:30):
  - B0214 rtx5060ti and B0215 wsl-cft-gpu, exclusive to 05:30 (pid 44384);
  - B0216 desktop, shared to 06:30 (pid 28236).
- **Launched at 02:11:37 from PowerShell:**
  - the GPU check, launch-p2-now.sh on 61e45bc, with seam script f4e475dd; it cloned fresh (pins ok, mpmath 1.3.0);
  - make check, int-check-61e45bc.log (cc x86_64-w64-mingw32, a clean build first).
  Waiters b1228fyj4 and b22j18mh3.
- **Next:**
  - read the GPU check: check_records, check_wave --device gpu --quick and p1p2_seam;
  - read make check against int-check-620c98b.log: 25 legs equal, plus check_wave as the 26th;
  - then fast-forward main to 61e45bc, push, release, and report to Logan.
For: anyone, Logan

## 2026-11-20 02:44 - P2's GPU check on 61e45bc: PASS on hip:0 (the RTX 5060 Ti); B0214/B0215 released

- **lead-wsl/p2seam-61e45bc-1120-0213**, 02:11 to 02:42, read by the lead:
  - **setup:** rc 0, a fresh clone of 61e45bc, pins ok, hip:0 = NVIDIA GeForce RTX 5060 Ti (sm_120), CUDA_VISIBLE_DEVICES=1;
  - **(a) make HIP=1 check-gpu, GPU_LEGS=check_records:** rc 0 in 1676 s. In it:
    - check_records (quick) PASSes 4 ok, 0 FAIL in 15m21s, with 4 of 4 processes on the device and every device line the probe's;
    - check_wave --device gpu --quick, the hand edit's second line, gives **RESULT: PASS, 147 ok, 0 FAIL**. Its scratch directory is now build/check_wave/<pid> (send-back 7), and it ran without --keep. Gate 4's GPU corpus digest ca7246a62d9533f6 equals the host build's. "A: the record's one device line is the GPU's", and the count verdicts hold on every record;
  - **(b) p1p2_seam.py (f4e475dd): 24 ok, 0 FAIL.**
    - cpu, hip and wave records: the wave's backend is hip:0:sm_120, as wanted;
    - the kernel record's one device line names the RTX 5060 Ti and equals its --device-info line;
    - hip against cpu and wave against cpu are IDENTICAL: 4 sample lines of 394 values, 64 body lines, the headers and the five counters;
    - all 11 controls FAIL by name, each on its one planted value;
    - compare_run holds the hip record and the kernel's IDENTICAL;
    - P2 x P3: compare_run --producer-files gives IDENTICAL with members 0 and 1 not rerun, and 6 particles from P2's own files are IDENTICAL; the one-ulp control FAILs member 0's particles by name.
- **B0214 and B0215 released at 02:43.**
- **Still to hold before main moves:** make check on 61e45bc (B0216, pid 28236), read leg by leg against int-check-620c98b.log.
For: anyone, Logan

## 2026-11-20 05:05 - P2's make check on 61e45bc: PASS; main fast-forwarded 620c98b..61e45bc and PUSHED; B0216 released

- **make check on 61e45bc** (gpu/int-check-61e45bc.log): 02:11:37 to 05:03:15, so **2:51:38** on a shared host, beside the GPU check for its first 31 minutes. MEASURED: clean rc 0, build rc 0, check rc 0. The build has 5 warnings and no Error, as at 620c98b.
- **Read against int-check-620c98b.log** (legcmp.py, normlog.py):
  - 26 legs against 25. The 25 in common are identical in their ok, FAIL, RESULT, Error and warn counts, and in their order once check_wave is removed;
  - **check_wave is the 26th**, after check_reversal: 144 ok, 0 FAIL, RESULT: PASS (the full form). Its count rule holds on A.rec at 5 lines x 390 and x 54;
  - RESULT: PASS lines 17 to 18, the new one check_wave's;
  - outside check_wave's leg, the normalized diff is the start line (the commit) and the four new wave-host build lines (wave_host, wave_host_unchecked, wave_host_contract, wave_corpus);
  - every line carrying a 16+ hex digit token, with timings and temp directories masked: 122 against 122, all identical.
- **The bar for P2's merge, every part met:**
  - V2 READY on 9fa5956 and on 3d8ab5b;
  - the GPU check, the seams, PASS on 61e45bc (the 02:43 entry);
  - this make check PASS, read from its log;
  - one merge at a time, with no suite running in cft-rebound-r5.
- **In the main checkout:** `git merge --ff-only round5-int` (620c98b to 61e45bc), then `git push origin main`: "620c98b..61e45bc main -> main", rc 0. main = origin/main = **61e45bc**.
- B0216 released at 05:04. No booking of ours is held.
- **All four parcels of round 5 are now on main:** P3 (4a8fe99), P1 (fda3b40), PL (620c98b) and P2 (61e45bc).
- **Next:** records phase 2 (D, then VD), the merge of round5-docs with its own make check, archiving the ledger, and closing the round. The pin move comes only on Logan's word after the close.
For: anyone, Logan

## 2026-11-20 05:06 - Records phase 2: D resumed on round5-docs

- **round5-docs** is at a2c84fb (phase 1, VD READY), two commits on fda3b40. They touch README.md, ROUND5.md, docs/RING.md and docs/VALIDATION.md, none of which main has changed since fda3b40. `git merge-tree --write-tree main round5-docs` gives rc 0, a clean merge (MEASURED).
- **D** (a0315491678809509) has been resumed for phase 2, docs only, never merging main into its branch:
  - VALIDATION entries 56 (P2) and 58 (the integration: PL's merge, P2's failed first merge 7444157 and its redo 61e45bc, the suites, the GPU checks, the conflict resolution, the outage);
  - CLAUDE.md's make check row and leg count (26), and possibly one line on "a run with other arguments is not the gate's run";
  - ROADMAP: round 5 closed; the pin move waits on Logan's word;
  - ROUND5.md, RING.md and README;
  - the phase-1 carry-overs: both check_dropin times, the costs.py open note, P0's stale "To do", and entry 50's "every hip:0 record measured".
- **Then:** VD, the merge of round5-docs with its own make check, archiving the ledger to archive/round5-ledger.zip, and the round's close. The pin move comes only on Logan's word.
For: D, VD, anyone

## 2026-11-20 05:31 - D's records phase 2 at b1cd3ed + 83f2188; one CLAUDE.md clause asked; a correction to the 01:28 entry

- **D's report** (R5-D-report-3.md, verbatim). MEASURED by the lead (git):
  - b1cd3ed and 83f2188 sit on a2c84fb, and round5-docs touches documents only: CLAUDE.md, README.md, ROADMAP.md, ROUND5.md, docs/RING.md and docs/VALIDATION.md (+1082/-32 over phase 1);
  - `git merge-tree --write-tree main round5-docs` gives rc 0, a clean merge into 61e45bc;
  - D's worktree is clean.
  READ in CLAUDE.md's diff:
  - the make check row: 2 h 52 min, 26 legs, 61e45bc, 2026-11-20, shared host; and 3 h 17 min, 25 legs, 620c98b;
  - "26 since check_wave (entry 56)";
  - the new bullet, "A run with other arguments is not the gate's run" (entry 58).
- **The lead's calls on D's points:**
  - P2's merge and suite go in entry 58, as round 4 did: agreed;
  - the rate table goes in entry 56, under P1's ruling: agreed;
  - the citations move to main's lines: agreed;
  - process lapses stay out of VALIDATION.md, since the ledger keeps them: agreed.
  - **Asked of D:** one clause in CLAUDE.md's planted-control bullet for round 5. It sent the shape back nine more times (P1's seam three, check_wave six), and plants at both ends of every loop still let a skipped middle line pass until check_wave held compare_run's own count.
- **Correction to the 01:28 entry:** 7444157's make check was stopped in its **sixth** leg, check_door, after five: constants, check_dropin, check_dropin_wide, check_equivalence and check_program_engine. It was not "past ... four legs" (D's count from the --leg lines, confirmed by the lead's legcmp order).
- **Next:** D's clause, then VD (a1b6a216da4d69c3f) on phase 2.
For: D, VD, anyone

## 2026-11-20 05:32 - D's clause at 87fb2b8; VD resumed for records phase 2

- **87fb2b8** is on 83f2188 and touches CLAUDE.md only (+8/-4), MEASURED by the lead (git). The planted-control bullet now reads: "Round 5 sent it back nine more times: P1's seam three, check_wave six (entries 55, 56). Plants at both ends of every loop still let a skipped middle line pass, until check_wave held compare_run's printed count of the values it compared to the record's own." D checked both counts against its entries: send-back 7, the work directory, is not counted. It sharpened the second sentence to name both counts. round5-docs still merges into main cleanly (merge-tree rc 0).
- **VD** (a1b6a216da4d69c3f) has been resumed on round5-docs at 87fb2b8, covering b1cd3ed, 83f2188 and 87fb2b8:
  - every number traced to its source and recounted;
  - the labels;
  - CLAUDE.md against main's Makefile and entries 55, 56 and 58;
  - the citations, including D's two moved lines;
  - the scope, LEAD-FILL, the pin row's check_pins tests and merge-tree;
  - ROADMAP inventing nothing.
For: VD, anyone

## 2026-11-20 05:52 - VD NOT READY on records phase 2 (87fb2b8), on three sentences; D on the fixes and six nits

- **VD's report** (R5-VD-report-3.md, verbatim). Every number recounted matches its source:
  - both suites' times, legs, ok lines and RESULT lines;
  - the 25 legs held to 620c98b's counts;
  - check_wave 144 ok, and gate 4's 152,735 and 7,259;
  - the GPU folders;
  - the reports and git.
  Every citation is correct. The mechanics pass: six documents only, no LEAD-FILL, the pin row byte-identical to fda3b40's, merge-tree clean, and ROADMAP inventing nothing. VD's regex counts 117 hex lines where the lead counted 122; the entry attributes the 122 to the lead.
- **The three defects:**
  1. CLAUDE.md's "dry-run only on the host twin" has no support in entry 58. The fact is true, per this ledger at 2026-11-19 05:12, gpu/p1p2/dry2.log: 22 ok, "DRY RUN on the host: nothing on a GPU". The lead confirmed it; the first GPU run was at 7444157.
  2. Entry 56's physics bound is a ratio, not "within 1e-2".
  3. Entry 56's watchdog was never met: 7dec985 marks the two-second reset BELIEVED.
- **Six nits, all applied by the lead's call:**
  - ROUND5.md's "66 min alone";
  - ROADMAP item 2, narrowed as entry 50;
  - ROADMAP's gate-cache line, with "PL's open notes aside";
  - entry 58 naming D;
  - entry 58's "but the Makefile";
  - check_wave's usage left as the tool's own text, plus a note that check-gpu passes --expect.
- **D** is making one commit on 87fb2b8, documents only. VD then looks at that commit alone.
For: D, VD, anyone

## 2026-11-20 05:58 - VD READY on records phase 2 (57a148e); round5-docs merged into round5-int as ff9f494; the ledger archived next, then the closing make check

- **VD's report** (R5-VD-report-4.md): READY on 57a148e.
  - The nine changes match their sources: the dry-run sentence, against this ledger at 2026-11-19 05:12 and gpu/p1p2/dry2.log; the bounds, against check_wave.py:306; the watchdog, against 7dec985's message; and the six nits.
  - Nothing else moved, and the diff is documents only. merge-tree is clean, the pin row is byte-identical to fda3b40's and passes check_pins, and no LEAD-FILL is left.
- **The merge**, in cft-rebound-r5 with no suite running there (no make process alive; MEASURED):
  - `merge --no-ff --no-commit 57a148e` returned rc 0, with no conflicts;
  - the staged tree differs from 61e45bc only in CLAUDE.md, README.md, ROADMAP.md, ROUND5.md, docs/RING.md and docs/VALIDATION.md, each equal to 57a148e's;
  - committed with gpu/merge-records-msg.txt (-F; no braces, no CRs) as **ff9f494**, parents 61e45bc and 57a148e.
- **Next, on round5-int:**
  - archive/round5-ledger.zip, built by gpu/make_archive_r5.py: the ledger, the dispatched briefs, every report, the suites' and GPU checks' logs, and the lead's scripts, each entry byte-identical to its source;
  - one full make check on that commit;
  - then fast-forward main and push.
  **The ledger ends with this entry, before that commit's own suite.**
- **Not removed:** the working copy (.ledger/) and .ledger/scratch-r5, 312 MB, the round's durable scratch copy. The README says the lead removes the working copy, but that would delete files the archive does not hold, so it waits for Logan's word.
- **Pending on Logan's word:** the pin's move off eae74e3e, to cft-fp256 9e8ff270 or its docs-only descendants 340cd287 and c3c39c87.
For: anyone, Logan
