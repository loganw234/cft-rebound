(R5-V1's third look, at P1's 6a5e448, its final message on 2026-11-18 at ~13:26, copied verbatim by the lead.)

**NOT READY.** One fix remains: the seam still passes a compare_run that never compares a member's particles. Items 2 to 5 check out.

I checked out 6a5e448 detached in my worktree; it is clean. `git diff --stat ab75fbe 6a5e448` touches only `tools/check_gpu.py`, +91/−46. I used no GPU. My desktop booking (B0164, shared) is released and the mutant copies are deleted.

**1. Both waves planted — confirmed, with one gap measured.**
- `seam_form()` plants five REBOUND-form columns on each wave's first and last sampled lines: 140 and 142 for wave 0, 141 and 143 for wave 1. The FMA form plants x of body 1 on 142 and 143.
- Each plant's check needs:
  - rc 1;
  - the planted member to FAIL, naming "record line N (system w …)" and the column;
  - the other member IDENTICAL, and its particles present and all IDENTICAL.
- P1's 5060 Ti log shows all 12 plants passing that check.
- **The gap:** no check asks anything of the planted member's own particles.
  - I made a compare_run copy whose `particle_compare()` returns IDENTICAL without comparing (one added line, applied once).
  - On P1's desktop harness it scores exactly as the tree does: 16 ok, 0 FAIL each.
  - On the wave-1 plant of x of body 1, the tree's particles read `1 FAIL, 1 FAIL`; the mutant's read `1 IDENTICAL, 1 IDENTICAL`.
  - So the seam's "4 particle(s) … all IDENTICAL" can't fail.
- **Fix:** the particle replays hold x of body 1, dt_next, t_lo and t. For those four plants, and the FMA plant, require the planted member's particles to FAIL. vz of body 63 is not a sampled particle, so its plant stays IDENTICAL there.
- A copy that skips a planted column fails the member check. Columns that are never planted (t_hi, dt_last, E, y, z, vx, vy, the other bodies) are covered by no plant, as designed.

**2. The mutants — confirmed.**
- `mutate_compare_run.py` changes line 1072 only; I diffed it.
- It refuses with rc 2 and writes nothing when the edit lands 0 times (run on its own mutant) or 2 times (a copy with the line doubled).
- On P1's desktop harness at 6a5e448, the tree scores 16 ok, 0 FAIL. Each member mutant scores 10 ok, 6 FAIL: exactly that member's five REBOUND plants and its FMA plant.
- P1's four 5060 Ti logs agree:
  - the tree, 26 ok;
  - each mutant, 11 ok and 6 FAIL, with "IDENTICAL: not compared";
  - P3's compare_run, 17 ok;
  - every device line is the 5060 Ti's.

**3. TIMING_KEYS — confirmed.**
- The 13 names are exactly the trailer's timings:
  - seconds and steps_per_s, from the printf (`src/ias15_cft.c:4773`);
  - wall_seconds and the nine t_ rows of `trailer_keys[]` (:3281-3295);
  - system_steps_per_s (:4782).
- No counter is named: calls, divsqrt_calls, program_calls, staged_bytes, nextstep_calls, E and pc_lane_efficiency are all held.
- A name must be followed by "=", so a counter whose name starts with a timing's name can't be set aside.
- I re-ran my 32 plants against 6a5e448's `analyse()`:
  - every counter next to a timing is caught;
  - t_new=1 and x_new=1 are caught at "line 11, field 13", as control a3 reports live;
  - the clean records, the two-wave one included, still pass.
- The list is checked both ways: a removed key fails a3, and a new timing key fails every leg loudly as a difference.
- Aside: `hw/gpu/where.py`'s `records_same()` still sets aside anything matching `t_[a-z_]+`. It's a measurement tool, not the witness.

**4. Nothing else moved — confirmed.** The seven hunks are three header comments, TIMING, control a3, the seam comment and `seam_form()`'s plants. The wrapper, `analyse()`, `refused_early()`, `witness_verdict()`, the routes and the legs are unchanged.

**5. P1.md — confirmed.** The 13:03 corrections now read right:
- one hex digit on one line per plant;
- +1.86%, with the other rows +0.23% to +1.30% (I recomputed them);
- the identity check binds gate_real alone: `identity_ok` at :646, its phases :458-571, check_checkpoint's calls :168-286;
- my measured check_checkpoint and check_seams results, credited to me.

The line numbers in P1's notes (:543, :592, :660, :1339) point where they say.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\r5v1\sb1v\`.

**NOT READY**, on the planted member's particles alone.
