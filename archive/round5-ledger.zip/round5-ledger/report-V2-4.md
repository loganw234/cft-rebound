(R5-V2's report on its fourth look at P2's 2d062cd, its final message on 2026-11-19 at ~22:56, copied verbatim by the lead.)

**NOT READY on 2d062cd, on one point only.** Everything on your READY list holds when measured. The blocker: a compare_run that skips the middle sample line passes check_wave in both forms (104/0 and 113/0), and one that stops after four lines passes full (113/0). One rule in check_wave.py would close both. I ran on the desktop only, booked shared as B0206 (20:24–22:50, now released), never more than three of my runs at a time.

**1. Scope**
- MEASURED: from f3ef701 to 2d062cd, and each of the three commits against its parent, the diff is `M tools/check_wave.py` alone.
- READ, the whole diff (+339/−33): copies 12–14, own_columns(), measured_plants(), the per-copy verdict, the measured left-out rule and coverage(). Nothing outside part 5 changed.

**2. Build** — MEASURED: detached at 2d062cd and clean, nothing relinked. No file under build/ is newer, every .exe and .a keeps its mtime, and `make -q wave-host` returns 0.

**3. The tree** — MEASURED: --quick PASS 104/0 and full PASS 113/0, P2's numbers.
- All 14 copies hold exactly their planned values.
- The coverage verdict lists every class, all seven massive bodies, and sample 0 in every member. It also confirms each member was left out of one copy.

**4. The third look's mutants** — my own edits, each landing exactly once (I showed refusals at 0 and at 6 landings). MEASURED: every one is RESULT: FAIL by name.

| mutant | --quick ok/FAIL | full ok/FAIL | what FAILs |
|---|---|---|---|
| step class dropped | 91/1 | 100/1 | coverage: record_classes() disagrees, and step is missing on both lines in every member |
| max_pc_iterations dropped | 103/1 | 112/1 | coverage: the counters disagree with COUNTERS, and the column is never planted |
| `[1:]` → `[1:2]` | 98/6 | 107/6 | copies 2, 4, 6, 8 and 12 refused (sample 3 planned, sample 1 found), and the last-line gaps |
| left-out copies past the end | 102/2 | 111/2 | copy 11 holds NOTHING, and no member is left out |
| (iii) member 2 skipped | 90/1 | 99/1 | coverage: member 2's gaps |
| (iv) counters skipped | 94/4 | 103/4 | copies 9–11 hold NOTHING, and the counter class is missing |

My (iii) and (iv) skip the plants in hold_plants(), where P2's skip them in plants(). My `[1:2]` and left-out edits are textually the same as P2's, because P2 took them from my third-look report.

**5. compare_run's loop ends** — my edits, at the loops' first lines and inside the pairs loop. MEASURED: each FAILs by name.

| mutant | --quick | full | what FAILs |
|---|---|---|---|
| pairs loop skips the last massive body | 101/3 | 110/3 | plants 12.0–12.2: 0 of 2 particles FAIL |
| sample 0 skipped in both loops | 101/3 | 110/3 | plants 13.0–13.2: neither the member nor its particles FAIL |
| sample 0 skipped in compare() alone | 101/3 | — | the member doesn't name the plant; the particles do |
| sample 0 skipped in particle_compare() alone | 101/3 | — | the member names the plant; 0 of 2 particles do |

**6. The copies** (MEASURED unless marked)
- P2's reason for masking holds. Comparing two --quick runs of 2d062cd, and its --quick run against its full run, the record and all 14 copies differ only on line 218, in `system_steps_per_s` and `wall_seconds`. With those masked, they are identical.
- Given the same record, the check_wave.py of f3ef701, 1e13456 and ff7221a write copies 1–11, 1–11 and 1–12 byte-identical to 2d062cd's. My third-look run at f3ef701 also matches 2d062cd's once masked.
- READ: the per-plant verdict code is unchanged since f3ef701, and the new verdicts can only add FAILs. So send-back 2's 27 compare_run mutants need no rerun.

**7. My mutants of the new code**
- MEASURED, first through part 5 alone. That means hold_plants() run on the kept --quick record, with compare_run's real outputs reused for copies whose bytes it had already seen. On the tree this harness writes copies byte-identical to the real run's, and all 54 of its verdicts pass.
- 12 of my 13 mutants FAIL by name:
  - measured_plants(): the scalar range one short, the body index shifted, the total dropped.
  - own_columns(): `# active` one short, the last `# body` line dropped, the per-body columns one short, the sample index read from the step field.
  - coverage(): the first line taken as sample 2, the last massive body pinned to body 5.
  - The new plants: copy 12 on body 5, copies 13 and 14 on sample 1, copy 13 dropped.
- Re-run in the real gate, the total-dropped and body-5 mutants each FAIL 103/1.
- **One passes:** the sample-0 rule pinned to sample 1 (`h[2] == 0` changed to `== 1`) passes the real gate 104/0, because sample 1's plants satisfy it. This weakens a rule rather than removing a plant, and every single edit that drops or moves the sample-0 plants still FAILs. I'd treat it as an open note, not a blocker.

**8. P2's six unfixed shapes**
1. **steps_done and the (k, step) checks:** an open note. No record plant can reach them; I measured that in my second look.
2. **Selection loops:** an open note. They compare nothing, and each replayed particle is planted on its own body (READ).
3. **Trailer-key presence:** an open note. A missing key still FAILs the counter loops (READ).
4. **Totals sum stopping one short: held, not open.** MEASURED: it FAILs 103/1 and 112/1 on record B, whose three members each reject a step. compare_run says "the members' trailers reject 2 steps, and the record's total (line 218) says steps_rejected=3". P2's READ that it passes is wrong.
5. **hold_initial() and the other refusals:** an open note. BELIEVED: the loops still compare sample 0's bodies against a rerun that starts from the problem file.
6. **The value count: blocks READY.** MEASURED: skipping the middle sample line passes, 104/0 and 113/0. compare_run then prints "4 samples, 1170 values" for each member and 162 values for each particle, where the tree prints 1560 and 216.

**The lead's note: it matters.**
- MEASURED: the full form plants the same 14 copies as --quick (identical once masked), so in neither form does any plant sit past sample 3.
- Full's longer records are only compared clean: A, B and F have 5 lines and C has 31 (MEASURED), D1 has 5 (READ).
- MEASURED: compare_run loops that stop after four lines pass full 113/0. On A they print "5 samples, 1560 values", where the tree prints 1950.
- Moving the plants onto full's A would hold sample 4 and nothing past it. The count rule below holds every line of every record.

**Send-back (tools/check_wave.py only):** hold compare_run's printed counts.
- Every IDENTICAL member line and particle line that check_wave reads, at least for the clean records, must print the record's own sample count for that member.
- It must also print that many lines' worth of values, by the record's `# columns:` line: 390 per member line and 54 per particle line for the ring.
- After that, the middle-line mutant must FAIL by name in both forms, and the four-line mutant in full.

**Housekeeping**
- The mutant trees are deleted, and the worktree is clean at 2d062cd.
- The logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\sb3\logs.
- Ledger entries are in V2.md at 20:27, 21:00 and 22:56.
- I stopped five idle `tail -f` processes left by my own monitors. Nothing of mine is running.

**NOT READY**
