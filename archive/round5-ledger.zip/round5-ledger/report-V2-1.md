(R5-V2's first look at P2's 82b75b8, its final message on 2026-11-18 at ~14:30, copied verbatim by the lead.)

**NOT READY.** The kernel holds up: the GPU records are the CPU port's bits on both GPUs, for the reasons P2 gives. The problem is in `check_wave`'s planted controls. They have the same shape you sent P1 back for twice.

**Where I ran, and under which booking.** On the desktop, my worktree was detached at 82b75b8 with both pins cloned locally (B0163, shared). On the RX 7600 I worked in ~/cft-rebound-r5-v2, built from my own bundles (sha256 equal at both ends), under B0161/B0162 from 12:57 to 13:25. I also made one 20-second unbooked run there at 13:31, after `check --short` showed it free. On the 5060 Ti I worked in /root/cft-rebound-r5-v2 under B0165/B0166 from 13:07 to 13:16, with `CUDA_VISIBLE_DEVICES=1`. I only read P2's directories. Every booking is released and nothing of mine is running. My ledger entries in V2.md are at 13:08, 13:26, 13:37 and 14:28.

**1. Bit-identity is not validity — confirmed.**
- Each verdict prints every member's steps, rejections, mean and max passes and cap hits, and compare_run holds them to the port's.
- What is asserted:
  - B rejects every wave's first attempt.
  - C rejects after accepted steps.
  - D1 rejects and hits the cap.
  - A, B, C and E meet the circularity, angle-swept and energy bounds.
- compare_run compares all 64 bodies of every member, so the moons are compared. Each particle replay also holds the 7 massive bodies.
- Step mutants of the host twin, held by compare_run, all fail:
  - J2/J4 switched off fails at sample 0's E.
  - Frozen particles fail.
  - Saturn's J2 reaction dropped fails.

**2. Planted controls — defect.**
- **Where the plants are.** Every plant is in case E: ring wave 1 run alone (`--member 1`), a one-system record that compare_run calls "member 1".
  - Lines: sample lines 1 and 2 only (steps 4 and 8 in --quick, 6 and 12 in full).
  - Columns: E and t_lo in --quick; t, E, vz of body 63 and t_lo in full.
  - The counter plant is B's member 0, steps_rejected.
  - P2's own GPU seam (scratch seam.py, not committed) plants seven columns on wave 0's lines 141 and 143. Wave 1 is never planted.
- **Mutants.** Each is a copy in scratch whose edit lands exactly once; the script refuses at 0 or 2 landings. Each was run through `check_wave`.
- **These pass `check_wave`** (49 ok --quick, 57 ok full), with compare_run never comparing:
  - ensemble member 1's lines, member 0's lines, member 1 at all, or member 2 (full);
  - any sample line past the third;
  - any particle (not replayed, or V1's no-op particle_compare);
  - columns x, y, z, vx, vy, vz, t, dt_next, dt_last, t_hi (--quick), or x (full);
  - the member path's trailer counters, or the step field.
- **These also pass:** check_wave with its own physics decision, its attempts comparison, or its particle parse skipped.
- **These fail:**
  - skipping the member labelled 1, or skipping one-system records (caught by E's plants);
  - columns E and t_lo (--quick), t and vz (full);
  - check_wave asking for `--strata 1` (caught by `ident == E`).
- **Concrete failure, run.** I planted one digit in wave 1's last sample line of the --quick A record. The tree's compare_run returns rc 1. The never-member-1 copy and the first-three-lines copy both return rc 0, and both pass check_wave. A kernel wrong only in workgroup 1, or only after sample 2, would pass beside either copy. E does not cover it, because on a GPU it runs as blockIdx 0.
- **Also:**
  - Nothing asserts that a particle was replayed (`pid == len(parts)` at :520 is true at 0 of 0).
  - The physics control computes its own `caught` (:666) and never reads physics_verdict's decision.
- **Mitigation, measured.** check_compare_run --quick fails the never-member-1 copy (42 ok, 3 FAIL). That gate runs in every desktop tier and in check-gpu (check_gpu.py:155). Nothing anywhere holds check_wave's particle count, its physics decision or its attempts comparison.

**3. Contraction — confirmed.**
- `make -n` on all three hosts: every shipped object gets -ffp-contract=off (and --fmad=false under nvcc). Only the contract controls get contraction on.
- Fused-instruction counts:

| compiler | shipped | checked source, contraction on | unchecked: off → on |
|---|---|---|---|
| g++ (desktop) | 10 vfmadd, all from `_mm_fmadd_sd`, 3 of them the predictor's | 11; the extra is in `now_s()` (the timer) | 3 → 44 |
| hipcc, gfx1102 | 632 v_fma_f64 | identical assembly, line for line | 403 → 597 |
| nvcc, sm_120 | 1,169 DFMA | identical SASS (56,840 lines) | 848 → 1,084 |

- So the flags do reach every compiler, and the source has plenty of a*b+c to fuse. What stops fusion is that each product feeds its flag check (my belief about the mechanism; the effect is measured).
- **A control that can fail:** one product-sum fused by hand (gravity's x accumulation) fails compare_run, in member 1 at its last sample.

**4. Gate 4 — confirmed.**
- The corpus is what P2 says, with references cft_run, cft_div, cft_sqrt and cft_augmented_add.
- Every plant is named by its operation (desktop, n 4000):

| plant | mismatches |
|---|---|
| divide by reciprocal | 3,400 |
| sqrt by reciprocal | 4,729 |
| product subnormals flushed | 8,250 |
| add subnormal inputs read as zero | 8,156 |
| augmentedAddition as TwoSum | 1,501 |
| fma as multiply then add | 12,981 |
| underflow decided one exponent early | 4,868 flags |
| gfx1102 corpus built with -fdenormal-fp-math=preserve-sign | 65,602, all seven operations |

- The digest is 3cd1af43b434860c on the desktop and on both GPUs' host and GPU builds, with 0 mismatches each.
- Matching per-operation counts would not prove the 81af26a run's inputs; my re-run at 82b75b8 settles it.

**5. Determinism and portability — confirmed.**
- From the code: every `each()` and `one()` ends in a barrier, and E, the reactions and the maxima are folded serially by thread 0. There are no wave intrinsics.
- Runs that came out identical apart from timings:
  - RX 7600: a 3-wave ring from dt0 1e5 run twice;
  - RX 7600: 527 waves × 24 steps run three times;
  - RX 7600: a `-mwavefrontsize64` rebuild against the wave32 build;
  - 5060 Ti: a 2-wave ring run twice.

**6. Flags — confirmed.**
- Every arithmetic operation in the step decides all four flags exactly, and gate 4 holds those decisions.
- **Limit stated only in wave_step.h, not in P2's reports:** the port computes and discards 1,596 test–test pairs that the kernel never computes. So two coincident test particles stop the port with DIVBYZERO but not the kernel.
- The unchecked control fails as claimed (contraction off passes, contraction on fails), but it holds a different source from the shipped one.

**7. Final commit — confirmed.**
- RX 7600, full: `RESULT: PASS`, 78 ok, 0 FAIL.
- 5060 Ti, --quick: `RESULT: PASS`, 66 ok, 0 FAIL.

**8. Across GPUs — confirmed.** P2's two 4,096-wave, 10-orbit records differ in 0 of 278,535 lines, once backend=, the identity and device lines and the five timings are set aside. A planted digit in a copy shows as one line.

**9. Makefile — confirmed.**
- `make -n -B` of all and programs is identical at 5b1cac6 and 82b75b8.
- Each tier adds only the four wave-host builds and the check_wave leg.
- HIP=0 is identical to HIP unset.
- Every artifact check_wave executes is an `--input` of its leg.

**10. Seams.**
- **P2×P3 — confirmed.**
  - On an 8-wave host ring, 4a8fe99's `--producer-files` replays 16 particles from P2's files, 6 of their members not rerun. All are identical, and every key equals the port's `--run-key`.
  - On the RX 7600's own files, 2 members not rerun and 6 particles: identical.
  - One ulp planted in a not-rerun member's attempt fails both its particles by name.
  - check_wave reads 4a8fe99's output lines correctly: PASS, 49 ok.
- **P1×P2 — confirmed.**
  - `git merge-tree` of P3+P1, then P2, has no conflict, but the check_wave line is in neither branch and must be added by hand.
  - An empty GPU_EXPECT restricts neither tool.
  - GPU_LEGS and GPU_SKIP subsets would still run check_wave.

**11. Rates — confirmed.** P2's labels hold. My re-run of 527 × 24 on the RX 7600 came in within 1% of P2's row:

| | my three runs | P2's row |
|---|---|---|
| kernel clock | 0.257, 0.254, 0.254 s | 0.255 s |
| wall clock | 0.317, 0.313, 0.314 s | 0.314 s |

**12. Things you didn't ask about.**
- The record's `# identity … contract=off … flags=checked` is a hard-coded literal (wave_main.cpp:502), so the unchecked and contract control records claim it too.
- check_wave.py:405 says a wrong device "runs nothing". In fact its probe (:407) runs two kepler steps on hip:0 first, which in a cft-gpu shell without `CUDA_VISIBLE_DEVICES` could be the 4070.
- E's verdict labels member 1's counters as "member 0".
- P2's claim about MinGW's library holds: library sqrt(0x1.fffffffffffffp+1023) = 0x1p+512, and library fma differs from the instruction on 18,013 of 199,714 triples.
- The 527-wave ring generated on nvidia-box matches P2's desktop file byte for byte.
- The three-way check on the RX 7600 (port on CPU, port on hip:0, kernel) is identical through a first-attempt rejection.

**Send-back, tools/check_wave.py only:**
- plant in an ensemble record, in member 0 and in a later member, and on the last sample line;
- require each plant to fail its own member, and its sampled particles where they hold the column, with the other members identical;
- assert that particles were replayed;
- route the physics control through physics_verdict;
- the mutants above must then fail.

I deleted every mutant and control copy on all three hosts. I kept the two GPU trees and P2's two 4,096-wave records in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\xgpu.

**NOT READY**
