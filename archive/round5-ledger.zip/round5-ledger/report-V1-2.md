(R5-V1's final report on P1, its final message on 2026-11-18 at ~12:08, copied verbatim by the lead.)

**READY.** On both GPUs, `make HIP=1 check-gpu` at ab75fbe passes. Every process ran on the named GPU and printed the probe's device line, and every record is identical to the software backend's. check_corrector is now accounted for under strace on the RX 7600. The fixes listed after the item list don't block the merge; whether they land before it is your call.

All runs were at ab75fbe on the eae74e3e pin. Every booking is released (B0096/97, B0134-36, B0142-46). The RX 7600 and nvidia-box went back at 12:07 and I told main. On nvidia-box I deleted `refusal-work` and `where-work` at 08:53, and left cft-fp256's files alone. I edited no tracked file and deleted my control copies.

**5. The final commit on a GPU — confirmed.**
- **RTX 5060 Ti (cft-gpu, 05:53-07:56).**
  - Setup: in `/root/cft-rebound-r5-v1`, `make clean`, then the nvidia `HIP=1` build. `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1` was set before anything opened `hip:0`.
  - Command: `make HIP=1 … GPU_EXPECT="RTX 5060 Ti" GPU_SKIP=<the other nine legs> check-gpu`, make rc 0.
  - Output: `check_gpu: 36 ok, 0 FAIL, in 123m04s on hip:0`, RESULT: PASS. That covers the probe, controls a to f, the routes at three formats and the seam in both forms. Control g printed "NOT RUN: no strace on this host".
  - `ok   check_records (quick form): rc 0, RESULT: PASS, 4 ok, 0 FAIL, 14m34s; witness: 4 of 4 process(es) on the device (ias15_cft 4), a device line each and every line the probe's; 4 of 4 record(s) identical to the software backend's from the same arguments, 8 route line(s) by=absent against opt_in; execs not traced (no strace on this host)`
  - `ok   check_corrector (quick form): rc 0, RESULT: PASS, 212 ok, 0 FAIL, 100m10s; witness: 163 of 165 process(es) on the device (check_dropin 1, ias15_cft 164), a device line each and every line the probe's, and 2 refused by their own arguments before opening it, as the software backend refuses them; 165 of 165 record(s) identical to the software backend's from the same arguments, 270 route line(s) by=absent against opt_in`. Its check_dropin: 170 ok, every case passed.
  - The one device line, printed by every process: `cft hip: hip:0 = NVIDIA GeForce RTX 5060 Ti (sm_120, 36 multiprocessors, bus 0000:05:00.0, 16283 MiB), HIP platform nvidia, runtime 12090, driver 13040; of 1 visible, CUDA_VISIBLE_DEVICES=1; this libcft: HIP_ARCH 120, stage 64 MiB, page 256 bytes, kernels 40/40/64 registers and 4728/4208/12624 bytes local a thread (run/level/seq)`
- **RX 7600 (nvidia-box, strace on every exec, 08:53-12:06).**
  - Command: `make HIP=1 PYTHON=python3 GPU_EXPECT="RX 7600" GPU_LEGS=check_corrector check-gpu`, make rc 0.
  - `ok   check_corrector (quick form): rc 0, RESULT: PASS, 212 ok, 0 FAIL, 192m16s; witness: 163 of 165 … and 2 refused by their own arguments …; 165 of 165 record(s) identical …; strace: 165 run(s) of the witnesses and 330 of the real programs, as the witness accounts`
  - Device line: `cft hip: hip:0 = AMD Radeon RX 7600 (gfx1102, 16 multiprocessors, bus 0000:03:00.0, 8176 MiB), HIP platform amd, runtime 71626385, driver 71626385; of 1 visible; this libcft: HIP_ARCH gfx1102, …`
  - The two refused processes are the same two on both GPUs (`--trace-pc` or `--record-iters` beside `--replay-iters`).
- The seam's plants show the same values on both GPUs, so the `hip:0` ring record is the same bits on each.

**1. Stand-ins — confirmed, with one structural gap.**
- **Bypass:** none found by reading. Every leg finds its programs through `--build $(B)`, the shadow. `check_gpu.py --list` shows the leg commands are check-quick's word for word.
- **strace coverage:** on the RX 7600, every leg is now strace-checked. P1's logs at 8ea24bd show it for the other ten (read, not re-run by me; the leg code is unchanged since then).
- **The gap:** on the 5060 Ti nothing can see a bypass. The evidence there is only the same code and the same process count per leg.
- **The device line:** it proves the process opened the GPU, not that every operation ran there. Under gdb on the RX 7600, `cft_class` (79 calls) and `cft_augmented_add` (5) never reach the device: 84 of 19,434 counted calls are host work by design.

**2. What the witness sets aside — confirmed, with two latent notes.**
- I planted 32 differences in copies of real `hip:0` witness data, read by check_gpu's own `analyse()`. Every plant next to a set-aside rule was caught by line and column, including counters next to the timings and `calls=`/`fallbacks=` next to `by=absent`.
- Latent 1: `TIMING` (`check_gpu.py:164`) drops any trailer key named `t_*`. A planted `t_new=1` passed; every `t_` key is a timing today.
- Latent 2: stderr is printed but never fails a leg.

**3. The refusal rule — confirmed.** I ran real failures through the witness on the RX 7600:
- `hip:1`, a hidden device, `CFT_HIP_INFO=2`, SIGSEGV after the device line and SIGKILL at once all FAIL.
- The genuine argument refusal is the only one counted as refused.
- The software replay never opens a device, so a device failure can't be refused the same way in software.
- Minor: refused processes count as device processes (`check_gpu.py:527`).

**4. Seam — confirmed on both GPUs, with one gap measured.**
- **Plants:** each is one hex digit on one line, not two. dt_next and t_lo are on line 140; x of body 1, vz of body 63 and t are on line 142.
- **FMA form:** really run.
- **P3's wording:** check_gpu's regexes read P3's `2922fa1` output (8 of 8 checks ok).
- **The gap:** every plant is in wave 0. A one-line compare_run mutant that never compares member 1 passed all of the seam's checks in both forms. On a wave-1 plant (line 143) the tree's compare_run FAILs member 1; the mutant calls it IDENTICAL.

**6. `HIP=0` changes nothing — confirmed.**
- `make -n -B` output is identical, and a one-word recipe mutant differs.
- On the desktop, `make check-gpu` refuses by name with rc 2.

**7. What runs where — confirmed at fp64.** where.py reproduces P1's counts exactly. The 5060 Ti part is timing only, and labelled so.

**8. gate_real — right about gate_real, wrong about the other two, now measured.**
- `identity_ok` runs only in gate_real's self-contained mode (line 646). The `--straight`, `--save` and `--resume` modes the other two use never call it.
- Surveyed on the 5060 Ti with `--reach`:
  - check_checkpoint `--quick` **passes** on `hip:0`: 7m56s, all 18 gate_real processes show the device line.
  - check_seams `--quick` **fails**, 12 ok and 24 FAIL. Every FAIL is a forced indexed or pair_gather case, or a count of them. The reduce_seg and scalar cases all pass.
- So the ledger's 17:05 entry is wrong about check_checkpoint, and gives the wrong reason for check_seams.

**9. Costs and corrections — confirmed, with one overstatement.**
- "Within 1.5% of P0" is 1.9% for kepler fp128 on the program engine.
- `cft_reduce` is never called on the default path: by code (`ias15_cft.c:1835`) and by gdb (0 entries).
- The clock's augmented sum runs at every step attempt: by code (line 3049) and gdb (5 of 5).

**10. Things you didn't ask about.**
- `--analyse` is weaker than a live run: it checks no rc and takes the device line from the processes themselves. My two live PASSes replace P1's re-read of check_corrector.
- On cft-gpu, the check-gpu make relinked `check_dropin` and `ias15_ref` four minutes after the setup build, from unchanged sources. I believe it's WSL clock skew; every binary's build time was printed.
- A strace-free bypass check for the 5060 Ti: run the real binaries from a copy only the witness knows, so a bypass fails instead of passing.

**Fixes before or with the merge (your call):**
- One plant in wave 1.
- A narrower `t_*` timing rule.
- Corrections to the records: one line per plant, 1.9% not 1.5%, and the check_checkpoint/check_seams finding.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\r5v1\`; the ledger entries are in `...\scratchpad\ledger-drop-r5\V1.md`.

**READY.**
