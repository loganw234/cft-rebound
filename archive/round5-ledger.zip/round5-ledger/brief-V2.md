You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, the multi-precision arithmetic library of the sibling repository cft-fp256. Its central invariant is that every backend gives the same bits and **no committed record line moves** unless a change means it to. Round 5 (ROUND5.md) brings in libcft's GPU device, `hip:N`.

Round 5's parcel P2 built **the wave kernel**. IAS15's step at the hardware's binary64 is written as `__host__ __device__` functions in src/wave/. They run on the CPU as a host twin (`make wave-host`), and on a GPU as a HIP kernel with one ring system to a 64-thread workgroup (`make HIP=1 wave`). tools/check_wave.py holds their records bit for bit to `ias15_cft --arith fma --format fp64`'s, through tools/compare_run.py.

**The question: are the kernel's records really the CPU port's bits on both GPUs, for the reasons P2 gives? And could a kernel, or a gate that compares less, get past check_wave?**

Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for the failure shapes to hunt: a gate driving a stand-in, a comparison that cannot fail, bit-identity taken for validity.

## What to verify

P2's branch is `worktree-agent-aecde4474af33b9f7`, on main `5b1cac6`, with tip `82b75b8`. That tip is the one commit after `81af26a`, and it makes gate 4's random draws independent of the compiler.

The branch adds:
- src/wave/: wave_arith.h, wave_corpus.cpp, wave_gpu.inc, wave_hd.h, wave_io.h, wave_main.cpp and wave_step.h;
- tools/check_wave.py;
- the Makefile's `wave-host` and `wave` targets, and check_wave's leg in all three tiers.

The claims:
- **P2's reports:** read both, all of each, in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\`:
  - `R5-P2-report-1.md`, its pause at 81af26a on 2026-11-16;
  - `R5-P2-report-2.md`, the final report.
- **What P2 was asked to do, and the traps:** its brief, `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\briefs\filled\R5-P2.md`.
- **Its ledger entries:** `C:\Users\logan\source\repos\cft-rebound\.ledger\P2.md`. Read every file in that directory.
- **The context:** ROUND5.md's P2 section, docs/RING.md, docs/VALIDATION.md entries 47 to 51 and 54, and CLAUDE.md.

P2's logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\`. Its GPU work is in `~/cft-rebound-r5-p2` on nvidia-box and `/root/cft-rebound-r5-p2` in WSL cft-gpu. Read them there; never write them.

**Already checked by the lead; do not repeat:** P2's full `make check` at 82b75b8 (`scratchpad\p2r5\full3.log`, 05:59 to 09:27, rc 0). Its 25 legs equal P0's on d7b5047 leg by leg. check_wave is a 26th leg: 57 ok, RESULT: PASS.

**Do not run a full `make check`.** The merge runs one.

## Where things are, and when you may use them

- **The desktop: your isolated worktree.**
  - `git checkout --detach 82b75b8`, then confirm it.
  - Clone the pins locally, never from the web, each in a separate command:
    - REBOUND from `/c/Users/logan/source/repos/cft-rebound/third_party/rebound`, at bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93;
    - cft-fp256 from `/c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256`, at eae74e3eddc67836d4b7c8922badd40e6e1bdb2f.
  - Build with `export PATH="/c/msys64/mingw64/bin:$PATH"`, which is not optional, then:

    ```
    make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs wave-host
    ```

  - No `make -j` in a fresh tree.
- **The RX 7600:** nvidia-box (`ssh -o BatchMode=yes logan@192.168.0.2`, ROCm at /opt/rocm, gfx1102).
  - Work only in **~/cft-rebound-r5-v2**, which you create.
  - mpmath 1.3.0 is at ~/cft-rebound-r5-py (`PYTHONPATH`).
- **The RTX 5060 Ti:** WSL `cft-gpu`, reached with `wsl.exe -d cft-gpu -- bash -lc '...'`. In MSYS bash, set `MSYS_NO_PATHCONV=1`.
  - Work only in **/root/cft-rebound-r5-v2**.
  - Build with `HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120`.
  - **Set `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1` before anything opens a device. Never the RTX 4070.**
  - Copy the desktop's mpmath 1.3.0 into your directory.
- **Code on both hosts:** carry it as git bundles made on the desktop from local clones. Nothing comes from the web. Run `make clean` before the first `make HIP=1` in a tree first built without HIP.
- **The windows** (TimeSheet, 12:48 today):
  - The RX 7600 and nvidia-box are free, so start there.
  - **The 5060 Ti and WSL go to P1 first.** P1 runs its seam test there between about 13:00 and 15:00, and WSL takes one agent at a time.
    - Use cft-gpu only when the TimeSheet shows nothing on `wsl-cft-gpu` or `rtx5060ti`.
    - Keep each visit short and release at once: the lead needs a short seam run there later.
  - cft-fp256 needs neither GPU today.
- **Booking:** book every GPU run of 10 minutes or more from the desktop, as `--who cft-REBOUND/V2`, with the ssh or wsl session's Windows pid attached. Release it when the run ends:

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book <rx7600|rtx5060ti> --mode exclusive --from now --until <WHEN> --who cft-REBOUND/V2 --why "<what>" --pid <pid>
  ```

  - Book nvidia-box (shared) or wsl-cft-gpu (exclusive) beside it.
  - Before a short run, run `check <resource> --short` and also `list`. `check --short` sees only sensitive windows, not someone else's exclusive one.
- Start with everything that needs no GPU.

## Specific things to attack

1. **Bit-identity is not validity.**
   - Does each gate print and assert physics counters beside its verdict: steps, passes, rejections, and a precession or circularity counter?
   - Do its rings reject, including a first-attempt rejection? (CLAUDE.md: "A rejection leaves state only before the first accepted step".)
   - Are the moons compared, as well as the particles?
   - Could a kernel that never moves the particles, or one that drops the zonal term, pass?
2. **Planted controls.** check_wave plants one hex digit "in a sampled member's record, a column on two lines". The GPU seam test catches "7 of 7 planted digits".
   - For each plant, name its member, wave, lines and column.
   - Then run the mutants that compare less, each from a copy in scratch:
     - compare_run never comparing member k, for each member the gate holds;
     - compare_run never comparing a column;
     - check_wave with any one comparison skipped.
   - Each edit must land exactly once, or your script refuses.
   - Report which mutants pass. V1 found exactly this shape in P1's seam: every plant was in wave 0, and a compare_run that skipped member 1 passed.
3. **Contraction.** P2 says the brief's literal contraction control "changes nothing on any of the three compilers, so it cannot fail as worded". Find out why:
   - Does the checked source contain no contractible `a*b + c`, or did the flags never reach the compiler?
   - Read `make -n` of `wave-host` and of `HIP=1 wave` on each host.
   - Count the fma instructions in the built kernels and host twin (objdump, cuobjdump, llvm-objdump) against the `fma()` calls the source writes.
   - Is there a control that *can* fail? Say what it would be.
4. **Gate 4, the hardware's arithmetic.**
   - Is the corpus what P2 says? That is: random operands, ties, subnormals and the extremes; add, multiply, fma, divide and sqrt; `cft_div`, `cft_sqrt` and the augmented addition.
   - Can it fail? Plant one wrong operation in a copy and show gate 4 names it. For example:
     - a divide or sqrt that is not correctly rounded;
     - a subnormal flushed to zero;
     - TwoSum's ties-to-even in place of libcft's augmentedAddition.
   - **82b75b8's digest:** on the RX 7600, does the GPU build's digest equal the host build's, and the desktop's?
   - The 5060 Ti's gate 4 ran at 81af26a, before there was a digest. Is "same inputs, by identical per-operation counts" enough? Re-run gate 4 there at 82b75b8 if you get a window.
5. **The kernel's determinism and portability.** It runs one system to a 64-thread workgroup, reduces the maxima and minimum in shared memory, and uses no wave intrinsics.
   - Read the kernel. Is there a warp-size assumption, a missing barrier, a race, or a reduction whose order changes a sum (the E column, in `energy_all()`'s order)?
   - Run one record twice on the RX 7600 and compare the two files.
6. **Flags.** Where the port aborts on OVERFLOW, DIVBYZERO or UNDERFLOW, the kernel checks its own results and stops by name.
   - What does it check, and what is a stated limit?
   - Is the unchecked variant's failure the control it claims to be?
7. **The final commit on each GPU.** P2's RX 7600 runs are at 82b75b8, but its 5060 Ti runs are at 81af26a.
   - Run `check_wave --device gpu`, full, at 82b75b8 on the RX 7600.
   - Run the `--quick` form on the 5060 Ti when you can book it.
   - Report actual lines.
8. **Across GPUs.** P2 did not compare its two GPUs' 4,096-wave 10-orbit records file to file.
   - Do it, reading both of P2's directories without writing, and copying to the desktop.
   - Set aside header and trailer timings. Every differing member is a finding.
9. **The Makefile and the cache.**
   - On the desktop with HIP unset, compare `make -n -B` of `all`, `programs`, `check`, `check-quick` and `check-light` between 5b1cac6 and 82b75b8. What changes beyond check_wave's leg and the wave-host build?
   - Is every artifact check_wave executes an `--input` of its leg?
   - Does `HIP=0` change nothing?
10. **The seams for the merge.** P2 merges after P1 (check-gpu and tools/check_gpu.py, branch `worktree-agent-ab5e6c159761d1e5e`) and after P3, which is now on main at `4a8fe99`. Merge nothing.
    - **P2 × P3:**
      - Take compare_run.py, extract_particle.py and check_replay.py from 4a8fe99 (`git show 4a8fe99:<path>`) into a scratch copy.
      - Run it with `--producer-files` on a wave_host record and its `--attempts-dir`.
      - Is every NOT RERUN member's particle replay held? Does the run key match?
      - Does check_wave.py's reading of compare_run's lines (around :361-364) still read 4a8fe99's output?
    - **P1 × P2:** check_wave is to join `check-gpu` as its second recipe line. Read both Makefiles. Would a conflict, or an assumption (GPU_EXPECT, CUDA_VISIBLE_DEVICES, the shadow build directory), break check_wave's GPU leg there?
11. **The rates.**
    - Is each of P2's rows labelled as what it is? That means: one run a row, which clock, the 5060 Ti's taken on a shared desktop, and GPU-E2's estimates pricing software binary64.
    - Re-run one short row on the RX 7600 (24 steps at 527 waves), and say how close it comes.
12. **Anything else.** Tell the lead what it did not think to ask.

## Ground rules

- Re-run things; do not trust pasted output.
- Report only. Edit no tracked file. Build controls and mutants from copies in scratch, and delete them afterwards.
- No card, and never the RTX 4070. No network except the SSH to nvidia-box and WSL.
- Never bare `git stash`. Never push, merge or rebase.
- On any host, never touch another session's directories. P1's are off limits, P2's are read-only, and so are cft-fp256's (`/root/lead-1118-replay`, `~/lead-1118-replay`).
- Append ledger entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\V2.md`. Head each with the time `date` prints.
- "Found nothing" is a fine answer. State precisely what you ran, where, and under which booking.

## Report

- **For each numbered item:** the commands you ran, what you observed, and a verdict: **confirmed**, **defect** or **not determined**. A defect needs a concrete failure scenario.
- **End with** **READY** or **NOT READY**.
- **Length:** under 1,500 words. Your report is your final message.
