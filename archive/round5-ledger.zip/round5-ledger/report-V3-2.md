(R5-V3's second look, its final message on 2026-11-18 at ~07:44, copied verbatim by the lead.)

**V3, second look at P3 (`0bee543`): NOT READY.** The driver's output now tells the truth about a NOT RERUN member. But two of your five mutants pass the gate, and one clause of the limit line says more than a rerun holds.

**Setup.** The worktree is detached at 0bee543, and `git diff --stat 2922fa1 0bee543` shows the two tools only (+219/−111). `make … all programs` rebuilt nothing: both binaries kept their 11-16 16:48 times. The phony `programs` target re-assembled the 66 images, as it does on every call. Desktop booked as B0139 (shared) and released at 07:43. Logs and scripts are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v3-r5b\`; the copies are deleted.

**1. D1, the line — defect, in the gate (and one clause).**
- **Placement — confirmed.** On my ring the line is printed once: line 11, after the plan line (8) and before the first member line (14). It is also printed once on a `--member` record and under `--plan`. The gate asserts it, and passes, in GATE 1's runs and the empty-directory runs at each format, in GATE 1b and in the program-engine case. It is absent on all six default setups.
- **Clauses:**
  - "takes … as given": true.
  - "only a member that is rerun holds its decisions": true, through its bits and counters.
  - "particles that are not sampled are held by nothing": true after sample 0, which the problem check holds for every body. Understated, harmless.
  - **The settings clause overstates.** I made producer records at other settings, rewrote their headers to name the defaults, and ran each as rerun member 4. pc_tol_shift 2 and 8, and max_iter 12, came back IDENTICAL: nothing moved. max_iter 6 (2 cap hits) and epsilon 1e-8 FAIL. A rerun holds these settings only through what they move.
- **The reworded lines — no overclaim.** The member line, its plan line and RESULT's suffix claim no more than the replays hold. My earlier plants confirm the items listed: E, Mimas's x, t_hi, t_lo, the mean.
- **The five mutants against `--quick`:**

| Mutant | Result | What catches it |
|---|---|---|
| line removed | 65 ok, 4 FAIL | the from-files verdict (which quotes the limit), the empty directory, GATE 1b, the program-engine case. Only the first FAIL line names the limit. |
| one word changed | 65 ok, 4 FAIL | same four |
| printed before the plan line | 65 ok, 4 FAIL | same four |
| **printed twice** | **69 ok, PASS** | nothing |
| **printed on the default path too** | **69 ok, PASS** | nothing |

- **Why "twice" passes:** `limit_once` uses `out.count("\n"+LIMIT+"\n")`, which counts non-overlapping matches. Two adjacent copies share a newline and count once; I confirmed 2 lines counted as 1.
- **Why "default path" passes:** nothing asserts the line is absent without `--producer-files`.
- **Scenario:** a refactor that prints the limit at the call site right after producer_plan (an adjacent duplicate), or beside SAMPLE_LIMIT (on every run, telling default-path readers about files never read), passes the gate.
- **Fix:** count lines (`out.splitlines().count(...) == 1`), and assert absence in case 1 and in the kepler run.
- An unsampled particle planted on two lines (x of body 7; vz of 63) is still a PASS, now with the line printed once beside it.

**2. Readers — confirmed.**
- On three cases at both commits — the default path (P1's seam), the producer path with NOT RERUN members, and a planted moon-x FAIL — every pattern captures identically:
  - P1's lines 994, 995, 1000 and 1027;
  - part 3's two patterns;
  - P2's lines 362–364, 593 and 621.
- None of them matches the limit line. `NOT RERUN` never matches `(IDENTICAL|FAIL)`. P2's non-greedy `.*?: (IDENTICAL|FAIL)` stops at "held to the record:", before the suffix.
- check_ring_seams `--quick` at 0bee543: 21 ok, PASS.

**3. Default path — confirmed.** Output is byte-identical at 2922fa1 and 0bee543 on all six setups.

**4. Your list.**
- **Pass counts — confirmed, with one weak spot.**
  - The gate now derives what each plant moves and prints it. At fp64: member 4 moves 26 tokens and the mean; member 5 the mean only; member 2 the mean and the max; member 0 moves 9 tokens, the mean and the max. At fp128 all four move 0 tokens.
  - The wordings at :97 and :698 are gone.
  - A plant that moves nothing fails, because its particles stay IDENTICAL.
  - **Weak spot:** `moves()` reads GATE 1's kept replays. If one is missing, it reports −1 tokens and all five counters moved instead of failing.
  - "At binary128, only the counters" is printed, not asserted, and only in the full gate; check-quick and check-light run fp64.
- **Mutants against `--quick`, matching P3:**
  - M1: 65 ok, 4 FAIL — the line naming the rerun's schedule, GATE 1b, the program-engine case, q2.
  - M2: 64 ok, 5 FAIL — the same four plus the half pair.
  - Mf2: 67 ok, 2 FAIL — the program-engine case, and q2's new member-0 plant.
  - Mj: 68 ok, 1 FAIL — the program-engine case.
- **`make -n`:** check-quick and check-light both run `check_compare_run.py --build build --quick` with no `--light`, so the 4-step program-engine case runs unscaled. It is a real run: 3 samples, and Mj is refused there. Everything it runs — ias15_cft on both engines, programs/out, compare_run.py, extract_particle.py — is in IN_COMPARE.
- **" and " path:** `--quick --build "…/runs/scratch and build/build"` gave 69 ok, PASS.
- **Corrections:**
  - The five whole-file reads match the code.
  - Tokens: the same fp64 plant moves 28 tokens on the member's full lines, and 9, 9 and 10 on each particle's replay columns. The sampled particles are bodies 2 and 3, so P3's 9 is right.

**5. Gate re-run — confirmed.**
- `--quick`: 69 ok, PASS. It ran cases 1, 3, 4, 5 and 7 (with the 4-step program-engine case), then q1–q7, a–p2 and i.
- Full: 105 ok, PASS, 07:01–07:43. P3's counts hold.
- The full count is unchanged because no full-tier line was added. The limit is asserted inside 8 existing verdicts, q2's fourth plant sits inside each q2 line, and GATE 1b's first line now derives its counters.
- `--quick` gained one line: the program-engine case (68 → 69).

**6. Anything else.**
- P3's report says the gate asserts the line "exactly once", which is false for adjacent copies.
- The gate asserts the limit in 4 of its 9 producer-path runs. The other five (half pair, `--member`, single problem, other producer, zonal) print it but nothing checks.

**NOT READY.** Two one-line gate fixes (count the line by lines; assert it is absent on the default path) and a reworded settings clause. The driver itself is right.
