You are a **verifier** of round 5's records. You try to disconfirm, and you report. You fix nothing.

## What to verify

Commit `4980440` on branch `round5-docs`, in the repository `C:\Users\logan\source\repos\cft-rebound`. It is one commit on `fda3b40`, by the round's docs drafter (D). It is **phase 1** of the round's records: what has landed so far (round 5's P1 and P3), and the corrections the ledger queued. It changes four documents:
- docs/VALIDATION.md: new entries 55 (P1) and 57 (P3), a corrected sentence in entry 54, and LEAD-FILL lines for entries 56 and 58;
- ROUND5.md: the queued corrections, in place;
- docs/RING.md;
- README.md.

These are the project's permanent record, and the integrator lands them. A wrong number there misleads every later round, and a claim stronger than its evidence is the failure this project exists to prevent. Phase 2 (P2, the lead's integration, CLAUDE.md, ROADMAP.md, ROUND5.md's status) comes later and is not yours now.

**D's report** is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\R5-D-report-1.md`. It lists every number D wrote, with its source, and eleven contradictions and choices. D's own brief is `...\scratchpad\gpu\briefs\filled\R5-D.md`.

**The lead's rulings on D's eleven items:**
- Items 1-3, 6, 8, 10 and 11: D's resolution stands.
- Item 4: both 5060 Ti figures go in at phase 2, each with its source: P1's 62 min and V1's 66 min.
- Item 5: P1's cost table stays, labelled MEASURED, with its host and conditions, as entry 54 did.
- Item 7: hw/gpu/costs.py's comment is code and stays. It becomes an open note in phase 2.
- Item 9: phase 2.

Check them anyway.

**The sources** (read only):
- the reports in `...\scratchpad\gpu\reports\`: R5-P1-*, R5-P3-*, R5-V1-*, R5-V3-*, and R5-P2-* and R5-V2-* for the corrections only;
- the ledger `C:\Users\logan\source\repos\cft-rebound\.ledger\`. lead.md is the authority on merges, suites, rulings and corrections;
- the suite logs in `...\scratchpad\gpu\`: int-check-4a8fe99.log, int-check-fda3b40.log and r5-check-d7b5047.log. The GPU seam's logs are in `gpu\lead-wsl\run-fda3b40.log` and `gpu\lead-wsl\seam-fda3b40-1118-1547\`;
- the commits, `git log --format='%h %s%n%n%b' 5b1cac6..fda3b40`;
- the code at fda3b40.

## How to work

- You are in an isolated worktree: run `git checkout --detach 4980440` first.
- No build is needed. Do not run any suite: others are running on this host.
- Do not edit any tracked file, here or anywhere.
- Stay out of `C:\Users\logan\source\repos\cft-rebound-r5` (the lead's), `C:\Users\logan\source\repos\cft-fp256` (another session's; read only), and the other worktrees.
- Never run bare `git stash`. Never push, merge or rebase.

## Check

1. **Every number against its source.** Use D's list as the index.
   - Check every number in the changed parts of RING.md, ROUND5.md and README.md, and every suite figure: times, leg counts and ok counts, which you recount from the logs yourself.
   - Check a sample of at least 40 across entries 55 and 57, covering both.
   - For each, report the source line and whether it matches. Report each mismatch exactly.
2. **Every claim against its label.**
   - Is anything stated as MEASURED that was only BELIEVED or READ?
   - Is anything a verifier refuted still stated? For example, V3's GATE 1b: a producer's files hold its arithmetic, not its decisions.
   - Does any sentence overstate what a gate holds? Read the gate's code where needed: tools/check_gpu.py, tools/compare_run.py, tools/check_compare_run.py.
3. **The corrections.** For each queued correction (lead.md 2026-11-16 16:55, 17:05 and 17:40, and V1's reports):
   - Was it made in the file that carried the wrong claim?
   - Is it corrected to what the source says, no more?
   - Is any wrong claim the queue named still standing somewhere else in the four files?
4. **README.**
   - Read the options it states against compare_run.py's argparse, and check-gpu's variables against the Makefile at fda3b40.
   - Is the cft-fp256 provenance row byte-identical to fda3b40's? Diff it; tools/check_pins.sh greps for it.
5. **The LEAD-FILL lines.** Are there exactly the five D lists, and no other placeholder, TODO or empty table cell?
6. **Consistency.** Do RING.md, ROUND5.md's corrections and entries 54, 55 and 57 agree with each other: the commits, the counts, the merge order, and who sent what back?
7. **D's eleven items and the lead's rulings.** For each, say whether the resolution is right.
8. **Anything else** a reader of these records would be misled by. In new text, Logan is named or called they/them.

## Report

- **For each item:** what you checked, what you found, and a verdict: confirmed, or defect with the exact text and its correction.
- **End with** READY or NOT READY for phase 1.
- **Length:** under 1,500 words. Your report is your final message. The lead may message you later for phase 2.
