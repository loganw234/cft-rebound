(R5-V2's report on its fifth look at P2's 9fa5956, its final message on 2026-11-20 at ~00:58, copied verbatim by the lead.)

**READY on 9fa5956.** The count rule holds both of my compare_run mutants in both forms, by name. None of the single weakenings of the rule I tried lets either through, and the 14 copies are unchanged. I ran on the desktop only, booked shared as B0208 (23:37–00:54, now released), never more than three runs at a time.

**1. Scope**
- MEASURED: `git diff --name-status 2d062cd 9fa5956` shows `M tools/check_wave.py` alone (+84/−1).
- READ, the whole diff: compare() now calls hold_counts() after every compare_run run. That covers all five call sites: the records, the controls, P, the 14 copies and E's plants.
- The expected counts come from record_counts(), which reads the record itself: each system's sample lines and `# body` lines, and widths from the `# columns:` words and `# active`. None comes from compare_run's output. Nothing else changed.

**2. Build** — MEASURED: detached at 9fa5956 and clean, nothing relinked. No file under build/ is newer, every .exe and .a keeps its mtime, and `make -q wave-host` returns 0.

**3. The tree** — MEASURED: --quick PASS 130/0 (26 count verdicts) and full PASS 144/0 (31), P2's numbers.

**4. My two mutants** — my fourth-look edits: `if i == 2: continue` and `if i >= 4: break` at the top of both sample loops. P2's mutants change the `for` lines instead. MEASURED: each FAILs by name in both forms, and every FAIL is a count verdict.

| mutant | --quick ok/FAIL | full ok/FAIL | where it FAILs |
|---|---|---|---|
| middle line skipped | 116/14 | 126/18 | every record, the unchecked control and copies 5, 6, 9–11; full adds P and E's plants |
| stops after four lines | 128/2 | 134/10 | --quick: C (13 lines) and D1 (5), as P2 says; full: every record longer than four lines, the unchecked control and E's plants |

A typical FAIL for the middle line: "member 0 says 4 samples, 1170 values, where the record's 4 sample lines ... at 390 values a line make 1560", and on particles 162 values against 216.

**5. The rule's own independence** (MEASURED, --quick, my own edits)

Three compare_run mutants, each of which only one part of the rule can catch, against the tree:
- No counts printed: FAIL 116/14, "IDENTICAL with no counts".
- A middle line skipped in the particle loop alone: FAIL 118/12, on the particle lines.
- Both loops cut to four lines after the length checks, so compare_run also reports 4 samples: FAIL 128/2, "says 4 samples, 1560 values, where the record's 13 sample lines ... make 5070".

Mutants of the rule itself:
- The particle width one short fails the tree itself, 118/12 ("at 53 values a line make 212").
- Three weakenings, each run beside my two mutants (middle line, then four-line cap):

| weakening of the rule | middle line ok/FAIL | four-line cap ok/FAIL |
|---|---|---|
| expected counts taken from compare_run's output | 116/14 | 128/2 |
| particle lines skipped | 118/12 | 128/2 |
| plant copies skipped | 107/9 | 114/2 |

**None of these lets either of my mutants through.**
- Two weakenings do pass, 130/0 each, but only beside the narrower mutant each one leaves unheld:
  - expected counts from the output, beside the cut that also reports four samples;
  - particle lines skipped, beside the particle-only skip.
- So the record's own count and the particle half of the rule are each needed, and the tree has both.

**6. The copies** — MEASURED: I compared all 14 copies, in both forms, against 2d062cd's from my fourth look. Raw, they differ only on line 218 (`system_steps_per_s`, `wall_seconds`); with those masked, they are identical.

**For the merge message** (from my fourth look; none of these blocks):
- The sample-0 rule pinned to sample 1 still passes, because sample 1's plants satisfy it. That is a weakened rule, not a missing plant.
- P2's shapes 1, 2, 3 and 5 stay open notes: steps_done and the (k, step) checks, which no record plant can reach; the selection loops; the trailer-key presence check; and the whole-run refusals.

**Housekeeping**
- The mutant trees are deleted, and the worktree is clean at 9fa5956.
- The logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\sb4\logs.
- Ledger entries are in V2.md at 23:39 and 00:58.
- I stopped three idle `tail -f` processes left by my own monitors. Nothing of mine is running.

**READY**
