(R5-V2's report on its third look at P2's f3ef701, its final message on 2026-11-19 at ~15:28, copied verbatim by the lead.)

**NOT READY on f3ef701.** The tree passes, and all four of your mutants fail in both forms. The gap is in the new coverage verdict: three one-line edits that make check_wave plant less still pass it. No compare_run mutant you asked about passes; what isn't held is check_wave's own coverage. I ran on the desktop only, booked shared as B0198 (13:11–15:24, now released), never more than three runs at a time.

**1. Scope**
- MEASURED: `git diff --name-status 8f559c8 f3ef701` shows `M tools/check_wave.py` and nothing else (+115/-55).
- READ (whole diff): the changes are record_classes(), plants(), hold_plants()' bookkeeping, the coverage verdict and part 5's header comment. Two more, both serving the plants: a new Cols attribute, `step_named`, and a decimal counter's new value is now chosen by the "." in it rather than by its name.
- READ: Cols raises when a record has no "step" word, so in practice the step class is always present.

**2. Build** — MEASURED. I checked out f3ef701 detached, clean, and ran `make all programs wave-host` with mingw64 first. Nothing relinked: no file under build/ is newer, every .exe and .a keeps its mtime, and `make -q wave-host` returns 0.

**3. The tree** — MEASURED, matching P2's numbers.
- --quick: RESULT: PASS, 81 ok, 0 FAIL. Full: RESULT: PASS, 90 ok, 0 FAIL.
- 30 plants in 11 copies. The step field is planted in all three members, on the first sampled line (lines 206–208) and the last (212–214).
- The 11 plant copies differ between the two forms only in the totals trailer's timings, and the plant verdicts match line for line.

**4. The four mutants** — MEASURED. Each edit lands exactly once; the script refuses at 0 and at 2 landings, and I showed both refusals.

| mutant | --quick ok/FAIL | full ok/FAIL | what FAILs |
|---|---|---|---|
| (i) step checked in member 0 only | 77/4 | 86/4 | members 1 and 2's step plants, both lines |
| (ii) step never checked on sample 1 | 78/3 | 87/3 | the three sample-1 step plants |
| (iii) member 2 never planted | 70/1 | 79/1 | the coverage verdict |
| (iv) no counter planted | 74/1 | 83/1 | the coverage verdict |

- For (iii) and (iv), the coverage verdict is the only line that FAILs, and it names each gap:
  - (iii): member 2's eight class-and-line gaps ("class step not planted in member 2 on its first sampled line", and so on), its missing counter, and the seven columns that only member 2 carried.
  - (iv): "class counter not planted" in members 0, 1 and 2, and each of the five counters.
- My (i) and (ii) edits sit at different lines from P2's.
- My (iii) and (iv) edits in plants() turned out character-identical to P2's when I compared afterwards. So I added a second pair in hold_plants(), skipping member 2's plants or every counter plant as they are made. They fail the same way: 70/1 and 79/1, then 74/1 and 83/1, with the same gaps named.

**5. What holds the coverage verdict** (MEASURED, --quick unless a full count is given)
- **plants(): held.**
  - READ: the verdict reads the plants hold_plants() actually made, not how plants() dealt them out.
  - A plants() that never chooses the last sampled line FAILs 80/1, naming all 12 last-line gaps, as do (iii) and (iv) above.
- **record_classes(): not held.** The verdict reads the classes "again" through the same function.
  - Dropping the step class passes: 75/0, and 84/0 in full. It makes 24 plants, none in the step field, and the verdict's class list simply leaves "step" out.
  - Dropping one counter passes: 81/0, with max_pc_iterations never planted.
  - The cost: the step-class drop plus mutant (i) passes check_wave, 75/0. Send-back 1's gap is open again behind one line.
- **The line actually written: not held.** The verdict records each plant's planned line, not the line it wrote.
  - A hold_plants() that keeps only sample 1 (`[1:]` changed to `[1:2]`) passes: 81/0, and 90/0 in full.
  - Every plant meant for the last line lands on lines 206–208, and sample 3 is untouched. The verdict still says "first and last sampled lines".
  - BELIEVED: a record with only one sampled line would pass the same way.

**6. Left-out members: held in the tree, but not guarded by the verdict**
- MEASURED: copies 9, 10 and 11 leave out members 0, 1 and 2, and each says "member(s) N IDENTICAL, their particles too".
- MEASURED, the check bites:
  - Flipping t in each left-out member's first sampled line FAILs 75/6.
  - Changing one left-out particle line to FAIL, with its member line untouched, also FAILs 75/6.
  - In both, every verdict of copies 9–11 names its quiet member.
- READ: the "exactly two particles" condition is part of the same check; I did not test it on its own.
- MEASURED, not guarded: moving plants()' left-out copies past the end (`left = {C + w: ...}`) passes 81/0.
  - Copies 1–10 plant all three members, and copy 11 is the clean record with nothing planted.
  - No verdict holds any member IDENTICAL next to a planted one, yet the coverage verdict says "each member left out of a copy". An empty copy satisfies it.

**Send-back** (the coverage verdict in tools/check_wave.py only)
1. Take the expected classes from something other than record_classes(). For example, parse the `# columns:` words and every member's trailer keys inside the verdict, or check against `COUNTERS` (line 123) and the four class names.
2. Record the line each plant was written on. Require each member's first and last sampled lines, found inside the verdict, and require them to differ.
3. Count a member as left out only in a copy that planted another member and held it IDENTICAL.

After that, my four passing mutants (step class dropped, max_pc_iterations dropped, last-line plants on sample 1, left-out copies past the end) must each FAIL by name.

**Cleanup**
- The mutant trees are deleted, and the worktree is clean at f3ef701.
- The logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\sb2\logs.
- Ledger entries are in V2.md at 13:12, 14:52 and 15:27.
- My report at 08:57 this morning said nothing of mine was running, which was wrong. I found and stopped 19 idle `tail -f` processes (their greps then exited) left by my own monitors since 11-18. They only read my own logs, used no CPU and wrote nothing. Nothing of mine is running now.

**NOT READY**
