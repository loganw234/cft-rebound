# PL (round 5)

## 2026-11-19 05:29 - Fix 1, the PROGRAMS key: the images named from programs/*.cfta (3012353)

Base: branch round5-pl at fda3b40, in my worktree (agent-ac15ed035e5aaef0b). Pins cloned locally from the main checkout's copies, cft-fp256 at eae74e3e and rebound at bdfda4b (MEASURED, `git rev-parse HEAD` in each). Built `all programs` 05:24:30 to 05:25:57, rc 0, `cc -dumpmachine` x86_64-w64-mingw32, "assembled 66 programs" (MEASURED).

**The fix** (Makefile, the PROGRAMS line):

    PROGRAMS := $(sort $(patsubst programs/%.cfta,programs/out/%.cftp,$(wildcard programs/*.cfta)) \
                       $(wildcard programs/out/*.cftp))

- The sources give the 66 whether or not programs/out exists when make reads the file.
- The union keeps what fda3b40's wildcard keyed: an image in programs/out with no source.
  - Why it matters, READ: tools/check_gravity.py lines 175-187 lists programs/out and FAILs on any gravity image the binary does not carry.
- `$(sort)` drops the duplicates, so a built tree lists each image once.

**Evidence, MEASURED.** Method: `make -n` of check, check-quick and check-light. scratchpad/pl/legs_inputs.py reads each `--leg` line's `--input` words; scratchpad/pl/mkn.sh runs the three tiers.
- **Fresh tree** (my worktree before the build: no build/, no programs/out):
  - fda3b40's Makefile: no programs/out file on any of the 25 legs, in all three tiers.
  - The fix: the same 66 on check_program_engine, check_corrector, check_replay, check_gravity, check_zonal, check_scalar, check_ring, check_compare_run, check_seams and check_ring_seams. The other 15 legs' sets are unchanged.
- **Built tree** (66 .cftp): the fix's sets equal the fresh tree's on all 25 legs, and equal fda3b40's Makefile's on all 25 legs, in each tier. So no stamp's key moves in a built tree.
- **Built tree, programs/out moved aside:** fda3b40's Makefile again lists none, and the fix lists the 66 on the same 10 legs, the sets equal to the built tree's.
- **A stray image planted** (gravity-fold512-fp64.cftp, a copy, then removed):
  - fda3b40's Makefile and the fix list it on the 10 legs, with identical sets on all 25.
  - The derivation alone (scratchpad/pl/Makefile.pure) drops it from those 10.

**Found, not fixed** (READ):
- The check_ensemble leg lists no program images in any tree, yet tools/check_ensemble.py runs three program-engine cases with `--programs programs/out` (lines 101 and 137-150). An image that changes while the binary does not would let check-quick skip a leg that executes it. Not touched: the brief keeps every other leg's inputs as they are.
- A program new in tools/gen_programs.py is written by `programs` after make has read the file, so it is keyed from the next make on. The Makefile comment says so.

## 2026-11-19 05:40 - Fix 2, limit_absent: the change, the mutant copies, and the runs started (uncommitted, under test)

**The change** (tools/check_compare_run.py; git hash-object b77e7944 is the file under test):
- **(a) Indentation.** `limit_lines()` takes every line that holds the limit's opening words (LIMIT_OPENS) anywhere in it. Both readers use it:
  - `limit_absent()`;
  - `limit_once()`'s "no other line". It had the same gap: a test of the line's start, so an indented second copy passed. That one is beyond the brief, and has its own mutant, M5.
- **(b) Every run.** `drive()` keeps every run of the driver without --producer-files, with the limit's lines from its whole stdout and stderr.
  - One closing verdict, before RESULT, holds that none printed one.
  - It counts the runs: all of them; with --plan; with --rerun-engine; at binary128 or binary256; in the FMA form; through a copy of the driver.
  - It FAILs if any of the first four kinds is missing, and names each run that printed the line, with the line.
  - READ: drive() is the only place check_compare_run starts the driver. No other call does it.
- **Case 6 now runs in every tier**, 4 steps in --quick.
  - READ: with case 6 in full only, --quick had no run with --rerun-engine and without --producer-files. Case 7's two --rerun-engine runs both carry files.
  - So no change to the gate could make the M2 mutant FAIL --quick without such a run.
- The per-run checks on case 1 and case 5 are kept.

**The copies.** scratchpad/pl/mutate.py copies compare_run.py with the 7 files it imports or runs (control i's list, plus P3's two) into mutants/<M>/tools/. It inserts lines after one anchor, and REFUSES unless the anchor lands exactly once. MEASURED:
- X0 (anchor absent): "REFUSED: its anchor lands 0 times".
- X2: "lands 2 times". X3: "lands 3 times".
- M0: identical to tools/compare_run.py. M1 to M4 add 2 lines each, M5 adds 1. All 7 siblings are identical to the tree's.

What each copy does with the limit's line:
- M1: prints it indented by two spaces on the default path (`else:` of the --producer-files branch).
- M2: prints it only with --rerun-engine and without --producer-files.
- M3: prints it only under --plan, without files.
- M4: prints it only when the record's file is waves_fp128_short.rec or waves_fma_short.rec, case 4's two names, without files. Control e drives those same files but is REFUSED before that point.
- M5: prints an indented second copy after the limit on the producer path.

**Smoke, MEASURED** (scratchpad/pl/smoke.py, 05:34 to 05:38). Short records of the gate's own waves under the gate's names; each copy run on five kinds of run. The count is the lines carrying the limit; "i" means one of them is indented:

| run | M0 | M1 | M2 | M3 | M4 | M5 |
|---|---|---|---|---|---|---|
| default path | 0 | 1i | 0 | 0 | 0 | 0 |
| --plan | 0 | 1i | 0 | 1 | 0 | 0 |
| case 4's binary128 record | 0 | 1i | 0 | 0 | 1 | 0 |
| --rerun-engine loop | 0 | 1i | 1 | 0 | 0 | 0 |
| --producer-files, empty dir | 1 | 1 | 1 | 1 | 1 | 2i |

Every one of the 30 runs ended PASS (or PLAN) with rc 0. So only the limit's line can catch these copies.

**Runs.** Booked B0187 (desktop, shared, 05:39 to 09:30), with the queue's pids 18164 and 42908 attached. scratchpad/pl/queue.sh runs jobs.txt, at most 5 at once, each with its own --build dir holding copies of the two binaries:
- the fix (the worktree's gate): clean full and quick; M0 quick; M1 to M5, quick and full;
- fda3b40's gate (a git archive of fda3b40's tools and data, with programs/out copied): clean quick; M1 to M5 quick; M2 full.

## 2026-11-19 06:39 - Fix 2: the fix's gate in full, clean and M1 to M4 (MEASURED)

Five runs at once beside V2, 05:39 to 06:39, the CPU near 100%. No timing is claimed. Logs are in scratchpad/pl/logs/.
- **Clean** (the tree's own compare_run.py): PASS, rc 0, 109 ok, 0 FAIL. That is fda3b40's 108 plus the closing verdict; case 6 already ran in full. The closing verdict: "none of the 48 runs of the driver without --producer-files printed a line of it ... (10 with --plan, 1 with --rerun-engine, 4 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)".
- **M1** (indented, default path): FAIL, rc 1, 103 ok, 6 FAIL.
  - Case 1's absence at fp64, fp128 and fp256.
  - Case 5's two records.
  - The closing verdict, "printed by 37" of the 48: every run but the 8 refused before that point (e and f twice each, g four times) and control i's 3, which hold a copy of the tree's driver and not the --driver one.
- **M2** (--rerun-engine only): FAIL, rc 1, 108 ok, 1 FAIL. The closing verdict, "printed by 1: waves_fma_program.rec --rerun-engine loop".
- **M3** (--plan only): FAIL, rc 1, 108 ok, 1 FAIL. The closing verdict, "printed by 10: waves_fp64.rec --plan --seed 1 ...".
- **M4** (case 4's records only): FAIL, rc 1, 108 ok, 1 FAIL. The closing verdict, "printed by 2: waves_fp128_short.rec ...; waves_fma_short.rec ...".

## 2026-11-19 08:14 - Fix 2 committed (5fa7534): every run, both tiers, both gates (MEASURED)

The committed tools/check_compare_run.py is blob b77e7944, the file all 20 runs held. git hash-object was the same at 05:39, at 08:04 and at the commit.
- The queue: 05:39:30 to 08:10:22, at most 5 at once beside V2. No run printed a Traceback.
- Booking B0187 released 08:13. No process of mine is left.

**The clean tree:**
- The fix's gate:
  - --quick: PASS, 73 ok. That is 70 plus case 6's two verdicts plus the closing verdict, which reads "none of the 46 runs ... (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)".
  - Full: PASS, 109 ok (48 runs).
- fda3b40's gate: --quick PASS, 70 ok. In full it held M2 and PASSed, 108 ok, the lead's figure.
- M0, a pristine copy, under the fix's gate: --quick PASS, 73 ok, its 73 verdict lines identical to the clean run's (diff).

**The mutants** (FAIL counts are the gate's `  FAIL ` lines):

| copy | the fix, --quick | the fix, full | fda3b40's gate |
|---|---|---|---|
| M0, unedited | PASS, 73 ok | not run | not run |
| M1, indented, on the default path | FAIL, 69 ok, 4 FAIL: case 1's absence, case 5's two, closing ("printed by 35") | FAIL, 103 ok, 6 FAIL: case 1 at 3 formats, case 5's two, closing ("printed by 37") | --quick PASS, 70 ok |
| M2, --rerun-engine without files | FAIL, 72 ok, 1 FAIL: closing, "printed by 1: waves_fma_program.rec --rerun-engine loop" | FAIL, 108 ok, 1 FAIL: the same | full PASS, 108 ok; --quick PASS, 70 ok (no case 6 in its --quick: no "case 6" line in the log) |
| M3, --plan only | FAIL, 72 ok, 1 FAIL: closing, "printed by 10: waves_fp64.rec --plan --seed 1 ..." | FAIL, 108 ok, 1 FAIL: the same | --quick PASS, 70 ok |
| M4, case 4's records only | FAIL, 72 ok, 1 FAIL: closing, "printed by 2: waves_fp128_short.rec ...; waves_fma_short.rec ..." | FAIL, 108 ok, 1 FAIL: the same | --quick PASS, 70 ok |
| M5, an indented 2nd copy, producer path | FAIL, 61 ok, 12 FAIL: every producer run's limit_once | FAIL, 89 ok, 20 FAIL: the same at 3 formats | --quick PASS, 70 ok |

**That the passes were the gap.** scratchpad/pl/verify_gaps.py drives each copy again, with the gate's own arguments, on the files the fda3b40 run left. It applies both gates' own readers to the output (verify_gaps.log, 08:11 to 08:13):
- M1, on case 1's fp64 record and on case 5's --member 3 record: the line is printed indented. fda3b40's limit_absent says True (absent); the fix's says False.
- M2 (case 6, --rerun-engine), M3 (--plan, seed 1) and M4 (both of case 4's records): the line is printed at the start. Either reader catches it (False). fda3b40's gate never asked on those runs.
- M5, on case 7's fp64 producer run: two lines. fda3b40's limit_once says True; the fix's says False.

**Found, not fixed** (READ unless marked):
- **Control i ignores --driver** (READ). It copies tools/compare_run.py from `here`, not the --driver copy, so its three runs hold the tree's driver. A mutant in P3's not-callable path would pass `--driver`.
  - Consistent with M1's full run (MEASURED): 37 of the 48 runs printed. The other 11 match the 8 refused before M1's line (e, f, g) plus control i's 3.
- **Refused runs that read a producer's files.** q3 to q7 and the other-engine record without --rerun-engine read files but are refused. The gate holds no limit there, neither once nor absent. Today the driver prints the limit before its key check refuses (BELIEVED from producer_plan's order).
- **A stderr tail.** drive() appends only the last 600 characters of stderr to what the per-run checks read. The closing verdict reads the whole stderr.
- **A shared name.** hold_clean has its own local `unread`, the rejecting members it could not read. main's new `unread` list is a different scope, so they never meet. A rename would be cosmetic, and was not made, to keep the committed file the tested one.
- **check-gpu.** Its check_compare_run leg is the --quick command, so it now also runs case 6 on the device: one 4-step program-engine record and two driver runs. BELIEVED to need nothing new: case 7's --quick already runs a program-engine record there. Not run on a GPU.

## 2026-11-19 08:27 - Send-back 1: check_ensemble keys on the program images (cc3d87a)

**The change:** `$(IN_PROGS)` added to the three check_ensemble lines (check, check-quick, check-light), and nothing else. `git diff --stat 5fa7534..cc3d87a`: Makefile, 3 insertions, 3 deletions. `git status --short` is empty after the commit.

**1. The keys, MEASURED.** Method: `mkn.sh` and `legs_inputs.py compare`, 5fa7534's Makefile against the fix, all three tiers. The fresh tree is the worktree with build/ and programs/out moved aside, then moved back.
- Built and fresh alike, check_ensemble alone changes: 8 inputs become 74, the 66 images added.
- Every other leg's set is unchanged.
- The fresh sets equal the built sets, under both Makefiles.
- 11 legs now list programs/out, all with one and the same set of 66 files.

**2. The cache, MEASURED.** Done in the worktree's own build/ and build/.gate-cache. Each run is the check-quick check_ensemble line exactly as `make -n check-quick` printed it: scratchpad/pl/cc/line_old.txt from 5fa7534's Makefile, line_new.txt from the fix's. The step log is scratchpad/pl/cc/steps.txt.
- **The image** is programs/out/predict-ens-fp64.cftp.
  - READ: load_programs() (src/ias15_cft.c:1966) loads "predict-ens" when use_ens_predict, which is the program engine with E > 1 and adaptive steps (:4676). check_ensemble's --quick runs fp64 only, and two of its cases are adaptive program-engine ensembles.
  - MEASURED (cc/load_probe.log): case "kepler vscale E=5 adaptive eps=1e-9, program engine", run as check_ensemble builds it, on a copy of programs/out without that file, exits rc 3: "cannot open program image .../predict-ens-fp64.cftp". Its member 0 run alone on the same copy is rc 0.
  - The change is byte 0x24, 0x06 to 0x05, one byte (cmp -l: `37 6 5`). Run on a scratch copy holding it, the ensemble moves 5 of its 10 data lines. The member alone moves none; only its timings differ.
- **5fa7534's line.** First run: PASS, the stamp fd5db2bb532a written with 8 inputs. Run again: "check_ensemble: SKIPPED - inputs unchanged since it passed (fd5db2bb532a, quick run)". With the byte changed (image sha256 aee5e2d4..): SKIPPED again, the same line. Image restored.
- **The fix's line.** First run on the restored image: it runs, because the inputs changed. PASS, the stamp d5dbf84d504a written with 74 inputs. Run again: SKIPPED (d5dbf84d504a). With the byte changed: it ran, rc 1, RESULT: FAIL. The 2 FAILs are the two adaptive program-engine cases, each "member 0: first difference at sample 1 (step 30) column 0". The stamp was retired.
- **Restored.** All 66 images match the baseline sha256. The fix's line then ran, PASS, and wrote the same key, d5dbf84d504a.
  - `make programs` (08:26) rewrote programs/out. Its 66 sha256 equal the baseline taken before the control. So programs/out is what `make programs` writes. The tracked .cfta are unchanged.

**Found, not fixed** (READ; the brief says nothing else):
- check_ensemble's key still lacks tools/check_equivalence.py (imported, line 24) and tools/make_ensemble.py (run, lines 118-125). check_program_engine's key lists both.
- check_records imports check_equivalence (line 23), and it is not in its key.
- check_bodycount imports check_equivalence (line 41) and runs make_nbody.py (line 66), neither in its key.
- scratchpad/pl/leg_scripts.py's survey also names some files that are not findings:
  - make_ensemble.py for check_compare_run and check_ring_seams, reached only through check_ensemble's main(), which neither calls;
  - compare_formats.py and oracle.py for check_ring_seams, reached only through compare_run's --format-diff path, which check_ring_seams never passes.

No booking: each run of check_ensemble --quick took about 51 s, and the whole control about 5 minutes. No process of mine is running.

## 2026-11-19 09:00 - Send-back 2: the cache-key audit, and its six inputs added (e8a7d89)

**The audit** is scratchpad/pl/audit_keys.py, not committed; run it as `audit_keys.py TREE MAKE_N_OUTPUT [--json OUT]`. Its rules (the file's docstring has them in full):
1. **The start.** Each `--leg` line's command after `--`. A Python leg starts from its script run as __main__. A binary leg is its own key input, and its C source is READ by hand.
2. **What is reached, by ast.**
   - `import M`, `from M import f` and importlib.import_module("M"), where tools/M.py exists: M's top-level code, and f.
   - A name that is a top-level def or class of the same module, or `A.f` on a module alias.
   - Any tools/X.py the code builds a path to is run as __main__, except a shutil.copy source, which is read as data.
   - A def nothing reachable names is never entered.
3. **Paths, by a small evaluator.** It reads string constants, f-strings, `+` and `%`, os.path.join/dirname/abspath/normpath/basename, `x if c else y`, names assigned in the same def or at module level (`x += "s"` too), and loop names over literal lists, tuples included.
   - Arguments at call sites are bound to a def's parameters, iterated until nothing grows.
   - `args.<dest>` comes from the leg's command line, or else the add_argument default, evaluated in the scope that declares it.
   - Skipped: docstrings, help/description strings, add_argument defaults at the declaration, and what open(...,"w"), makedirs, rmtree and the destinations of copies write.
   - A path counts only if it has no whitespace, lies in the tree, and its first part is tools, build, data, results, src, tests or programs.
4. **Classes of path.**
   - An existing file there is needed. A directory means every file directly in it.
   - build/: only a .exe/.a/.h/.dll/.so directly in build/; deeper is the leg's scratch.
   - A path with an unknown part is UNRESOLVED, by file:line, its unknown parts made `*` and globbed against the inputs.
   - third_party/ is reported as outside the roots, never needed.
5. **MISSING** is needed but not an --input. Every MISSING and UNRESOLVED line was READ before acting.

**Its findings at cc3d87a** (MEASURED): the full output is scratchpad/pl/audit_check.txt, 92 lines, and audit_check-quick.txt and audit_check-light.txt. All three tiers give the same findings: 25 legs each, 8 MISSING lines.

READ, line by line:

| leg | MISSING | READ |
|---|---|---|
| check_records | tools/check_equivalence.py | imported at check_records.py:23. **Added** |
| check_ensemble | tools/check_equivalence.py | imported at :24. **Added** |
| check_ensemble | tools/make_ensemble.py | run at :118-125, every run. **Added** |
| check_bodycount | tools/check_equivalence.py | imported at :41. **Added** |
| check_bodycount | tools/make_nbody.py | run at :66 when build/problems/nbody<N>.txt is absent. MEASURED: the first run wrote nbody256, nbody1024 and nbody1025. **Added** |
| check_bodycount | src/ias15_limits.h | cap_from_source() reads it (:56), called from main at :88. **Added** |
| check_ring_seams | tools/compare_formats.py | compare_run.py runs it only in format_diff(), called only under `args.format_diff` (:1375-1376). check_ring_seams' driver command (:418-419) has no --format-diff, and drive() changes only the record. **Not added** |
| check_ring_seams | tools/oracle.py | imported only by compare_formats.py. **Not added** |

UNRESOLVED, every one READ:
- data/problems/* (check_corrector, 16 sites; check_scalar:746), programs/out/* (check_gravity:178, check_ring:329) and results/horizon/reversal/* (check_reversal:334-335): all inputs.
- **check_scalar.py:207 src/*:** with_includes() reads each `#include "*.inc"` of src/ias15_cft.c. The only one is ias15_zonal.inc (:1555), an input.
- **check_compare_run.py:1960 tools/*:** control i copies a literal tuple of six files, then P3's two, all inputs. The audit merges `f`'s other loops in main.
- **check_reversal.py:246 tools/*:** mutate() copies TOOLS = reversal.py, state_to_problem.py and check_equivalence.py (:95), all inputs. Same merging.

The rest, READ:
- **absent** programs/out/ring_*.txt (check_ring:329): the same merging. The line lists programs/out's .cftp.
- **written, not read:**
  - gen_constants: only without --no-write; the leg passes --no-write, and :493-495 return first.
  - check_zonal:633: only under --write-problem.
- **Outside the roots:**
  - constants reads third_party/rebound/src/integrator_ias15.c (:397, :442), not in its key. Not acted on: outside the roots you named.
  - check_corrector's third_party/cft-fp256/programs/MANIFEST is an input.
- **Binary legs, READ.** No fopen, spawn or exec in their C sources outside their keys.
  - check_dropin: tools/check_dropin.c, dropin_common.c and cases_*.c (CASES_SRC). The library half loads nothing from disk, and cft_rebound_run.c is not linked (cases_forces.c:664).
  - gate_real: tests/gate_real.c and cft_archive.c, which reads and writes the gate's own checkpoints.
  - gate_subprocess: tests/gate_subprocess.c spawns the program its --build names, through cft_rebound_run.c. IN_SUBPROC has ias15_cft.exe. No --engine or --programs is passed, so no image is loaded.

**Stop rule:** 6 inputs to add, each a per-leg --input, so under 15 and no new shared variable. No IN_* variable is used by exactly these legs, so they are added per leg.

**The fix (e8a7d89).** Makefile only, 9 lines, the 3 legs in each of the 3 tiers:
- check_records gains `--input tools/check_equivalence.py`;
- check_ensemble gains `--input tools/check_equivalence.py --input tools/make_ensemble.py`;
- check_bodycount gains `--input tools/check_equivalence.py --input tools/make_nbody.py --input src/ias15_limits.h`.

**Evidence, MEASURED.**
1. **The keys.** `mkn.sh` with cc3d87a's Makefile and with the fix, tree built and fresh (build/ and programs/out moved aside, then back), and `grow_check.py`.
   - All 6 of the tier and tree combinations: "PASS: 25 legs; every leg grew by exactly its audit list and none lost an input".
   - Fresh equals built, with the fix.
   - The audit rerun on the fix's make -n: only check_ring_seams' two READ-pruned lines remain, in every tier.
2. **The cache, one control per kind.** scratchpad/pl/control2.sh, 08:51:39 to 08:57:12, in this worktree's build/.gate-cache. Each line run exactly as make -n check-quick printed it. Log: cc2/steps.txt. One byte of a comment changed each time (a capital made small; onebyte.py refuses a line that is not a comment).
   - **An import** (check_equivalence.py:5, with check_records): cc3d87a's line SKIPPED, stamp feeaf7a19588. The fix's line ran, PASS, 4 ok.
   - **A script run** (make_nbody.py:5, with check_bodycount): cc3d87a's SKIPPED (b0e0f532fe6b). The fix's ran, PASS.
   - **A file read** (src/ias15_limits.h:4, with check_bodycount): cc3d87a's SKIPPED (b0e0f532fe6b). The fix's ran, PASS.
   - Each run on the fix's line started from its own stamp held (SKIPPED by name: e7f0b31f2c51 and fcff2ff0ea53).
   - Restored from cp -p copies: the final sha256 equals the baseline for all three, and `git hash-object` equals HEAD's blobs (f850fb8c, c6c70892, 25af6b68).
3. `git status --short` is empty after the commit.

Booking B0193 (desktop, shared, 08:51 to 09:45, pids 37840 and 39148): released 08:57, both pids gone.

**Found, not fixed:**
- **Cached problem files.** check_bodycount keeps the nbody<N>.txt it generates in build/problems and reuses them (:63-71), and check_gravity does the same with its own (READ :198-200). So a changed make_nbody.py now reruns the leg, but on the old problem until that file is deleted.
  - MEASURED: the fix's run after the make_nbody change passed on the problems the first run wrote.
- **The constants leg** reads third_party/rebound/src/integrator_ias15.c, outside the roots and its key.
- **The audit's limits:**
  - imports outside tools/ are not followed (check_zonal's cft_golden, which IN_ZONAL lists);
  - binding is flow-insensitive, so merges give the spurious UNRESOLVED and absent lines above;
  - a script one leg runs (compare_run.py) gets its own defaults, not the caller's arguments.

## 2026-11-19 13:31 - Send-back 3: the constants leg keys on REBOUND's integrator_ias15.c (4fcd775)

**The fix (4fcd775, on e8a7d89):** `--input third_party/rebound/src/integrator_ias15.c` added to the constants line in the three tiers (Makefile 729, 764, 802). That is 3 lines; nothing else changes. `git status --short` is empty after the commit.

**Third_party/, rechecked in every leg.** Three independent ways:
1. **grep, READ.** All of tools/*.py, src/ and tests/ for "third_party", comment lines aside. Six sites:
   - gen_constants.py:416: the default of --rebound-src, read at :397 and :442. The finding.
   - check_corrector.py:189: cft-fp256's programs/MANIFEST, an input.
   - check_zonal.py:120: sys.path gets third_party/cft-fp256/python, for its cft_golden imports.
   - check_gpu.py:259 and :1343: check-gpu is no gate_cache leg.
   - make_problems.py:89: no leg runs it (grep of tools/ and the Makefile).
   - src/ and tests/ name none.
2. **The audit, rerun with third_party/ as a root** (audit_keys.py --third-party-root, all three tiers at e8a7d89):
   - the only third_party file MISSING is this one, in the constants leg;
   - check_corrector's MANIFEST is needed and an input;
   - by the audit's needed sets, only constants, check_corrector and check_zonal reach the five tools that name third_party/ (tp_reach.py); the other 22 legs reach none of them.
3. **Dynamic, MEASURED.** An audit hook (scratchpad/pl/trace_site/sitecustomize.py, through PYTHONPATH, so in every Python process each leg starts) logs every open, import, listdir and process start under third_party/. It ran on the three legs' check-quick commands, 13:23 to 13:29:
   - constants opens only integrator_ias15.c;
   - check_zonal opens only nine cft_golden modules: __init__, augmented, chars, formatof, formats, reduce, softfloat, transcend and vectors. All are in GOLDEN_PY. Two directory listings are the import machinery's;
   - check_corrector opens only programs/MANIFEST, an input.
   - The lazy imports in those nine are mpmath, math, and vectors.py:531's pi_worstcase. check_zonal calls only softfloat functions and formats (READ), so none of them reaches third_party/.

So MANIFEST is not needed in the constants key: the leg's only read under third_party/ is integrator_ias15.c, now keyed by its bytes. A pin move that leaves those bytes alone cannot change the leg; one that changes them changes the key.

**The keys (MEASURED).** make -n of the three tiers, tree built and fresh (build/ and programs/out moved aside), e8a7d89's Makefile against the fix. grow_check3.py, all 6: "PASS: 25 legs; every leg grew by exactly its audit list and none lost an input". Only constants grows, by the file.

**The control, through make (MEASURED).** control3.sh, 13:30:01 to 13:30:10, in this worktree's build/.gate-cache. Each step runs the constants line exactly as `make -n -f <Makefile> check-quick` prints it then. The log is scratchpad/pl/cc3/steps.txt.
- e8a7d89's line ran, PASS, 78 constants matching; stamp 4210bd53eb4f, 1 input. Run again: "constants: SKIPPED - inputs unchanged since it passed (4210bd53eb4f, quick run)". That is the tip's stamp in place.
- **The edit** (edit_h1.py): h[1] 0.0562625605369221464656521910318 to ...369321..., line 185, byte 10691, '2' to '3'. The clone's git status shows ` M src/integrator_ias15.c`.
  - The bare literal occurs twice (also :1002, mpf_set_str), so the edit anchors on the h[8] array's own text and refuses unless that lands once.
  - Shown on copies: the bare anchor is refused ("lands 2 times"); a second application is refused ("lands 0 times").
- **e8a7d89's line:** SKIPPED (4210bd53eb4f).
- **The new line:** ran, rc 1, "78 constants compared, MISMATCHES; DERIVATION CHECK FAILED"; the stamp retired.
  - gen_constants.py run directly: rc 1, "FAIL h[1]: derived 0.05626256053692215, REBOUND literal 0.05626256053693215".
- **Restored** from the cp -p copy: byte for byte, sha256 085a0bcb.. (the baseline), the clone's git status empty, HEAD bdfda4b.
  - The new line ran, PASS; stamp 0e3b9434b62f, 2 inputs. Run again warm: SKIPPED (0e3b9434b62f).

The third_party clone was touched by that edit and its restore only. No booking: the trace took 6 minutes and the control 9 seconds. No process of mine is running.
