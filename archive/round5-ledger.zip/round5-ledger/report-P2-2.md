(R5-P2's final report, its final message on 2026-11-18 at ~12:44, copied verbatim by the lead.)

P2 is done at **82b75b8**. On the RX 7600 the kernel matches the CPU port and its own host twin bit for bit, just as on the 5060 Ti, and every gate passes. The full `make check` at 82b75b8 passes and matches P0's suite leg for leg. All my bookings are released, nothing of mine is running on any host, and the worktree is clean.

## Final tip and what changed
82b75b8 is one commit on top of 81af26a, made this morning after a problem the RX 7600 exposed:
- **The problem:** gate 4's random test inputs depended on the compiler. A call like `add_case(c, R.any(), R.any())` makes two random draws, and C++ leaves their order to the compiler: g++ draws the last argument first, clang the first. So the RX 7600 build (clang) tested a different set of operands than the desktop and the 5060 Ti (both g++). Its first gate 4 still passed, with 0 mismatches.
- **`src/wave/wave_corpus.cpp`:** every such draw now happens in g++'s order, written out explicitly, and the program prints a digest of all operands. Built with the desktop's g++, the old and new code give the same digest (`3cd1af43b434860c`) and identical output, so the earlier desktop and 5060 Ti gate 4 runs still hold.
- **`tools/check_wave.py`:** prints the digest, and on a GPU checks that the GPU build's digest equals the host build's.
- **`Makefile`:** `make HIP=1 wave` also builds the host corpus program that check uses.

## Full make check at 82b75b8
- Desktop, 05:59:39 to 09:27:33, rc 0. B0131's booking text says 81af26a; the suite ran at 82b75b8.
- Legs 1 to 25 match P0's run on d7b5047 exactly: the same ok count per leg, 1,464 ok in total, no FAIL verdicts, nothing skipped.
- `check_wave` is the new 26th leg: 57 ok, RESULT: PASS.
- The desktop was shared, so I make no timing claims from it.

## RX 7600 beside the 5060 Ti
| | RX 7600 (today, 82b75b8) | 5060 Ti (2026-11-16, 81af26a) |
|---|---|---|
| Build | HIP 7.16, AMD clang 24, gfx1102; 59 s, warnings only | HIP 7.2.4 over nvcc 12.9, sm_120; 100 s |
| Kernel resources | 120 VGPRs, scratch 144 B a lane, LDS 22,544 B | 182 registers, stack 112 B, shared 23,568 B |
| `check_wave --device gpu`, full | PASS, 78 ok, 0 FAIL, 1,406 s | PASS, 77 ok, 0 FAIL, 1,276 s |
| `check_wave --device gpu --quick` (the form check-gpu runs) | PASS, 66 ok | PASS, 65 ok |
| Gate 4 | 1,064,352 cases, 0 mismatches; digest equals the host build's | 0 mismatches (3 on 11-16, fixed then); same inputs, by identical per-operation counts |
| Seam test on the GPU's first record | PASS, 7 of 7 planted digits caught by name | PASS, 7 of 7 |
| Port on CPU, port on the GPU, kernel | identical | identical |
| 10-orbit rate record, 2 members rerun by the port | 527 waves: IDENTICAL, PASS | 1,755 waves: IDENTICAL, PASS |

- Each GPU's extra ok line is the new digest check (since 82b75b8).
- In the gate runs, every record matched the port member by member, with particles replayed, and matched the host twin line for line.
- The brief's literal contraction control (the checked source built with contraction on) changes nothing on any of the three compilers, so it cannot fail as worded. The variant with the flag checks compiled out does fail, as it should.
- The physics printed beside the rate runs come out identical on the two GPUs to every printed digit, for the 16-wave and 4,096-wave runs.

## Rate rows beside GPU-E2
One run a row; ring seed 1, dt0 600 s, epsilon 1e-9, one sample at the end. Two clocks, both from the record's trailer:
- **Kernel clock:** `kernel_seconds` minus `first_launch_seconds`, the program's own timer around each launch through its synchronize.
- **Wall clock:** `wall_seconds`, the program's run loop including writing the record.

| Row | RX 7600, kernel / wall | 5060 Ti, kernel / wall |
|---|---|---|
| GPU-E2's rung, 362 steps (10 orbits) | 527 waves: 3.35 s / 3.41 s (57,016 / 56,028 system-steps/s) | 1,755 waves: 9.46 s / 9.64 s (67,143 / 65,883) |
| 4,096 waves × 362 steps | 25.00 s / 25.45 s | 21.62 s / 22.04 s |
| 24 steps, kernel system-steps/s | 1 wave: 800; 16: 11,636; 128: 40,960; 527: 49,600; 4,096: 54,222 | 1 wave: 857; 16: 12,800; 128: 53,895; 1,755: 63,529; 4,096: 64,504 |

GPU-E2 estimated 13 minutes on the RX 7600 (about 245 system-steps/s) and 14 minutes on the 5060 Ti (about 756). Those estimates priced libcft's software binary64; the kernel uses the hardware's. The 5060 Ti rows ran with its host (the desktop) shared, so its wall-clock figures carry that load.

## Owned, and not done
- **Inside V1's window:** at 06:56 I ran one read-only command in cft-gpu (`cuobjdump` on my own binary, about a second, no GPU use) during V1's booking. TimeSheet's `check --short` said FREE, but it only looks at sensitive windows, not someone else's exclusive one. It's recorded in the ledger.
- **Not done:** a direct file-to-file comparison of the two GPUs' 4,096-wave 10-orbit records. The 5060 Ti's copy is in cft-gpu, and I said I wouldn't touch that today without your word; it's about a minute when you want it.

Everything above is also in my drop file, entries 06:33 to 12:45.
