(R5-V1's fourth look, at P1's fc4ba21, its final message on 2026-11-18 at ~14:22, copied verbatim by the lead.)

**NOT READY.** One gap is left: no plant ever touches a sampled particle's own body, so a compare_run that never compares the particle itself still passes the seam. Items 2 to 4 check out.

I checked out fc4ba21 detached and confirmed it is clean. I used the desktop only (B0169, shared, now released) and no GPU. The mutant copies are deleted.

**1. The rule — right as far as it goes; one carried class is never planted.**
- The sampled bodies and the massive-body count do come from compare_run's own particle lines: the `(body N, …)` part and "the member's 7 massive bodies". The clean run lists bodies 22 and 30 in wave 0, 57 and 31 in wave 1.
- A body counts as massive when its index is below that count, which matches compare_run's own choice of particles from bodies 7 to 63.
- The classification is correct for every plant made:
  - t, dt_next, t_lo and x of body 1 must FAIL each sampled particle, naming the same line and column.
  - vz of body 63, which isn't sampled, must stay IDENTICAL.
  - A refused or unparsed particle line counts as FAIL.
  - If the massive count were misread, the tree would fail loudly; no mutant could slip through quietly.
- **The gap:** the rule says a replay carries the particle's own body, but no plant lands on one.
  - I made a compare_run copy whose `particle_compare()` skips the particle's own body: one line, `enumerate(bodies[:-1])`.
  - It passes the seam: **16 ok, 0 FAIL**.
  - It is a real mutant. With vz of body 22 (a sampled particle) planted on line 142, the tree's replay FAILs body 22; the copy calls it IDENTICAL and compares 144 values where the tree compares 162.
- **Fix:** in each wave, plant one column of a sampled particle's own body; the bodies are already read from the clean run. That particle must FAIL and the other must stay IDENTICAL.

**2. The mutants — confirmed.** On P1's desktop harness at fc4ba21:

| Run | Tree's compare_run | P3's (round5-int, a49a75d9…) |
|---|---|---|
| Clean | 16 ok | 16 ok |
| Particle mutant | 6 ok, 10 FAIL | 6 ok, 10 FAIL |
| Member 0 mutant | 10 ok, 6 FAIL | 10 ok, 6 FAIL |
| Member 1 mutant | 10 ok, 6 FAIL | 10 ok, 6 FAIL |

The FAIL sets match P1's report plant for plant on both versions.

**3. The mutation script — confirmed.** The particle edit's anchor is the `def` line plus the first docstring line. It lands once: at line 814 in the tree's compare_run, 971 in P3's. The script refuses with rc 2 and writes nothing when the anchor lands 0 times (run on its own mutants) or 2 times (a copy with the anchor doubled).

**4. Nothing else moved — confirmed.** `git diff 6a5e448 fc4ba21` changes only:
- section 3's comment;
- inside `seam_form()`: how `drive()` parses the particle lines, two display helpers, the clean verdict (same condition) and the plant verdict.

Logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\r5v1\sb2v\`.

**NOT READY**: one plant per wave on a sampled particle's own body.
