You are parcel **P1** of round 5 in cft-rebound: an isolated git worktree of `C:\Users\logan\source\repos\cft-rebound`. Your base is commit `5b1cac6`, main where round 5's P0 landed. **Check you are on it** with `git log --oneline -1`. If you are not, `git reset --hard 5b1cac6` on your own branch and say so in your ledger file.

cft-rebound is REBOUND's IAS15 integrator on libcft, a multi-precision arithmetic library. Every backend gives the same bits, and **no committed record line moves** unless a change means it to. Round 5 (ROUND5.md) brings in libcft's GPU device, `hip:N`. P0 built this tree with it (`make HIP=1`) on an RX 7600 and ran one problem on `hip:0`, in the software backend's bits. **Your parcel is ROADMAP's GPU-half step 2: this tree, as it is, on `hip:0`, held to the software backend gate by gate.** Your gate becomes the GPU half's first, and carries its seam test.

## Start here

1. `ROUND5.md`, all of it, then its **P1** section, which defines your job.
2. `C:\Users\logan\source\repos\ParcelRound\METHOD.md`, §1 and §5.
3. docs/VALIDATION.md entries 54 (P0's build and smoke), 53 (the pin), 37 and 45 (this tree on the card: the same kind of work on another device), and 50 and 51 (tools/compare_run.py and the seam tests).
4. cft-fp256's docs/HOSTAPI.md, "The GPU backend: a HIP device as a libcft device", read in your pin clone at `eae74e3e`. Its section on what runs on the device, on the host, and what is refused, is what you are measuring against.
5. `CLAUDE.md`, all of it.

## The ledger

`C:\Users\logan\source\repos\cft-rebound\.ledger\`. Read **every** file there at three moments: before you start, before you design anything ROUND5.md calls shared, and before you report. Append your entries to `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P1.md`. Anything that must not wait goes in the same drop as `urgent-P1-<slug>.md`. **Arm a watcher on `.ledger\urgent\` first.**

## Your job

1. **`make HIP=1 check-gpu`, a new target.** Run on a GPU host, it runs the suite's record-making legs in their `--quick` form with `CFT_REBOUND_ARTIFACT=hip:0`:
   - check_records, check_equivalence, check_program_engine at binary64;
   - check_ensemble, check_ring, check_replay and check_compare_run;
   - check_zonal and check_reversal;
   - check_corrector and check_dropin, which go through the registered integrator.

   Each record must be the software backend's, or the leg must refuse by name. It is not in the desktop's three tiers: the desktop has no GPU.
2. **Prove the GPU ran.** A leg that quietly ran the software backend is a stand-in, so find out which legs honour `CFT_REBOUND_ARTIFACT` and which do not.
   - In particular: the registered integrator's legs, gate_real, the archive gates, and the Python gates that spawn `ias15_cft`.
   - Each leg's verdict carries `CFT_HIP_INFO=1`'s device line, captured from the run, as its evidence. The record's `backend=hip:0` is **not** evidence: it only echoes the artifact string the run was given (src/ias15_cft.c:4697-4699; V0, entry 54).
   - A leg that cannot be pointed at the GPU is reported, with why.
3. **The GPU seam test** (ROUND4.md, "What the integrator keeps"; ROUND5.md). tools/compare_run.py is pointed at a `hip:0` record of a ring wave from tools/make_ring.py, with its zonal line. A difference planted in that record, one hex digit of one column on one line, must be caught by name, while an unplanted member stays IDENTICAL. It belongs in `check-gpu`.
4. **What runs where,** confirmed by measurement, not read:
   - the exact-time clock's `cft_augmented_add` on the host at every step (src/ias15_cft.c:3049);
   - the divides and square roots by libcft's program route (CFT_DIVSQRT_SEQ);
   - the index-table routes `by=absent`;
   - the programs within 256 scratch slots and 512 bank slots.

   Say how you measured each: a counter, an environment variable that forces the other route, a profile.
5. **Costs:** time a call and a step, at each format, on each GPU, using the trailer's `wall_seconds`. Its `seconds` and `steps_per_s` are CPU time, which HIP's own threads make 1.5 to 2.0 times the wall time on `hip:0` (V0, over 24 runs). MEASURED, labelled, one run a row, and unranked within CLAUDE.md's noise.
   - The ratio to software depends on the problem: V0 found a 64-body ring wave faster on `hip:0` than in software. Its GPU time is still its calls; software is what slows at 64 bodies.
   - `check_dropin --light` took 449 s in software on nvidia-box, so roughly 1 to 3.5 hours on `hip:0`. Book its window long, or hold a named subset and say which.
6. **The routes on `hip:0`,** as V0 found them (entry 54), held in `check-gpu`. Forced on, `scalar` and `reduce_seg` run in the software backend's bits, and `indexed` and `pair_gather` are refused by name. `--door-selftest` holds 116 cases identical, with 48 not compared because their routes are absent.
7. **Both GPUs.**
   - **The RX 7600 first**, on nvidia-box (`ssh -o BatchMode=yes logan@192.168.0.2`), in **~/cft-rebound-r5-p1**.
   - **Then the RTX 5060 Ti,** in WSL `cft-gpu`, in **/root/cft-rebound-r5-p1**:
     - `HIP_PLATFORM=nvidia HIP_ROOT=/opt/rocm-7.2.4 HIP_ARCH=120`;
     - `CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=1` before any `hip:0`, so that the device is the 5060 Ti and never the RTX 4070, which drives the displays;
     - reach it with `wsl.exe -d cft-gpu -- bash -lc '...'`. In MSYS bash, set `MSYS_NO_PATHCONV=1` for wsl.exe's arguments.
   - In both places, build from git bundles of your branch and the pins, made on the desktop from local clones and carried by scp (or the WSL path). Nothing comes from the web.
   - **The stale-library trap** (V0). In a tree first built without HIP, `make HIP=1 all` returns 0 but leaves libcft.a software-only, and `hip:0` is refused by name. Run `make clean` before the first `make HIP=1`.
   - mpmath 1.3.0 is at ~/cft-rebound-r5-py on nvidia-box (`PYTHONPATH`). Check whether cft-gpu's Python has it; if not, copy the desktop's the same way and say so.

## Booking: every GPU run of 10 minutes or more

- **Book it in the TimeSheet from the desktop first:**

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book <resource> --mode exclusive --from now --until <WHEN> --who cft-REBOUND/P1 --why "<what>" --pid <the ssh or wsl session's Windows pid>
  ```

  - The resources: `rx7600` with `nvidia-box` (shared), and `rtx5060ti` with `wsl-cft-gpu`.
  - Release each booking when the run ends.
  - Before a short run, `check <resource> --short`.
- **cft-fp256's GPU round 2 shares both GPUs** from Tuesday 2026-11-17. Book early, and never over its windows; a conflict goes to its lead or to Logan.
- **The lead's own window** is rx7600 B0043, 09:00 to 17:00 today, exclusive. It is released to you when you start: the lead will tell you in your dispatch.

## Files you own

- `Makefile`: the `check-gpu` target, and its `IN_*` variables if it uses the gate cache. The lead merges the Makefile's conflicts.
- `tools/check_gpu.py`, new: the legs' driver, their evidence and the seam test.
- New files under `hw/gpu/`, if you want scripts for the GPU hosts.

## Files you must NOT touch

- `src/` and `include/`: the port does not change in P1. A refusal that would need a change is reported first.
- The integrator's files: README.md, ROADMAP.md, CLAUDE.md, docs/VALIDATION.md, docs/HARDWARE.md, docs/RING.md, ROUND5.md and third_party/MANIFEST.
- Any other parcel's files: P2's `src/wave/` and `tools/check_wave.py`, and P3's `tools/compare_run.py` and `tools/check_compare_run.py`. You **run** compare_run.py; you do not change it.
- ../cft-fp256, which you read and never write. On nvidia-box, every directory but your own, and the lead's ~/cft-rebound-r5, which you may read.

## Building and testing on the desktop

Your worktree has no `third_party/`. Clone it locally (no download) at the pins:

```bash
while read -r dir url commit; do case "$dir" in ''|\#*) continue;; esac
  git clone --quiet --no-checkout "/c/Users/logan/source/repos/cft-rebound/third_party/$dir" "third_party/$dir" && git -C "third_party/$dir" checkout --quiet "$commit"; done < third_party/MANIFEST
export PATH="/c/msys64/mingw64/bin:$PATH"
make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
     PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
```

- The PATH line is not optional; no `make -j` in a fresh tree.
- `check-gpu` must refuse, by name, on a host with no `hip:0`, such as the desktop.
- Before you report, run a full `make check` on the desktop, booked as `desktop` shared and started from PowerShell (CLAUDE.md). `HIP=0` must change nothing there. **Read the log, not the exit code.**

## Working rules this repository learned the hard way

- **Bit-identity is not validity.** Print each leg's physics counters beside its verdict.
- **A gate that cannot fail is not a gate.** Show `check-gpu` failing on a planted difference, and say how a leg that ran the software backend would be caught.
- **Derive; never transcribe.** Read the record format with the tools that already read it.
- **Label every claim** MEASURED or BELIEVED.
- **No speed claims** beyond labelled measurements.
- **Never bare `git stash`.** No card, never the RTX 4070. Never push, merge or rebase.

## Report

- what changed, file by file;
- `check-gpu`'s output on each GPU, as **actual lines**;
- the seam test and every control, with their numbers;
- which legs reach the GPU, which do not, and why;
- what runs where, and how you measured it;
- the costs, labelled;
- what you did not do;
- **anything you found that this brief or ROUND5.md got wrong.**

If something makes the approach unworkable, stop and report it.
