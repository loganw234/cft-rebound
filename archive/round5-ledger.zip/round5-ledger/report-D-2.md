(R5-D's report on VD's phase 1 fixes, its final message on 2026-11-19 at ~10:30, copied verbatim by the lead.)

The fixes are committed as a second commit on `round5-docs`, `a2c84fb` (parent `4980440`). It changes documents only, and nothing is pushed or merged.

```
 README.md          | 14 ++++++----
 ROUND5.md          | 14 +++++++---
 docs/RING.md       | 53 ++++++++++++++++++++++++------------
 docs/VALIDATION.md | 80 ++++++++++++++++++++++++++++++++----------------------
 4 files changed, 102 insertions(+), 59 deletions(-)
```

**The 13 items, at `a2c84fb`**

| # | item | where it is now | source reread |
|---|---|---|---|
| D1 | leg times "on the RX 7600" | README.md:815 | entry 55's leg table |
| D2 | P2's check_wave runs and mutants under B0171 until 17:35 | VALIDATION.md:7601-7602 | P2.md 17:37; lead.md 19:52 |
| D3 | "P2's suite" struck | VALIDATION.md:7904-7905 | P2.md 09:28: ended 09:27:33, B0131 released 09:28 |
| D4 | the member held IDENTICAL; GATE 1b's run ends rc 1; RESULT: PASS is V3's | ROUND5.md:309-316, RING.md:213-221, VALIDATION.md:7729-7737, and "(rc 1)" in entry 57's GATE 1b bullet at :7791 | check_compare_run.py:836; the suite log's "(rc 1)"; V3's item4.py and item4.log |
| D5 | "the arithmetic that reaches its samples and trailer", with entry 49's caveat | RING.md:202-210, VALIDATION.md:7723-7728 | compare_run.py:155-159 |
| D6 | which of V3's looks checked which reader, and how | VALIDATION.md:7700-7706 | V3 report 1 items 3 and 8; report 2 item 2; report 3 item 7 |
| D7 | refused processes counted apart, and still as device processes | RING.md:276-282 (check_gpu.py:565-570 and :562), the merge message's second note in "What it does not hold" at RING.md:316-321, README.md:797-800 | check_gpu.py at `fda3b40`; P1.md 13:03 |
| D8 | ROUND5.md corrected in place; entry 55's "had" left as written | ROUND5.md:189-192 | P1's report, item 3 |
| D9 | "two fewer on an accepted first attempt", and the rejected-attempt plant's 8 tokens at binary256 | VALIDATION.md:7739-7745 | P3.md 11:34; P3.md 06:54; P3 report 3 |
| Minor 1 | "eleven legs, ten in their quick form and check_dropin in its --light form" | RING.md:268-272 | the Makefile's recipes |
| Minor 2 | "[the same variables as the build]" in the check-gpu usage | RING.md:265-266 | README's matching line |
| Minor 3 | the build reads HIP only off Windows; check-gpu passes it on every OS | README.md:778-780 | Makefile:217, :837 |
| Minor 4 | one bracketed correction after entry 50's vaugadd sentence, citing entries 54 and 55 | VALIDATION.md:6322-6325 | entries 54 and 55 |

The five LEAD-FILL lines have moved to ROUND5.md:9 and :411, RING.md:327, and VALIDATION.md:7661 and :7936. The cft-fp256 provenance row is unchanged, and it passes check_pins' two README tests, which I ran by hand.

**Not done exactly as asked**
- **D4 says "a three-wave ring", not "a two-wave ring".** V3's own run used `ring3_z.txt` with `E, N = 3, 64` (v3-r5/item4.py:21-24). Its log, item4.log:44, reads "1 sampled member(s) of 3 … 2 member(s) not rerun", with wave 0 at 2 passes where this tree takes 4. So VD's "two-wave" does not match the source, and the text says three.
- **One fix beyond the list.** Entry 55's legs bullet (VALIDATION.md:7269-7274) had the same "each in its quick form" wording as RING.md, so it got the same fix.

Waiting for your message for phase 2.
