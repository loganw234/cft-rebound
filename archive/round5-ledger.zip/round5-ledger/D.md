# D (round 5): the records drafter, round5-docs

## 2026-11-20 05:30 - Records phase 2 at 83f2188: entries 56 and 58, ROUND5.md's status and findings, RING.md's wave kernel, README, CLAUDE.md, ROADMAP; documents only

Done (round5-docs, four commits on fda3b40, worktree clean, nothing pushed or merged):
- 4980440 and a2c84fb, phase 1 (VD READY on a2c84fb; R5-D-report-1 and -2).
- b1cd3ed and 83f2188, phase 2: CLAUDE.md, README.md, ROADMAP.md, ROUND5.md, docs/RING.md and docs/VALIDATION.md, +1082/-32 against a2c84fb (MEASURED, git). No LEAD-FILL line is left. 83f2188 only adds "at 4a8fe99, :863 since PL" to entry 57's one citation of check_compare_run.py:836.
- `git merge-tree --write-tree main round5-docs` at b1cd3ed: rc 0, a clean merge into 61e45bc (MEASURED; no ref moved).

Measured by D, from the logs (scratchpad/r5d/legcount.py, per-leg ok and FAIL counts):
- int-check-620c98b.log: 13:38:35 to 16:55:59; 25 legs; 1,505 lines beginning "  ok "; 17 RESULT lines, all PASS; every leg at fda3b40's count but check_compare_run, 108 to 109.
- int-check-61e45bc.log: 02:11:37 to 05:03:15; 26 legs; 1,649 "  ok "; 18 RESULT lines, all PASS; the 25 shared legs at 620c98b's counts; check_wave 144 ok.
- int-check-7444157.log: stopped in its sixth leg, check_door.
- main's Makefile: 26 --leg lines in each tier; check-gpu's --hip line is Makefile:988 on main, so the README now cites :988, not fda3b40's :837.

Read, for the lead:
- tools/check_compare_run.py moved under PL: entry 57's :836 is 4a8fe99's line; on main the same test is :863, and entry 57 now names both.
- The earlier records (entries 55, 57) carry their merges and suites; entry 56 leaves P2's merge to entry 58, as round 4's entries 50 and 51 did.

For: lead, VD

## 2026-11-20 05:36 - 87fb2b8 on 83f2188: round 5 in CLAUDE.md's planted-control bullet; round5-docs ready for VD

- CLAUDE.md only, +8/-4 (MEASURED, git): after "(entries 50, 51)", round 5's nine more send-backs of that shape, P1's seam three (entry 55: the lead's on V1's READY, then V1's two NOT READYs) and check_wave six (entry 56: V2's four, P2's two disclosures; send-back 7, the work directory, is another shape), and the skipped middle line that plants at both ends of every loop let pass until the count rule.
- `git merge-tree --write-tree main round5-docs`: rc 0 (MEASURED; no ref moved).

For: lead, VD

## 2026-11-20 06:10 - 57a148e on 87fb2b8: VD's three phase-2 fixes and six nits; documents only

- Five documents, +34/-23 (MEASURED, git); `git merge-tree --write-tree main round5-docs`: rc 0, no ref moved.
- The three: entry 58's seam-script bullet gains its dry run before the merge (lead.md 2026-11-19 05:12; gpu/p1p2/dry2.log, READ by D: "DRY RUN on the host: nothing on a GPU", 22 ok, 0 FAIL); entry 56's physics bounds as check_wave.py's head states them (CIRC_BOUND, MM_BOUND, E_BOUND = 1e-2, 1e-4, 1e-13, READ at main); entry 56's watchdog reset BELIEVED, never met (7dec985's message, READ).
- The six nits as VD listed them; check-gpu's --expect line is Makefile:990 on main (READ).

For: lead, VD
