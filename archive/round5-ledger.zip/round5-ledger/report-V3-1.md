I found one blocking defect, so: **NOT READY**. The driver's bits are right. What's wrong is that its output never says what a NOT RERUN member is not held to. All ten items finished before the pause; one extra mutant run of mine (Mj) was stopped once it had given its result.

**Setup.** My worktree was detached at 2922fa1 with both pins cloned locally, and `make ... all programs` passed with 66 programs. The desktop was booked as B0094 (shared), with every process attached, and released at 17:54. Scripts and logs are in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v3-r5\`, with the gate logs in its `gate-logs\` folder. All copies are deleted and no tracked file was edited.

**1. Scope — confirmed.** `git diff --stat 5b1cac6 2922fa1` shows the two tools only. Everything case 7 runs or imports is in IN_COMPARE: ias15_cft, compare_run.py and its three imports, extract_particle.py, check_replay.py, oracle.py, kepler.txt, and programs/out.

**2. Gate — confirmed.**
- **`--quick`:** 68 ok, 0 FAIL, RESULT: PASS. Cases 1 (fp64), 3, 4, 5 and 7 ran, then q1–q7, controls a to p2, and i.
- **`--build build` (full):** 105 ok, 0 FAIL, RESULT: PASS, 16:56 to 17:54. At all three formats GATE 1 holds 18 particles, 1512 tokens, files traced 18 of 18 each way, and members [0, 1] among them; GATE 2 agrees with mpmath to 3.3e-7.
- Every case-7 line P3 quotes recurs, including q3 (`member, state`), q5 (`format, pc_tol_shift, dt0, epsilon, state`), q6 (`active`) and q4 (`zonal`).

**3. Default path — confirmed; only text changed.**
- I ran compare_run at 5b1cac6 and at 2922fa1 on six setups: the gate's waves at `--strata` 3 and 8 and seed 7, a 3-wave make_ring ring with its zonal line, P1's 2-wave ring from dt0 1e5, and kepler.
- The sample lines, member lines, particle picks and verdicts, the particle summaries and the RESULT lines were identical. Only the particle lines differ: they gain the source clause and the counters and closest-approach suffix.
- `--particle-strata` without `--producer-files` is an argument error, so the default particle sample cannot move.
- `check_ring_seams --quick` at 2922fa1: 21 ok, PASS. P1's regexes (from check_gpu.py at ab75fbe) and part 3's capture the same results at both commits on P1's five plants.

**4. NOT RERUN — it holds what its replays hold, and says nothing of the rest.**
Setup: a 3-wave ring with its zonal line from dt0 100, no rejections, run with `--strata 1 --particle-strata 3`. Waves 0 and 1 are NOT RERUN. I planted one change at a time in wave 0, each on lines 206 and 209.

| Plant | Result |
|---|---|
| t, dt_next, E, x of Mimas, t_hi, t_lo | Both particles FAIL, naming "record line 206 … <column>". **E is held.** |
| vy of the sampled particle p0000020 | That particle FAILs; the other is IDENTICAL. |
| the wave's trailer `mean_pc_iterations` +0.001 | Both particles FAIL. |
| x of p0000000, vz of p0000056 (unsampled) | rc 0, `RESULT: PASS: … and 2 member(s) not rerun, each held by the record and its particles' replays from the producer's own files` |

The output never says that an unsampled particle of a NOT RERUN member is held by nothing. This is part of D1 below.

**5. Mutants of the driver.** My own script refuses to run unless each edit lands exactly once; I tested that refusal. Each mutant ran through `--driver` against 2922fa1's `--quick` gate. The unmutated copy, as a control, gave 68 ok and PASS.

| Mutant | Gate | Caught by |
|---|---|---|
| M1 | 65 ok, 3 FAIL | the producer-files check (the line names the rerun's schedule), GATE 1b (member 2's particles), q2. GATE 1 alone passes. |
| M2 | 64 ok, 4 FAIL | the same three, plus the half pair |
| (a) key check skipped | 63 ok, 5 FAIL | q3 twice, q5, q6, q4: rc 1, not a REFUSED naming fields. extract_particle's own key check still refuses the particles, so no PASS leaks. |
| (b) `zonal` dropped / `active` dropped | 67 ok, 1 FAIL each | q4 alone / q6 alone |
| (c) silent fallback | 66 ok, 2 FAIL | the empty-directory and half-pair texts |
| (d) no replays for NOT RERUN | 59 ok, 9 FAIL | 12 particles counted, not 18 |
| (e) producer's schedule with the rerun's attempts record | 65 ok, 3 FAIL | provenance (the producer-files check and GATE 1), and q1 (members 0 and 1) |
| Mf2 (mine): rerun's schedule for rejecting members only, still naming the producer's | **68 ok, PASS** | nothing |
| Mj (mine): files keyed to `--rerun-engine`'s engine | 68 ok, 1 FAIL, stopped after it | only the full-only program-engine case. `--quick`, as run in check-quick and check-light, cannot see it. |

**6. Placement of the controls.**
- **q1:** five plants, one line in each of five members. They include member 0's first-attempt rejection and one outcome flip. They run at three formats in the full gate and at fp64 only under `--quick`.
- **q2:** three plants and **no rejected attempt**: no member that can be NOT RERUN rejects, and q2's rerun pick rejects nothing. Mf2 passing is the result. I measured that two fewer passes on member 0's rejected first attempt moves 28 tokens at fp64 and 8 at fp256.
- **The pass-count claim is wrong.** I replayed each plant as q2 does (the attempts record as the dt file, the planted schedule re-keyed, an unplanted control identical at every format) and read both counters.
  - At fp64, member 4's plant moves bits.
  - Of the other eight, the five first-attempt plants also move `max_pc_iterations`: 8→7, 16→14, 17→16, 33→31, 36→35.
  - Only the three middle-attempt +1 plants rest on the mean alone.
  - The driver compares the max too but names only the first counter that differs. The same error is in check_compare_run.py:97 and :698 ("only the mean passes").
- **The ~1,000-attempt limit is right:** the mean is passes over attempts, printed to three decimals (src/ias15_cft.c:4769). It binds only on an attempt below the member's maximum.
- **The 10^6 ring is within it.** GPU-E2 at eae74e3e gives 36.2 steps an orbit at 1e-9 and 10 orbits in 5.8 days. With RING.md's Pan figures (period 49,819 s, cap 1,388.09 s), a wave takes 359 to 374 steps (COMPUTED), so one pass moves the mean by about 0.0027. The limit binds only beyond about 28 orbits.

**7. The key — confirmed.**
- `run_key()` calls `ias15_cft --run-key`, `hold_key()` compares text, and hashlib only draws samples.
- Each case was refused (rc 2) before anything ran, naming the member, the file, the field and both values:
  - epsilon 1e-8, in both files and in the schedule alone;
  - dt0 101, in both files and in the attempts record alone;
  - another engine, in both directions (FMA form);
  - wave 0 run as a one-system problem (member=-1) placed as member 0: "differs … in member (member: -1 in the file, 0 for member 0)".

**8. The readers — confirmed.** On the producer-path output, P1's member regex sees only the rerun member, and `NOT RERUN` never matches `IDENTICAL|FAIL`. P1's and part 3's particle regexes count all six particles. One thing to know: a NOT RERUN member whose particles FAIL keeps its NOT RERUN line, so only the particle lines and RESULT name it.

**9. Findings.**
- **GATE 1b reproduced on the ring.** Wave 0's first attempt at 2 passes (and at 1), where this tree takes 4, leaves 2 of 3 sample lines not this tree's. From the producer's files: NOT RERUN, both particles IDENTICAL, **RESULT: PASS**. With every member rerun it FAILs at line 206 (y of Pan; at 1 pass, t).
- **D1, DEFECT: the limit is not in the output.**
  - The limit is stated only in compare_run.py's source header (:145–154); no print states it.
  - The output says the opposite: "NOT RERUN: its lines are held by the record alone, and by its particles' replays", followed by the PASS above.
  - Concrete case, measured with this tree standing in for the producer: P2's ring run through `--producer-files`, with a kernel whose exit test stops two passes early in a wave that isn't rerun, prints exactly that PASS.
  - The sample's limit (SAMPLE_LIMIT) and the format difference's scope are printed and asserted by the gate. GATE 1b's own line says "as the driver states it", but the driver's output doesn't.
  - **Fix:** a printed limit line (the producer's dts, outcomes and passes are taken as given; unsampled particles are held by nothing), asserted verbatim by the gate.
- **Overreach in P3's report:**
  - the pass-count finding (item 6);
  - "the header states the limit" refers to the source header, not the output;
  - "about three whole-file reads" per member is five by the code (it was labelled BELIEVED).

**10. Anything else.**
- **The key is a label for other producers.** For a producer that keys its files by calling `--run-key` on the record's arguments (P3's advice to P2), nothing holds epsilon, pc_tol_shift, max_iter or the settings a record doesn't carry, on a member that isn't rerun. This belongs in D1's line.
- **The P2 x P3 seam has not run.** No file from a producer other than ias15_cft has gone through `--producer-files`.
- **Tiers:** Mj shows that check-quick and check-light cannot see the key-engine rule; only `make check` does.
- **Gate fragility:** the gate's PF_SOURCE regex splits the two file paths at " and ", so a scratch path containing " and " fails spuriously.
- **Housekeeping:** `scratchpad\v3` was round 4's V3 directory. I overwrote 8 files under `v3\base\tools`, restored them from `v3\base.tar`, and moved everything of mine out.

**NOT READY**, on D1 alone, which is a printing fix. The rest are corrections to P3's report and to two comments in the gate.