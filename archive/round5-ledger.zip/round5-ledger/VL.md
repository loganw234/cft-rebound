# VL (round 5): verifier of the lead's own fixes, round5-pl at e8a7d89

## 2026-11-19 09:10 - Setup, scope, and the fresh-tree extraction (before any build)

- Worktree agent-a6ab97e79a666f25b, `git checkout --detach e8a7d89` (MEASURED: `git log --oneline -1` e8a7d89). Pins cloned locally, rebound bdfda4b and cft-fp256 eae74e3e, equal to third_party/MANIFEST (MEASURED).
- Scope (MEASURED): `git diff --name-status fda3b40 e8a7d89` is M Makefile, M tools/check_compare_run.py; no rename, mode or other path.
- Fresh tree (no build/, no programs/out, pins present), my own extractor (scratchpad/vl/mkn.sh, vl_legs.py, vl_imgsets.py), `make -n -f <copy>` of check, check-quick, check-light under fda3b40, 3012353, cc3d87a and e8a7d89 Makefiles: rc 0, 25 legs each; build/ and programs/out still absent after, `git status` clean (MEASURED).
  - fda3b40: no programs/out file on any leg, any tier.
  - e8a7d89: one image set of 66, equal to programs/*.cfta mapped to .cftp, on 11 legs in every tier; no duplicates.
  - fda3b40 -> e8a7d89: 12 legs identical; the 11 gain the 66 (check_ensemble also check_equivalence.py, make_ensemble.py); check_records gains check_equivalence.py; check_bodycount gains check_equivalence.py, make_nbody.py, src/ias15_limits.h. Nothing lost.
For: lead

## 2026-11-19 09:55 - Built tree, the stale skips at fda3b40 and 5fa7534 reproduced through make, and a trap in the brief's recipe

- Built `all programs` (cc x86_64-w64-mingw32, rc 0, `git status` clean after: gen_programs.py rewrote the 66 tracked .cfta identically and made none other). Built-tree make -n: the tip's 66 on 11 legs equal fresh and equal programs/out; fda3b40 -> tip in a built tree changes only check_ensemble (+66 +2 tools), check_records (+1) and check_bodycount (+3); no input listed twice on any leg, any tier, either tree, any Makefile (MEASURED).
- **A hand edit of a .cfta never reaches an image** (MEASURED): `make programs` runs gen_programs.py first, which rewrote predict-ens-fp64.cfta back to the committed bytes; the image's sha256 did not move. Every tier depends on `programs`, so the realistic route to a changed image is tools/gen_programs.py (in no key, by design) or the pinned assembler.
- **5fa7534, check_ensemble** (MEASURED): a one-line change to predict_ens in gen_programs.py, then `make programs`: predict-ens-fp64/128/256 and their .cfta moved, nothing else (binaries unchanged). 5fa7534's check-quick line: SKIPPED (stamp 86c8ea449826). The tip's, from its own stamp (6d272344b22d, SKIPPED once to show it held): ran, FAIL on the two adaptive program-engine cases. Restored: 195 baseline hashes match, the tip's line PASS with the same key.
- **fda3b40, the PROGRAMS key** (MEASURED, check_program_engine's check-quick line): a tree whose programs/out is absent at parse (fresh clone, or `rm -rf programs/out`) keys on no image (10 inputs). Pass, then predict changed in gen_programs.py and programs/out removed again: the same line byte for byte, SKIPPED (1355ddaa4c43), binary unchanged. The tip's line in the same sequence: 76 inputs, ran, FAIL. A stale skip needs programs/out absent at BOTH parses; with it present at the second, fda3b40 lists the 66 and reruns.
For: lead

## 2026-11-19 10:15 - Item 4b's controls: make_ensemble.py, the constants leg, and the cached problems (MEASURED)

- **make_ensemble.py with check_ensemble**, a kind PL did not control: a crash in the --vscale branch, which only check_ensemble runs (READ: no other tool passes --vscale). cc3d87a's check-quick line, from its own stamp 7d8438d13d1a: SKIPPED. The tip's, from its own stamp 6d272344b22d (SKIPPED once first): ran, rc 1, "RESULT: FAIL (could not write an ensemble file)", IndexError. Restored, baseline hashes match.
- **The constants leg**: one digit of h[1] in third_party/rebound/src/integrator_ias15.c (the first try REFUSED: its text was in the file twice). check-pins: ok, rc 0 (it checks HEAD, not a dirty clone). The constants line: SKIPPED on its stamp 4210bd53eb4f. gen_constants.py --no-write run directly: rc 1, "FAIL h[1]: derived ..., REBOUND literal ...". Restored; the clone's `git status` empty. And MANIFEST is not in its key either (READ), so a REBOUND pin move that changed the file would leave the stamp standing too.
- **check_bodycount's cached problems**: make_nbody.py broken (N one more than the bodies). check-quick's line: ran (key 2b5205570540), PASS on build/problems from the good generator; then SKIPPED; and SKIPPED again after build/problems was deleted, since nothing in the key moved. So in check-quick and check-light a broken generator is passed and then held. make check's line (--mode full): with no build/problems, FAIL (ias15_ref rc 2, ias15_cft rc 3 on the problem); with the good generator's problems cached, PASS. The lead's merge script runs `make clean` first (READ, gpu/int-check-r5-pl.sh), so its make check would catch it; a make check in a tree with build/problems would not. Restored, all baseline hashes match.
For: lead

## 2026-11-19 10:56 - The compare_run gate: clean tip and the first mutants (MEASURED)

- Setup: each gate run in its own `git archive` tree in scratch (vl/t/<tree>, the worktree's 66 images copied, sha256-checked) with its own build dir (copies of ias15_cft.exe and ias15_ref.exe, sha256-checked); tip trees hold gate blob b77e7944, fda3b40 trees a83b16e9. A mutant replaces tools/compare_run.py in its tree (no --driver), so control i's copies hold the mutant too. vl_mutate.py refuses unless its anchor lands once (measured: "lands 0 times", "lands 9 times"); a smoke test showed each copy prints only where meant, every run's rc and RESULT otherwise unchanged.
- Clean tip: --quick PASS 73 ok, closing "none of the 46 runs ... (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)"; full PASS 109 ok, 48 runs (10, 1, 4, 3, 3).
- (a) tab-indented and (b) embedded after other text, default path, tip full: FAIL, 103 ok, 6 FAIL each: case 1 at fp64/fp128/fp256, case 5's two, and the closing verdict "printed by 40" of 48 (PL's --driver M1 saw 37: control i's 3 now hold the mutant).
- Case 6: quick record (4 steps) members 0 and 1 reject their first attempt, member 8 nothing, 5 sampled; full (20 steps) member 8 rejects 3 after accepted steps, 6 sampled. So --quick's case 6 holds no rejection that follows an accepted step.
For: lead

## 2026-11-19 12:12 - Item 5 done; mutants (a), (b), (c) so far (MEASURED)

- fda3b40's gate (git archive tree, same image and binary bytes): --quick PASS 70 ok, full PASS 108 ok. Verdict lines diffed against the tip's with paths made placeholders (vl_vdiff.py): --quick adds case 6's two verdicts (4 steps, 5 members IDENTICAL each) and the closing verdict, the other 70 identical; full changes case 6's two verdicts by "(20 steps)" only and adds the closing verdict, the other 106 identical. PL's 70 -> 73 and 108 -> 109 hold.
- tip gate: (a) quick FAIL 69 ok / 4 FAIL (case 1 fp64, case 5's two, closing "printed by 38" of 46); (a), (b), (c) full FAIL 103 ok / 6 FAIL each (case 1 at three formats, case 5's two, closing "printed by 40" of 48); (b) quick FAIL 69/4.
- I stopped tip-e-f (the full gate on mutant (e)) at 11:03 to spare the shared host: (e) prints only in a 4-step case 6, which the full tier never makes, so its full run is the clean full run by construction. Not measured; said as such.
For: lead

## 2026-11-19 13:05 - Mutants done; my own key audit by trace; check-quick cold, warm and one byte (MEASURED)

- **Mutants, tip's gate** (FAIL lines named): (a) quick 69/4, full 103/6; (b) quick 69/4, full 103/6; (c) stderr only quick 69/4, full 103/6 (case 1 per format, case 5's two, closing "printed by 38/40"); (d) control i's last run only: quick 72/1, full 108/1, closing "printed by 1: kepler.rec --problem kepler.txt through .../p3_present/tools/compare_run.py"; (e) quick case 6 only: quick 72/1, closing "printed by 2: waves_fma_program.rec; ... --rerun-engine loop" (full not run, by construction a clean run); (f) twice on a producer run: quick 61/12, full 89/20, every producer run's limit_once; closing ok.
- **fda3b40's gate --quick**: (a), (b), (c), (d), (e) PASS 70; (f) FAIL 58/12.
- **(g), extra**: a second copy of the limit on a producer run, on stderr, followed by 700 characters of stderr: tip --quick PASS 73 ok, fda3b40 PASS 70. drive() hands the per-run checks only stderr's last 600 characters, and the closing verdict covers runs without --producer-files only. Minor: no reader takes stderr.
- **Key audit by trace** (scratchpad/vl/audit_site/sitecustomize.py, an audit hook logging every open, process start, listing and import, in the cold check-quick; vl_audit.py, each leg's process tree under gate_cache, C programs' reads from their arguments): one input missing, the constants leg's third_party/rebound/src/integrator_ias15.c. Every input e8a7d89 added is read, imported or run. Only check_gravity's verdict reads programs/out's listing; check_ring lists it for a printed count. check_compare_run reads its own build/check_compare_run copies (CopyFile2 leaves no audit event; read by hand: control i's p3_present and the producer dirs).
- **check-quick in the worktree**: cold (after make clean, traced) rc 0, all 25 ran and passed, check_compare_run 73 ok with the 46-run closing verdict; warm rc 0, all 25 "SKIPPED - inputs unchanged" by name; one byte of programs/out/predict-ens-fp64.cftp changed, then make check-quick: rc 0, all 25 SKIPPED, and the image was the original again: `programs` reassembled it before any leg ran.
For: lead

## 2026-11-19 13:20 - Item 8's last phase, cleanup, B0195 released; verdict READY

- **The generator phase** (MEASURED): predict_ens's register s moved r4 -> r5 in tools/gen_programs.py, then make check-quick: rc 0; predict-ens-fp64/128/256 moved, binaries unchanged; exactly the 11 legs that list $(IN_PROGS) ran and passed, the other 14 printed SKIPPED by name. Restored: programs/out equals the cold run's 66, every non-build baseline hash (189) matches, `git status` empty in the worktree and in the rebound clone.
- The trace also shows case 6's quick record is byte for byte case 7's quick program-engine command (two identical ias15_cft invocations).
- Rebuilt binaries after `make clean` differ in bytes from the first build of the same sources (3 of 3), so a clean rebuild moves every key that names a binary. Harmless (make clean also empties the cache).
- Cleanup: the scratch trees, build copies, mutants, archives and backups deleted (vl/t, vl/b, vl/arch, vl/smoke, vl/bak); scripts, logs, make -n outputs and the trace kept in scratchpad/vl. No process of mine runs. B0195 released 13:14 with both pids gone.
- Verdict READY. One defect, pre-existing and disclosed by PL, with a one-line fix: the constants leg's key lacks third_party/rebound/src/integrator_ias15.c (stale skip measured; check-pins checks HEAD only, and MANIFEST is not in that key).
For: lead

## 2026-11-19 13:40 - PL send-back 3 (4fcd775): scope, my constants control through make, the third_party sweep; READY

- Worktree detached at 4fcd775, parent e8a7d89 (MEASURED). `git diff e8a7d89 4fcd775`: Makefile, 3 lines, each the constants line gaining `--input third_party/rebound/src/integrator_ias15.c` (MEASURED).
- My extractor, all three tiers, fresh (build/ and programs/out moved to scratch and back, 105 hashes checked) and built: constants alone changes, by that one file; 24 of 25 legs identical; 4fcd775 fresh = built; no duplicates (MEASURED).
- Control (scratchpad/vl/sb3.sh, logs/sb3.log): the edit refuses the bare literal ("lands 2 times") and a second application ("lands 0 times"); anchored on the h[8] line it lands once. e8a7d89's line SKIPPED (4210bd53eb4f) before and after the edit. 4fcd775's line: PASS (0e3b9434b62f, PL's key too), SKIPPED, then after the edit ran, rc 1, "FAIL h[1] ... DERIVATION CHECK FAILED"; `make -o <file> check-quick` rc 2 at the constants leg, nothing rebuilt. Restored: sha256 085a0bcb (baseline), clone `git status` empty; PASS with 0e3b9434b62f, then warm SKIPPED. Worktree status empty; 189 non-build hashes match.
- Trace from item 8 (e8a7d89's check-quick): only constants (integrator_ias15.c), check_corrector (cft-fp256 programs/MANIFEST) and check_zonal (nine cft_golden modules, all in GOLDEN_PY) read under third_party/; the other 22 legs nothing. Agrees with PL. vectors.py:520-538's lazy import of host/tools/pi_worstcase.py was not reached, and check_zonal names no vectors function (READ).
- No booking (each run under 10 minutes). No process of mine runs.
For: lead

## 2026-11-20 01:40 - The lead's p1p2_seam.py change (c9e39a38): READY

- **Scope** (READ, `diff -u` against .orig-7444157): the docstring, DEVICE_PREFIX, parse() putting `# device ` lines in their own list and aside, the kernel's wanted backend hip:0:<arch from its one device line> on a GPU, the record verdict's wording ("want") and a backend detail line, and one new verdict. compare(), plant(), the controls and sections 3-4 are untouched.
- **Through the script's own main()** (MEASURED, scratchpad/vl/vl_seamtest.py: the lead's file loaded by path, sha checked, no bytecode written; run() stubbed to answer from the 0100 run's saved records, probe line and compare_run logs): the saved records 24 ok / 0 FAIL, as 0125. Each FAILs by name: no device line (2), two (2), another GPU named (1), a device line in the cpu record (1) or the hip record (1), backend=gpu (1), another arch in the backend (1) or in the device line (1), another index in the backend (1). An unknown header ("# devices hip:0", "# devicehip:0 =", "# note x" in hip) still FAILs, 7 to 9 verdicts.
- **Not caught**: the device line's own index changed (hip:1 = ...) and the arch changed in both the device line and the backend together: 24 ok. And with --dry-host, a device line in any record is set aside with no verdict (22 ok). None reachable from today's kernel (READ: wave_gpu.inc builds the line and the backend from the same dv and arch, after hipSetDevice(0); a host run writes no device line).
- **0100 against 0125** (MEASURED): 23 and 24 verdicts; 15 same outcome, 8 flip FAIL to ok (the wave record, wave against cpu, the six wave controls), 1 new (the kernel record's device line).
- **The right change** (READ): the line is P2's design (wave_main.cpp:28-29, 531; 46ddfed: "the proof the GPU ran is its own description"), held by check_wave (exactly one, equal to the probe's line, --expect in it: check_wave.py:1099-1110, 1208-1209 at 7444157); compare_run holds header lines one way and lets a producer's own line stand (compare_run.py:873-877), so it never needed to know it.
For: lead

## 2026-11-20 01:36 - The three hardenings in p1p2_seam.py (f4e475dd): READY

- **The diff** (READ, against .orig-7444157 and the c9e39a38 diff): section 0 keeps kdev, the probe's first stdout line starting `# device `, and refuses unless it exists and names --expect; the device verdict adds dv == kdev; the arch regex ends `[,:]`; under --dry-host a new verdict wants no `# device` line in any record. Nothing else moved.
- **Through main()** (MEASURED, scratchpad/vl/vl_seamtest2.py, the same stub, sha f4e475dd checked at load, no bytecode written): the saved records 24 ok / 0 FAIL. The three that passed now FAIL by name: the device line's index (the device verdict, "same as its --device-info line (False)"), the arch in both fields (the same), and a device line under --dry-host in the cpu record or the host twin's ("dry run: no record carries ..."; the clean dry run 23 ok). The nine earlier cases still FAIL, each by the same verdicts as before (another arch in the device line now FAILs the device verdict too).
- A gcnArchName with feature flags, `(gfx90a:sramecc+:xnack-, ` in both the probe's line and the record's with backend=hip:0:gfx90a: 24 ok. The probe's line one character off the record's (16284 MiB): the device verdict FAILs. The probe's line on stderr only, or naming another GPU: REFUSED in section 0, before anything runs.
For: lead
