(R5-P1's report on send-back 1, its final message on 2026-11-18 at ~13:05, copied verbatim by the lead.)

The send-back is done at **6a5e448**: two new commits on ab75fbe, changing tools/check_gpu.py only. On the 5060 Ti the clean tree passes the seam, and each compare_run mutant FAILs it by name in both forms. Nothing is pushed or merged, and all three bookings are released.

**Commits**
- **a068acc**: the seam now plants in both waves.
  - REBOUND form: five columns (x of body 1, vz of body 63, t, dt_next, t_lo) on each wave's first and last sampled lines.
  - FMA form: x of body 1 in each wave.
  - Each plant must FAIL its own wave, naming the line and column; the other wave and its particles must stay IDENTICAL.
  - Section 3 of the header comment says so.
- **6a5e448**: TIMING names today's 13 timing keys instead of matching `t_[a-z_]+`. I read the keys from src/ias15_cft.c's trailer. A new control, a3, plants `t_new=1` in a trailer and must catch it.

**5060 Ti, WSL cft-gpu** (`CUDA_VISIBLE_DEVICES=1`; every device line names the 5060 Ti, bus 05:00.0)

| Run | Result | ok | FAIL | Time |
|---|---|---|---|---|
| Clean tree, controls and seam | rc 0, PASS | 26 | 0 | 7m24s |
| Mutant that never compares member 1 | rc 1, FAIL | 11 | 6 | 6m12s |
| Mutant that never compares member 0 | rc 1, FAIL | 11 | 6 | 6m23s |
| P3's merged compare_run (round5-int) in the tree's place | rc 0, PASS | 17 | 0 | 6m17s |

- **Clean tree plants:**
  - Wave 0: line 140 (dt_next, t_lo) and line 142 (x, vz, t).
  - Wave 1: line 141 (dt_next, t_lo) and line 143 (x, vz, t).
  - FMA: line 142 (wave 0) and line 143 (wave 1).
  - Every plant FAILs its wave by line and column, and the other wave stays IDENTICAL with its 2 particles.
- **Member-1 mutant:** its 6 FAILs are exactly wave 1's five REBOUND plants and its FMA plant. Each detail line reads `member 1 (w00001): IDENTICAL: not compared`. On the wave-1 vz-of-body-63 plant, the mutant compare_run itself exits 0; the seam still FAILs it by name.
- **Member-0 mutant:** the same in wave 0.
- **The refusal:** the mutation script, run on its own mutant, prints "REFUSED: the edit lands 0 time(s) … not once; nothing written" and exits 2.
- **Control a3 on hip:0:** "caught: stdout line 11, field 13: device t_new=1, software <end>". The clean run's 12 timing values were each set aside, 9 of them different between device and software. On the two-wave seam records, all 13 keys are present and 12 differ; the trailers are equal once they are set aside.
- **Before and after:** on my 16 Nov 5060 Ti data, ab75fbe calls the `t_new=1` copy "1 of 1 identical"; 6a5e448 names it at line 11, field 13.
- **Merge pre-check:** the P3 row means the seam reads the merged compare_run correctly in both waves. The same mutation lands once in it, at its line 1358.
- **Desktop, no GPU** (software record, witness stubbed; it tests only the plants, the patterns and the mutants): the tree gives 16 ok, 0 FAIL, each mutant 10 ok, 6 FAIL, and P3's version and its two mutants match those counts.

**Bookings:** wsl-cft-gpu B0158 and rtx5060ti B0159 (exclusive), and desktop B0160 (shared), booked at 12:34 with the runs' pids attached. Released at 13:01:31, 13:01:32 and 13:02:06, as the runs ended.

**P1.md** has a 13:03 entry with your four corrections:
- Each plant is one hex digit on one line.
- 1.9%, not 1.5% (kepler fp128 on the program engine).
- check_checkpoint runs on hip:0 as it is.
- check_seams fails only on the forced indexed and pair_gather cases.

Reading the source confirms the last two: `identity_ok` is called only at tests/gate_real.c:646, in the self-contained mode. The entry also carries the three notes, unfixed: stderr never fails a leg, refused processes count as device processes, and nothing can see a bypass on the 5060 Ti.

The kept witness data, the mutant copies and the P3 copy stay in /root/cft-rebound-r5-p1 for V1.

Files are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad:
- p1\sb1\mutate_compare_run.py
- p1\sb1\sb1-6a5e448-1118-1235\ (README and the four GPU logs)
- ledger-drop-r5\P1.md
