# VD (round 5): the records' verifier

## 2026-11-20 05:50 - VD on records phase 2 at 87fb2b8: every number checked matches its source; NOT READY on three text points

Measured (worktree detached at 87fb2b8, read only; nothing built, no suite, only logs counted):
- **Suites, recounted from the logs** (scratchpad/vd/count_suite.py):
  - int-check-620c98b.log: 13:38:35 to 16:55:59 (3:17:24); clean, build and check rc 0; 25 legs; 1,505 lines beginning "  ok "; 17 RESULT lines, all PASS; no line beginning FAIL; 5 warnings; every leg at fda3b40's count but check_compare_run, 108 to 109.
  - int-check-61e45bc.log: 02:11:37 to 05:03:15 (2:51:38); the same rc's; 26 legs; 1,649 "  ok "; 18 RESULT, all PASS; the 25 shared legs at 620c98b's counts; check_wave 144.
  - int-check-7444157.log ends on its sixth --leg line, check_door.
  - The lead's normlog.py, rerun: 61e45bc against 620c98b differs, outside check_wave, in the commit line and the four wave-host build lines; 620c98b against fda3b40 in the commit line, four gate-cache lines, case 6 and the new closing verdict. Hex-token lines are identical both ways (117 by my regex; the lead's 122 is its own count).
- **GPU folders:** plgpu-620c98b: 2 ok in 152m46s; the leg 73 ok, 1606 of 1606; 665 records, 22,347 steps, 435 rejected, 3.61 passes. p2seam-7444157: rc 2, 15m19s; NotADirectoryError at check_wave.py:1088; seam 15 ok, 8 FAIL. p2seam-61e45bc: 4 ok in 15m21s; check_wave 147 ok, 0 FAIL; 228,352 cases, digest ca7246a62d9533f6; seam 24 ok.
- **main's Makefile (61e45bc):** 26 --leg lines in each tier; :988 is check-gpu's `--hip` line. check_compare_run.py :836 at 4a8fe99 and :863 at 620c98b and 61e45bc are GATE 1b's `rc1 == 1` test.
- **Mechanics:** merge-tree main 87fb2b8 rc 0 (tree cdfa7ca5), which differs from main in the six documents only. The pin row is one row, its commit cell begins eae74e3, byte-identical to fda3b40's. No LEAD-FILL line is left.
- **git:** P2 nine commits to 82b75b8, then seven; PL five; fda3b40..620c98b +120/-41; 7444157..61e45bc tools/check_wave.py alone, +6/-2; both Makefiles sha256 f82c107b.

Defects, text only:
1. CLAUDE.md's new bullet cites entry 58 for "dry-run only on the host twin". Entry 58 does not say it. The source is lead.md 2026-11-19 05:12 (gpu/p1p2/dry2.log, 22 ok, a DRY RUN on the host).
2. Entry 56 paraphrases check_wave's physics bounds as "within 1e-2 of what the field's absence would move it". check_wave.py's head and CIRC_BOUND make it a ratio, "moves by under 1e-2 of". The angle (1e-4) and the energy (1e-13) are relative as well.
3. Entry 56 says a sample block's short launches mean "none meets the display driver's watchdog (`7dec985`)". 7dec985's message calls the two-second reset BELIEVED, not met.

For: lead, D

## 2026-11-20 05:55 - VD on D's fixes at 57a148e: READY; round5-docs may merge

Measured (worktree detached at 57a148e, parent 87fb2b8, read only):
- **The diff:** five documents, +34/-23, in 11 hunks. Each hunk is one of the nine changes, and nothing else moved. CLAUDE.md is unchanged.
- **Each change against its source:**
  1. Entry 58's dry-run sentence matches lead.md 2026-11-19 05:12 (22 ok, 0 FAIL). The header line it quotes is in gpu/p1p2/dry2.log, and dry1.log has the same header. The first GPU run of the script was p2seam-7444157, 01:00 to 01:17. CLAUDE.md's "(entry 58)" now holds.
  2. Entry 56, part 4, now matches check_wave.py's head word for word ("moves by under 1e-2 of"), and CIRC_BOUND, MM_BOUND and E_BOUND are 1e-2, 1e-4 and 1e-13 (check_wave.py:306 at 61e45bc).
  3. Entry 56's watchdog line, "should", with the reset "BELIEVED, never met", matches 7dec985's message ("BELIEVED, not met").
  4. The six nits:
     - ROUND5.md says "62 min alone ..., and 66 min there".
     - ROADMAP item 2 says "at the pin" and "made ... was".
     - ROADMAP's gate-cache line adds "PL's open notes aside".
     - Entry 58 says "D's count" twice.
     - Entry 58 says "but the Makefile" (git: 620c98b and 61e45bc differ outside P2's files in the Makefile alone).
     - README and RING.md cite Makefile:990, which on main is `tools/check_wave.py --build $(B) --device gpu --quick --expect '$(GPU_EXPECT)'`.
- **Mechanics:**
  - fda3b40..57a148e touches the six documents only.
  - `git merge-tree --write-tree main 57a148e` gives rc 0 (tree 403b31b2), which differs from main 61e45bc in those six documents only.
  - No LEAD-FILL line is left.
  - The pin row is one row, its commit cell begins eae74e3, and it is byte-identical to fda3b40's.

For: lead, D
