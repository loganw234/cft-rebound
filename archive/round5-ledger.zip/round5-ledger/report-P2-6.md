(R5-P2's report on send-back 4, ff7221a, its final message on 2026-11-19 at ~18:53, copied verbatim by the lead.)

Send-back 4 is done: commit **ff7221a** on 1e13456, tools/check_wave.py only (+90/−25), not pushed or merged. Body 6 is now planted in every member, and the off-by-one that passed 1e13456 fails in both forms. One more gap of the same kind is still open at sample 0, and I left it, since this send-back didn't ask for it. Everything is MEASURED on the desktop unless marked READ.

**1. The gap, on 1e13456.** compare_run's particle_compare() covers the massive bodies through the replay's body list (compare_run.py:835). In my copy that slice stops one short: `list(enumerate(bodies))[:-2] + list(enumerate(bodies))[-1:]` in place of `enumerate(bodies)`. The edit must land exactly once or the script refuses; I showed refusals at 2 landings and at 0. On 1e13456, check_wave `--quick` gives RESULT PASS, 92 ok, 0 FAIL, and its massive plants on bodies 0–5 all pass.

**2. The new plants.** A twelfth copy goes after the eleven: vz of body 6 (janus) on member 0's first sampled line, vy on member 1's last, vx on member 2's first.
- The eleven copies cannot be byte-identical raw between any two runs, not even two runs of 1e13456. The program writes its measured throughput (`system_steps_per_s`, sometimes `wall_seconds`) into the record's totals line, line 218, and every copy carries that line.
- Raw, each copy differs on line 218 alone. With those timing values masked, all eleven match 1e13456's sha256 in both forms:

| copy | masked sha256 |
|---|---|
| 1 | f9d011c72c3d26b5 |
| 2 | 1a70463b46ed8acf |
| 3 | 75e362ecf8bbe7d4 |
| 4 | 900aadd4189ccad0 |
| 5 | d69b76f3c1834146 |
| 6 | 67ea2cead83d2846 |
| 7 | f442d73642c1a127 |
| 8 | 4e186f776d464e4a |
| 9 | cd46c540f82985a4 |
| 10 | 9f474a5a48f50ad6 |
| 11 | 5519bfa0a811d113 |
| 12 (new) | f370f9eef4b40364 |

So the 27 compare_run mutants need no rerun.

**3. The coverage verdict.** It now reads the `# active` count and each member's `# body` lines itself, not through `record_classes()`. Each member must list its 64 bodies in order, with a nonzero mass on exactly bodies 0–6. Every massive body must be planted at least once, and the last one in every member; a gap is named like "the last massive body, 6 (janus), not planted in member 1".

**Other classes' last items:** t_lo (schedule), vz (a particle's own columns), max_pc_iterations (counters) and each member's last sampled line are all planted, and the verdict already required each.

**The open end is sample 0.** It is never planted, because compare_run checks sample 0's bodies against the problem file and refuses the whole run on any difference (READ, compare_run.py:515–529). A compare_run whose member and particle loops both start one late, so it never compares sample 0's schedule columns, passes `--quick` at 1e13456 (92/0) and at ff7221a (96/0). Closing it would mean one more copy of the same shape (a schedule column on sample 0 in every member) plus one coverage rule.

**4. Runs**

| run | `--quick` ok/FAIL | full ok/FAIL |
|---|---|---|
| tree at ff7221a | PASS 96/0 | PASS 105/0 |
| tree at 1e13456 (reference) | PASS 92/0 | PASS 101/0 |
| off-by-one | FAIL 93/3 | FAIL 102/3 |

The off-by-one's three FAILs are plants 12.0–12.2, each "vz/vy/vx of body 6 … its particles: 2 of 2 carry it and FAIL naming it … 0 of 2".

The six mutants plus my two particle mutants, all RESULT FAIL, now against 1e13456:

| mutant | now (`--quick`) | at 1e13456 (`--quick`) |
|---|---|---|
| step class dropped | 87/1 | 83/1 |
| max_pc_iterations dropped | 95/1 | 91/1 |
| `[1:2]` | 90/6 | 87/5 |
| left-out past end | 94/2 | 90/2 |
| (iii) member 2 never planted | 85/1 | 81/1 |
| (iv) no counter | 87/1 | 83/1 |
| my particle mutants | 95/1 each | 91/1 each |

Two of these moved, so I also ran them in full:
- `[1:2]` also refuses copy 12, whose member-1 plant lands on sample 1. Full: 99/6, same FAILs as quick.
- (iii)'s gap list changed: copy 12 now covers member 2's first-line massive class, and the new rule adds bodies 4 and 5 as never planted. Full: 94/1, same FAIL as quick.

**Housekeeping**
- All runs were on the desktop, booked shared as B0204 (17:31–18:53, now released), at most four at a time.
- The ledger entry is in P2.md under 18:53.
- Nothing of mine is running.

Everything is in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\sb4:
- run4.log
- copies_sha.log
- mutants4.py
- snap\, tree\, mutA\, mutB\ (one log per run)
