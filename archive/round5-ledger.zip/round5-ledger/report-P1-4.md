(R5-P1's report on send-back 3, its final message on 2026-11-18 at ~14:55, copied verbatim by the lead.)

The gap is closed in **0f324bd**, a new commit on fc4ba21. Every class a particle's replay carries now has a plant in each wave, in both forms. V1's own-body mutant fails the seam, the three earlier mutants still do, and the tree passes. Nothing is pushed or merged, and I used no GPU.

**What changed** (`seam_form()`, section 3 of the header, and the one-line plant-count comment in `seam()`)
- **New plant:** in each wave, vy of the first particle the clean run sampled, on the wave's first sampled line (body 22 on line 140, body 57 on line 141). The member must FAIL naming it, that particle must FAIL naming the same line and column, the wave's other particle must stay IDENTICAL, and the other wave and its particles must stay IDENTICAL.
- **Class per plant:** each plant is labelled schedule, massive body, sampled particle's own body, or a body no sampled replay carries. The label is derived from compare_run's own particle lines. Each class fixes how many of the wave's particles must FAIL (all, all, exactly one, none), and the planted run must agree with that count.
- **Coverage verdict:** a last verdict in each form checks that every class has a plant in each wave.
- **I added one class you didn't ask for: the trailer's counters.** Both the member comparison and every particle replay check them, but the rule didn't name them and no plant reached them. The new plant changes mean_pc_iterations on each wave's trailer line (lines 144 and 145).
- **FMA form:** it now plants every class in each wave (x of body 1, dt_next, the particle's vy, the trailer); before, it planted only x of body 1.
- **Dry-run time:** 24 compare_run runs a seam instead of 14, so your live seam will take longer than before.

**Counts** (desktop harness, software record; same counts on both compare_runs)

| Run | This tree's compare_run | P3's (round5-int) |
|---|---|---|
| Tree | 28 ok, 0 FAIL | 28 ok, 0 FAIL |
| Never compares member 1 | 17 ok, 11 FAIL | 17 ok, 11 FAIL |
| Never compares member 0 | 17 ok, 11 FAIL | 17 ok, 11 FAIL |
| V1's particle mutant | 8 ok, 20 FAIL | 8 ok, 20 FAIL |
| V1's own-body mutant | 24 ok, 4 FAIL | 24 ok, 4 FAIL |
| Member's counters never compared | 24 ok, 4 FAIL | 24 ok, 4 FAIL |
| Particle's counters never compared | 24 ok, 4 FAIL | 24 ok, 4 FAIL |

- **Member mutants:** each fails all eleven of its wave's plants.
- **Particle mutant:** fails every plant except the vz-of-body-63 ones, which no sampled replay carries.
- **Own-body mutant:** fails exactly the four vy plants. Its detail reads "body 22: IDENTICAL: 3 samples, 144 values", where the tree compares 162.
- **Counters mutants:** each fails exactly the four trailer plants.
- **Both versions:** each mutant fails the same plants on both compare_runs.
- **Mutation script:** every edit landed once in both versions. Run on its own output, each new kind refuses: "the edit lands 0 time(s) … nothing written", rc 2.

**Unplanted classes:** none of the classes the rule names. Some values inside classes are still unplanted, as V1 accepted as designed:
- dt_last, E and t_hi in the schedule;
- the trailer's other counters;
- the other values of the massive bodies and of the particle's own body.

The "body no sampled replay carries" plant exists in the REBOUND form only.

**Bookings:** desktop, shared, B0170 from 14:29 to 14:54:09, released when the batch ended. The send-back 2 passes used B0167 and B0168, released at 13:46:19 and 14:01:46.

Files are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad:
- p1\sb3\ (the 14 dry-run logs)
- p1\sb1\mutate_compare_run.py
- ledger-drop-r5\P1.md (14:56 entry)
