(R5-VL's report on the three hardenings of the lead's p1p2_seam.py, f4e475dd5282914a, its final message on 2026-11-20 at ~01:45, copied verbatim by the lead.)

**The three hardenings in p1p2_seam.py (sha f4e475dd5282914a): READY.** Every case you listed behaves as asked.

**The diff (READ).** Compared with the c9e39a38 version, the only changes are your three:
- Section 0 keeps `kdev` (the first stdout line from `--device-info` that starts with `# device `) and refuses the run unless it exists and names `--expect`.
- The device verdict also requires the kernel record's one device line to equal `kdev`.
- The arch regex now ends `[,:]`.
- Under `--dry-host`, a new verdict requires that no record carries a `# device` line.

**Through `main()` (MEASURED).** I used the same stub as last time, in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\vl_seamtest2.py`. It checks the sha when it loads your file and writes no bytecode.
- **Unchanged:** the saved records still give 24 ok, 0 FAIL on the GPU path.
- **The three that passed before now FAIL by name:**
  - the device line's index changed: the device verdict FAILs ("same as its --device-info line (False)");
  - the arch changed in both the device line and the backend: the same verdict FAILs;
  - under `--dry-host`, a device line in the cpu record or in the host twin's record: "dry run: no record carries a `# device` line" FAILs. The clean dry run gives 23 ok.
- **The nine earlier cases still FAIL,** by the same verdicts as before. A changed arch in the device line alone now also FAILs the device verdict.
- **Feature flags:** with `(gfx90a:sramecc+:xnack-, ` in both the probe's line and the record's, and `backend=hip:0:gfx90a`, the run gives 24 ok.
- **Probe one character off:** a probe line differing from the record's by one character (16284 MiB) FAILs the device verdict.
- **Two refusals I added:** a probe line on stderr only, and one naming another GPU, are each refused in section 0 before anything runs.

Your script is unchanged by my runs, and the ledger entry is "2026-11-20 01:36" in VL.md.

**READY**
