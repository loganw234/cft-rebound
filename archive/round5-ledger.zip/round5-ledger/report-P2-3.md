(R5-P2's report on send-back 1, its final message on 2026-11-18 at ~17:36, copied verbatim by the lead.)

Send-back 1 is done at **8f559c8**, one commit on 82b75b8. `check_wave` now plants in an ensemble record, and all 27 mutants from V2's list fail it by name in both the `--quick` and full forms. The worktree is clean and nothing of mine is running anywhere.

**What changed** (`tools/check_wave.py`, `src/wave/wave_main.cpp`, `Makefile`):
1. **The plants:** 24 per run, in the 3-member ring record (A in `--quick`; the same ring at 12 steps, "P", in full), on whichever device the run uses.
   - Columns: the schedule (t, dt_next, dt_last, E, t_hi, t_lo), x–vz of massive bodies 1–6, x–vz of a sampled particle's own body, the step field, and the five trailer counters.
   - Spread over members 0, 1 and 2, on the first sampled line and the last. Nine record copies, one plant per member each; three copies leave a member unplanted.
   - Each plant must fail its own member naming the line and column. That member's particles must fail where their replay carries the column and stay identical where it doesn't; which carry it comes from compare_run's own particle lines. Unplanted members and their particles must stay identical.
2. **Particle count:** checked against a plan computed from the problem file (6 for the ring), so 0 of 0 now fails.
3. **Physics control:** now reads `physics_verdict()`'s decision, and requires both the distance and angle criteria to refuse.
4. **Attempts comparison:** is now one function, with a control that changes one dt.
5. **Identity line:** `contract=` and `flags=` come from the build's own defines; `check_wave` asserts them for A and both control builds.
6. **GPU probe:** `wave --device gpu --device-info` opens the device and launches nothing. `check_wave` runs it first and refuses an unexpected device before anything runs. Comment fixed.
7. **Smaller fixes:**
   - E's counters now carry member 1's label.
   - The quick ring is now 3 waves, so member 2 is covered in both forms.

**Desktop, the tree:** `--quick` PASS, 74 ok, 0 FAIL; full PASS, 83 ok, 0 FAIL.

**Mutants** (`scratchpad\p2r5\sb1\mutants.py`). Each edit must land exactly once or the script refuses before anything runs; the refusal shown was `REFUSED: an edit of compare_run.py lands 2 times, not once`. Every row is RESULT: FAIL; counts are ok/FAIL.

| mutant | quick | full |
|---|---|---|
| m0_lines | 68/6 | 77/6 |
| m1_lines | 68/6 | 77/6 |
| m1_all | 66/8 | 75/8 |
| m2_all | 67/7 | 76/7 |
| first3_lines | 65/9 | 74/9 |
| first3_both | 65/9 | 74/9 |
| no_particles | 44/30 | 52/31 |
| particle_noop | 52/22 | 61/22 |
| col_x, col_y, col_z, col_vx, col_vy | 72/2 | 81/2 |
| col_vz | 72/2 | 80/3 |
| col_t | 73/1 | 81/2 |
| col_dt_next, col_dt_last, col_t_hi | 73/1 | 82/1 |
| step | 73/1 | 82/1 |
| ctr_steps_rejected, ctr_mean, ctr_max, ctr_caps, ctr_steps_done | 73/1 | 82/1 |
| cw_physics, cw_attempts | 73/1 | 82/1 |
| cw_particles | 44/30 | 52/31 |

A step or steps_done plant is caught first by compare_run's completeness check, not its comparison. So the step and ctr_steps_done mutants remove that check as well; without it, each would behave exactly like the tree.

**RX 7600 at 8f559c8:** `check_wave --device gpu --quick --expect "RX 7600"` gave RESULT: PASS, 91 ok, 0 FAIL, 1,109 s, with `# device hip:0 = AMD Radeon RX 7600 (gfx1102, …)`. Run with `--expect "RTX 4070"` it is refused on the probe's device line in 0.12 s, and its work directory stays empty.

**Bookings, all released:** B0171 (desktop, 14:42 to 17:35), B0174 (RX 7600) and B0175 (nvidia-box), 15:15 to 15:36.

**Records:** the drop file's 14:59 entry adds the test–test limit (two coincident test particles stop the port with DIVBYZERO but not the kernel) and that the unchecked control holds a different source from the shipped one. The 17:37 entry has the full results.

**Left undone:**
- V2's second look.
- A full `make check` at 8f559c8: not run, as briefed.
- The 5060 Ti: not run, as briefed.
