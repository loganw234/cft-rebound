P3 is done and committed in my worktree: `compare_run.py --producer-files DIR` replays sampled particles from a producer's own attempts records and schedules, with no rerun of their member. The gate and both full suites pass, and both mutants of the driver are caught. The most important finding is a limit: a producer's files hold its arithmetic, not its decisions.

**Base and commit.** The base is `5b1cac6`, checked with `git log --oneline -1`. The commit is `2922fa1` on `worktree-agent-a35562c26dc613fed`, worktree only; nothing pushed, merged or rebased. It changes `tools/compare_run.py` and `tools/check_compare_run.py`, in `C:\Users\logan\source\repos\cft-rebound\.claude\worktrees\agent-a35562c26dc613fed\`.

## What changed, file by file

**`tools/compare_run.py`**
- **New options:** `--producer-files DIR` and `--particle-strata P` (default: as many as `--strata`). `PRODUCER_FILES` states the file names once; the gate imports it.
- **Which particles are sampled:** those of the member sample's members, plus one member from each of P ranges of member index, drawn under a separate SHA-256 name so the two samples are independent.
- **Key check before anything runs:** each pair found is held to its member's run by the key `ias15_cft --run-key` prints. Nothing in Python hashes anything.
  - A file keyed for another wave, format, `active` line or `zonal` line is REFUSED (rc 2), naming the member, the file and every key field that differs.
  - A file not of its form is refused by its first line.
- **The replay:** particles replay against the producer's own files with no rerun of their member, on the engine the files are keyed to.
- **Member lines, "say which, and why":** a member in the member sample is rerun as today. A member outside it prints `NOT RERUN`: held by the record alone, and by its particles' replays, which hold every massive body and the exact-time pair. A pair that is not both there falls back to today's rerun and names the missing file.
- **The key's engine:** the record's own engine if this tree has it; otherwise the one given to `--rerun-engine`. Without either, it is refused by name.
- **Particle lines:** each now names the files it replayed from, plus its replay's counters and its closest approach. The prefix and `held to the record: IDENTICAL|FAIL` are unchanged; I told P1 and P2 the exact wording. Each replay's record is kept as `particles/<stem>.rec`.
- **The header** states the limit described under Findings.

**`tools/check_compare_run.py`**
- Case 7 holds gates 1, 1b and 2, plus the cases listed under Gate output: zonal waves, half a pair, one-system records, another producer's engine, and (full only) the program engine.
- Controls q1 to q7.
- `--driver FILE`, so the gate can hold a mutant copy of the driver.

**Makefile:** no change. Case 7 runs nothing the leg's `--input` list didn't already name; its single problem is written from the gate's own waves.

## For P2: names and format (in the ledger since 10:03)

- **Names:** `DIR/member<k>.att` and `DIR/member<k>.sched`. k is the member's index in the problem file, decimal, unpadded.
  - For a problem with no system lines there is no `--member`: the files are `member0.*` and the key says `member=-1`. P2 found my first entry wrong here; corrected.
- **Format:** exactly what `--attempts-out` and `--record-iters` write for that member run alone. Line 1 is the form's magic line; line 2 is `# run <key>`.
  - The attempts record has one line per attempt (`<hex dt> a` or `<hex dt> r`), then `<dt> next`.
  - The schedule has one line per attempt: the passes, or `<max_iter>c` where the cap stopped it.
  - LF and CRLF both read.
- **Key:** what `ias15_cft --run-key` prints for the arguments compare_run reruns the member with.

## Gate output (actual lines, from the full `make check`'s leg, binary64; long lines trimmed with [...])

```
ok   fp64: GATE 1, the same particles: each of the 18, picked alike in both runs, replayed from the producer's own files is IDENTICAL to the same particle replayed from a rerun's - every sample line, 1512 tokens, and the trailer's counters, flags and calls; each replay's record names the attempts record it ran from, the producer's in 18 of 18 and the rerun's in 18 of 18; members [0, 1] rejected their first attempt, the rejection that leaves state, and their particles are among them
ok   fp64: GATE 2, the physics beside each: every particle's replay counters are its member's trailer (steps 40, rejected 0 to 3, mean passes 3.293 to 3.875, max passes 7 to 9, cap hits 0), and so is each not-rerun member's trailer line; its 36 closest approaches [...] agree with this gate's mpmath [...] to 3.29e-7 relative
ok   GATE 1b, from the producer's own files: member 4, NOT RERUN, holds - both its particles IDENTICAL to the producer's record, whose lines are not this tree's [...]; member 2 FAILs on its rerun (trailer mean_pc_iterations is 3.275 in the record (line 90), and 3.300 here [...]), while both its particles, replayed against the producer's schedule, are IDENTICAL
ok   GATE 1b, the same record replayed from this tree's reruns instead (no producer's pair): members 4 and 2 FAIL, and all 4 of their particles FAIL [...] (rc 1)
```

- Gates 1 and 2 pass identically at binary128 and binary256: 18 particles each, members [0, 1] among them.
- Also ok (MEASURED):
  - the zonal waves: 18 particles replayed with the zonal line;
  - half a pair: the schedule alone is named missing, and that member falls back;
  - a `--member 4` record;
  - a single problem keyed `member=-1`;
  - kepler, with every body active: the files are not read, and it says so;
  - a record rewritten as `program=wave ... engine=wave` with `--rerun-engine loop`: PASS, and REFUSED without `--rerun-engine`;
  - full only: the program-engine record with `--rerun-engine loop`, its files keyed at `engine=program`: PASS.

## Controls (each on a copy, deleted after; MEASURED)

| control | result |
|---|---|
| q1: one attempt's dt, one line per member: first attempt rejected (member 0), first accepted (4), middle accepted (5), the `next` line (7); plus the outcome column (member 1, r made a) | each FAILs both of that member's particles by name, e.g. `record line 61 (system 0 sample 0, step 0): dt_next`; the outcome flip is refused by the replay ("schedule holds more"); everything else IDENTICAL. At all three formats. |
| q2: one pass count: first attempt −2 (member 4), a middle attempt +1 (member 5), first attempt −1 in rerun member 2 | each FAILs by name. At binary64 member 4 failed in bits (`E` at line 74); the other 8 of the 9 plants across three formats were caught only by `mean_pc_iterations`. |
| q3: schedule, then attempts record, from another wave | REFUSED, fields `member, state` |
| q4: the zonal line's J2 changed | REFUSED, field `zonal` and no other |
| q5: schedule recorded at binary128 | REFUSED, fields `format, pc_tol_shift, dt0, epsilon, state` |
| q6: schedule recorded under `active 3` | REFUSED, field `active` and no other |
| q7: attempts record given as the schedule | REFUSED by its first line |

**Mutants of the driver** (one-time; the script refuses to run unless each edit lands exactly once):
- **M1**, the brief's mutant: it reads the files but replays rerun members against the rerun's schedule. RESULT FAIL, 61 ok and 3 FAIL: GATE 1b and q2 catch it by outcome, and the particle lines' file paths catch it by provenance. GATE 1 alone passed against it, which is why GATE 1b exists.
- **M2**, which also reruns every particle member: FAIL, 64 ok and 4 FAIL.
- Both ran the quick gate as it stood that morning. The permanent catchers, GATE 1b and q2, are unchanged in the final commit.

## Suites (MEASURED; shared host, all booked and released)

| run | result |
|---|---|
| full `make check` (B0085), 12:39 to 16:40 | rc 0; 25 legs in full mode, none skipped; 1,501 ok, 0 FAIL, 17 RESULT: PASS. check_compare_run 105 ok (67 + 38); the other 24 legs total 1,396 (P0's 1,463 − 67), not compared leg by leg. 24 wide-state digest lines present, also not compared with P0's (I have no P0 log). |
| `make check-light` (B0081) | rc 0; 25 legs, none skipped; 937 ok, 0 FAIL |
| `check_compare_run` full | PASS, 101 ok (the gate as of 10:36) |
| `check_compare_run --quick` | PASS, 68 ok |
| `check_ring_seams --quick` | PASS, 21 ok |

## Findings

- **Arithmetic, not decisions (MEASURED, GATE 1b).** Without a rerun, the replay takes the producer's dts, outcomes and passes as given. A producer whose first attempt took 5 passes where this tree's takes 7 passes on a member that is not rerun, even though 2 of 3 of its sample lines are not this tree's; the same member FAILs once rerun. Decisions are held only on rerun members.
- **Pass counts barely move bits (MEASURED).** One pass more or fewer moved no bit at the samples in 7 of 7 tries at binary64. At binary128 and binary256 even two fewer moved none. Only the trailer's 3-decimal `mean_pc_iterations` catches them.
  - COMPUTED, not run: in a member of more than ~1,000 attempts a single pass is not guaranteed to show there.
  - Today's rerun path has the same blind spot. With the producer's files, a rerun member could be held pass for pass; not built, since the brief keeps member lines "as today".
- **Rejecting waves are always rerun.** Every member with a rejected step stays in the member sample, as briefed. A ring started from too large a dt0 is rerun whole, files or not.
- **P2's shape works (MEASURED by hand, not a gate case).** On a 2-wave, 64-body make_ring ring with its zonal line, the wave that was not rerun had both particles IDENTICAL from the producer's files.
- **Cost on the 10^6 ring (BELIEVED, not run).** About three whole-file reads of the ~175 MB problem per particle member: one for my key check, plus extract_particle's own key calls.

## What I did not do

- No GPU, and none of P2's files read. P2 measured that its host twin writes my names and forms.
- The pass-for-pass check of rerun members' files described above.
- Sampling by close approach to a moon, or a record that names non-default run settings (both still not built).
- No change to `docs/`.
- `--particle-strata` defaulting to `--strata` is my choice.

## What the brief or ROUND5.md got wrong

- **ROUND5.md's first test cannot fail on its own.** "Particles sampled from [ias15_cft's] own files are identical to those sampled through a rerun" is true, but those files are a rerun's to the byte, and M1 measured GATE 1 passing against a driver that ignores them. It needs GATE 1b's different producer. The brief's mutant control anticipates this; ROUND5.md's text alone does not.
- **"A planted pass count is caught" is true, but by a counter, not the bits.** The counter loses resolution on long runs.
- **docs/RING.md** implies the producer's files are enough to hold a member that is not rerun. They hold its arithmetic only.
- **"With no rerun of the member"** never applies to a rejecting wave.
- **The brief's one-line `third_party` clone** is refused by the worktree guard; separate commands work. P2 hit the same.
- **My own errors, corrected in the ledger:** the key command for single problems, and guessed heading times (mine at 10:20, and P1's and P2's as well).

I wrote seven ledger entries, the last at 16:42 (in `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\P3.md`, placed in the ledger). The mutation script is `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p3-r5\mutate.py`, and the run logs are beside it in the same `p3-r5` folder.