(R5-V2's report on its sixth look at P2's 3d8ab5b, its final message on 2026-11-20 at ~02:12, copied verbatim by the lead.)

**READY on 3d8ab5b.** check_wave's default work directory no longer collides with build/wave, the tree passes both forms and leaves nothing behind, and the 14 copies are unchanged.

1. **Scope:** `git diff 9fa5956 3d8ab5b` touches tools/check_wave.py only, +6/−2 (MEASURED). It changes the header note and the default path, which is now `<build>/check_wave/<pid>`, plus a two-line comment above it (READ). Nothing else.
2. **The clash, on my own setup:** a scratch copy of build/ with a 73-byte plain file at `wave`, run without --keep (MEASURED).
   - At 9fa5956 it fails before running anything: rc 1 in 261 ms, at check_wave.py:1088 `os.makedirs`, with `FileNotFoundError: [WinError 3]` on `...\build\wave\26424`. The log holds only the traceback.
   - At 3d8ab5b, `--quick` gives RESULT: PASS 130/0. The `wave` file's sha256 and mtime are unchanged.
3. **The tree:** `--quick` with --keep PASSes 130/0, and full without --keep PASSes 144/0 (MEASURED). Neither run without --keep (this one and the clash run) left a `<pid>` directory; only the empty `check_wave/` parent remains.
4. **Nothing else uses the old path** (READ).
   - No tracked file names `<build>/wave/` as a directory. Every `build/wave` in the tree is the kernel itself.
   - Everything check_wave writes is under its work directory, and it never passes --keep to compare_run.
   - No Makefile output is named `check_wave`. The `wave` and `wave-host` outputs (wave*, wave_host*, wave_corpus*) are all distinct from it.
   - On the merge commit 7444157, `check-gpu` runs check_wave with the default path, next to check_gpu.py's `<build>/check_gpu/<pid>`.
5. **The copies:** all 14 from the --quick run match 9fa5956's once masked (MEASURED). Raw, they differ only in line 218's `system_steps_per_s`.

**P2's note about leftover `build/wave/<pid>` directories:** I agree, with one nuance (READ).
- `make clean` is `rm -rf $(B)`, but no check target depends on `clean`: not `check`, `check-quick` or `check-light`, and not 7444157's `check-gpu`. So the `make clean` before the redone merge's `make check` comes from your procedure, not the Makefile.
- A leftover directory would block `make HIP=1 wave` (or `make HIP=1 check-gpu`) only on a reused GPU tree. A fresh clone has none, and the desktop never builds `wave`.
- All my own GPU runs passed --keep outside build/, so none of my trees holds one.

Cleanup:
- The desktop booking B0213 was released at 02:09.
- The scratch build copy is deleted, the worktree is clean at 3d8ab5b, and nothing of mine is running.
- The ledger entry is in V2.md at 02:12.
- Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\v2\sb5.

**READY**
