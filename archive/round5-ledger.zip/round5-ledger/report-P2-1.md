The round is paused cleanly. The branch tip is **81af26a** on `worktree-agent-aecde4474af33b9f7` and the worktree is clean. On the RTX 5060 Ti the kernel matches the port bit for bit and passes its gates. The RX 7600 was never run, and there is no complete full `make check` at the tip.

Nothing of mine is running on the desktop, in cft-gpu or on nvidia-box (I never touched nvidia-box). All five bookings are released: B0073 and B0074 at 17:29 unused, B0071, B0072 and B0090 at 17:52. The ledger entry (17:53) is in my drop file.

## Where to pick up
1. Book `rx7600` (exclusive) and `nvidia-box` (shared), about 2.5 h each.
2. Copy to `nvidia-box:~/cft-rebound-r5-p2/p2in/`, all from `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\`:
   - `bundles\*` (`p2.bundle` is at 81af26a, sha256 `19987652…`);
   - `gpu_setup.sh`, `gpu_session.sh`, `box_p2.sh`, `seam.py`, `rates.sh`, `threeway.sh`, `physics.py`;
   - `rings\ring_{1,16,128,527,4096}.txt` and `rings\ring2_seam.txt`.
3. Run `ssh -o BatchMode=yes logan@192.168.0.2 bash cft-rebound-r5-p2/p2in/box_p2.sh r1 pre setup build first corpus literal threeway gate gate-quick ladder rung hold phys` and attach that ssh's Windows pid to both bookings.
4. Run the full `make check` at the tip beside it, started from PowerShell.

These scripts are not committed, since they sit outside my files. If the scratchpad is cleared they can be rebuilt from my transcript.

## What changed, file by file (8 commits on 5b1cac6)
- **`src/wave/wave_hd.h`**: defines `__host__`/`__device__` away without HIP. It refuses an x86-64 host build without `-mfma`, and refuses `-ffast-math`.
- **`src/wave/wave_arith.h`**:
  - checked binary64 add, sub, mul, div, sqrt and fma, with exact detection of all four flags the port aborts on, INVALID included;
  - the clock's augmentedAddition, which rounds ties toward zero;
  - the host's fma and sqrt through intrinsics, so every optimisation level gives the same bits;
  - at 81af26a, a subtract's slow path reads `b` itself rather than its negation (see gate 4).
- **`src/wave/wave_step.h`**: the step in the port's FMA form: predictor and corrector, gravity with the `active` split, J2/J4 in the port's order, PRS23 step control, Kahan sums, sqrt7, energy.
- **`src/wave/wave_io.h`**: libcft's hex text in both directions.
- **`src/wave/wave_main.cpp`**: problem reader, constants, both record formats, attempts and schedule files under the port's run key, flag stops by name.
- **`src/wave/wave_gpu.inc`**: the HIP kernel. One system a workgroup, one thread a body, reductions in shared memory. Launches are bounded, so none runs into the display driver's watchdog.
- **`src/wave/wave_corpus.cpp`**: gate 4. Its GPU device line now matches the records'.
- **`tools/check_wave.py`**: the gate, parts 1 to 6, on host or GPU. At bc9feb3 its ring physics is derived rather than transcribed, and it gained a no-zonal-field control.
- **`Makefile`**: `wave-host`, `make HIP=1 wave`, and the `check_wave` leg in all three tiers (26 `--leg` lines each).

## Gate output
- **Desktop, first full `make check` at 7dec985** (11:55 to 15:51, rc 2): 25 legs PASS. `check_wave` failed one verdict of its own:
  `FAIL A: in Saturn's own field every test particle's distance from it moved 1.7622 km at most (the bound is 1 km; …)`
  - That 1 km was copied from round 4's seam figure on a different run.
  - In the full tier's 3-wave ring, p0000159 passed 679 km from Pandora and moved 1.76 km. Every other particle moved 0.26 km at most, and all records were identical to the port's.
  - bc9feb3 replaces it with a derived check: each particle's distance change against what the field's absence would give (worst 1.43e-3, bound 1e-2), the angle swept against n·t in the field (|mm| at most 9e-6, bound 1e-4), and the energy (bound 1e-13).
- **Desktop, `check_wave` alone at bc9feb3's gate**: `--quick` RESULT: PASS, 49 ok; full RESULT: PASS, 57 ok.
- **5060 Ti at 81af26a**: full `RESULT: PASS`, 77 ok, 0 FAIL, 1,276 s; `--quick` PASS, 65 ok, 365 s. The quick form is what check-gpu will run.
  - Every record is compare_run-IDENTICAL member by member, with particles replayed.
  - Every record also equals the host twin's line for line.
  - Every attempts record and schedule is the port's own.
  - Device line: `hip:0 = NVIDIA GeForce RTX 5060 Ti (sm_120, 36 multiprocessors, bus 0000:05:00.0, …)`.
- **Seam on the GPU's first record**: `SEAM: PASS: the GPU record IDENTICAL unplanted, and 7 of 7 plants caught by name in wave 0 with wave 1 IDENTICAL`.
- **Three ways** on one ring wave (port on the CPU, port on hip:0, the kernel): IDENTICAL, including a first-attempt rejection.
- **The 10-orbit record held**: compare_run on the 1,755-wave, 362-step rate record, 2 members rerun by the port: IDENTICAL, PASS.

## Gate 4 per GPU
- **Desktop**: 1,064,352 cases, 0 mismatches.
- **5060 Ti at bc9feb3**: 3 mismatches, every one a subtract with a signaling NaN as `b`:
  - `MISMATCH gpu sub (flags): a=0x1.25076e184d9c1p-797 b=-snan(0x59e580b9bf431) … libcft flags=0x01; gpu flags=0x00`
  - `… a=0x1.71090a6804d01p-279 b=-snan(0x35f41abc7ff87) …`
  - `… a=-0x1.6ae38728241d5p-360 b=snan(0x72a2bd6b738cb) …`
  - A probe showed why: nvcc compiles the bit-level sign flip as `DADD R6, -RZ, -R2` (and the abs mask as `DADD R8, -RZ, |R2|`), which turns a signaling NaN quiet.
  - Fixed at 81af26a; no finite value changes.
- **5060 Ti at 81af26a**: 0 mismatches in 1,064,352 cases.
- **RX 7600**: not run.

## Controls
- **Contraction**: the unchecked source with contraction off passes; with contraction on it fails (the `t` column differs at line 207 on the GPU).
- **The brief's literal control**: the checked source with contraction on is IDENTICAL to the shipped build on both g++ and nvcc, so as worded it cannot fail.
- **Planted digits**: `t`, `E`, `vz`, `t_lo` on the desktop, plus the GPU seam's 7 columns; all caught by name.
- **Trailer counter**: `steps_rejected` +1 is caught.
- **Physics control** (new): wave 0 with its zonal line deleted gives 5 sample lines identical to the port's, and the physics check fails it on both counts (distance ratio 1.00, angle -1.3e-2).
- **Flags**: each of the four flags stops both programs (rc 3, named), and under `--no-flag-abort` both report the same flags.

## Rates on the 5060 Ti (MEASURED, one run a row)
Kernel time excludes the first launch; ring seed 1, dt0 600 s, epsilon 1e-9.

| waves | steps | kernel s | wall s | system-steps/s (kernel) | system-steps/s (wall) |
|---|---|---|---|---|---|
| 1 | 24 | 0.028 | 0.029 | 857 | 828 |
| 16 | 24 | 0.030 | 0.032 | 12,800 | 12,000 |
| 128 | 24 | 0.057 | 0.072 | 53,895 | 42,667 |
| 1,755 | 24 | 0.663 | 0.852 | 63,529 | 49,437 |
| 4,096 | 24 | 1.524 | 2.028 | 64,504 | 48,473 |
| 1,755 | 362 | 9.462 | 9.643 | 67,143 | 65,883 |
| 4,096 | 362 | 21.616 | 22.036 | 68,595 | 67,288 |

GPU-E2 estimated 14 min for 10^5 particles over 10 orbits, which is 756 system-steps/s (COMPUTED as 1,755 × 362 / 840 s). The kernel runs that rung in 9.6 s. The estimate priced libcft's software binary64, while the kernel uses the hardware's. Energy over the 10-orbit runs moved 3.5e-15 and 4.1e-15 of itself.

## Not done
- **RX 7600**, steps 3 to 6: build, records, gate 4, seam, rates.
- **Full `make check` at the tip**: the second run (81af26a) was stopped at 17:29 in leg 9 of 26 (`check_gravity`), with legs 1 to 8 passing.
- **check-gpu's `check_wave` line**: agreed with P1; the lead adds it at the merge.

## What the brief or ROUND5.md got wrong
- **The clock is not TwoSum.** libcft's augmentedAddition rounds ties toward zero, and ring records show the difference.
- **The literal contraction control cannot fail** on g++ or nvcc.
- **The flags list omits INVALID**, which the port also aborts on.
- **New trap:** under nvcc a bit-level negation or abs is not a bit operation on a NaN.
- **MinGW's library fma and sqrt are not correctly rounded**, and g++ calls them at -O0.
- **Not comparable:** GPU-E2's estimates are for libcft's binary64, not the hardware's.

The 1 km physics bound was my error, not the brief's.