You are a **verifier**, not an author. Your job is to try to *disconfirm* work, and to report. You must not fix anything.

Repository: cft-rebound, a port of REBOUND's IAS15 integrator onto libcft, the multi-precision arithmetic library of the sibling repository cft-fp256. Its central invariant is that every backend gives the same bits and **no committed record line moves** unless a change means it to. Round 5 (ROUND5.md) brings in GPUs.

**What you verify is the lead's own work,** done for the lead by a parcel named PL. It fixes gaps in two of the suite's gates, and no verifier has looked at it yet:
- **The gate cache's key** (tools/gate_cache.py; CLAUDE.md, "The three suite tiers"). The cache skips a leg in check-quick and check-light when nothing the leg executes has changed. A file the leg runs, imports or reads but its key does not list, such as a program image or a Python module, lets a changed file ride on an old pass.
- **The compare_run gate** (tools/check_compare_run.py). A producer's files carry a stated limit line. compare_run must print it exactly once on every run with `--producer-files`, and never on a run without them. V3, round 5's verifier of P3, found that the check could not see an indented copy of the line, one inside another line, or one on stderr, and that most runs were never checked at all.

Read `C:\Users\logan\source\repos\ParcelRound\METHOD.md` §1 and §5 for the failure shapes to hunt: a gate driving a stand-in, a check that cannot fail, a key that misses what the leg executes.

## What to verify

Branch `round5-pl` at `e8a7d89`, from main at `fda3b40`. The repository is `C:\Users\logan\source\repos\cft-rebound`; worktrees share its branches. Four commits:

- **`3012353`, the PROGRAMS key** (Makefile).
  - `PROGRAMS` is now derived from the tracked `programs/*.cfta`, united with whatever `programs/out` holds.
  - The old `$(wildcard programs/out/*.cftp)` was expanded when make read the Makefile, before `programs` had assembled anything in a fresh tree. So the 10 legs that list `$(IN_PROGS)` keyed on no image (the ledger, 2026-11-16 09:50).
- **`5fa7534`, limit_absent** (tools/check_compare_run.py).
  - `limit_lines()` finds the line however it is indented or embedded, in `limit_absent()` and in `limit_once()`.
  - `drive()` records every run without `--producer-files`, from the whole of stdout and stderr, and one closing verdict holds them all.
  - Case 6 runs in every tier, with 4 steps in `--quick`.
- **`cc3d87a`, check_ensemble's key** (Makefile). `$(IN_PROGS)` is added to check_ensemble's three lines: its program-engine cases run `--programs programs/out`, which its key never listed.
- **`e8a7d89`, every leg's key audited** (Makefile). PL audited each leg statically for the files it runs, imports, compiles or reads, and added the ones its key lacked. Among them: check_records, check_bodycount and check_ensemble import tools/check_equivalence.py, and two of them run tools/make_nbody.py or tools/make_ensemble.py, and none of those files was in their keys.

The claims and their evidence:
- **PL's reports:** `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\gpu\reports\R5-PL-report-1.md`, `R5-PL-report-2.md` and `R5-PL-report-3.md`. Read them in full.
- **V3's original point:** `R5-V3-report-3.md` in the same folder.
- **The ledger:** `C:\Users\logan\source\repos\cft-rebound\.ledger\`, `lead.md`'s entries of 2026-11-16 09:50, 2026-11-18 09:42 and 2026-11-19 05:12 and after, and `PL.md`.
- **The commits:** read each message with `git log --format=%B fda3b40..e8a7d89`.

PL's scripts are in `scratchpad\pl\`. You may read them. Build your own extractor and mutants; do not reuse its.

## Where things are

- **Your isolated worktree.** Run `git checkout --detach e8a7d89` and confirm it with `git log --oneline -1`.
- **Before you build anything,** do item 2's fresh-tree extraction: the worktree has no `build/` and no `programs/out` yet, and that is the case under test.
- **The pins.** Clone them locally, never from the web, **each in a separate command** (a one-line loop is refused by the worktree guard). Then build:

  ```bash
  git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/rebound third_party/rebound
  git -C third_party/rebound checkout --quiet bdfda4bda4c0a4b6b0c707afae5a86d3341cbc93
  git clone --quiet --no-checkout /c/Users/logan/source/repos/cft-rebound/third_party/cft-fp256 third_party/cft-fp256
  git -C third_party/cft-fp256 checkout --quiet eae74e3eddc67836d4b7c8922badd40e6e1bdb2f
  export PATH="/c/msys64/mingw64/bin:$PATH"
  make OS=Windows_NT TMP="C:/Users/logan/AppData/Local/Temp" TEMP="C:/Users/logan/AppData/Local/Temp" \
       PYTHON="/c/Users/logan/AppData/Local/Programs/Miniconda3/python.exe" all programs
  ```

  The PATH line is not optional: without it, bare `cc` is the 32-bit toolchain and the binaries will not run. No `make -j` in a fresh tree.
- **Booking.** CPU only. Book any run of 10 minutes or more on the desktop first, as `desktop` shared with your pids, and release it when the run ends:

  ```
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py book desktop --mode shared --from now --until <WHEN> --who cft-REBOUND/VL --why "<what>" --pid <pid>
  python C:\Users\logan\source\repos\TimeSheet\timesheet.py release --who cft-REBOUND/VL <id>
  ```

  The lead's full `make check` of another merge may be running on the desktop, so make no timing claims.

## Specific things to attack

1. **Scope.** Does `git diff --stat fda3b40 e8a7d89` touch only the Makefile and tools/check_compare_run.py? No record, problem, schedule, source or other tool may change.
2. **The PROGRAMS key, by extraction.** Extract each leg's `--input` set from `make -n` of check, check-quick and check-light:
   - under fda3b40's Makefile (`git show fda3b40:Makefile` to a copy, then `make -n -f <copy>`) and under the tip's;
   - in the fresh tree, and again after `all programs`.

   Then check each claim:
   - in a fresh tree, fda3b40's Makefile lists no programs/out file on any leg;
   - the tip's lists the same image set on the 11 legs that now list `$(IN_PROGS)`, fresh or built, in every tier;
   - every other leg's set equals fda3b40's.

   Also:
   - Does each `programs/*.cfta` map to exactly the image `make programs` writes?
   - Does `make programs` write any image with no tracked `.cfta`, or create a `.cfta` during the build (tools/gen_programs.py)?
   - Is any image listed twice?
3. **What the old key could actually miss.** Name a sequence of make invocations under which fda3b40's Makefile skips a leg although an image it executes changed, while the tip's runs it. Then run that sequence.
   - If you find none, say so plainly. The fix would then correct stamps keyed short, but no stale skip was possible.
   - The union with programs/out: is listing an image with no source right for every leg that lists `$(IN_PROGS)`, or only for check_gravity? Could a stray image change a leg's verdict without its key showing it, or the reverse?
4. **check_ensemble's key.**
   - Which images do its program-engine cases load (tools/check_ensemble.py:101, 137-150)?
   - Is any of them not embedded in `ias15_cft` (tools/embed_programs.py, `$(B)/normalabs_images.h`)? For those, a changed image leaves `$(IN_PROGRAM)` unchanged.
   - Reproduce the realistic stale skip at 5fa7534, as a separate run under each Makefile. Edit the `.cfta` of one image those cases load, from a copy you restore afterwards. Run `make programs`, then the check-quick check_ensemble line exactly as `make -n check-quick` prints it.
   - 5fa7534's Makefile should skip it and the tip's should run it. If the binary changes with the image, 5fa7534 had no realistic stale skip for this leg; say so. Restore the source, rebuild, and confirm by hash.
   - **Is check_ensemble the last such leg?** Read every tool each leg runs or imports, in all three tiers' lines, for `--programs`, `programs/out` and `--engine program`. For each hit, say whether that leg's line lists `$(IN_PROGS)`. IN_RSEAMS and IN_COMPARE list tools/check_ensemble.py.
4b. **The key audit (`e8a7d89`), done again by you.** Do your own audit, then compare it with PL's, which is in R5-PL-report-3.md with its rules. Do not start from PL's list.
   - For each leg in each tier, find every file it runs, imports (transitively), compiles or reads.
   - Name each file still missing from its key by file:line.
   - Name each input PL added that the leg does not in fact use.
   - Are PL's rules blind to anything, such as a path built at run time, a module loaded through `sys.path`, or a binary named by a variable? Find one, or say you looked and how.
   - Run one cache control of your own on an input PL added, of a kind PL did not control: under cc3d87a's Makefile the leg must skip, and under the tip's it must run.
   - PL's two open finds:
     - check_bodycount and check_gravity reuse the `nbody<N>.txt` problems they wrote earlier in `build/`, so a changed make_nbody.py reruns the leg on old problems. Does that let a stale verdict through in check-quick or check-light? Can it happen in `make check`, which the lead runs after `make clean`?
     - The constants leg reads third_party/rebound's integrator_ias15.c, which its key does not list. Does the pin check (check-pins) cover it?
5. **limit_absent, re-run.** Run `tools/check_compare_run.py --build build` and the same with `--quick` at the tip. Read the lines, not the exit code.
   - Run fda3b40's gate on the same build from a `git archive` copy of fda3b40.
   - Diff the two gates' verdict lines, and account for every added or removed line by name. PL measured 70 to 73 ok in `--quick`, and 108 to 109 in full.
6. **limit_absent, your own mutants.** Build your own copies of compare_run.py and the files beside it. Each mutation script must refuse to run unless its edit lands exactly once. The copies:
   - (a) the limit printed indented with a tab, on the default path;
   - (b) printed after other text on the same line;
   - (c) printed on stderr only, on the default path;
   - (d) printed only on the gate's last run without `--producer-files`;
   - (e) printed only by `--quick`'s case 6;
   - (f) printed twice on a producer run.

   Each must FAIL the tip's gate, `--quick` and full, by name. Say which of them pass fda3b40's gate.
7. **The door and the closing verdict.**
   - Does any run of compare_run.py in the gate start outside `drive()`? PL says control i copies the tree's compare_run.py.
   - The closing verdict requires a `--plan`, a `--rerun-engine`, a binary128/256 and an FMA run. Is that a presence check only? Could a gate that drops most runs from its record still pass it, and does that matter?
   - Can `limit_lines()` match a line that is not the limit, failing a clean run or counting another line as the limit?
   - Case 6 at 4 steps in `--quick`: what does case 6 hold, and does it still hold it at 4 steps? Read its lines.
8. **The cache, end to end.**
   - Run `make check-quick` in your tree cold, then once more warm, and read every leg's lines; every skip prints itself by name.
   - Then change one byte of one image check_ensemble loads, keeping the original to restore, and run check-quick again. Which legs rerun? Every leg that lists the images must rerun, and no other.
   - Restore the image and confirm by hash.
9. **check-gpu, by reading only (no GPU).**
   - Does check-gpu's check_compare_run leg (tools/check_gpu.py) run the gate's `--quick` form or its full one?
   - Case 6 now runs in every tier. Is there anything in its runs that the witness cannot hold byte for byte on hip:0, such as an output file the witness would not see?
   - The lead runs `make HIP=1 check-gpu GPU_LEGS=check_compare_run` on the 5060 Ti at merge time; say what it should look for.
10. **Anything else.** Tell the lead what it did not think to ask.

## Ground rules

- Re-run things; do not trust pasted output.
- **Report only.** Edit no tracked file. Build controls from copies in scratch, and delete them afterwards. Restore every image or source you change, and confirm it by hash.
- **Stay out of other trees.** Do not touch:
  - any other worktree, PL's included;
  - `C:\Users\logan\source\repos\cft-rebound` itself (read it, never write it);
  - `C:\Users\logan\source\repos\cft-rebound-r5`, the lead's, where a full suite may be running;
  - `C:\Users\logan\source\repos\cft-fp256`, another session's, which you may only read.
- No GPU, no WSL, no card, no network. Never bare `git stash`. Never push, merge or rebase.
- Do not run the full `make check`; the lead runs it at the merge.
- "Found nothing" is a fine answer. State precisely what you ran.

## Report

- **For each numbered item:** the commands you ran, what you observed, and a verdict: **confirmed**, **defect** or **not determined**.
  - A defect needs a concrete failure scenario.
  - Distinguish "the shipped change is right" from "the gate would catch it if it weren't".
- **End with** **READY** or **NOT READY**.
- **Length:** under 1,500 words. Your report is your final message.
