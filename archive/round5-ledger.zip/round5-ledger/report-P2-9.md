(R5-P2's report on send-back 7, 3d8ab5b, its final message on 2026-11-20 at ~01:46, copied verbatim by the lead.)

Send-back 7 is done: commit **3d8ab5b** on 9fa5956, tools/check_wave.py only (+6/−2), not pushed or merged. check_wave's default work directory is now `<build>/check_wave/<pid>`, like check_gpu's `<build>/check_gpu/<pid>`, so it can no longer collide with the kernel at build/wave. No other file needed changing. Everything is MEASURED on the desktop unless marked READ.

**Where the old path appeared, and why nothing else changes** (READ)
- It is named in exactly two places, both in check_wave.py: the header note (:127) and the default itself (:1085). Both now give the new path.
- The FAIL message (:1445) and the cleanup (:1447) use the work-directory variable, so they follow automatically.
- No doc, Makefile line or other tool names the old path.
- .gitignore ignores all of build/, and `make clean` is `rm -rf $(B)` (Makefile:1004–1005), so neither needs changing.

**No collision** (READ)
- Everything check_wave writes goes under its work directory (:1158–1431). check_wave never passes --keep to compare_run, so compare_run uses its own temporary directory.
- The `wave` target makes build/wave, wave_corpus_gpu, wave_unchecked, wave_contract and wave_corpus (Makefile:672–699).
- `wave-host` makes wave_host, wave_host_unchecked, wave_host_contract and wave_corpus (:630).
- The only Makefile output named `check_*` is check_dropin. Nothing anywhere is named check_wave.

**The clash, before and after.** I used a scratch copy of build/ with a 53-byte plain file at `wave`, and deleted it afterwards.
- **At 9fa5956:** `--quick` without --keep exits rc 1 within a second at check_wave.py:1088 (`os.makedirs`), before running anything. On Windows the error is `FileNotFoundError: [WinError 3]`; your Linux run reported it as `NotADirectoryError`.
- **At 3d8ab5b:** the same run gives RESULT PASS, 130 ok, 0 FAIL. The plain `wave` file is untouched.

**The tree**

| run | result |
|---|---|
| `--quick`, kept | PASS 130/0 |
| full, kept | PASS 144/0 |
| `--quick` without --keep | PASS 130/0 |

- Both runs without --keep removed their `<pid>` directories, so nothing is left over. The empty build/check_wave/ parent stays, as build/check_compare_run/ does.
- The 14 copies are identical to 9fa5956's in both forms once timings are masked; raw, they differ only on line 218's timings.

**Why the GPU runs never hit this**
- **Mine:** my GPU session script always passed `--keep "$P2WORK/gate…"`, outside build/ (READ, gpu_session.sh:69). The RX 7600 runs went through the same script (box_p2.sh:46, :48).
- **What my logs show:** the 5060 Ti logs (s2, s4) print check_wave's banner, which comes after the makedirs at :1088, and reach PASS on a tree whose build/wave is the kernel file. So the default path was never used (MEASURED).
- **V2's:** V2's GPU run passed `--keep $HOME/cft-rebound-r5-v2/cw_full` (READ, v2/box_full.sh:7).
- **The desktop:** it never builds the `wave` target, so the old default path never met a file there.

**Worth knowing before the re-merge.** My build/wave/ held seven leftover work directories from runs that failed or were killed under the old default. On a HIP=1 tree, such a directory blocks the kernel's own link, the reverse of this clash. I removed mine. Any tree where the old check_wave ever failed may hold one too; `make clean` clears it.

**Housekeeping:**
- B0212 (01:26–01:46) is released; at most four runs ran at a time.
- The ledger entry is in P2.md under 01:46.
- Nothing of mine is running.

Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\sb7:
- clash_before.log
- clash_after.log
- tree\quick.log
- tree\full.log
- tree_nokeep.log
- after.log
- copies_sha7.log
