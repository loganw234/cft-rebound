(R5-P2's report on send-back 2, f3ef701, its final message on 2026-11-19 at ~13:00, copied verbatim by the lead.)

Send-back 2 is done at **f3ef701**, one commit on 8f559c8, touching `tools/check_wave.py` only. All 31 mutants (V2's four and the earlier 27) fail `check_wave` in both forms. The worktree is clean, nothing is running, B0194 is released, and the ledger entry is in the drop at 12:59.

**What changed:**
- **Classes read from the record** (`record_classes()`):
  - from the `# columns:` line: schedule (t dt_next dt_last E t_hi t_lo), massive body x..vz, sampled particle's own x..vz, step field;
  - from the trailer's own keys: the five counters.
- **Plants** (`plants()`): every sample-line class goes into every member on its first and last sampled line, and the counter class into every member.
  - Columns are dealt across members so each is planted at least once.
  - One plant per member per copy, and each member is left out of one copy in turn and must stay IDENTICAL with its particles.
  - That makes 30 plants in 11 copies. The step field is now planted in all three members, on first and last lines.
- **Coverage verdict:** one closing check, computed from the plants actually made against the classes read again from the record. Each gap is named, e.g. "class step not planted in member 2 on its first sampled line".

**Desktop, the tree:** `--quick` RESULT: PASS, 81 ok, 0 FAIL; full RESULT: PASS, 90 ok, 0 FAIL.

**Mutants:** every one is RESULT: FAIL in both forms (ok/FAIL; full-form ok counts are 9 higher). The mutant copies are f3ef701 plus their edits. Each edit must land exactly once or the script refuses: `REFUSED: an edit of compare_run.py lands 2 times, not once`.

| mutant | --quick | full |
|---|---|---|
| (i) step checked in member 0 only | 77/4 | 86/4 |
| (ii) step never checked on sample 1 | 78/3 | 87/3 |
| (iii) `check_wave` never plants member 2 | 70/1 | 79/1 |
| (iv) `check_wave` plants no counter | 74/1 | 83/1 |
| member 0 / 1 lines never compared | 75/6 | 84/6 |
| member 1 never compared at all | 73/8 | 82/8 |
| member 2 never compared at all | 74/7 | 83/7 |
| lines past the third (members; members and particles) | 72/9 | 81/9 |
| no particles replayed | 50/31 | 58/32 |
| particle comparison a no-op | 59/22 | 68/22 |
| columns x, y, z, vx, vy (vz: full 87/3) | 79/2 | 88/2 |
| column t | 80/1 | 88/2 |
| columns dt_next, dt_last, t_hi | 80/1 | 89/1 |
| step field never compared | 75/6 | 84/6 |
| counters: steps_rejected, mean, max, caps | 80/1 | 89/1 |
| counter steps_done | 79/2 | 88/2 |
| physics decision skipped / attempts comparison skipped | 80/1 | 89/1 |
| particle parse skipped | 50/31 | 58/32 |

Mutant (iii)'s single FAIL is the coverage verdict, naming member 2's eight class-and-line gaps and its missing counter.

**V2's note on step and steps_done: I agree, by reading `compare_run.py`.** `hold_structure()` marks a member incomplete when a sample line's step is out of place (:573) or its steps_done differs from the run's (:610). Only members not so marked are rerun (:1049). So a planted step or steps_done never reaches `compare()`'s comparisons (:756, :766) or `particle_compare()`'s step check (:844). Those can fire only when the rerun itself breaks its own layout.

**Run notes:**
- Desktop only, under B0194 (09:04 to 12:59). The desktop was shared, so no timing claims.
- The network outage at 12:38 cut my session, not the runs; every run's log was complete, so nothing was re-run.

**Left undone:** V2's narrow third look.
