(R5-P2's report on send-back 6, 9fa5956, its final message on 2026-11-19 at ~23:30, copied verbatim by the lead.)

Send-back 6 is done: commit **9fa5956** on 2d062cd, tools/check_wave.py only (+84/−1), not pushed or merged. check_wave now holds compare_run's printed counts, and both of V2's mutants fail by name in both forms. Everything is MEASURED on the desktop unless marked READ.

**A correction first.** I was wrong in send-back 5 that a totals sum stopping one short passes. V2 measured it failing 103/1 and 112/1 on record B, whose three members each reject a step. My sweep looked at the plants and missed what record B's clean comparison already holds. The ledger entry records the correction.

**The rule** (READ, from the diff)
- check_wave's compare() now holds the counts on every compare_run run of the gate: the clean records, the two controls, P, the 14 copies and E's plants.
- check_wave reads the record itself, of either kind. It counts each member's sample lines and `# body` lines. From the `# columns:` line and the `# active` count it computes the widths: 390 per member line and 54 per particle line for the ring, 18 for kepler, 24 for zonal_saturn.
- Each IDENTICAL member and particle line must say "N samples, M values", with N the record's sample lines for that member and M equal to N times the width. A line without counts, or with wrong ones, FAILs by name.
- No expected count is taken from compare_run's output.

**Runs** (B0207, 22:58–23:30, released; at most four at a time)

| run | `--quick` ok/FAIL | full ok/FAIL | what FAILs |
|---|---|---|---|
| tree | PASS 130/0 | PASS 144/0 | — (104 + 26 and 113 + 31 count verdicts) |
| check_wave's member width one short | FAIL 118/12 | — | every record with an IDENTICAL member line, e.g. "4 samples, 1560 values, where … at 389 values a line make 1556" |
| compare_run skipping the middle line | FAIL 116/14 | FAIL 126/18 | every record, plus copies 5, 6, 9–11 (full adds P): "1170 values" against 1560, "162" against 216 |
| compare_run stopping after four lines | FAIL 128/2 | FAIL 134/10 | every record longer than four lines: "5 samples, 1560 values" against 1950 |

Every mutant FAIL is a count verdict; nothing else moved. Each edit lands exactly once or the script refuses; I showed refusals at 2 landings and at 0.

**Records longer than four lines:** `--quick` does have two, C (13 lines a member) and D1 (5). So the four-line mutant is held in `--quick` too. In full, A, B, E, F, D1, D4 and D5 have 5 lines and C has 31. P, the copies, D2 and D3 have 4 in both forms.

**The 14 copies:** with timings masked, all 14 have 2d062cd's sha256 in both forms; raw, they differ only on line 218's timings. The rule can only add FAILs, so the earlier mutants were not rerun.

**Housekeeping:**
- The ledger entry is in P2.md under 23:30.
- Nothing of mine is running.

Logs are in C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\p2r5\sb6:
- run6.log
- copies_sha6.log
- mutants6.py
- tree\, mut\ (one log per run)
