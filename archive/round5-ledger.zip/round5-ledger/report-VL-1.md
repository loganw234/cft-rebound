(R5-VL's report on round5-pl at e8a7d89, its final message on 2026-11-19 at ~13:15, copied verbatim by the lead.)

**VL on round5-pl at e8a7d89: READY, with one defect to fix (item 4b).** The four commits do what they claim; the defect is older than them, PL disclosed it, and the fix is one line.

Setup: worktree detached at e8a7d89 and checked with `git log --oneline -1`; the pins were cloned locally at bdfda4b and eae74e3e. Each compare_run gate ran in its own `git archive` tree in scratch, with sha256-checked copies of the 66 images and both binaries. B0195 ran 09:22–13:14 and is released; none of my processes are left; no timing claims. Ledger: `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\ledger-drop-r5\VL.md`. Scripts and logs: `C:\Users\logan\AppData\Local\Temp\claude\443d8e8619fd4f31\fa64df2f-560a-4117-8348-b3ce1b89172a\scratchpad\vl\`.

**1. Scope — confirmed (MEASURED).** `git diff --name-status fda3b40 e8a7d89` shows M Makefile and M tools/check_compare_run.py, and nothing else.

**2. PROGRAMS key — confirmed (MEASURED).** Command: `make -n -f <git show copy>` of all three tiers under the fda3b40, 3012353, cc3d87a and e8a7d89 Makefiles, read by my own extractor. I ran it in the fresh tree before any build (rc 0, 25 legs, no build/ or programs/out created) and again after `all programs`.
- Fresh tree, fda3b40: no programs/out file on any leg.
- Tip: one set of 66 images (programs/*.cfta mapped to .cftp) on 11 legs, every tier. Fresh and built trees give identical sets on all 25 legs.
- Every other leg's set equals fda3b40's, apart from e8a7d89's own additions.
- `make programs` writes exactly those 66 images. gen_programs.py rewrites the 66 tracked .cfta identically and creates none (`git status` clean).
- No input is listed twice on any leg, in any of the 30 extractions.

**3. What the old key could miss — confirmed, narrow (MEASURED).**
- The sequence: a tree with no programs/out when make reads the Makefile (a fresh clone, or `rm -rf programs/out`), then `make check-quick`. Then change a non-gravity program in tools/gen_programs.py, `rm -rf programs/out`, and `make check-quick` again.
- I ran it on check_program_engine. Under fda3b40 the key had 10 inputs both times and the line was byte-identical: SKIPPED (1355ddaa4c43), although predict-fp64.cftp had moved (the binary had not). The tip's line has 76 inputs: it ran and FAILed.
- If programs/out exists at the second parse, fda3b40 lists the images and reruns. So the old key could skip stale only when programs/out was absent at both parses.
- The union with programs/out matters only to check_gravity, whose verdict reads that directory's listing (check_gravity.py:175-187). check_ring lists it only for a printed count. For the other legs a stray image just causes a harmless rerun.
- A stray image is listed by both Makefiles (67, measured with `make --eval`). It cannot change a verdict without the key showing it, because `programs` only writes images of .cfta present at parse.

**4. check_ensemble — confirmed. The brief's recipe cannot work as written.**
- Its program-engine cases load predict, correct1-7 and nextstep, plus predict-ens in the adaptive ensembles (ias15_cft.c:1964-1970, 4676). None of these is embedded in ias15_cft; only the 36 gravity-* and the pin's 3 normalabs are.
- Editing a .cfta and running `make programs` changes nothing (MEASURED): gen_programs.py rewrote the file and the image did not move. Every tier runs `programs`, so an image only changes through gen_programs.py or the assembler.
- So I changed predict_ens in gen_programs.py. 5fa7534's check-quick line SKIPPED (86c8ea449826). The tip's line, starting from its own stamp, ran and FAILed the two adaptive program-engine cases.
- Restored: all 195 baseline hashes match, and the tip's line PASSes with the same key.
- check_ensemble is the last such leg. Only the 11 legs' scripts and compare_run.py pass `--engine program`, `--programs` or programs/out, and all 11 legs list `$(IN_PROGS)`. check_records reruns only engine=loop records. The trace (item 4b) shows no program-engine run in any other leg.

**4b. My key audit — defect (constants leg).**
- Method: I traced the cold check-quick (item 8) with an audit hook that logs every file open, process start, directory listing and import, and changes nothing else. vl_audit.py groups each leg's processes and takes the C programs' file reads from their arguments. I read the full-tier-only branches by hand; they differ only in formats and step counts.
- Missing from a key: **`third_party/rebound/src/integrator_ias15.c` in the constants leg** (gen_constants.py:414-416). Nothing else is missing, and every input e8a7d89 added is imported, run or read.
- PL's audit rules cannot see two things. Its rule 4 treats third_party/ as never needed. And it cannot see files whose presence, not their bytes, steers a leg: problems cached in build/ (check_bodycount.py:65, check_gravity.py:199, 202, 458).
- My own cache control, of a kind PL did not run: a crash in make_ensemble.py's `--vscale` branch, which only check_ensemble uses. cc3d87a's line SKIPPED; the tip's ran and FAILed (IndexError).
- Constants leg (MEASURED): I changed one digit of h[1] in the rebound clone.
  - check-pins still said ok, rc 0: it checks HEAD, not a dirty tree.
  - The constants line SKIPPED, while gen_constants.py run directly FAILed.
  - MANIFEST is not in that key either, so a rebound pin move would also leave the old stamp.
  - **Fix:** add `--input third_party/rebound/src/integrator_ias15.c` to the constants line in all three tiers.
- Cached problems (MEASURED): with make_nbody.py broken, check-quick reran check_bodycount on the old build/problems and PASSed under the new key. It then SKIPPED even after build/problems was deleted, because nothing in the key moved. make check's line FAILs without build/problems and PASSes with them. Your merge script runs `make clean` first, so your make check would catch it; check-quick and check-light never will.

**5. limit_absent re-run — confirmed (MEASURED).**
- Tip: `--quick` PASS, 73 ok (also in the worktree with `--build build`, through check-quick). Full: PASS, 109 ok. The closing verdict counts 46 and 48 runs.
- fda3b40's gate on the same bytes: 70 and 108.
- Diff of the verdict lines (vl_vdiff.py): `--quick` adds case 6's two verdicts and the closing verdict. Full changes case 6's two verdicts by "(20 steps)" and adds the closing verdict. Every other line is identical.

**6. My mutants — confirmed.** Each mutant replaces tools/compare_run.py in its own tree copy, so control i's copies run it too. vl_mutate.py refuses unless its edit lands exactly once (it refused "lands 0 times" and "lands 9 times"). A smoke test showed each mutant prints only where intended.

| mutant | tip `--quick` | tip full | fda3b40 `--quick` |
|---|---|---|---|
| (a) indented with a tab, default path | FAIL 69 ok / 4 FAIL: case 1, case 5 ×2, closing | FAIL 103/6 | PASS 70 |
| (b) after other text on the line | FAIL 69/4 | FAIL 103/6 | PASS 70 |
| (c) stderr only | FAIL 69/4 | FAIL 103/6 | PASS 70 |
| (d) the gate's last run only (control i) | FAIL 72/1: closing names `…p3_present/tools/compare_run.py` | FAIL 108/1 | PASS 70 |
| (e) `--quick`'s case 6 only | FAIL 72/1: closing names both case 6 runs | not run (see below) | PASS 70 |
| (f) twice on a producer run | FAIL 61/12 | FAIL 89/20 | FAIL 58/12 |

I stopped (e)'s full run: the full tier's case 6 is 20 steps, so (e) never prints there and the run would be the clean full run. So (a)–(e) pass fda3b40's gate and only (f) fails it.

**7. The door and the closing verdict.**
- Only drive() starts the driver (check_compare_run.py:1273); the trace agrees. Control i copies the tree's own compare_run.py (:1958-1960), so a `--driver` mutant never reaches its 3 runs. That is why my tree copies counted "printed by 40" where PL's `--driver` runs counted 37.
- The closing verdict is a presence check only: at least one run of each of four kinds (:2002). The counts are printed, not asserted, so a drive() that kept one run of each kind would still pass. This matters little while drive() is the only door, but nothing pins the 46 and 48.
- limit_lines() cannot match a line that is not the limit: in the driver and its siblings only PRODUCER_LIMIT carries the opening words (READ), and no clean run printed one (MEASURED).
- Case 6 at 4 steps still holds its claim, on fewer lines. Members 0 and 1 reject their first attempt and member 8 rejects nothing; 5 sampled members are IDENTICAL on both engines. At 20 steps member 8 rejects 3 times after accepted steps. So `--quick` no longer covers a rejection that follows an accepted step on the program engine.

**8. The cache, end to end — confirmed (MEASURED).**
- Cold (after `make clean`, traced): rc 0, all 25 legs ran and passed.
- Warm: all 25 printed "SKIPPED - inputs unchanged", each by name.
- One byte of predict-ens-fp64.cftp changed, then check-quick: all 25 SKIPPED. `programs` had reassembled the image before any leg ran, so this step of the brief cannot reach a leg.
- Instead, I moved register s from r4 to r5 in predict_ens, which changes three images' bytes and no results. Exactly the 11 legs that list `$(IN_PROGS)` ran (all PASS); the other 14 skipped by name.
- Restored: programs/out equals the cold run's, all 189 non-build hashes match, and `git status` is empty.

**9. check-gpu, by reading.**
- check_gpu.py takes the leg's command from check-quick's recipe (:1189-1200), so it runs the `--quick` form, case 6 included.
- The witness holds stdout and the three output flags it knows (:189). Those are every file ias15_cft opens for writing (ias15_cft.c:4458, 4671, 4674), so no output goes unseen.
- Case 6's quick record is byte for byte the same command as case 7's quick program-engine record; the trace shows it twice. What is new on the device is the driver rerunning members on the program engine.
- At the merge, check four things:
  - the leg line reads `rc 0, RESULT: PASS, 73 ok, 0 FAIL`;
  - the leg's log has case 6's "4 steps" header with its two ok lines;
  - the closing verdict reads "46 runs (10 with --plan, 1 with --rerun-engine, 2 at binary128 or binary256, 3 in the FMA form, 3 through a copy of the driver)";
  - the witness line reads "N of N process(es) on the device … K of K record(s) identical", with N above fda3b40's count.

**10. Things you did not ask about.**
- A gap in the per-run limit check (my extra mutant (g)): a second copy of the limit printed on stderr during a producer run, followed by 700 characters of stderr, PASSes both gates (tip 73, fda3b40 70). drive() passes the per-run checks only the last 600 characters of stderr, and the closing verdict skips producer runs. Minor.
- PL's cache controls edited images after `make programs` and then ran leg lines directly. They are valid at the cache level, but no make sequence produces that state (item 8).
- Binaries rebuilt after `make clean` differ in bytes from an earlier build of the same sources, so a clean rebuild changes every key that names a binary. Harmless.
- With PROGRAMS fixed, your merge script no longer needs its separate `all programs` step for the keys.

**READY.**
