(R5-D's report on records phase 2, b1cd3ed and 83f2188 on round5-docs, its final message on 2026-11-20 at ~05:28, copied verbatim by the lead.)

Phase 2 is committed on `round5-docs` as `b1cd3ed`, plus `83f2188`, a one-line citation fix, both on `a2c84fb`. It changes documents only, and nothing is pushed or merged. A read-only `git merge-tree --write-tree main round5-docs` gives rc 0: the branch merges cleanly into `61e45bc`. No LEAD-FILL line is left. The pin row passes both check_pins README tests, which I ran by hand. My ledger entry is in the drop as `D.md`.

```
 CLAUDE.md          |  17 +-
 README.md          |  45 ++-
 ROADMAP.md         |  53 +++-
 ROUND5.md          | 105 ++++++-
 docs/RING.md       | 104 ++++++-
 docs/VALIDATION.md | 790 ++++++++++++++++++++++++++++++++++++++++++++++++++++-
 6 files changed, 1082 insertions(+), 32 deletions(-)
```

**What was written**
- **Entry 56 (P2):**
  - what the kernel is, and check_wave's six parts with their controls;
  - what gate 4 found;
  - both GPUs and the comparison across them;
  - P2's rate rows, labelled MEASURED, one run a row;
  - V2's six looks and all seven send-backs, each with its measured mutants;
  - P2's own suites, and the merge message's nine open notes.
- **Entry 58 (the integration):**
  - PL's five commits and VL's looks;
  - `620c98b`'s GPU check and make check;
  - `7444157` and its two failures, the response, and the redo as `61e45bc`;
  - the tier conflict and how it was resolved;
  - `61e45bc`'s GPU check and make check;
  - the outage.
- **Phase-1 carry-overs:**
  - both check_dropin times go in entry 55 and ROUND5.md;
  - costs.py's stale header is an open note in entry 55;
  - P0's "To do" is now "Done", from its suite log;
  - entry 50 now reads "every hip:0 record measured".
- **ROUND5.md:** the status line, and the closing "What the round found against this plan", each item cited by entry.
- **RING.md:** the wave kernel's section, check-gpu's second line, a check_wave row, and entries 56 and 58 in the record list.
- **README:** src/wave/ and check_wave.py in the layout, check-gpu's second line, and a wave-kernel section quoting the usage text from the program and the gate.
- **CLAUDE.md:**
  - the make check row;
  - "26 since check_wave";
  - your proposed line under "Ways this suite has lied". I agree it cost hours: about 70 minutes from the failed check at 00:59 to the redo's launch at 02:11, plus a stopped make check.
- **ROADMAP:** round 5's section; round 4's list items 2 to 5 marked with what round 5 did; the pin move waiting on Logan.

**Numbers, by source**
- **From the logs, counted myself** (with legcount.py):
  - **`int-check-620c98b.log`:** 13:38:35–16:55:59, 25 legs, 1,505 `  ok ` lines, 17 RESULT lines, all PASS; check_compare_run went from 108 to 109.
  - **`int-check-61e45bc.log`:** 02:11:37–05:03:15, 26 legs, 1,649 `  ok ` lines, 18 RESULT lines, all PASS; check_wave 144 ok. Both suites ran from clean, with 5 compiler warnings each.
  - **`int-check-7444157.log`:** stopped in its sixth leg, check_door.
  - **The 61e45bc log also gives:** 152,735 augmentedAddition cases with 7,259 ties, and A at 5 lines of 390 and of 54.
  - **main's Makefile:** 26 `--leg` lines in each tier, and check-gpu's `--hip` line at :988.
- **The GPU-check folders:**
  - **plgpu-620c98b:** 152m46s; 73 ok; 1606 of 1606 processes; 665 records, 22,347 steps, 435 rejected, 3.61 passes an attempt.
  - **p2seam-7444157:** rc 2; check_records 15m19s; the traceback naming `/1549` at check_wave.py:1088; the seam script 15 ok and 8 FAIL.
  - **p2seam-61e45bc:** check_records 4 ok in 15m21s; check_wave 147 ok; 228,352 cases, digest `ca7246a62d9533f6`; the seam 24 ok; 4 lines of 394 values, 12 steps, 1 rejected, 3.769 mean passes.
- **P2's reports 1–9 and P2.md** (11:00, 11:15, 14:59, 16:13, 17:53, 06:33, 06:59, 09:28, 12:45):
  - every send-back's ok/FAIL counts;
  - the rate table, with GPU-E2's estimates converted by P2 to 245 and 756 system-steps a second, and the rung times;
  - the kernel frames;
  - MinGW's 20,461 and 14 mismatches; the 1 km bound and the 1.7622 km move;
  - 3 mismatches from nvcc's sign flip;
  - 1,596 test-test pairs;
  - suite times for `82b75b8` and `7dec985`.
- **V2's reports 1–6 and V2.md** (13:08, 13:26): every look's mutant counts; gate 4's plant counts; the contraction counts; 0 of 278,535 lines differing across GPUs; 18,013 of 199,714 fma triples; the re-run of one rate row.
- **PL's reports 1–4 and VL's 1–4:** the 10 and 76 inputs; 73/109 against 70/108; the six missing inputs; the h[1] literal; the seam script's 16/0 and 24/0, and VL's nine and three cases.
- **The lead's ledger and git:**
  - **the 11-19 entries:** the merge kit (13:24, 13:32, 13:34), the outage (12:58), the 46 and 48 runs, and the 122 hex lines;
  - **the 11-20 entries:** the first merge, its failures and the fixes (01:00, 01:28), and the redo (02:12);
  - **pin candidates** 9e8ff270, 340cd287 and c3c39c87 (11-18 09:28 and 12:15, 11-19 10:07);
  - **from git:** P2's 9 commits plus 7 send-backs, and fda3b40..620c98b at +120/−41.
- **Elsewhere:** P0's suite from `r5-check-d7b5047.log`; 62 and 66 min from P1.md 16:37 and V1.md 12:10; the costs.py header at lines 18–19 of that file.

**Waiting on Logan**
- **The pin's move** off `eae74e3` to 9e8ff270, or to 340cd287 or c3c39c87, which are docs-only past it. Logan's word was to finish round 5 first; the move is its own step after the close.
- **cft-fp256's open choices,** READ from its lead and noted in ROADMAP item 3: which device-callable divide shape to build, and whether to route the divide by size. Both are with Logan on cft-fp256's side.

**For you and VD**
- **Two citations updated to main.** README's Makefile line is now cited as :988, main's line, where `fda3b40` had :837. Entry 57's GATE 1b test is cited as check_compare_run.py:836 at `4a8fe99`, and :863 since PL.
- **Where the merge and suite live.** Entry 56 leaves P2's merge and suite to entry 58, as round 4's entries 50 and 51 did. Entries 55 and 57 from phase 1 carry their own.
- **P2's rate table is in entry 56,** under the same ruling as P1's cost table. Cut it if you read the rule otherwise.
- **The lapses are not recorded:**
  - the waiter processes left running after it was stopped;
  - V2's idle `tail -f` processes;
  - P2's cuobjdump inside V1's booking;
  - V2's unbooked 20-second run.
- **Not changed in CLAUDE.md.** The planted-control bullet still counts only round 4's send-backs. Round 5 repeated that shape three times for P1's seam and six for check_wave.
- **One count differs from your ledger.** You logged 7444157's stopped make check as "past the build and four legs". I counted its sixth `--leg` line, check_door, because constants counts as a leg.
- **Read from code, not the log.** In `61e45bc`'s GPU check, the work directory `build/check_wave/<pid>` follows from the code. The log shows only that the command had no `--keep`.

I'll wait for VD's look.
